package co.com.ath.persistence.dao;

import java.util.List;

import javax.sql.DataSource;

import co.com.ath.persistence.dto.ParameterDTO;

/**
 * Interface DAO para la tabla de parametros
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public interface ParameterDAO {
	/** 
	 * This is the method to be used to initialize
	 * database resources ie. connection.
	 */
	public void setDataSource(DataSource ds);

	/** 
	 * This is the method to be used to create
	 * a record in the Roles table.
	 */
	public void create(String clave, String valor, String estado, String descripcion);

	/** 
	 * This is the method to be used to list down
	 * a record from the Roles table corresponding
	 * to a passed Roles id.
	 */
	public ParameterDTO getParameter(String clave);

	/** 
	 * This is the method to be used to list down
	 * all the records from the Roles table.
	 */
	public List<ParameterDTO> listParameters();

	/** 
	 * This is the method to be used to delete
	 * a record from the Roles table corresponding
	 * to a passed Roles id.
	 */
	public void delete(String clave);

	/** 
	 * This is the method to be used to update
	 * a record into the Roles table.
	 */
	public void update(String clave, String valor, String estado, String descripcion);
}
