package co.com.ath.client.authorize.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)

public class BodyAutorization {
	
	@XmlElement(name = "autorizar", namespace = "http://soi.avvillas.com/ManejoIdentidad/WSBA_ManejoIdentidad_autorizar")
	private Autorizar autorizar;
	
	public BodyAutorization() {
		this.autorizar = new Autorizar();
	}
	
	public Autorizar getAutorizar() {
		return this.autorizar;
	}
}
