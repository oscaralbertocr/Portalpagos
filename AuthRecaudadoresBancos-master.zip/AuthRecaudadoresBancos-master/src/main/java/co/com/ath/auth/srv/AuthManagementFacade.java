package co.com.ath.auth.srv;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import co.com.ath.auth.controller.impl.AuthenticateControlServiceImpl;
import co.com.ath.auth.dto.CustomException;
import co.com.ath.auth.dto.GenericErrorResponse;
import co.com.ath.auth.dto.RequestAuthenticateService;
import co.com.ath.auth.dto.ResponseAuthenticateService;
import co.com.ath.auth.mapper.MapperResponseAuthService;

/**
 * Entrada del servicio Rest, Exposicion del EndPoint.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */

@RestController
@RequestMapping(value ="/authManager")
public class AuthManagementFacade {
	
	@Autowired
	AuthenticateControlServiceImpl authenticateControlServiceImpl; 
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthManagementFacade.class);
	
	@RequestMapping(value = "/authenticate" , method = RequestMethod.POST)
	public ResponseEntity<?> initAuthentication(
			@RequestBody RequestAuthenticateService requestAuthService) {
		ResponseEntity<Object> response;
		GenericErrorResponse genericErrorResponse;
		try {			
			ResponseAuthenticateService rs = authenticateControlServiceImpl.authenticate(requestAuthService);
			HttpHeaders headers = new HttpHeaders();
			headers.add("X-RqUID", "X-RqUID");
			LOGGER.info("Finalizada autenticaci�n");
			return new ResponseEntity<ResponseAuthenticateService>(rs, headers, HttpStatus.CREATED);
		} catch(CustomException e) {
			genericErrorResponse = MapperResponseAuthService.mapperResponseErrorCore(e);
			response = new MapperResponseAuthService().responseAuthService(HttpStatus.PARTIAL_CONTENT, genericErrorResponse);
			LOGGER.error("@initTransfer error output" + "\n" + genericErrorResponse);
		} catch (Exception e) {
			genericErrorResponse = MapperResponseAuthService.mapperResponseErrorCore(e);
			response = new MapperResponseAuthService().responseAuthService(HttpStatus.INTERNAL_SERVER_ERROR, genericErrorResponse);
			LOGGER.error("@initTransfer error output" + "\n" + genericErrorResponse);
		}
		return response;
	}
	
	@RequestMapping(value = "/authenticate", method = RequestMethod.OPTIONS)
    public ResponseEntity handle() {
        return new ResponseEntity(HttpStatus.NO_CONTENT);
    }
}