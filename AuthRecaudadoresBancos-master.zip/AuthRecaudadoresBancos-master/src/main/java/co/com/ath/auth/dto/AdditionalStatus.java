
package co.com.ath.auth.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.auth.util.XMLUtil;

/**
 * DTO para el AdditionalStatus.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class AdditionalStatus implements Serializable {

	@JsonProperty("StatusCode")
	private String statusCode;
	@JsonProperty("StatusDesc")
	private String statusDesc;
	@JsonProperty("Severity")
	private String severity;
	private static final long serialVersionUID = -8949993428231959780L;

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	
	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}
	
	@Override
	public String toString() {
		XMLUtil<AdditionalStatus> util = new XMLUtil<AdditionalStatus>();
		return util.convertObjectToJson(this);
	}

}
