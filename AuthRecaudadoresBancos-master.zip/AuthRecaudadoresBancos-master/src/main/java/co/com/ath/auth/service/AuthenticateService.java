package co.com.ath.auth.service;

import co.com.ath.auth.dto.CustomException;
import co.com.ath.auth.dto.RequestAuthenticateService;
import co.com.ath.auth.dto.ResponseAuthenticateService;

/**
 * Interface para el servicio de autenticacion.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public interface AuthenticateService {
	
	/**
	 * Authenticate Control
	 */
	public ResponseAuthenticateService authenticate(RequestAuthenticateService rq) throws CustomException;

}
