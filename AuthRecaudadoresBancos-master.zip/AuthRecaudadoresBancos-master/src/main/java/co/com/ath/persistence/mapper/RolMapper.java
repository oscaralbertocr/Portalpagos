package co.com.ath.persistence.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import co.com.ath.persistence.dto.RolDTO;

/**
 * Mapper para los registros de la tabla de roles
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class RolMapper implements RowMapper<RolDTO> {

	public RolDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		RolDTO rol = new RolDTO();
		rol.setId(rs.getInt("ID"));
		rol.setName(rs.getString("NOMBRE"));
		return rol;
	}
}
