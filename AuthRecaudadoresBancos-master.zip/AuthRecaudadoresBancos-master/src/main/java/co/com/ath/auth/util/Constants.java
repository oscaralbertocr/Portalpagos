package co.com.ath.auth.util;

/**
 * Constantes requeridas para la respuesta del servicio.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public interface Constants {

	public static final String TIMEZONE = "America/Bogota";
	
	public static final Integer ERROR_STATUS_CODE_300 = 300;
	
	public static final String ERROR_STATUS_CODE_DESC = "No es posible procesar la transacci�n.";

	public static final String HEADER1 = "RqUID";

	public static final String HEADER2 = "Channel";
	
}
