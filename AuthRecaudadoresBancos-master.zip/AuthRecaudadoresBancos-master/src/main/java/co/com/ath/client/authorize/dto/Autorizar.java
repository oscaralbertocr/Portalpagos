
package co.com.ath.client.authorize.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="oe_entrada" type="{http://soi.avvillas.com/ManejoIdentidad/WSBA_ManejoIdentidad_autorizar}oe_Autorizacion"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 *
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "oeEntrada"
})
@XmlRootElement(name = "autorizar")
public class Autorizar {

    @XmlElement(name = "oe_entrada", required = true, nillable = true)
    protected OeAutorizacion oeEntrada;

    /**
     * Obtiene el valor de la propiedad oeEntrada.
     * 
     * @return
     *     possible object is
     *     {@link OeAutorizacion }
     *     
     */
    public OeAutorizacion getOeEntrada() {
        return oeEntrada;
    }

    /**
     * Define el valor de la propiedad oeEntrada.
     * 
     * @param value
     *     allowed object is
     *     {@link OeAutorizacion }
     *     
     */
    public void setOeEntrada(OeAutorizacion value) {
        this.oeEntrada = value;
    }

}
