package co.com.ath.client.authenticate.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
		"header",
		"body"
})
@XmlRootElement(name = "Envelope", namespace = "http://schemas.xmlsoap.org/soap/envelope/")
public class SoapEnvelopeAutentication {
	
	@XmlElement(name = "Header", namespace = "http://schemas.xmlsoap.org/soap/envelope/")
	private String header;
	
	@XmlElement(name = "Body", required = true, nillable = true, namespace = "http://schemas.xmlsoap.org/soap/envelope/")
	private BodyAutentication body;
	
	
	public SoapEnvelopeAutentication() {
		this.body = new BodyAutentication();
	}
	public BodyAutentication getBody() {
		return this.body;
	}
}