
package co.com.ath.auth.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.auth.util.Constants;

/**
 * DTO para el Status.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class Status implements Serializable
{
	@JsonProperty("StatusCode")
    private String statusCode;
	@JsonProperty("StatusDesc")
    private String statusDesc;
	@JsonProperty("Severity")
    private String severity;
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone = Constants.TIMEZONE)
	@JsonProperty("EndDt")
    private Date endDt;
	@JsonProperty("AdditionalStatus")
    private AdditionalStatus additionalStatus;
    private final static long serialVersionUID = -5664576071857602659L;

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }
    
    public String getStatusDesc() {
        return statusDesc;
    }

    public void setStatusDesc(String statusDesc) {
        this.statusDesc = statusDesc;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public Date getEndDt() {
        return endDt;
    }

    public void setEndDt(Date endDt) {
        this.endDt = endDt;
    }

	public AdditionalStatus getAdditionalStatus() {
		return additionalStatus;
	}

	public void setAdditionalStatus(AdditionalStatus additionalStatus) {
		this.additionalStatus = additionalStatus;
	}

}
