package co.com.ath.auth.util;

import java.nio.charset.StandardCharsets;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

/**
 * Utilidad para manejo de algortimos de cifrado y descifrado .
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */

@SuppressWarnings("static-access")
public class CipherUtil {
	private final String algoritm = "AES";
	private final String algoritmDP = "DES";
	private final String method = "AES/CBC/ISO10126Padding";

	private Base64 control = new Base64();

	public String encrypt(String key, String iv, String cleartext) throws Exception {
		Cipher cipher = Cipher.getInstance(method);
		SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes(), algoritm);
		IvParameterSpec ivParameterSpec = new IvParameterSpec(iv.getBytes());
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec, ivParameterSpec);
		byte[] encrypted = cipher.doFinal(cleartext.getBytes());
		return new String(control.encodeBase64(encrypted));
	}

	public String encryptDES(String key, String cleartext) throws Exception {
		Cipher cipher = Cipher.getInstance(algoritmDP);
		SecretKeyFactory skf = SecretKeyFactory.getInstance(algoritmDP);
		DESKeySpec kspec = new DESKeySpec(key.getBytes());
		SecretKey ks = skf.generateSecret(kspec);
		cipher.init(Cipher.ENCRYPT_MODE, ks);
		byte[] encrypted = cipher.doFinal(cleartext.getBytes());
		return new String(control.encodeBase64(encrypted));
	}

	public String decrypt(String key, String iv, String encrypted) throws Exception {
		Cipher cipher = Cipher.getInstance(method);
		SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes(), algoritm);
		IvParameterSpec ivParameterSpec = new IvParameterSpec(iv.getBytes());
		byte[] enc = control.decodeBase64(encrypted);
		cipher.init(Cipher.DECRYPT_MODE, skeySpec, ivParameterSpec);
		byte[] decrypted = cipher.doFinal(enc);
		return new String(decrypted, StandardCharsets.UTF_8);
	}
	
	public String decryptDES(String key, String encrypted) throws Exception {
		Cipher cipher = Cipher.getInstance(algoritmDP);
		SecretKeyFactory skf = SecretKeyFactory.getInstance(algoritmDP);
		DESKeySpec kspec = new DESKeySpec(key.getBytes());
		SecretKey ks = skf.generateSecret(kspec);
		cipher.init(Cipher.DECRYPT_MODE, ks);
		byte[] decrypted = cipher.doFinal(control.decodeBase64(encrypted));
		return new String(decrypted, StandardCharsets.UTF_8);
	}

}
