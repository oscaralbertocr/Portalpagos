
package co.com.ath.auth.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.auth.util.XMLUtil;

/**
 * DTO para el GenericErrorResponse.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class GenericErrorResponse implements Serializable {

	@JsonProperty("MsgRsHdr")
	private MsgRsHdr msgRsHdr;
	private static final long serialVersionUID = 6294218922180477354L;

	public MsgRsHdr getMsgRsHdr() {
		return msgRsHdr;
	}

	public void setMsgRsHdr(MsgRsHdr msgRsHdr) {
		this.msgRsHdr = msgRsHdr;
	}

	@Override
	public String toString() {
		XMLUtil<GenericErrorResponse> util = new XMLUtil<GenericErrorResponse>();
		return util.convertObjectToJson(this);
	}

}
