
package co.com.ath.client.authenticate.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para anonymous complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="os_salida" type="{http://soi.avvillas.com/ManejoIdentidad/WSBA_ManejoIdentidad_autenticar}os_AutenticacionResp"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "osSalida"
})
@XmlRootElement(name = "autenticarResponse")
public class AutenticarResponse {

    @XmlElement(name = "os_salida", required = true, nillable = true)
    protected OsAutenticacionResp osSalida;

    /**
     * Obtiene el valor de la propiedad osSalida.
     * 
     * @return
     *     possible object is
     *     {@link OsAutenticacionResp }
     *     
     */
    public OsAutenticacionResp getOsSalida() {
        return osSalida;
    }

    /**
     * Define el valor de la propiedad osSalida.
     * 
     * @param value
     *     allowed object is
     *     {@link OsAutenticacionResp }
     *     
     */
    public void setOsSalida(OsAutenticacionResp value) {
        this.osSalida = value;
    }

}
