package co.com.ath.client.authenticate.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)

public class BodyAutentication {
	
	@XmlElement(name = "autenticar", namespace = "http://soi.avvillas.com/ManejoIdentidad/WSBA_ManejoIdentidad_autenticar")
	private Autenticar autenticar;
	
	public BodyAutentication() {
		this.autenticar = new Autenticar();
	}
	
	public Autenticar getAutenticar() {
		return this.autenticar;
	}
}
