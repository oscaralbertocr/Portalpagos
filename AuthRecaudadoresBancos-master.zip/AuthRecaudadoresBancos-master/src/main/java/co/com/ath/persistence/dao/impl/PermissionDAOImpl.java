package co.com.ath.persistence.dao.impl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import co.com.ath.persistence.dao.PermissionDAO;
import co.com.ath.persistence.dto.PermissionDTO;
import co.com.ath.persistence.mapper.PermissionMapper;

/**
 * Implementacion de la Interface DAO para la tabla de permisos
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class PermissionDAOImpl implements PermissionDAO{

	@Autowired
	private DataSource dataSource;

	private JdbcTemplate jdbcTemplateObject;

	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	public void create(String permission) {
		
	}

	public PermissionDTO getPermission(Integer id) {
		String SQL = "SELECT * FROM PERMISOS WHERE ID = ?";
		PermissionDTO permission = jdbcTemplateObject.queryForObject(SQL, 
				new Object[]{id}, new PermissionMapper());

		return permission;
	}

	public List<PermissionDTO> listPermissions() {
		String SQL = "SELECT * FROM PERMISOS";
		List <PermissionDTO> permissions = jdbcTemplateObject.query(SQL, new PermissionMapper());
		return permissions;
	}

	public List<PermissionDTO> getPermissionsByRol(String nameRol) {
		String SQL = "SELECT PERMISOS.* "
				+ "FROM ROL INNER JOIN (ROLES_PERMISOS INNER JOIN PERMISOS ON ROLES_PERMISOS.ID_PERMISO = PERMISOS.ID) "
				+ "ON ROL.ID=ROLES_PERMISOS.ID_ROL WHERE ROL.NOMBRE = ? ORDER BY PERMISOS.ID";
		System.out.println(SQL.replace("?", nameRol));
		List <PermissionDTO> permissions = jdbcTemplateObject.query(SQL, 
				new Object[]{nameRol}, new PermissionMapper());
		System.out.println(permissions);
		return permissions;
	}
	
	public void delete(Integer id) {
		
	}

	public void update(Integer id, String permission) {
		
	}

}
