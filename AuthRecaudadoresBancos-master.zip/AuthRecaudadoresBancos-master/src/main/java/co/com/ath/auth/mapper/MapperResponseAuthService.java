package co.com.ath.auth.mapper;

import java.util.Calendar;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import co.com.ath.auth.dto.AdditionalStatus;
import co.com.ath.auth.dto.GenericErrorResponse;
import co.com.ath.auth.dto.MsgRsHdr;
import co.com.ath.auth.dto.Status;
import co.com.ath.auth.util.Constants;

/**
 * Clase que mapea la respuesta del servicio.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class MapperResponseAuthService {

	public ResponseEntity<Object> responseAuthService(HttpStatus status, GenericErrorResponse genericErrorResponse) {
		HttpHeaders headers = new HttpHeaders();
		if(genericErrorResponse != null)
			return new ResponseEntity<Object>(genericErrorResponse, headers, status);
		else
			return new ResponseEntity<Object>(headers, status);
	}
	
	public static GenericErrorResponse mapperResponseErrorCore(Exception exception) {
		GenericErrorResponse genericErrorResponse = new GenericErrorResponse();
		
		Status status = new Status();
		status.setStatusCode(String.valueOf(Constants.ERROR_STATUS_CODE_300));
		status.setStatusDesc(Constants.ERROR_STATUS_CODE_DESC);
		status.setEndDt(Calendar.getInstance().getTime());
		
		AdditionalStatus additionalStatus = new AdditionalStatus();
		additionalStatus.setStatusCode(String.valueOf(Constants.ERROR_STATUS_CODE_300));
		additionalStatus.setStatusDesc(exception.getMessage());
		status.setAdditionalStatus(additionalStatus);
		
		MsgRsHdr msgRsHdr = new MsgRsHdr();
		msgRsHdr.setStatus(status);
		msgRsHdr.setEndDt(Calendar.getInstance().getTime());
		genericErrorResponse.setMsgRsHdr(msgRsHdr);
		
		return genericErrorResponse;
	}
}
