package co.com.ath.auth.controller;

import co.com.ath.auth.dto.CustomException;
import co.com.ath.auth.dto.RequestAuthenticateService;
import co.com.ath.auth.dto.ResponseAuthenticateService;

/**
 * Interface control para la autenticacion.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public interface AuthenticateControlService {
	
	/**
	 * Authenticate Control
	 */
	ResponseAuthenticateService authenticate(RequestAuthenticateService rq) throws CustomException;
	
	void validateRequest(RequestAuthenticateService rq) throws CustomException;
	
}
