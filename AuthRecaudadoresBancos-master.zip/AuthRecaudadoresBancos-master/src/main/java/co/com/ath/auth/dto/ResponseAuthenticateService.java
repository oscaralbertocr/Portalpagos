package co.com.ath.auth.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.auth.util.XMLUtil;
import co.com.ath.persistence.dto.PermissionDTO;

/**
 * DTO para el ResponseAuthenticateService.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class ResponseAuthenticateService implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("Rol")
	private ArrayList<String> rol;
	
	@JsonProperty("Permission")
	private List<PermissionDTO> permission;
	
	@JsonProperty("NumDoc")
	private String numDoc;
	
	@JsonProperty("Login")
	private String login;
	
	@JsonProperty("Name")
	private String name;
	
	@JsonProperty("CostCenterCode")
	private String costCenterCode;
	
	@JsonProperty("CostCenterDes")
	private String costCenterDes;
	
	@JsonProperty("ChargeCode")
	private String chargeCode;
	
	@JsonProperty("ChargeDes")
	private String chargeDes;
	
	@JsonProperty("Token")
	private String token;

	/**
	 * @return the rol
	 */
	public ArrayList<String> getRol() {
		return rol;
	}

	/**
	 * @param rol the rol to set
	 */
	public void setRol(ArrayList<String> rol) {
		this.rol = rol;
	}

	/**
	 * @return the permission
	 */
	public List<PermissionDTO> getPermission() {
		return permission;
	}

	/**
	 * @param permission the permission to set
	 */
	public void setPermission(List<PermissionDTO> permission) {
		this.permission = permission;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNumDoc() {
		return numDoc;
	}

	public void setNumDoc(String numDoc) {
		this.numDoc = numDoc;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getCostCenterCode() {
		return costCenterCode;
	}

	public void setCostCenterCode(String costCenter) {
		this.costCenterCode = costCenter;
	}

	public String getCostCenterDes() {
		return costCenterDes;
	}

	public void setCostCenterDes(String costCenterDes) {
		this.costCenterDes = costCenterDes;
	}

	public String getChargeCode() {
		return chargeCode;
	}

	public void setChargeCode(String chargeCode) {
		this.chargeCode = chargeCode;
	}

	public String getChargeDes() {
		return chargeDes;
	}

	public void setChargeDes(String chargeDes) {
		this.chargeDes = chargeDes;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
	@Override
	public String toString() {
		XMLUtil<ResponseAuthenticateService> util = new XMLUtil<ResponseAuthenticateService>();
		return util.convertObjectToJson(this);
	}
	
}
