package co.com.ath.persistence.dto;

import java.io.Serializable;

/**
 * DTO tabla de parametros "ROL"
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class RolDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private String name;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
