package co.com.ath.persistence.dto;

import java.io.Serializable;

/**
 * DTO tabla de parametros "EXT_PARAM_RECAUDADOR_BANCO"
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class ParameterDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String clave;
	private String valor;
	private String estado;
	private String descripcion;
	
	public String getClave() {
		return clave;
	}
	public void setClave(String llave) {
		this.clave = llave;
	}
	public String getValor() {
		return valor;
	}
	public void setValor(String valor) {
		this.valor = valor;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
}
