package co.com.ath.auth.dto;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.auth.util.Constants;
import co.com.ath.auth.util.XMLUtil;

/**
 * DTO para el MsgRsHdr.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class MsgRsHdr implements Serializable {

	@JsonProperty("Status")
	private Status status;
	@JsonFormat(pattern="yyyy-MM-dd HH:mm:ss", timezone = Constants.TIMEZONE)
	@JsonProperty("EndDt")
	private Date endDt;
	private static final long serialVersionUID = -5941293430268074204L;

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Date getEndDt() {
		return endDt;
	}

	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}
	
	@Override
	public String toString() {
		XMLUtil<MsgRsHdr> util = new XMLUtil<MsgRsHdr>();
		return util.convertObjectToJson(this);
	}	

}