package co.com.ath.auth.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.auth.util.XMLUtil;

/**
 * DTO para el RequestAuthenticateService.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class RequestAuthenticateService implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("User")
	private String user;
	
	@JsonProperty("Pass")
	private String pass;
	
	/**
	 * @return the user
	 */
	public String getUser() {
		return user;
	}

	/**
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	 * @return the pass
	 */
	public String getPass() {
		return pass;
	}

	/**
	 * @param pass the pass to set
	 */
	public void setPass(String pass) {
		this.pass = pass;
	}

	@Override
	public String toString() {
		XMLUtil<RequestAuthenticateService> util = new XMLUtil<RequestAuthenticateService>();
		return util.convertObjectToJson(this);
	}
}
