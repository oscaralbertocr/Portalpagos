@javax.xml.bind.annotation.XmlSchema(namespace = "http://soi.avvillas.com/ManejoIdentidad/WSBA_ManejoIdentidad_autorizar")
package co.com.ath.client.authorize.dto;
