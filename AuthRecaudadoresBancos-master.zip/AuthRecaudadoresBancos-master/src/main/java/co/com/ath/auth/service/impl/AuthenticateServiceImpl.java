package co.com.ath.auth.service.impl;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import co.com.ath.auth.dto.CustomException;
import co.com.ath.auth.dto.RequestAuthenticateService;
import co.com.ath.auth.dto.RequestTokenService;
import co.com.ath.auth.dto.ResponseAuthenticateService;
import co.com.ath.auth.service.AuthenticateService;
import co.com.ath.auth.util.CipherUtil;
import co.com.ath.bridge.BridgeAuthService;
import co.com.ath.client.authenticate.dto.OeAutenticacion;
import co.com.ath.client.authorize.dto.OeAutorizacion;
import co.com.ath.persistence.dao.impl.ParameterDAOImpl;
import co.com.ath.persistence.dao.impl.PermissionDAOImpl;
import co.com.ath.persistence.dto.ParameterDTO;
import co.com.ath.persistence.dto.PermissionDTO;

/**
 * Implementacion de la Interface para el servicio de autenticacion.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
@Service
public class AuthenticateServiceImpl implements AuthenticateService{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(AuthenticateServiceImpl.class);

	@Autowired
	BridgeAuthService bridgeAuthService;
	
	@Autowired
	PermissionDAOImpl permissionDAOImpl;
	
	@Autowired
	ParameterDAOImpl parameterDAOImpl;
	
	private ParameterDTO strAPP;
	
	private ParameterDTO uriToken;

	private ParameterDTO keyCipher;
	
	private ParameterDTO ivCipher;

	public ResponseAuthenticateService authenticate(RequestAuthenticateService rq) throws CustomException {
		ResponseAuthenticateService rs = new ResponseAuthenticateService();
		try {
			SecureRandom number = SecureRandom.getInstance("SHA1PRNG");
			String channel = "1";
			String rquid = String.valueOf(Math.abs(number.nextInt()));
			RequestTokenService requestTokenService = new RequestTokenService();
			Set<PermissionDTO> permissions = new HashSet<PermissionDTO>();
			Set<String> perm = new HashSet<String>();
			OeAutenticacion oeAutenticacion = new OeAutenticacion();
			oeAutenticacion.setStrUsuario(rq.getUser());
			CipherUtil cu = new CipherUtil();
			this.keyCipher = parameterDAOImpl.getParameter("keyCipher");
			this.ivCipher = parameterDAOImpl.getParameter("ivCipher");
			LOGGER.info("Descifrando contrase�a");
			String pasClear = cu.decrypt(keyCipher.getValor(), ivCipher.getValor(), rq.getPass());
			LOGGER.info("Contrase�a Descifrada correctamente usuario");
//			LOGGER.info("Cifrando contrase�a para DataPower, usuario: {}",rq.getUser());
//			String pasCDES = cu.encryptDES(this.keyCipher.getValor(), pasClear);
//			LOGGER.info("Contrase�a Cifrada correctamente para DataPower, usuario: {}",rq.getUser());
			oeAutenticacion.setStrContrasena(pasClear);
			OeAutorizacion oeAutorizacion = new OeAutorizacion();
			oeAutorizacion.setStrUsuario(rq.getUser());
			this.strAPP = parameterDAOImpl.getParameter("strAPP");
			this.uriToken = parameterDAOImpl.getParameter("uriToken");
			oeAutorizacion.setStrAPP(this.strAPP.getValor());
			ArrayList<String> roles = new ArrayList<String>();
			String[] rsAuthenticate = bridgeAuthService.authenticate(oeAutenticacion,channel,rquid);
			if(rsAuthenticate[0].equals("OK")) {
				requestTokenService.setUser(rq.getUser());
				RestTemplate restTemplate = new RestTemplate();
				rs.setToken(restTemplate.postForObject(this.uriToken.getValor(), requestTokenService, String.class));
				LOGGER.info("Token recibido para el usuario");
				if(rsAuthenticate.length>=8) {
					rs.setNumDoc(rsAuthenticate[1]);
					rs.setLogin(rsAuthenticate[2]);
					rs.setName(rsAuthenticate[3]);
					rs.setCostCenterCode(rsAuthenticate[4]);
					rs.setCostCenterDes(rsAuthenticate[5]);
					rs.setChargeCode(rsAuthenticate[6]);
					rs.setChargeDes(rsAuthenticate[7]);
				}
				for (String nameRol : bridgeAuthService.authorize(oeAutorizacion,channel,rquid)) {
					roles.add(nameRol);
					for(PermissionDTO permission : permissionDAOImpl.getPermissionsByRol(nameRol)) {
						if(!perm.contains(permission.getId() + "")) {
							perm.add(permission.getId() + "");
							permissions.add(permission);
						}
					}
				}
			}
			ArrayList<PermissionDTO> al = new ArrayList<PermissionDTO>();
			al.addAll(permissions);
			rs.setRol(roles);
			rs.setPermission(al);
		}catch(CustomException ce){
			throw ce;
		}catch(RestClientException e){
			LOGGER.error(e.getMessage());
			e.printStackTrace();
			throw new CustomException("Falla al conectar con servicio rest "+ this.uriToken +"  "+ e.getMessage());
		}catch(EmptyResultDataAccessException e){
			LOGGER.error(e.getMessage());
			e.printStackTrace();
			throw new CustomException("No se encuentra parametro en la base de datos");
		}catch(Exception e){
			LOGGER.error(e.getMessage());
			e.printStackTrace();
			throw new CustomException(e.getMessage());
		}
		return rs;
	}

}
