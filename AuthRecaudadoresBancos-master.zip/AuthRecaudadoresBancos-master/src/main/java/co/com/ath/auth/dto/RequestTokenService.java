package co.com.ath.auth.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.auth.util.XMLUtil;

/**
 * DTO para el RequestTokenService.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class RequestTokenService implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@JsonProperty("User")
	private String user;

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}
	
	@Override
	public String toString() {
		XMLUtil<RequestTokenService> util = new XMLUtil<RequestTokenService>();
		return util.convertObjectToJson(this);
	}	
}
