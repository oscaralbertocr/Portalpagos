package co.com.ath.persistence.dao.impl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import co.com.ath.persistence.dao.RolDAO;
import co.com.ath.persistence.dto.RolDTO;
import co.com.ath.persistence.mapper.RolMapper;

/**
 * Implementacion de la Interface DAO para la tabla de roles
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class RolDAOImpl implements RolDAO{

	@Autowired
	private DataSource dataSource;

	private JdbcTemplate jdbcTemplateObject;

	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	public void create(String name, Integer age) {

	}

	public RolDTO getRol(Integer id) {
		String SQL = "SELECT * FROM ROL WHERE ID = ?";
		RolDTO rol = jdbcTemplateObject.queryForObject(SQL, 
				new Object[]{id}, new RolMapper());

		return rol;
	}

	public List<RolDTO> listRoles() {
		String SQL = "SELECT * FROM ROL";
		List <RolDTO> roles = jdbcTemplateObject.query(SQL, new RolMapper());
		return roles;
	}

	public List<RolDTO> getRolesByPermission(Integer idPermission) {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(Integer id) {

	}

	public void update(Integer id, Integer age) {

	}


}
