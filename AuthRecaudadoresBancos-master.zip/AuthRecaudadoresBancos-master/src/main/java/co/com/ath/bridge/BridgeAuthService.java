package co.com.ath.bridge;

import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;

import org.json.JSONObject;
import org.json.XML;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import co.com.ath.auth.dto.CustomException;
import co.com.ath.auth.util.Constants;
import co.com.ath.client.authenticate.dto.OeAutenticacion;
import co.com.ath.client.authenticate.dto.SoapEnvelopeAutentication;
import co.com.ath.client.authorize.dto.OeAutorizacion;
import co.com.ath.client.authorize.dto.SoapEnvelopeAutorization;
import co.com.ath.persistence.dao.impl.ParameterDAOImpl;

/**
 * Puente de servicios SOAP. Realiza el llamado a los servicios SOAP de autenticacion y autorizacion
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
@Service
public class BridgeAuthService {

	@Autowired
	ParameterDAOImpl parameterDAOImpl;

	@Value("${urlEndPointAuthenticate}")
	private String urlEndPointAuthenticate;

	@Value("${urlEndPointAuthorize}")
	private String urlEndPointAuthorize;

	private static final Logger LOGGER = LoggerFactory.getLogger(BridgeAuthService.class);

	public String[] authenticate(OeAutenticacion oeAutenticacion, String channel, String rquid) throws CustomException{
		try {

			LOGGER.info("Iniciando Autenticacion para el usuario: {}",oeAutenticacion.getStrUsuario());
			String resp = this.transport(rquid, channel, oeAutenticacion);
			if(!(resp.startsWith("OK"))) {
				throw new CustomException(resp);
			}
			LOGGER.info("Autenticacion Correcta para el usuario: {}",oeAutenticacion.getStrUsuario());
			return resp.split("\\|");
		}catch(CustomException ce){
			throw ce;
		}catch(Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}

	public String[] authorize(OeAutorizacion oeAutorizacion, String channel, String rquid) throws CustomException{
		try {
			LOGGER.info("Iniciando Autorizacion para el usuario: {}", oeAutorizacion.getStrUsuario());
			String resp = this.transport(rquid, channel, oeAutorizacion);

			if(resp.startsWith("Error")) {
				throw new CustomException(resp);
			}else if(resp.isEmpty()){
				throw new CustomException("sin permisos");
			}
			LOGGER.info("Autorizacion Correcta para el usuario: {}",oeAutorizacion.getStrUsuario());
			return resp.split(",");
		}catch(CustomException ce){
			throw ce;
		}catch(Exception e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
			throw new CustomException(e.getMessage());
		}
	}

	private String transport(String rquid, String channel, Object request) {
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_XML);
			headers.add(Constants.HEADER1, rquid);
			headers.add(Constants.HEADER2, channel);
			RestTemplate service = new RestTemplate();
			String url = "";
			JAXBContext jaxbContext;
			StringWriter sw= new StringWriter();
			if(request instanceof OeAutenticacion) {
				SoapEnvelopeAutentication se = new SoapEnvelopeAutentication();
				se.getBody().getAutenticar().setOeEntrada((OeAutenticacion)request);
				url  = this.urlEndPointAuthenticate;
				jaxbContext = JAXBContext.newInstance(SoapEnvelopeAutentication.class);
				Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
				jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
				jaxbMarshaller.marshal(se, sw);
				
			}else if(request instanceof OeAutorizacion) {
				SoapEnvelopeAutorization se = new SoapEnvelopeAutorization();
				se.getBody().getAutorizar().setOeEntrada((OeAutorizacion)request);
				url  = this.urlEndPointAuthorize;
				jaxbContext = JAXBContext.newInstance(SoapEnvelopeAutorization.class);
				Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
				jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
				jaxbMarshaller.marshal(se, sw);
				
			}

			String xmlString = sw.toString();
			
			HttpEntity<OeAutenticacion> rq = new HttpEntity(xmlString, headers);

			LOGGER.info("Iniciando Cliente para Autenticacion: {}", url);
			String resp = service.postForObject(url, rq, String.class);
			JSONObject xmlJSONObj = XML.toJSONObject(resp);
			String jsonPrettyPrintString = xmlJSONObj.toString();
			JSONObject json = new JSONObject(jsonPrettyPrintString);
			if(request instanceof OeAutenticacion) {
				return json.getJSONObject("soapenv:Envelope")
	            		.getJSONObject("soapenv:Body")
	            		.getJSONObject("out2:autenticarResponse")
	            		.getJSONObject("os_salida")
	            		.getString("return");
			}else if(request instanceof OeAutorizacion) {
				return json.getJSONObject("soapenv:Envelope")
	            		.getJSONObject("soapenv:Body")
	            		.getJSONObject("out:autorizarResponse")
	            		.getJSONObject("os_salida")
	            		.getString("return");
			}
			
		} catch (PropertyException e) {
			e.printStackTrace();
			LOGGER.error(e.getMessage());
		} catch (JAXBException e) {
			LOGGER.error(e.getMessage());
		}
		return null;
	}

}
