
package co.com.ath.client.authenticate.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Clase Java para oe_Autenticacion complex type.
 * 
 * <p>El siguiente fragmento de esquema especifica el contenido que se espera que haya en esta clase.
 * 
 * <pre>
 * &lt;complexType name="oe_Autenticacion"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="strUsuario" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="strContrasena" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "oe_Autenticacion", propOrder = {
    "strUsuario",
    "strContrasena"
})
public class OeAutenticacion {

    protected String strUsuario;
    protected String strContrasena;

    /**
     * Obtiene el valor de la propiedad strUsuario.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrUsuario() {
        return strUsuario;
    }

    /**
     * Define el valor de la propiedad strUsuario.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrUsuario(String value) {
        this.strUsuario = value;
    }

    /**
     * Obtiene el valor de la propiedad strContrasena.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStrContrasena() {
        return strContrasena;
    }

    /**
     * Define el valor de la propiedad strContrasena.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStrContrasena(String value) {
        this.strContrasena = value;
    }

}
