package co.com.ath.auth.controller.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.auth.controller.AuthenticateControlService;
import co.com.ath.auth.dto.CustomException;
import co.com.ath.auth.dto.RequestAuthenticateService;
import co.com.ath.auth.dto.ResponseAuthenticateService;
import co.com.ath.auth.service.impl.AuthenticateServiceImpl;

/**
 * Implementacion para la Interface control para la autenticacion.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */

@Service
public class AuthenticateControlServiceImpl implements AuthenticateControlService{

	@Autowired
	AuthenticateServiceImpl authenticateServiceImpl;

	public ResponseAuthenticateService authenticate(RequestAuthenticateService rq) throws CustomException {
		ResponseAuthenticateService rs = null;
		try {
			validateRequest(rq);
			rs = authenticateServiceImpl.authenticate(rq);
		}catch(CustomException ce){
			throw ce;
		}catch(Exception e){
			e.printStackTrace();
			throw new CustomException(e.getMessage());
		}
		return rs;
	}
	
	public void validateRequest(RequestAuthenticateService rq) throws CustomException {
		if(rq.getUser()==null || rq.getPass()==null) {
			throw new CustomException("Valores invalidos");
		}
	}

}
