package co.com.ath.persistence.dto;

import java.io.Serializable;

import co.com.ath.auth.util.XMLUtil;

/**
 * DTO tabla de parametros "PERMISOS"
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class PermissionDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Integer id;
	private String permission;
	private String urlPermission;
	private String activo;
	private String tooltip;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPermission() {
		return permission;
	}
	public void setPermission(String permission) {
		this.permission = permission;
	}
	
    public String getUrlPermission() {
		return urlPermission;
	}
    
	public void setUrlPermission(String urlPermission) {
		this.urlPermission = urlPermission;
	}
	
	public String getActivo() {
		return activo;
	}
	
	public void setActivo(String activo) {
		this.activo = activo;
	}
	
	public String getTooltip() {
		return tooltip;
	}
	
	public void setTooltip(String tooltip) {
		this.tooltip = tooltip;
	}
	
	@Override
	public String toString() {
		XMLUtil<PermissionDTO> util = new XMLUtil<PermissionDTO>();
		return util.convertObjectToJson(this);
	}
}
