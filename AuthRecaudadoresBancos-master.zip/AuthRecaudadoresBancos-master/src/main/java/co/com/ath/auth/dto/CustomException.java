
package co.com.ath.auth.dto;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * DTO para el CustomException.
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */

public class CustomException extends Exception {

	private static final long serialVersionUID = 1L;
	private final Object objeto;

	public CustomException() {
        super();
        this.objeto = null;

    }
	

    public CustomException(String message) {
        super(message);
        this.objeto = null;
    }

    public CustomException(String message, Object objeto) {
        super(message);
        this.objeto = objeto;
    }

	public Object getObjeto() {
		return objeto;
	}
	
	
	private void readObject(ObjectInputStream aInputStream) throws ClassNotFoundException, IOException{// default implementation ignored
    }
 
    private void writeObject(ObjectOutputStream aOutputStream) throws IOException 
    {
        aOutputStream.writeObject(objeto);
    }

	
}
