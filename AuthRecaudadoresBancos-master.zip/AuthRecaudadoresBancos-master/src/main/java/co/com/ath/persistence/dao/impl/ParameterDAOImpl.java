package co.com.ath.persistence.dao.impl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import co.com.ath.persistence.dao.ParameterDAO;
import co.com.ath.persistence.dto.ParameterDTO;
import co.com.ath.persistence.mapper.ParameterMapper;

/**
 * Implementacion de la Interface DAO para la tabla de parametros
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class ParameterDAOImpl implements ParameterDAO{

	@Autowired
	private DataSource dataSource;

	private JdbcTemplate jdbcTemplateObject;

	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
		this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	public void create(String clave, String valor, String estado, String descripcion) {

	}

	public ParameterDTO getParameter(String clave) {
		String SQL = "SELECT * FROM EXT_PARAM_RECAUDADOR_BANCO WHERE CLAVE = ?";
		ParameterDTO parameter = jdbcTemplateObject.queryForObject(SQL, 
				new Object[]{clave}, new ParameterMapper());

		return parameter;
	}

	public List<ParameterDTO> listParameters() {
		String SQL = "SELECT * FROM EXT_PARAMETRO_RECAUDADOR_BANCO";
		List <ParameterDTO> parameters = jdbcTemplateObject.query(SQL, new ParameterMapper());
		return parameters;
	}

	public void delete(String clave) {

	}

	public void update(String clave, String valor, String estado, String descripcion) {

	}

}
