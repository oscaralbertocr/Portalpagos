package co.com.ath.persistence.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import co.com.ath.persistence.dto.PermissionDTO;

/**
 * Mapper para los registros de la tabla de permisos
 * 
 * @author Sophos Solutions.
 * @author Jesus Octavio Avenda�o <strong>jesus.avendano@sophossolutions.com</strong>
 * @version 0.0.0 01/11/2020
 */
public class PermissionMapper implements RowMapper<PermissionDTO> {

	public PermissionDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		PermissionDTO permission = new PermissionDTO();
		permission.setId(rs.getInt("ID"));
		permission.setPermission(rs.getString("PERMISO"));
		permission.setUrlPermission(rs.getString("URL_PERMISO"));
		permission.setActivo(rs.getString("ACTIVO"));
		permission.setTooltip(rs.getString("TOOLTIP"));
		return permission;
	}
}
