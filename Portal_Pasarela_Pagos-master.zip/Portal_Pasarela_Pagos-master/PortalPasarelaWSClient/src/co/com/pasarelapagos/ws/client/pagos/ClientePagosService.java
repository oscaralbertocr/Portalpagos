package co.com.pasarelapagos.ws.client.pagos;

import java.security.SecureRandom;
import java.util.Date;

import co.com.pasarelapagos.ws.client.pagos.proxy.GatewayPaymentPortProxy;
import co.com.pasarelapagos.ws.dto.WSPagosDTO;
import co.com.pasarelapagos.ws.dto.WSPagosResponseDTO;

/**
 * Clase que implementa los metodos que hacen uso de los servicios de pagos de la pasarela.
 * @author ATH
 * @author proveedor_jcramirez
 * @create 21/08/2014
 * @version 1.0
 */
public class ClientePagosService implements IClientePagosServiceFacade {

	@Override
	public WSPagosResponseDTO addAvalPayment(WSPagosDTO consulta) throws Exception {
		GatewayPaymentPortProxy proxy = new GatewayPaymentPortProxy();
		SecureRandom codGen = new SecureRandom();
		//Soluci�n IM RQIDS Negativos Inicio 
		 Long temporalRqid = codGen.nextLong();
         if (temporalRqid <= 0) {
        	 temporalRqid = temporalRqid*(-1);       
         }
        consulta.setRqUID(temporalRqid);
		consulta.setFechaSolicitud(new Date());
		return proxy.addAVALPayment(consulta);
	}
	   //Soluci�n IM RQIDS Negativos Fin 
	
	
	@Override
	public WSPagosResponseDTO addRBMPayment(WSPagosDTO consulta) throws Exception {
		GatewayPaymentPortProxy proxy = new GatewayPaymentPortProxy();
		SecureRandom codGen = new SecureRandom();
		//Soluci�n IM RQIDS Negativos Inicio 
		 Long temporalRqid = codGen.nextLong();
         if (temporalRqid <= 0) {
        	 temporalRqid = temporalRqid*(-1);       
         }
        consulta.setRqUID(temporalRqid);
		consulta.setFechaSolicitud(new Date());
		return proxy.addRBMPayment(consulta);
	}
	   //Soluci�n IM RQIDS Negativos Fin 
		
	
	
	@Override
	public WSPagosResponseDTO addPSETransaction(WSPagosDTO consulta) throws Exception {
		GatewayPaymentPortProxy proxy = new GatewayPaymentPortProxy();
		SecureRandom codGen = new SecureRandom();
		//Soluci�n IM RQIDS Negativos Inicio 
		Long temporalRqid = codGen.nextLong();
		if (temporalRqid <= 0) {
       	 temporalRqid = temporalRqid*(-1);       
        }
		consulta.setRqUID(temporalRqid);
		consulta.setFechaSolicitud(new Date());
		return proxy.addPSETransaction(consulta);
	}

}
