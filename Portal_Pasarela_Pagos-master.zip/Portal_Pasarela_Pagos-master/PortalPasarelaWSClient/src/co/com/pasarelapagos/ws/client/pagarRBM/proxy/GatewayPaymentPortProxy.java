package co.com.pasarelapagos.ws.client.pagarRBM.proxy;

import java.math.BigDecimal;
import java.net.URL;
import java.util.GregorianCalendar;
import co.com.portales.common.contants.IConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;
import org.apache.log4j.Logger;
import co.com.pasarelapagos.dto.EstadoPagoDTO;
import co.com.pasarelapagos.dto.TransaccionesDTO;
import co.com.pasarelapagos.ws.client.pagarRBM.types.AgreementInfoType;
import co.com.pasarelapagos.ws.client.pagarRBM.types.CustNameType;
import co.com.pasarelapagos.ws.client.pagarRBM.types.FeeType;
import co.com.pasarelapagos.ws.client.pagarRBM.types.OrderInfoType;
import co.com.pasarelapagos.ws.client.pagarRBM.types.PersonalDataType;
import co.com.pasarelapagos.ws.client.pagarRBM.types.ReferenceType;
import co.com.pasarelapagos.ws.client.pagarRBM.types.TaxFeeType;
import co.com.pasarelapagos.ws.client.pagarRBM.types.UserIdType;
import co.com.pasarelapagos.ws.dto.WSPagosDTO;
import co.com.pasarelapagos.ws.dto.WSPagosResponseDTO;
import co.com.pasarelapagos.ws.util.WSUtil;
import co.com.portales.common.util.XmlDataHandling;
import static co.com.portales.common.util.UtilidadesTexto.enmascararCorreo;


public class GatewayPaymentPortProxy{
	
	private static Logger log = Logger.getLogger(GatewayPaymentPortProxy.class);

    protected Descriptor _descriptor;

    public class Descriptor {
        private co.com.pasarelapagos.ws.client.pagarRBM.proxy.GatewayPaymentService _service = null;
        private co.com.pasarelapagos.ws.client.pagarRBM.proxy.GatewayPaymentRBM _proxy = null;
        private Dispatch<Source> _dispatch = null;

        public Descriptor() {
            init();
        }

        public Descriptor(URL wsdlLocation, QName serviceName) {
            _service = new co.com.pasarelapagos.ws.client.pagarRBM.proxy.GatewayPaymentService(wsdlLocation, serviceName);
            initCommon();
        }

        public void init() {
            _service = null;
            _proxy = null;
            _dispatch = null;
            _service = new co.com.pasarelapagos.ws.client.pagarRBM.proxy.GatewayPaymentService();
            initCommon();
        }

        private void initCommon() {
            _proxy = _service.getGatewayPaymentPort();
        }

        public co.com.pasarelapagos.ws.client.pagarRBM.proxy.GatewayPaymentRBM getProxy() {
            return _proxy;
        }

        public Dispatch<Source> getDispatch() {
            if (_dispatch == null ) {
                QName portQName = new QName("urn://ath.com.co/payments/v1/", "GatewayPaymentPort");
                _dispatch = _service.createDispatch(portQName, Source.class, Service.Mode.MESSAGE);

                String proxyEndpointUrl = getEndpoint();
                BindingProvider bp = (BindingProvider) _dispatch;
                String dispatchEndpointUrl = (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
                if (!dispatchEndpointUrl.equals(proxyEndpointUrl))
                    bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, proxyEndpointUrl);
            }
            return _dispatch;
        }

        public String getEndpoint() {
            BindingProvider bp = (BindingProvider) _proxy;
            return (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
        }

        public void setEndpoint(String endpointUrl) {
            BindingProvider bp = (BindingProvider) _proxy;
            bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);

            if (_dispatch != null ) {
                bp = (BindingProvider) _dispatch;
                bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);
            }
        }

        public void setMTOMEnabled(boolean enable) {
            SOAPBinding binding = (SOAPBinding) ((BindingProvider) _proxy).getBinding();
            binding.setMTOMEnabled(enable);
        }
    }

    public GatewayPaymentPortProxy() {
        _descriptor = new Descriptor();
        _descriptor.setMTOMEnabled(false);
        /** INICIO-C01 **/
        String endpointOperation = WSUtil.getWsdlEndpointOperation("PortalPasarelaConf","EndpointRBMPayment");
      		if(endpointOperation != null && !endpointOperation.equals("")){
      			_getDescriptor().setEndpoint(endpointOperation);
      			}
      		else
      			log.info("\n.. NO EXISTE EL ENDPOINT SOLICITADO EN AL ARCHIVO PROPERTIES PARA EL SERVICIO ");
        /** FIN-C01 **/
    }

    public GatewayPaymentPortProxy(URL wsdlLocation, QName serviceName) {
        _descriptor = new Descriptor(wsdlLocation, serviceName);
        _descriptor.setMTOMEnabled(false);
    }

    public Descriptor _getDescriptor() {
        return _descriptor;
    }
    
    public WSPagosResponseDTO initTransactionRbm(WSPagosDTO consulta){
    	WSPagosResponseDTO pagosResponse = null;
    	try{
    		XmlDataHandling xmlDataHandler = new XmlDataHandling();
    		InitTransactionRbmRqType initTransactionRbmRq = dtoToInitTrnasctionWsRequest(consulta);
    		String correoCliente = "";
    		String correoClientePago = "";
    		int numPersonalData = 0;
    		
    		// Modificacion para enmascarar datos sensibles.
    		if(initTransactionRbmRq.getPersonalData()!=null){
    			for(PersonalDataType persona : initTransactionRbmRq.getPersonalData()){
    				if(persona.getEmailAddr()!= null){
    					numPersonalData++;
    					if(numPersonalData == 1){
    						correoCliente = persona.getEmailAddr();
        					persona.setEmailAddr(enmascararCorreo(correoCliente));
        					initTransactionRbmRq.getPersonalData().set(0 , persona);
    					}else if(numPersonalData == 2){
    						correoClientePago = persona.getEmailAddr();
        					persona.setEmailAddr(enmascararCorreo(correoClientePago));
        					initTransactionRbmRq.getPersonalData().set(1, persona);
    					}	
    				}
    			}
    		}
    		
	    	log.info("\n...EL MENSAJE ENVIADO A INTEGRADOR InitTransactionRBM ES: \n"
	    	+ "\n wsdlEndPoint: "+_getDescriptor().getEndpoint()+"\n"
	    	+ "\n Service:  "+_getDescriptor()._service+"\n"
	    	+ new String(xmlDataHandler.marshalObject(initTransactionRbmRq)));
	    	
	    	numPersonalData = 0;
	    	// Modificacion para enmascarar datos sensibles.
    		if(initTransactionRbmRq.getPersonalData()!=null){
    			for(PersonalDataType persona : initTransactionRbmRq.getPersonalData()){
    				if(persona.getEmailAddr()!= null){
    					numPersonalData++;
    					if(numPersonalData == 1){
        					persona.setEmailAddr(correoCliente);
        					initTransactionRbmRq.getPersonalData().set(0, persona);
    					}else if(numPersonalData == 2){
        					persona.setEmailAddr(correoClientePago);
        					initTransactionRbmRq.getPersonalData().set(1, persona);
    					}
    				}
    			}
    		}
	    	
	    	InitTransactionRbmRsType initTransactionRbmRs = _getDescriptor().getProxy().initTransactionRbm(initTransactionRbmRq);
	    	log.info("\n...EL MENSAJE RECIBIDO DE INTEGRADOR initTransactionRbm ES: \n\n" + new String(xmlDataHandler.marshalObject(initTransactionRbmRs)));
	    	pagosResponse = wsResponseToInitTransactionRbmPagosDTO(initTransactionRbmRs);
    	}catch (Exception eExc) {
			log.error("::: ERROR EJECUTANDO initTransactionRbm: ", eExc);
			return null;
		}
        return pagosResponse;
    }
    
    
    
    private WSPagosResponseDTO wsResponseToInitTransactionRbmPagosDTO(InitTransactionRbmRsType initTransactionRbmRs){
    	WSPagosResponseDTO pagoResponse = new WSPagosResponseDTO();
    	TransaccionesDTO transactionInfo = new TransaccionesDTO();
    	pagoResponse.setStatusCode(initTransactionRbmRs.getStatus().getStatusCode());
    	pagoResponse.setStatusDesc(initTransactionRbmRs.getStatus().getStatusDesc());
    	pagoResponse.setServerStatusCode(initTransactionRbmRs.getStatus().getServerStatusCode());
    	pagoResponse.setServerStatusDesc(initTransactionRbmRs.getStatus().getServerStatusDesc());
    	pagoResponse.setRqUID(initTransactionRbmRs.getRqUID());
    	 //RQ25542 Motor de Riego Actualizacion INI
    	pagoResponse.setToken(initTransactionRbmRs.getToken());
    	 //RQ25542 Motor de Riego Actualizacion FIN
    	pagoResponse.setPortalURL(initTransactionRbmRs.getPortalURL());
    	try {
    		XmlDataHandling xmlDataHandler = new XmlDataHandling();
        	log.info("ResponseInitTransactionRBM : "+new String(xmlDataHandler.marshalObject(initTransactionRbmRs)));
			
		} catch (Exception e) {
			log.error(e);
		}
    
    	if(initTransactionRbmRs.getPmtId()!=null){
	    	try{
	    		transactionInfo.setPmtId(initTransactionRbmRs.getPmtId());
	    	}catch (Exception e) {
	    		log.error("::: EL ID DE LA TRANSACCION NO ES UN NUMERO VALIDO :::", e);
			}
    	}
    	if(initTransactionRbmRs.getTransactionStatus()!=null){
    		EstadoPagoDTO estadoTransaccion = new EstadoPagoDTO();
    		if(initTransactionRbmRs.getTransactionStatus().getTrnStatusCode()!=null){
    			estadoTransaccion.setId(initTransactionRbmRs.getTransactionStatus().getTrnStatusCode().intValue());
    		}
    		estadoTransaccion.setEstado(initTransactionRbmRs.getTransactionStatus().getTrnStatusDesc());
    		transactionInfo.setEstadoPago(estadoTransaccion);
       		if(initTransactionRbmRs.getTransactionStatus().getEffDt()!=null){
    			transactionInfo.setFechaPago(initTransactionRbmRs.getTransactionStatus().getEffDt().toGregorianCalendar().getTime());
    		}
    		transactionInfo.setApprovalId(initTransactionRbmRs.getTransactionStatus().getApprovalId());
    	}
    	pagoResponse.setTransaccion(transactionInfo);
    	return pagoResponse;
    }
    
    private InitTransactionRbmRqType dtoToInitTrnasctionWsRequest(WSPagosDTO consulta){
		InitTransactionRbmRqType initTransactionRbmRq = null;
    	
    	try{
    		initTransactionRbmRq = new InitTransactionRbmRqType();
    		
    		initTransactionRbmRq.setRqUID(consulta.getRqUID());
    		initTransactionRbmRq.setChannel(consulta.getChannel());
	    	
	    	GregorianCalendar gregory = new GregorianCalendar();
	    	gregory.setTime(consulta.getFechaSolicitud());
	    	XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);	    	
	    	initTransactionRbmRq.setClientDt(calendar);
	    	initTransactionRbmRq.setIPAddr(consulta.getIpOrigen());
	    	
	    	UserIdType userId = new UserIdType();
	    	userId.setCustIdType(consulta.getTransaccion().getUsuario().getTipoDocumento());
	    	userId.setCustIdNum(consulta.getTransaccion().getUsuario().getNoDocumento());
	    	userId.setCustLoginId(consulta.getTransaccion().getUsuario().getUsuario());
	    	initTransactionRbmRq.setUserId(userId);
	    	
	    	initTransactionRbmRq.setPmtId(consulta.getTransaccion().getPmtId());
	    	
	    	PersonalDataType personalData = new PersonalDataType();
	    	CustNameType custName = new CustNameType();
	    	custName.setLegalName(consulta.getTransaccion().getUsuario().getLegalName());
	    	custName.setFirstName(consulta.getTransaccion().getUsuario().getPrimerNombre());
	    	custName.setMiddleName(consulta.getTransaccion().getUsuario().getSegundoNombre());
	    	custName.setLastName(consulta.getTransaccion().getUsuario().getPrimerApellido());
	    	custName.setSecondLastName(consulta.getTransaccion().getUsuario().getSegundoApellido());
	    	personalData.setGender(consulta.getTransaccion().getUsuario().getGenero());
	    	if(consulta.getTransaccion().getUsuario().getFechaNacimiento()!=null){
	    		gregory = new GregorianCalendar();
		    	gregory.setTime(consulta.getTransaccion().getUsuario().getFechaNacimiento());
		    	calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
		    	personalData.setBirthDt(calendar);
	    	}
	    	
	    	personalData.setDeliveryCity(consulta.getTransaccion().getUsuario().getNombreCiudad());
	    	personalData.setStateProvName(consulta.getTransaccion().getUsuario().getNombreDepartamento());
	    	personalData.setCountryName(consulta.getTransaccion().getUsuario().getPais());
	    	personalData.setAddress(consulta.getTransaccion().getUsuario().getDireccion());
	    	personalData.setEmailAddr(consulta.getTransaccion().getUsuario().getCorreoElectronico());
	    	personalData.setPhone(consulta.getTransaccion().getUsuario().getTelefono());
	    	personalData.setCustIdType(consulta.getTransaccion().getUsuario().getTipoDocumento());
	    	personalData.setCustIdNum(consulta.getTransaccion().getUsuario().getNoDocumento());
	    	personalData.setCustName(custName);
	    		    	
	    	//Datos PersonalDataType 2
	    	PersonalDataType personalData2 = new PersonalDataType();
	    	CustNameType custName2 = new CustNameType();
	    	custName2.setFirstName(consulta.getTransaccion().getUsuario().getPrimerNombrePago().replaceAll("^\\s+",""));
	    	custName2.setMiddleName(consulta.getTransaccion().getUsuario().getSegundoNombrePago());
	    	custName2.setLastName(consulta.getTransaccion().getUsuario().getPrimerApellidoPago());
	    	custName2.setSecondLastName(consulta.getTransaccion().getUsuario().getSegundoApellidoPago());
	    	personalData2.setEmailAddr(consulta.getTransaccion().getUsuario().getCorreoElectronicoPago());
	    	personalData2.setCellPhone(consulta.getTransaccion().getUsuario().getTelefonoPago());
	    	

	    	personalData2.setCustIdType(consulta.getTransaccion().getUsuario().getTipoDocumentoPago());
	    	personalData2.setCustIdNum(consulta.getTransaccion().getUsuario().getNoDocumentoPago());
	    	personalData2.setCustName(custName2);
	    	
	    	initTransactionRbmRq.getPersonalData().add(personalData2);//datos pagador
	    	initTransactionRbmRq.getPersonalData().add(personalData);//datos beneficiario
	    	
	    	
	    	initTransactionRbmRq.setUserType("0");
	    		    	
	    	AgreementInfoType agreement = new AgreementInfoType();
	    	if(consulta.getTransaccion().getComercio()!=null){
	    		agreement.setAgreementId(consulta.getTransaccion().getComercio().getCodigoNura());
	    	}
	    	initTransactionRbmRq.setAgreementInfo(agreement);
	    	
	    	OrderInfoType orderInfo = new OrderInfoType();
	    	orderInfo.setOrderId(Long.valueOf(consulta.getTransaccion().getNumeroOrden()));
	    	orderInfo.setDesc(consulta.getTransaccion().getDescripcion());
	    	if(consulta.getTransaccion().getFechaLimitePago()!=null){
		    	gregory = new GregorianCalendar();
		    	gregory.setTime(consulta.getTransaccion().getFechaLimitePago());
		    	calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
		    	orderInfo.setEndDt(calendar);
	    	}
	    	if(consulta.getTransaccion().getFechaVencimiento()!=null){
		    	gregory = new GregorianCalendar();
		    	gregory.setTime(consulta.getTransaccion().getFechaVencimiento());
		    	calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
		    	orderInfo.setExpDt(calendar);
	    	}
	    	initTransactionRbmRq.setOrderInfo(orderInfo);
	    	
	    	FeeType fee = new FeeType();
	    	fee.setAmt(consulta.getTransaccion().getValorTotal());
	    	fee.setCurCode(consulta.getTransaccion().getMoneda());
	    	fee.setCurRate(consulta.getTransaccion().getTaza());
	    	initTransactionRbmRq.setFee(fee);
	    	
	    	TaxFeeType taxFee = new TaxFeeType();
	    	if(consulta.getTransaccion().getImpuesto()!=null){
		    	taxFee.setAmt(consulta.getTransaccion().getImpuesto().getValorImpuesto());
		    	if(consulta.getTransaccion().getImpuesto().getMoneda()== null){
		    		taxFee.setCurCode("Consumo");
		    	}
		    	else{
		    		taxFee.setCurCode(consulta.getTransaccion().getImpuesto().getMoneda());
		    		taxFee.setCurRate(consulta.getTransaccion().getImpuesto().getTaza());
		    	}
	    	}else{
	    		taxFee.setAmt(new BigDecimal(0));
	    		taxFee.setCurCode("Consumo");
	    	}
	    	
	    	initTransactionRbmRq.getTaxFee().add(taxFee);
	    	
	    	ReferenceType referenceOrderInfo= new ReferenceType();
	    	referenceOrderInfo.setRefId("numeroFactura");
	    	referenceOrderInfo.setRefType(consulta.getTransaccion().getNumeroOrden());
	    	
	    	ReferenceType referenceAgrementInfo= new ReferenceType();
	    	referenceAgrementInfo.setRefId("informacionComercio");
	    	referenceAgrementInfo.setRefType(consulta.getTransaccion().getComercio().getCodigoNura());	     	
	    	
	    	
	    	ReferenceType referenceInfoAdicional= new ReferenceType();
	    	referenceInfoAdicional.setRefId("informacionAdicional");
	    	referenceInfoAdicional.setRefType(consulta.getTransaccion().getDescripcion());
	    	
	    	//RQ25542 MotorDeRiesgosPortal
	    	ReferenceType referenciaDevice = new ReferenceType();
	    	referenciaDevice.setRefId(IConstants.MR_NOM_DEVICE_PRINT);
	    	referenciaDevice.setRefType(consulta.getDevicePrint());
	    		    	
	    	//RQ25542 MotorDeRiesgosPortal
	    	ReferenceType referenciaCookie = new ReferenceType();
	    	referenciaCookie.setRefId(IConstants.MR_NOM_DEVICE_TOKEN_COOKIE);
	    	referenciaCookie.setRefType(consulta.getDeviceToken());
	    	
	    	ReferenceType referenciaHttpAccept = new ReferenceType();
	    	referenciaHttpAccept.setRefId(IConstants.MR_HEADER_HTTP_ACCEPT);
	    	referenciaHttpAccept.setRefType(consulta.getHttpAccept());
	    	
	    	ReferenceType referenciaHttpAcceptLanguage = new ReferenceType();
	    	referenciaHttpAcceptLanguage.setRefId(IConstants.MR_HEADER_HTTP_ACCEPT_LANG);
	    	referenciaHttpAcceptLanguage.setRefType(consulta.getHttpAcceptLanguage());
	    	
	    	ReferenceType referenciaHttpReferrer = new ReferenceType();
	    	referenciaHttpReferrer.setRefId(IConstants.MR_HEADER_REFERER);
	    	referenciaHttpReferrer.setRefType(consulta.getHttpReferrer());
	    	
	    	ReferenceType referenciaUserAgent = new ReferenceType();
	    	referenciaUserAgent.setRefId(IConstants.MR_HEADER_USER_AGENT);
	    	referenciaUserAgent.setRefType(consulta.getUserAgent());
	    	
	    	//RQ25542 MotorDeRiesgosPortal
	    	initTransactionRbmRq.getReference().add(referenceOrderInfo);
	    	initTransactionRbmRq.getReference().add(referenceAgrementInfo);
	    	initTransactionRbmRq.getReference().add(referenceInfoAdicional);
	    	initTransactionRbmRq.getReference().add(referenciaDevice);
	    	initTransactionRbmRq.getReference().add(referenciaCookie);
	    	if(referenciaHttpAccept.getRefType() != null && !referenciaHttpAccept.getRefType().isEmpty())
	    		initTransactionRbmRq.getReference().add(referenciaHttpAccept);
	    	if(referenciaHttpAcceptLanguage.getRefType() != null && !referenciaHttpAcceptLanguage.getRefType().isEmpty())
	    		initTransactionRbmRq.getReference().add(referenciaHttpAcceptLanguage);
	    	if(referenciaHttpReferrer.getRefType() != null && !referenciaHttpReferrer.getRefType().isEmpty())
	    		initTransactionRbmRq.getReference().add(referenciaHttpReferrer);
	    	if(referenciaUserAgent.getRefType() != null && !referenciaUserAgent.getRefType().isEmpty())
	    		initTransactionRbmRq.getReference().add(referenciaUserAgent);
	    	
    	}catch (Exception e) {
			log.error("::: SE PRESENTARON PROBLEMAS AL MOMENTO DE ADICIONAR LA INFORMACION GENERAL DEL MENSAEJE dtoToRBMWsRequest ::: ", e);
		}
    	return initTransactionRbmRq;
}


    public InitTransactionRbmRsType initTransactionRbm(InitTransactionRbmRqType initTransactionRbmRq) {
        return _getDescriptor().getProxy().initTransactionRbm(initTransactionRbmRq);
    }

    public GetStateRBMPaymentRsType getStateRBMPayment(GetStateRBMPaymentRqType getStateRBMPaymentRq) {
        return _getDescriptor().getProxy().getStateRBMPayment(getStateRBMPaymentRq);
    }

}