package co.com.pasarelapagos.ws.client.pagos;

import co.com.pasarelapagos.ws.dto.WSPagosDTO;
import co.com.pasarelapagos.ws.dto.WSPagosResponseDTO;

/**
 * Interfaz que define los metodos que hacen uso de los servicios de pagos de la pasarela.
 * @author ATH
 * @author proveedor_jcramirez
 * @create 21/08/2014
 * @version 1.0
 */
public interface IClientePagosServiceFacade {
	
	/**
	 * Permite enviar la informaci�n de una transacci�n de un pago para que sea registrada en la aplicaci�n de la Pasarela de Pagos.
	 * @param wsInfo WSPagosDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSPagosResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	public WSPagosResponseDTO addAvalPayment(WSPagosDTO consulta) throws Exception;
	
	public WSPagosResponseDTO addRBMPayment(WSPagosDTO consulta) throws Exception;
	
	public WSPagosResponseDTO addPSETransaction(WSPagosDTO consulta) throws Exception;

}
