package co.com.pasarelapagos.ws.client.pagarRBM;

import java.security.SecureRandom;
import java.util.Date;

import co.com.pasarelapagos.ws.client.pagarRBM.proxy.GatewayPaymentPortProxy;
import co.com.pasarelapagos.ws.dto.WSPagosDTO;
import co.com.pasarelapagos.ws.dto.WSPagosResponseDTO;

/**
 * Clase que implementa los metodos que hacen uso del servicio pagarRBM de la pasarela.
 * @author Henry Hernandez
 * @create 04/01/2019
 * @version 1.0
 */
public class ClientePagoRBMService implements IClientePagoRBMServiceFacade {

	@Override
	public WSPagosResponseDTO initTransactionRbm(WSPagosDTO consulta) throws Exception {
		GatewayPaymentPortProxy proxy = new GatewayPaymentPortProxy();
		SecureRandom codGen = new SecureRandom();
		 Long temporalRqid = codGen.nextLong();
         if (temporalRqid <= 0) {
        	 temporalRqid = temporalRqid*(-1);       
         }
        consulta.setRqUID(temporalRqid);
		consulta.setFechaSolicitud(new Date());
		return proxy.initTransactionRbm(consulta);
	}
	

	  

}