package co.com.pasarelapagos.ws.client.pagarRBM;

import co.com.pasarelapagos.ws.dto.WSPagosDTO;
import co.com.pasarelapagos.ws.dto.WSPagosResponseDTO;

/**
 * Interfaz que define los metodos que hace uso el medio de pago RBM.
 * @author Henry Hernandez
 * @create 04/01/2019
 * @version 1.0
 */
public interface IClientePagoRBMServiceFacade {
	
	/**
	 * Permite enviar la informaci�n de una transacci�n de un pago para que sea registrada en la aplicaci�n de la Pasarela de Pagos.
	 * @param wsInfo WSPagosDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSPagosResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	public WSPagosResponseDTO initTransactionRbm(WSPagosDTO consulta) throws Exception;
	
	//public WSConsultasResponseDTO getStateRBMPayment(WSConsultasDTO consulta) throws Exception;
	

}

