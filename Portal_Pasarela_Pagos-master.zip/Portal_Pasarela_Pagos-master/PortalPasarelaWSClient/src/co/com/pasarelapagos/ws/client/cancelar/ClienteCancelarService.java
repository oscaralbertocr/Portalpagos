package co.com.pasarelapagos.ws.client.cancelar;

import java.security.SecureRandom;
import java.util.Date;

import co.com.pasarelapagos.ws.client.cancelar.proxy.GatewayPaymentAdmPortProxy;
import co.com.pasarelapagos.ws.dto.WSCalcelarDTO;
import co.com.pasarelapagos.ws.dto.WSCancelarResponseDTO;

public class ClienteCancelarService implements IClienteCancelarServiceFacade {

	/**
	 * Metodo encargado de enviar la informaci�n de cancelacion de una transacci�n registrada en la aplicaci�n de la Pasarela de Pagos.
	 * @param transaccion WSCalcelarDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSCancelarResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	@Override
	public WSCancelarResponseDTO modTransactionInfo(WSCalcelarDTO transaccion) throws Exception {
		GatewayPaymentAdmPortProxy proxy = new GatewayPaymentAdmPortProxy();
		
		SecureRandom codGen = new SecureRandom();
		//Soluci�n IM RQIDS Negativos Inicio 
		 Long temporalRqid = codGen.nextLong();
	      
         if (temporalRqid <= 0) {
        	 temporalRqid = temporalRqid*(-1);       
         }
        	transaccion.setRqUID(temporalRqid);
     		transaccion.setFechaSolicitud(new Date());
		return proxy.modTransactionInfo(transaccion);
	}
	   //Soluci�n IM RQIDS Negativos Fin 
	
}
