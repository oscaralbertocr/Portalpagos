package co.com.pasarelapagos.ws.client.consulta;

import java.security.SecureRandom;
import java.util.Date;

import co.com.pasarelapagos.ws.client.consulta.proxy.GatewayPaymentQueriesPortProxy;
import co.com.pasarelapagos.ws.dto.WSConsultasDTO;
import co.com.pasarelapagos.ws.dto.WSConsultasResponseDTO;
import co.com.pasarelapagos.ws.dto.WSRegistroTransacionesDTO;
import co.com.pasarelapagos.ws.dto.WSRegistroTransacionesResponseDTO;

/**
 * Clase que implementa los metodos que hacen uso de los servicios de consultas de la pasarela de pagos.
 * @author ATH
 * @author proveedor_jcramirez
 * @create 21/08/2014
 * @version 1.0
 */
public class ClienteConsultasService implements IClienteConsultasServiceFacade {

	/**
	 * Metodo encargado de consultar una transaccion asociada a un token especifico, por medio de un WS.
	 * @param wsInfo WSConsultasDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSConsultasDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	@Override
	public WSConsultasResponseDTO getTransactionByToken(WSConsultasDTO consulta) throws Exception {
		GatewayPaymentQueriesPortProxy proxy = new GatewayPaymentQueriesPortProxy();
		SecureRandom codGen = new SecureRandom();
		   //Soluci�n IM RQIDS Negativos Inicio 
			 Long temporalRqid = codGen.nextLong();
	         if (temporalRqid <= 0) {
	        	 temporalRqid = temporalRqid*(-1);       
	         }
	        	consulta.setRqUID(temporalRqid);
			consulta.setFechaSolicitud(new Date());
			return proxy.getTransactionByToken(consulta);
		   //Soluci�n IM RQIDS Negativos Fin 
	}

	/**
	 * Metodo encargado de consultar una transaccion asociada a un id especifico, por medio de un WS.
	 * @param wsInfo WSConsultasDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSConsultasResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	@Override
	public WSConsultasResponseDTO getTransactionById(WSConsultasDTO consulta) throws Exception {
		GatewayPaymentQueriesPortProxy proxy = new GatewayPaymentQueriesPortProxy();
		SecureRandom codGen = new SecureRandom();
		   //Soluci�n IM RQIDS Negativos Inicio 
			 Long temporalRqid = codGen.nextLong();
	         if (temporalRqid <= 0) {
	        	 temporalRqid = temporalRqid*(-1);       
	         }
	        	consulta.setRqUID(temporalRqid);
			consulta.setFechaSolicitud(new Date());
			return proxy.getTransactionById(consulta);
		   //Soluci�n IM RQIDS Negativos Fin 
	}

	/**
	 * Metodo encargado de consultar el estado de una transaccion asociada a un id especifico, por medio de un WS.
	 * @param wsInfo WSConsultasDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSConsultasResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	@Override
	public WSConsultasResponseDTO getTransactionStatus(WSConsultasDTO consulta) throws Exception {
		GatewayPaymentQueriesPortProxy proxy = new GatewayPaymentQueriesPortProxy();
		SecureRandom codGen = new SecureRandom();
		   //Soluci�n IM RQIDS Negativos Inicio 
			 Long temporalRqid = codGen.nextLong();
	         if (temporalRqid <= 0) {
	        	 temporalRqid = temporalRqid*(-1);       
	         }
	        	consulta.setRqUID(temporalRqid);
			consulta.setFechaSolicitud(new Date());
			return proxy.getTransactionStatus(consulta);
		   //Soluci�n IM RQIDS Negativos Fin 
	}

	/**
	 * Metodo encargado de consultar la lista de bancos asociados con los pagos PSE de un comercio, por medio de un WS.
	 * @param wsInfo WSConsultasDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSConsultasResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	@Override
	public WSConsultasResponseDTO getBankListByCommerce(WSConsultasDTO consulta) throws Exception {
		GatewayPaymentQueriesPortProxy proxy = new GatewayPaymentQueriesPortProxy();
		SecureRandom codGen = new SecureRandom();
		   //Soluci�n IM RQIDS Negativos Inicio 
			 Long temporalRqid = codGen.nextLong();
	         if (temporalRqid <= 0) {
	        	 temporalRqid = temporalRqid*(-1);       
	         }
	        	consulta.setRqUID(temporalRqid);
			consulta.setFechaSolicitud(new Date());
			return proxy.getBankList(consulta);
		   //Soluci�n IM RQIDS Negativos Fin 
	}
	
	
	/**
	 * Metodo encargado de consultar la lista de bancos asociados con los pagos PSE de un comercio, por medio de un WS.
	 * @param wsInfo WSConsultasDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSConsultasResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	@Override
	public WSRegistroTransacionesResponseDTO getHistoricTransaction(WSRegistroTransacionesDTO  consulta) throws Exception {
		GatewayPaymentQueriesPortProxy proxy = new GatewayPaymentQueriesPortProxy();
		SecureRandom codGen = new SecureRandom();
		   //Soluci�n IM RQIDS Negativos Inicio 
			 Long temporalRqid = codGen.nextLong();
	         if (temporalRqid <= 0) {
	        	 temporalRqid = temporalRqid*(-1);       
	         }
	        	consulta.setRqUID(temporalRqid);
			consulta.setFechaSolicitud(new Date());
			return proxy.getHistoricTransaction(consulta);
		   //Soluci�n IM RQIDS Negativos Fin 
		
	}
}
