package co.com.pasarelapagos.ws.client.pagos.proxy;
import java.math.BigInteger;
import java.net.URL;
import java.util.GregorianCalendar;
import co.com.portales.common.contants.IConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;
import org.apache.log4j.Logger;
import co.com.pasarelapagos.dto.BancoDTO;
import co.com.pasarelapagos.dto.EstadoPagoDTO;
import co.com.pasarelapagos.dto.TransaccionesDTO;
import co.com.pasarelapagos.ws.client.pagos.types.AgreementInfoType;
import co.com.pasarelapagos.ws.client.pagos.types.BankInfoType;
import co.com.pasarelapagos.ws.client.pagos.types.CardLogicalDataType;
import co.com.pasarelapagos.ws.client.pagos.types.CustNameType;
import co.com.pasarelapagos.ws.client.pagos.types.FeeType;
import co.com.pasarelapagos.ws.client.pagos.types.OrderInfoType;
import co.com.pasarelapagos.ws.client.pagos.types.PersonalDataType;
import co.com.pasarelapagos.ws.client.pagos.types.ReferenceType;
import co.com.pasarelapagos.ws.client.pagos.types.TaxFeeType;
import co.com.pasarelapagos.ws.client.pagos.types.UserIdType;
import co.com.pasarelapagos.ws.dto.WSPagosDTO;
import co.com.pasarelapagos.ws.dto.WSPagosResponseDTO;
import co.com.pasarelapagos.ws.util.WSUtil;
import co.com.portales.common.util.XmlDataHandling;
import static co.com.portales.common.util.UtilidadesTexto.enmascararCorreo;
import static co.com.portales.common.util.UtilidadesTexto.enmascararCVC;
import static co.com.portales.common.util.UtilidadesTexto.enmascararTC;

/**
 * 
 * @author ATH
 * @version 1.0
 * @RQ27850 <strong>Autor</strong> Jonathan Rodriguez </br>
 *          <strong>Cambio de EndPoint en las operaciones definidas en la WSLD</strong>  </br>
 *          <strong>Numero de Cambios</strong> 1</br> <strong>Identificador
 *          corto</strong> C01</br>      
 */

public class GatewayPaymentPortProxy{
	/**
	 * Variable para manejar los logs de la aplicaci�n.
	 */
	private static Logger log = Logger.getLogger(GatewayPaymentPortProxy.class);

    protected Descriptor _descriptor;

    public class Descriptor {
        private co.com.pasarelapagos.ws.client.pagos.proxy.GatewayPaymentService _service = null;
        private co.com.pasarelapagos.ws.client.pagos.proxy.GatewayPayment _proxy = null;
        private Dispatch<Source> _dispatch = null;

        public Descriptor() {
            init();
        }

        public Descriptor(URL wsdlLocation, QName serviceName) {
            _service = new co.com.pasarelapagos.ws.client.pagos.proxy.GatewayPaymentService(wsdlLocation, serviceName);
            initCommon();
        }

        public void init() {
            _service = null;
            _proxy = null;
            _dispatch = null;
            _service = new co.com.pasarelapagos.ws.client.pagos.proxy.GatewayPaymentService();
            initCommon();
        }
        


        private void initCommon() {
            _proxy = _service.getGatewayPaymentPort();
        }

        public co.com.pasarelapagos.ws.client.pagos.proxy.GatewayPayment getProxy() {
            return _proxy;
        }

        public Dispatch<Source> getDispatch() {
            if (_dispatch == null ) {
                QName portQName = new QName("urn://ath.com.co/payments/v1/", "GatewayPaymentPort");
                _dispatch = _service.createDispatch(portQName, Source.class, Service.Mode.MESSAGE);

                String proxyEndpointUrl = getEndpoint();
                BindingProvider bp = (BindingProvider) _dispatch;
                String dispatchEndpointUrl = (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
                if (!dispatchEndpointUrl.equals(proxyEndpointUrl))
                    bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, proxyEndpointUrl);
            }
            return _dispatch;
        }

        public String getEndpoint() {
            BindingProvider bp = (BindingProvider) _proxy;
            return (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
        }

        public void setEndpoint(String endpointUrl) {
            BindingProvider bp = (BindingProvider) _proxy;
            bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);

            if (_dispatch != null ) {
                bp = (BindingProvider) _dispatch;
                bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);
            }
        }

        public void setMTOMEnabled(boolean enable) {
            SOAPBinding binding = (SOAPBinding) ((BindingProvider) _proxy).getBinding();
            binding.setMTOMEnabled(enable);
        }
    }

    public GatewayPaymentPortProxy() {
        _descriptor = new Descriptor();
        _descriptor.setMTOMEnabled(false);
        /** INICIO-C01 **/
        String endpointOperation = WSUtil.getWsdlEndpointOperation("PortalPasarelaConf","EndpointOperationPayment");
      		if(endpointOperation != null && !endpointOperation.equals("")){
      			_getDescriptor().setEndpoint(endpointOperation);
      			}
      		else
      			log.info("\n.. NO EXISTE EL ENDPOINT SOLICITADO EN AL ARCHIVO PROPERTIES PARA EL SERVICIO ");
        /** FIN-C01 **/
    }

    public GatewayPaymentPortProxy(URL wsdlLocation, QName serviceName) {
        _descriptor = new Descriptor(wsdlLocation, serviceName);
        _descriptor.setMTOMEnabled(false);
    }

    public Descriptor _getDescriptor() {
        return _descriptor;
    }
    
    public WSPagosResponseDTO addAVALPayment(WSPagosDTO consulta){
    	WSPagosResponseDTO pagosResponse = null;
    	try{
    		XmlDataHandling xmlDataHandler = new XmlDataHandling();
    		AVALPaymentAddRqType avalPaymentAddRq = dtoToAVALWsRequest(consulta);
    		String correoCliente = "";
    		String correoClientePago = "";
    		int numPersonalData = 0;
    		
    		// Modificacion para enmascarar datos sensibles.
    		if(avalPaymentAddRq.getPersonalData()!=null){
    			for(PersonalDataType persona : avalPaymentAddRq.getPersonalData()){
    				if(persona.getEmailAddr()!= null){
    					numPersonalData++;
    					if(numPersonalData == 1){
    						correoCliente = persona.getEmailAddr();
        					persona.setEmailAddr(enmascararCorreo(correoCliente));
        					avalPaymentAddRq.getPersonalData().set(0 , persona);
    					}else if(numPersonalData == 2){
    						correoClientePago = persona.getEmailAddr();
        					persona.setEmailAddr(enmascararCorreo(correoClientePago));
        					avalPaymentAddRq.getPersonalData().set(1, persona);
    					}	
    				}
    			}
    		}
    		
    		
    		
	    	log.info("\n...EL MENSAJE ENVIADO A INTEGRADOR addAvalPayment ES: \n"
	    	+ "\n wsdlEndPoint: "+_getDescriptor().getEndpoint()+"\n"
	    	+ "\n Service:  "+_getDescriptor()._service+"\n"
	    	+ new String(xmlDataHandler.marshalObject(avalPaymentAddRq)));
	    	
	    	numPersonalData = 0;
	    	// Modificacion para enmascarar datos sensibles.
    		if(avalPaymentAddRq.getPersonalData()!=null){
    			for(PersonalDataType persona : avalPaymentAddRq.getPersonalData()){
    				if(persona.getEmailAddr()!= null){
    					numPersonalData++;
    					if(numPersonalData == 1){
        					persona.setEmailAddr(correoCliente);
        					avalPaymentAddRq.getPersonalData().set(0, persona);
    					}else if(numPersonalData == 2){
        					persona.setEmailAddr(correoClientePago);
        					avalPaymentAddRq.getPersonalData().set(1, persona);
    					}
    				}
    			}
    		}
	    	
	    	AVALPaymentAddRsType avalPaymentAddRs = _getDescriptor().getProxy().addAVALPayment(avalPaymentAddRq);
	    	log.info("\n...EL MENSAJE RECIBIDO DE INTEGRADOR addAvalPayment ES: \n\n" + new String(xmlDataHandler.marshalObject(avalPaymentAddRs)));
	    	pagosResponse = wsResponseToAVALPagosDTO(avalPaymentAddRs);
    	}catch (Exception eExc) {
			log.error("::: ERROR EJECUTANDO addAvalPayment: ", eExc);
			return null;
		}
        return pagosResponse;
    }
    
    public WSPagosResponseDTO addPSETransaction(WSPagosDTO pagosRequest){
    	WSPagosResponseDTO pagoResponse = null;
    	try{
    		XmlDataHandling xmlDataHandler = new XmlDataHandling();
    		PSETransactionAddRqType pseTransactionAddRq = dtoToPSEWsRequest(pagosRequest);
    		String correoCliente = "";
    		String correoClientePago = "";
    		int numPersonalData = 0;
    		
    		if(pseTransactionAddRq.getPersonalData()!=null){
    			for(PersonalDataType persona : pseTransactionAddRq.getPersonalData()){
    				if(persona.getEmailAddr()!= null){
    					numPersonalData++;
    					if(numPersonalData == 1){
    						correoCliente = persona.getEmailAddr();
        					persona.setEmailAddr(enmascararCorreo(correoCliente));
        					pseTransactionAddRq.getPersonalData().set(0, persona);
    					}else if(numPersonalData == 2){
    						correoClientePago = persona.getEmailAddr();
        					persona.setEmailAddr(enmascararCorreo(correoClientePago));
        					pseTransactionAddRq.getPersonalData().set(1, persona);
    					}	
    				}
    			}
    		}
    		
    		log.info("\n...EL MENSAJE ENVIADO A INTEGRADOR addPSETransaction ES: \n" 
    				+ "\n wsdlEndPoint: "+_getDescriptor().getEndpoint()+"\n"
	    			+ "\n Service:  "+_getDescriptor()._service+"\n"
    				+ new String(xmlDataHandler.marshalObject(pseTransactionAddRq)));
	    	
    		numPersonalData = 0;
	    	// Modificacion para enmascarar datos sensibles.
    		if(pseTransactionAddRq.getPersonalData()!=null){
    			for(PersonalDataType persona : pseTransactionAddRq.getPersonalData()){
    				if(persona.getEmailAddr()!= null){
    					numPersonalData++;
    					if(numPersonalData == 1){
        					persona.setEmailAddr(correoCliente);
        					pseTransactionAddRq.getPersonalData().set(0, persona);
    					}else if(numPersonalData == 2){
        					persona.setEmailAddr(correoClientePago);
        					pseTransactionAddRq.getPersonalData().set(1, persona);
    					}
    				}
    			}
    		}
    		
	    	PSETransactionAddRsType pseTransactionAddRs = _getDescriptor().getProxy().addPSETransaction(pseTransactionAddRq);
	    	log.info("\n...EL MENSAJE RECIBIDO DE INTEGRADOR addPSETransaction ES: \n\n" 
	    			+ new String(xmlDataHandler.marshalObject(pseTransactionAddRs)));
	    	pagoResponse = wsResponseToPSEPagosDTO(pseTransactionAddRs);
    	}catch (Exception eExc) {
			log.error("::: ERROR EJECUTANDO addPSETransaction: ", eExc);
			return null;
		}
        return pagoResponse;
    }

    public WSPagosResponseDTO addRBMPayment(WSPagosDTO consulta){
    	WSPagosResponseDTO consultaResponse = null;
    	try{
    		XmlDataHandling xmlDataHandler = new XmlDataHandling();
    		RBMPaymentAddRqType rbmPaymentAddRq = dtoToRBMWsRequest(consulta);
    		String correoCliente = "";
    		String correoClientePago = "";
    		int numPersonalData = 0;
    		
    		if(rbmPaymentAddRq.getPersonalData()!=null){
    			for(PersonalDataType persona : rbmPaymentAddRq.getPersonalData()){
    				if(persona.getEmailAddr()!= null){
    					numPersonalData++;
    					if(numPersonalData == 1){
    						correoCliente = persona.getEmailAddr();
        					persona.setEmailAddr(enmascararCorreo(correoCliente));
        					rbmPaymentAddRq.getPersonalData().set(0, persona);
    					}else if(numPersonalData == 2){
    						correoClientePago = persona.getEmailAddr();
        					persona.setEmailAddr(enmascararCorreo(correoClientePago));
        					rbmPaymentAddRq.getPersonalData().set(1, persona);
    					}	
    				}
    			}
    		}
    		
    		String cvc = rbmPaymentAddRq.getCardLogicalData().getCardVrfyData();
    		rbmPaymentAddRq.getCardLogicalData().setCardVrfyData(enmascararCVC(cvc));
    		String numeroTarjeta = rbmPaymentAddRq.getCardLogicalData().getCardEmbossNum().replaceAll(" ", "");
    		rbmPaymentAddRq.getCardLogicalData().setCardEmbossNum(enmascararTC(numeroTarjeta));
    		
    		log.info("\n...EL MENSAJE ENVIADO A INTEGRADOR addRBMPayment ES: \n" 
    				+ "\n wsdlEndPoint: "+_getDescriptor().getEndpoint()+"\n"
	    			+ "\n Service:  "+_getDescriptor()._service+"\n"
    				+ new String(xmlDataHandler.marshalObject(rbmPaymentAddRq)));
    		
    		numPersonalData = 0;
	    	// Modificacion para enmascarar datos sensibles.
    		if(rbmPaymentAddRq.getPersonalData()!=null){
    			for(PersonalDataType persona : rbmPaymentAddRq.getPersonalData()){
    				if(persona.getEmailAddr()!= null){
    					numPersonalData++;
    					if(numPersonalData == 1){
        					persona.setEmailAddr(correoCliente);
        					rbmPaymentAddRq.getPersonalData().set(0, persona);
    					}else if(numPersonalData == 2){
        					persona.setEmailAddr(correoClientePago);
        					rbmPaymentAddRq.getPersonalData().set(1, persona);
    					}
    				}
    			}
    		}
    		
    		rbmPaymentAddRq.getCardLogicalData().setCardVrfyData(cvc);
    		rbmPaymentAddRq.getCardLogicalData().setCardEmbossNum(numeroTarjeta);
    		
	    	RBMPaymentAddRsType rbmPaymentAddRs = _getDescriptor().getProxy().addRBMPayment(rbmPaymentAddRq);
	    	log.info("\n...EL MENSAJE RECIBIDO DE INTEGRADOR addRBMPayment ES: \n\n" 
	    			+ new String(xmlDataHandler.marshalObject(rbmPaymentAddRs)));
	    	consultaResponse = wsResponseToBRMPagosDTO(rbmPaymentAddRs);
    	}catch (Exception eExc) {
			log.error("::: ERROR EJECUTANDO addRBMPayment: ", eExc);
			return null;
		}
        return consultaResponse;
    }
    
    /**
     * Metodo encargado de setear la informaci�n general (header) para todos los metodos
     * @param consulta
     */
    private RBMPaymentAddRqType dtoToRBMWsRequest(WSPagosDTO consulta){
    	RBMPaymentAddRqType rbmPaymentAddRq = null;
    	
    	try{
    		rbmPaymentAddRq = new RBMPaymentAddRqType();
    		
    		rbmPaymentAddRq.setRqUID(consulta.getRqUID());
    		rbmPaymentAddRq.setChannel(consulta.getChannel());
	    	
	    	GregorianCalendar gregory = new GregorianCalendar();
	    	gregory.setTime(consulta.getFechaSolicitud());
	    	XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);	    	
	    	rbmPaymentAddRq.setClientDt(calendar);
	    	rbmPaymentAddRq.setIPAddr(consulta.getIpOrigen());
	    	
	    	UserIdType userId = new UserIdType();
	    	userId.setCustIdType(consulta.getTransaccion().getUsuario().getTipoDocumento());
	    	userId.setCustIdNum(consulta.getTransaccion().getUsuario().getNoDocumento());
	    	userId.setCustLoginId(consulta.getTransaccion().getUsuario().getUsuario());
	    	rbmPaymentAddRq.setUserId(userId);

	    	rbmPaymentAddRq.setPmtId(consulta.getTransaccion().getPmtId());
	    	
	    	PersonalDataType personalData = new PersonalDataType();
	    	CustNameType custName = new CustNameType();
	    	custName.setLegalName(consulta.getTransaccion().getUsuario().getLegalName());
	    	custName.setFirstName(consulta.getTransaccion().getUsuario().getPrimerNombre());
	    	custName.setMiddleName(consulta.getTransaccion().getUsuario().getSegundoNombre());
	    	custName.setLastName(consulta.getTransaccion().getUsuario().getPrimerApellido());
	    	custName.setSecondLastName(consulta.getTransaccion().getUsuario().getSegundoApellido());
	    	personalData.setGender(consulta.getTransaccion().getUsuario().getGenero());
	    	if(consulta.getTransaccion().getUsuario().getFechaNacimiento()!=null){
	    		gregory = new GregorianCalendar();
		    	gregory.setTime(consulta.getTransaccion().getUsuario().getFechaNacimiento());
		    	calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
		    	personalData.setBirthDt(calendar);
	    	}
	    	
	    	personalData.setCityName(consulta.getTransaccion().getUsuario().getNombreCiudad());
	    	personalData.setStateProvName(consulta.getTransaccion().getUsuario().getNombreDepartamento());
	    	personalData.setCountryName(consulta.getTransaccion().getUsuario().getPais());
	    	personalData.setAddress(consulta.getTransaccion().getUsuario().getDireccion());
	    	personalData.setEmailAddr(consulta.getTransaccion().getUsuario().getCorreoElectronico());
	    	personalData.setPhone(consulta.getTransaccion().getUsuario().getTelefono());
	    	personalData.setCustIdType(consulta.getTransaccion().getUsuario().getTipoDocumento());
	    	personalData.setCustIdNum(consulta.getTransaccion().getUsuario().getNoDocumento());
	    	personalData.setCustName(custName);
	    		    	
	    	//Datos PersonalDataType 2
	    	PersonalDataType personalData2 = new PersonalDataType();
	    	CustNameType custName2 = new CustNameType();
	    	custName2.setFirstName(consulta.getTransaccion().getUsuario().getPrimerNombrePago());
	    	custName2.setMiddleName(consulta.getTransaccion().getUsuario().getSegundoNombrePago());
	    	custName2.setLastName(consulta.getTransaccion().getUsuario().getPrimerApellidoPago());
	    	custName2.setSecondLastName(consulta.getTransaccion().getUsuario().getSegundoApellidoPago());
	    	personalData2.setEmailAddr(consulta.getTransaccion().getUsuario().getCorreoElectronicoPago());
	    	personalData2.setPhone(consulta.getTransaccion().getUsuario().getTelefonoPago());

	    	personalData2.setCustIdType(consulta.getTransaccion().getUsuario().getTipoDocumentoPago());
	    	personalData2.setCustIdNum(consulta.getTransaccion().getUsuario().getNoDocumentoPago());
	    	personalData2.setCustName(custName2);
	    	
	    	rbmPaymentAddRq.getPersonalData().add(personalData);
	    	rbmPaymentAddRq.getPersonalData().add(personalData2);
	    		    	
	    	AgreementInfoType agreement = new AgreementInfoType();
	    	if(consulta.getTransaccion().getComercio()!=null){
	    		agreement.setAgreementId(consulta.getTransaccion().getComercio().getCodigoNura());
	    	}
	    	rbmPaymentAddRq.setAgreementInfo(agreement);
	    	
	    	CardLogicalDataType tarjetaCredito = new CardLogicalDataType();
	    	tarjetaCredito.setBrand(consulta.getRbm().getTarjetaCredito().getFranquicia());
	    	tarjetaCredito.setCardEmbossNum(consulta.getRbm().getTarjetaCredito().getNumeroTarjeta());
	    	gregory = new GregorianCalendar();
	    	gregory.setTime(consulta.getRbm().getTarjetaCredito().getFechaVencimiento());
	    	calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
	    	tarjetaCredito.setExpDt(calendar);
	    	tarjetaCredito.setCardVrfyData(consulta.getRbm().getTarjetaCredito().getCodigoVerificacion());
	    	tarjetaCredito.setName(consulta.getRbm().getTarjetaCredito().getNombreTitular());
	    	rbmPaymentAddRq.setCardLogicalData(tarjetaCredito);
	    	
	    	rbmPaymentAddRq.setInstalamentsNum(BigInteger.valueOf(consulta.getRbm().getNumCuotas()));
	    	
	    	OrderInfoType orderInfo = new OrderInfoType();
	    	orderInfo.setOrderId(Long.valueOf(consulta.getTransaccion().getNumeroOrden()));
	    	orderInfo.setDesc(consulta.getTransaccion().getDescripcion());
	    	if(consulta.getTransaccion().getFechaLimitePago()!=null){
		    	gregory = new GregorianCalendar();
		    	gregory.setTime(consulta.getTransaccion().getFechaLimitePago());
		    	calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
		    	orderInfo.setEndDt(calendar);
	    	}
	    	if(consulta.getTransaccion().getFechaVencimiento()!=null){
		    	gregory = new GregorianCalendar();
		    	gregory.setTime(consulta.getTransaccion().getFechaVencimiento());
		    	calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
		    	orderInfo.setExpDt(calendar);
	    	}
	    	rbmPaymentAddRq.setOrderInfo(orderInfo);
	    	
	    	FeeType fee = new FeeType();
	    	fee.setAmt(consulta.getTransaccion().getValorTotal());
	    	fee.setCurCode(consulta.getTransaccion().getMoneda());
	    	fee.setCurRate(consulta.getTransaccion().getTaza());
	    	rbmPaymentAddRq.setFee(fee);
	    	
	    	TaxFeeType taxFee = new TaxFeeType();
	    	if(consulta.getTransaccion().getImpuesto()!=null){
		    	taxFee.setAmt(consulta.getTransaccion().getImpuesto().getValorImpuesto());
		    	taxFee.setCurCode(consulta.getTransaccion().getImpuesto().getMoneda());
		    	taxFee.setCurRate(consulta.getTransaccion().getImpuesto().getTaza());
	    	}
	    	
	    	rbmPaymentAddRq.setTaxFee(taxFee);
	    	
	    	//RQ25542 MotorDeRiesgosPortal
	    	ReferenceType referenciaDevice = new ReferenceType();
	    	referenciaDevice.setRefId(IConstants.MR_NOM_DEVICE_PRINT);
	    	referenciaDevice.setRefType(consulta.getDevicePrint());
	    	
	    	//RQ25542 MotorDeRiesgosPortal
	    	ReferenceType referenciaCookie = new ReferenceType();
	    	referenciaCookie.setRefId(IConstants.MR_NOM_DEVICE_TOKEN_COOKIE);
	    	referenciaCookie.setRefType(consulta.getDeviceToken());
	    	
	    	ReferenceType referenciaHttpAccept = new ReferenceType();
	    	referenciaHttpAccept.setRefId(IConstants.MR_HEADER_HTTP_ACCEPT);
	    	referenciaHttpAccept.setRefType(consulta.getHttpAccept());
	    	
	    	ReferenceType referenciaHttpAcceptLanguage = new ReferenceType();
	    	referenciaHttpAcceptLanguage.setRefId(IConstants.MR_HEADER_HTTP_ACCEPT_LANG);
	    	referenciaHttpAcceptLanguage.setRefType(consulta.getHttpAcceptLanguage());
	    	
	    	ReferenceType referenciaHttpReferrer = new ReferenceType();
	    	referenciaHttpReferrer.setRefId(IConstants.MR_HEADER_REFERER);
	    	referenciaHttpReferrer.setRefType(consulta.getHttpReferrer());
	    	
	    	ReferenceType referenciaUserAgent = new ReferenceType();
	    	referenciaUserAgent.setRefId(IConstants.MR_HEADER_USER_AGENT);
	    	referenciaUserAgent.setRefType(consulta.getUserAgent());
	    	
	    	
	    	//RQ25542 MotorDeRiesgosPortal
	    	rbmPaymentAddRq.getReference().add(referenciaDevice);
	    	rbmPaymentAddRq.getReference().add(referenciaCookie);
	    	if(referenciaHttpAccept.getRefType() != null && !referenciaHttpAccept.getRefType().isEmpty())
	    		rbmPaymentAddRq.getReference().add(referenciaHttpAccept);
	    	if(referenciaHttpAcceptLanguage.getRefType() != null && !referenciaHttpAcceptLanguage.getRefType().isEmpty())
	    		rbmPaymentAddRq.getReference().add(referenciaHttpAcceptLanguage);
	    	if(referenciaHttpReferrer.getRefType() != null && !referenciaHttpReferrer.getRefType().isEmpty())
	    		rbmPaymentAddRq.getReference().add(referenciaHttpReferrer);
	    	if(referenciaUserAgent.getRefType() != null && !referenciaUserAgent.getRefType().isEmpty())
	    		rbmPaymentAddRq.getReference().add(referenciaUserAgent);
	    	
    	}catch (Exception e) {
			log.error("::: SE PRESENTARON PROBLEMAS AL MOMENTO DE ADICIONAR LA INFORMACION GENERAL DEL MENSAEJE dtoToRBMWsRequest ::: ", e);
		}
    	return rbmPaymentAddRq;
    }
    
    /**
     * Convierte un tipo de dato RBMPaymentAddRsType a uno WSPagosResponseDTO
     * @param transactionInqRs RBMPaymentAddRsType Respuesta del WS que se quiere convertir en un WSPagosResponseDTO 
     * @return WSPagosResponseDTO 
     */
    private WSPagosResponseDTO wsResponseToBRMPagosDTO(RBMPaymentAddRsType rbmPaymentAddRs){
    	WSPagosResponseDTO pagoResponse = new WSPagosResponseDTO();
    	TransaccionesDTO transactionInfo = new TransaccionesDTO();
    	pagoResponse.setStatusCode(rbmPaymentAddRs.getStatusCode());
    	pagoResponse.setStatusDesc(rbmPaymentAddRs.getStatusDesc());
    	pagoResponse.setRqUID(rbmPaymentAddRs.getRqUID());
    	 //RQ25542 Motor de Riego Actualizacion INI
    	pagoResponse.setToken(rbmPaymentAddRs.getToken());
    	 //RQ25542 Motor de Riego Actualizacion FIN
    	try {
    		XmlDataHandling xmlDataHandler = new XmlDataHandling();
        	log.info("ResponseRBM : "+new String(xmlDataHandler.marshalObject(rbmPaymentAddRs)));
			
		} catch (Exception e) {
			log.error(e);
		}
    
    	if(rbmPaymentAddRs.getPmtId()!=null){
	    	try{
	    		transactionInfo.setPmtId(rbmPaymentAddRs.getPmtId());
	    	}catch (Exception e) {
	    		log.error("::: EL ID DE LA TRANSACCION NO ES UN NUMERO VALIDO :::", e);
			}
    	}
    	if(rbmPaymentAddRs.getTransactionStatus()!=null){
    		EstadoPagoDTO estadoTransaccion = new EstadoPagoDTO();
    		if(rbmPaymentAddRs.getTransactionStatus().getTrnStatusCode()!=null){
    			estadoTransaccion.setId(rbmPaymentAddRs.getTransactionStatus().getTrnStatusCode().intValue());
    		}
    		estadoTransaccion.setEstado(rbmPaymentAddRs.getTransactionStatus().getTrnStatusDesc());
    		transactionInfo.setEstadoPago(estadoTransaccion);
    		pagoResponse.setServerStatusCode(String.valueOf(rbmPaymentAddRs.getTransactionStatus().getTrnStatusCode()));
    		pagoResponse.setServerStatusDesc(rbmPaymentAddRs.getTransactionStatus().getTrnStatusDesc());
    		if(rbmPaymentAddRs.getTransactionStatus().getEffDt()!=null){
    			transactionInfo.setFechaPago(rbmPaymentAddRs.getTransactionStatus().getEffDt().toGregorianCalendar().getTime());
    		}
    		transactionInfo.setApprovalId(rbmPaymentAddRs.getTransactionStatus().getApprovalId());
    	}
    	pagoResponse.setTransaccion(transactionInfo);
    	return pagoResponse;
    }
    
    /**
     * Metodo encargado de setear la informaci�n general (header) para todos los metodos
     * @param consulta
     */
    private PSETransactionAddRqType dtoToPSEWsRequest(WSPagosDTO pagosRequest){
    	PSETransactionAddRqType pseTransactionAddRq = null;
    	try{
    		pseTransactionAddRq = new PSETransactionAddRqType();
    		pseTransactionAddRq.setRqUID(pagosRequest.getRqUID());
    		pseTransactionAddRq.setChannel(pagosRequest.getChannel());
	    	
	    	GregorianCalendar gregory = new GregorianCalendar();
	    	gregory.setTime(pagosRequest.getFechaSolicitud());
	    	XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);	    	
	    	pseTransactionAddRq.setClientDt(calendar);
	    	
	    	pseTransactionAddRq.setIPAddr(pagosRequest.getIpOrigen());
	    	
	    	UserIdType userId = new UserIdType();
	    	userId.setCustIdType(pagosRequest.getTransaccion().getUsuario().getTipoDocumento());
	    	userId.setCustIdNum(pagosRequest.getTransaccion().getUsuario().getNoDocumento());
	    	userId.setCustLoginId(pagosRequest.getTransaccion().getUsuario().getUsuario());
	    	pseTransactionAddRq.setUserId(userId);
	    	
	    	pseTransactionAddRq.setPmtId(pagosRequest.getTransaccion().getPmtId());
	    	
	    	PersonalDataType personalData = new PersonalDataType();
	    	CustNameType custName = new CustNameType();
	    	custName.setLegalName(pagosRequest.getTransaccion().getUsuario().getLegalName());
	    	custName.setFirstName(pagosRequest.getTransaccion().getUsuario().getPrimerNombre());
	    	custName.setMiddleName(pagosRequest.getTransaccion().getUsuario().getSegundoNombre());
	    	custName.setLastName(pagosRequest.getTransaccion().getUsuario().getPrimerApellido());
	    	custName.setSecondLastName(pagosRequest.getTransaccion().getUsuario().getSegundoApellido());
	    	personalData.setGender(pagosRequest.getTransaccion().getUsuario().getGenero());
	    	if(pagosRequest.getTransaccion().getUsuario().getFechaNacimiento()!=null){
	    		gregory = new GregorianCalendar();
		    	gregory.setTime(pagosRequest.getTransaccion().getUsuario().getFechaNacimiento());
		    	calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
		    	personalData.setBirthDt(calendar);
	    	}
	    	personalData.setCityName(pagosRequest.getTransaccion().getUsuario().getNombreCiudad());
	    	personalData.setStateProvName(pagosRequest.getTransaccion().getUsuario().getNombreDepartamento());
	    	personalData.setCountryName(pagosRequest.getTransaccion().getUsuario().getPais());
	    	personalData.setAddress(pagosRequest.getTransaccion().getUsuario().getDireccion());
	    	personalData.setEmailAddr(pagosRequest.getTransaccion().getUsuario().getCorreoElectronico());
	    	personalData.setPhone(pagosRequest.getTransaccion().getUsuario().getTelefono());
	    	personalData.setCustIdType(pagosRequest.getTransaccion().getUsuario().getTipoDocumento());
	    	personalData.setCustIdNum(pagosRequest.getTransaccion().getUsuario().getNoDocumento());
	    	personalData.setCustName(custName);
	    		    	
	    	//Datos PersonalDataType 2
	    	PersonalDataType personalData2 = new PersonalDataType();
	    	CustNameType custName2 = new CustNameType();
	    	custName2.setFirstName(pagosRequest.getTransaccion().getUsuario().getPrimerNombrePago());
	    	custName2.setMiddleName(pagosRequest.getTransaccion().getUsuario().getSegundoNombrePago());
	    	custName2.setLastName(pagosRequest.getTransaccion().getUsuario().getPrimerApellidoPago());
	    	custName2.setSecondLastName(pagosRequest.getTransaccion().getUsuario().getSegundoApellidoPago());
	    	personalData2.setEmailAddr(pagosRequest.getTransaccion().getUsuario().getCorreoElectronicoPago());
	    	personalData2.setPhone(pagosRequest.getTransaccion().getUsuario().getTelefonoPago());
	    	personalData2.setCustIdType(pagosRequest.getTransaccion().getUsuario().getTipoDocumentoPago());
	    	personalData2.setCustIdNum(pagosRequest.getTransaccion().getUsuario().getNoDocumentoPago());
	    	personalData2.setCustName(custName2);
	    	
	    	pseTransactionAddRq.getPersonalData().add(personalData);
	    	pseTransactionAddRq.getPersonalData().add(personalData2); 
	    	
	    	pseTransactionAddRq.setUserType(pagosRequest.getTransaccion().getUsuario().getTipoUsuario());
	    	
	    	AgreementInfoType agreement = new AgreementInfoType();
	    	if(pagosRequest.getTransaccion().getComercio()!=null){
	    		agreement.setAgreementId(pagosRequest.getTransaccion().getComercio().getCodigoNura());
	    	}
	    	pseTransactionAddRq.setAgreementInfo(agreement);
	    	
	    	BankInfoType bankInfo = new BankInfoType();
	    	try{
		    	bankInfo.setBankId(pagosRequest.getCuenta().getBanco().getBankId());
		    	bankInfo.setName(pagosRequest.getCuenta().getBanco().getNombre());
	    	}catch (Exception e) {
	    		log.error("::: SE PRESENTARON PROBLEMAS AL MOMENTO DE OBTENER LA INFORMACION DE LA CUENTA dtoToPSEWsRequest ::: ", e);
			}
	    	pseTransactionAddRq.setBankInfo(bankInfo);
	    	
	    	OrderInfoType orderInfo = new OrderInfoType();
	    	orderInfo.setOrderId(Long.valueOf(pagosRequest.getTransaccion().getNumeroOrden()));
	    	orderInfo.setDesc(pagosRequest.getTransaccion().getDescripcion());
	    	if(pagosRequest.getTransaccion().getFechaLimitePago()!=null){
		    	gregory = new GregorianCalendar();
		    	gregory.setTime(pagosRequest.getTransaccion().getFechaLimitePago());
		    	calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
		    	orderInfo.setEndDt(calendar);
	    	}
	    	if(pagosRequest.getTransaccion().getFechaVencimiento()!=null){
		    	gregory = new GregorianCalendar();
		    	gregory.setTime(pagosRequest.getTransaccion().getFechaVencimiento());
		    	calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
		    	orderInfo.setExpDt(calendar);
	    	}
	    	pseTransactionAddRq.setOrderInfo(orderInfo);

	    	FeeType fee = new FeeType();
	    	fee.setAmt(pagosRequest.getTransaccion().getValorTotal());
	    	fee.setCurCode(pagosRequest.getTransaccion().getMoneda());
	    	fee.setCurRate(pagosRequest.getTransaccion().getTaza());
	    	pseTransactionAddRq.setFee(fee);
	    	
	    	TaxFeeType taxFee = new TaxFeeType();
	    	if(pagosRequest.getTransaccion().getImpuesto()!=null){
		    	taxFee.setAmt(pagosRequest.getTransaccion().getImpuesto().getValorImpuesto());
		    	taxFee.setCurCode(pagosRequest.getTransaccion().getImpuesto().getMoneda());
		    	taxFee.setCurRate(pagosRequest.getTransaccion().getImpuesto().getTaza());
	    	}
	    	
	    	pseTransactionAddRq.setTaxFee(taxFee);
	    	
	    	//RQ25542 MotorDeRiesgosPortal
	    	ReferenceType referenciaDevice = new ReferenceType();
	    	referenciaDevice.setRefId(IConstants.MR_NOM_DEVICE_PRINT);
	    	referenciaDevice.setRefType(pagosRequest.getDevicePrint());
	    	
	    	//RQ25542 MotorDeRiesgosPortal
	    	ReferenceType referenciaCookie = new ReferenceType();
	    	referenciaCookie.setRefId(IConstants.MR_NOM_DEVICE_TOKEN_COOKIE);
	    	referenciaCookie.setRefType(pagosRequest.getDeviceToken());
	    	
	    	ReferenceType referenciaHttpAccept = new ReferenceType();
	    	referenciaHttpAccept.setRefId(IConstants.MR_HEADER_HTTP_ACCEPT);
	    	referenciaHttpAccept.setRefType(pagosRequest.getHttpAccept());
	    	
	    	ReferenceType referenciaHttpAcceptLanguage = new ReferenceType();
	    	referenciaHttpAcceptLanguage.setRefId(IConstants.MR_HEADER_HTTP_ACCEPT_LANG);
	    	referenciaHttpAcceptLanguage.setRefType(pagosRequest.getHttpAcceptLanguage());
	    	
	    	ReferenceType referenciaHttpReferrer = new ReferenceType();
	    	referenciaHttpReferrer.setRefId(IConstants.MR_HEADER_REFERER);
	    	referenciaHttpReferrer.setRefType(pagosRequest.getHttpReferrer());
	    	
	    	ReferenceType referenciaUserAgent = new ReferenceType();
	    	referenciaUserAgent.setRefId(IConstants.MR_HEADER_USER_AGENT);
	    	referenciaUserAgent.setRefType(pagosRequest.getUserAgent());
	    	
	    	//RQ25542 MotorDeRiesgosPortal
	    	pseTransactionAddRq.getReference().add(referenciaDevice);
	    	pseTransactionAddRq.getReference().add(referenciaCookie);
	    	
	    	if(referenciaHttpAccept.getRefType() != null && !referenciaHttpAccept.getRefType().isEmpty())
	    		pseTransactionAddRq.getReference().add(referenciaHttpAccept);
	    	if(referenciaHttpAcceptLanguage.getRefType() != null && !referenciaHttpAcceptLanguage.getRefType().isEmpty())
	    		pseTransactionAddRq.getReference().add(referenciaHttpAcceptLanguage);
	    	if(referenciaHttpReferrer.getRefType() != null && !referenciaHttpReferrer.getRefType().isEmpty())
	    		pseTransactionAddRq.getReference().add(referenciaHttpReferrer);
	    	if(referenciaUserAgent.getRefType() != null && !referenciaUserAgent.getRefType().isEmpty())
	    		pseTransactionAddRq.getReference().add(referenciaUserAgent);
	    	
    	}catch (Exception e) {
			log.error("::: SE PRESENTARON PROBLEMAS AL MOMENTO DE ADICIONAR LA INFORMACION GENERAL DEL MENSAEJE setInfoPSE ::: ", e);
		}
    	return pseTransactionAddRq;
    }
    
    /**
     * Convierte un tipo de dato PSETransactionAddRsType a uno WSPagosResponseDTO
     * @param transactionInqRs PSETransactionAddRsType Respuesta del WS que se quiere convertir en un WSPagosResponseDTO 
     * @return WSPagosResponseDTO 
     */
    private WSPagosResponseDTO wsResponseToPSEPagosDTO(PSETransactionAddRsType pseTransactionAddRs){
    	WSPagosResponseDTO pagoResponse = new WSPagosResponseDTO();
    	TransaccionesDTO transactionInfo = new TransaccionesDTO();
    	pagoResponse.setStatusCode(pseTransactionAddRs.getStatusCode());
    	pagoResponse.setStatusDesc(pseTransactionAddRs.getStatusDesc());
    	pagoResponse.setRqUID(pseTransactionAddRs.getRqUID());
    	 //RQ25542 Motor de Riego Actualizacion INI
    	pagoResponse.setToken(pseTransactionAddRs.getToken());
    	 //RQ25542 Motor de Riego Actualizacion FIN
    	BancoDTO banco = new BancoDTO();
    	transactionInfo.setTrazabilityCode(pseTransactionAddRs.getTrazabilityCode());
    	
    	if(pseTransactionAddRs.getTransactionStatus()!=null){
    		EstadoPagoDTO estadoTransaccion = new EstadoPagoDTO();
    		if(pseTransactionAddRs.getTransactionStatus().getTrnStatusCode()!=null){
    			estadoTransaccion.setId(pseTransactionAddRs.getTransactionStatus().getTrnStatusCode().intValue());
    		}
    		estadoTransaccion.setEstado(pseTransactionAddRs.getTransactionStatus().getTrnStatusDesc());
    		transactionInfo.setEstadoPago(estadoTransaccion);
    		pagoResponse.setServerStatusCode(pseTransactionAddRs.getTransactionStatus().getTrnServerStatusCode());
    		pagoResponse.setServerStatusDesc(pseTransactionAddRs.getTransactionStatus().getTrnServerStatusDesc());
    		if(pseTransactionAddRs.getTransactionStatus().getEffDt()!=null){
    			transactionInfo.setFechaPago(pseTransactionAddRs.getTransactionStatus().getEffDt().toGregorianCalendar().getTime());
    		}
    		if(pseTransactionAddRs.getTransactionStatus().getCompensationDt()!=null){
    			transactionInfo.setFechaCompensacion(pseTransactionAddRs.getTransactionStatus().getCompensationDt().toGregorianCalendar().getTime());
    		}
    		transactionInfo.setApprovalId(pseTransactionAddRs.getTransactionStatus().getApprovalId());
    		banco.setApprovalId(pseTransactionAddRs.getTransactionStatus().getApprovalId());
    	}
    	
    	pagoResponse.setTransaccion(transactionInfo);
    	
    	pagoResponse.setPortalURL(pseTransactionAddRs.getPortalURL());
    	
    	pagoResponse.setBanco(banco);

    	return pagoResponse;
    }
    
    /**
     * Metodo encargado de setear la informaci�n general (header) para todos los metodos
     * @param consulta
     */
    private AVALPaymentAddRqType dtoToAVALWsRequest(WSPagosDTO consulta){
    	AVALPaymentAddRqType avalPaymentAddRq = null;
    	
    	try{
    		avalPaymentAddRq = new AVALPaymentAddRqType();
    		avalPaymentAddRq.setRqUID(consulta.getRqUID());
    		avalPaymentAddRq.setChannel(consulta.getChannel());
	    	
	    	GregorianCalendar gregory = new GregorianCalendar();
	    	gregory.setTime(consulta.getFechaSolicitud());
	    	XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);	    	
	    	avalPaymentAddRq.setClientDt(calendar);
	    	avalPaymentAddRq.setIPAddr(consulta.getIpOrigen());
	    	
	    	UserIdType userId = new UserIdType();
	    	userId.setCustIdType(consulta.getTransaccion().getUsuario().getTipoDocumento());
	    	userId.setCustIdNum(consulta.getTransaccion().getUsuario().getNoDocumento());
	    	userId.setCustLoginId(consulta.getTransaccion().getUsuario().getUsuario());
	    	avalPaymentAddRq.setUserId(userId);
	    	
	    	avalPaymentAddRq.setPmtId(consulta.getTransaccion().getPmtId());
	    	
	    	//Datos PersonalDataType 1
	    	PersonalDataType personalData = new PersonalDataType();
	    	CustNameType custName = new CustNameType();
	    	custName.setLegalName(consulta.getTransaccion().getUsuario().getLegalName());
	    	custName.setFirstName(consulta.getTransaccion().getUsuario().getPrimerNombre());
	    	custName.setMiddleName(consulta.getTransaccion().getUsuario().getSegundoNombre());
	    	custName.setLastName(consulta.getTransaccion().getUsuario().getPrimerApellido());
	    	custName.setSecondLastName(consulta.getTransaccion().getUsuario().getSegundoApellido());
	    	personalData.setGender(consulta.getTransaccion().getUsuario().getGenero());
	    	
	    	if(consulta.getTransaccion().getUsuario().getFechaNacimiento()!= null){
	    		gregory = new GregorianCalendar();
		    	gregory.setTime(consulta.getTransaccion().getUsuario().getFechaNacimiento());
		    	calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
		    	personalData.setBirthDt(calendar);
	    	}
	    	
	    	personalData.setCustName(custName);
	    	personalData.setCityName(consulta.getTransaccion().getUsuario().getNombreCiudad());
	    	personalData.setStateProvName(consulta.getTransaccion().getUsuario().getNombreDepartamento());
	    	personalData.setCountryName(consulta.getTransaccion().getUsuario().getPais());
	    	personalData.setAddress(consulta.getTransaccion().getUsuario().getDireccion());
	    	personalData.setEmailAddr(consulta.getTransaccion().getUsuario().getCorreoElectronico());
	    	personalData.setPhone(consulta.getTransaccion().getUsuario().getTelefono());
	    	personalData.setCustIdType(consulta.getTransaccion().getUsuario().getTipoDocumento());
	    	personalData.setCustIdNum(consulta.getTransaccion().getUsuario().getNoDocumento());
	    	
	    	//Datos PersonalDataType 2
	    	PersonalDataType personalData2 = new PersonalDataType();
	    	CustNameType custName2 = new CustNameType();
	    	custName2.setFirstName(consulta.getTransaccion().getUsuario().getPrimerNombrePago());
	    	custName2.setMiddleName(consulta.getTransaccion().getUsuario().getSegundoNombrePago());
	    	custName2.setLastName(consulta.getTransaccion().getUsuario().getPrimerApellidoPago());
	    	custName2.setSecondLastName(consulta.getTransaccion().getUsuario().getSegundoApellidoPago());
	    	personalData2.setCustName(custName2);
	    	personalData2.setEmailAddr(consulta.getTransaccion().getUsuario().getCorreoElectronicoPago());
	    	personalData2.setPhone(consulta.getTransaccion().getUsuario().getTelefonoPago());
	    	personalData2.setCustIdType(consulta.getTransaccion().getUsuario().getTipoDocumentoPago());
	    	personalData2.setCustIdNum(consulta.getTransaccion().getUsuario().getNoDocumentoPago());
	    		    	
    		avalPaymentAddRq.getPersonalData().add(personalData);
    		avalPaymentAddRq.getPersonalData().add(personalData2); 	
	    	
	    	AgreementInfoType agreement = new AgreementInfoType();
	    	if(consulta.getTransaccion().getComercio()!=null){
	    		agreement.setAgreementId(consulta.getTransaccion().getComercio().getCodigoNura());
	    	}
	    	avalPaymentAddRq.setAgreementInfo(agreement);
	    	
	    	BankInfoType bankInfo = new BankInfoType();
	    	try{
		    	bankInfo.setBankId(consulta.getCuenta().getBanco().getBankId());
		    	bankInfo.setName(consulta.getCuenta().getBanco().getNombre());
	    	}catch (Exception e) {
	    		log.error("::: SE PRESENTARON PROBLEMAS AL MOMENTO DE OBTENER LA INFORMACION DE LA CUENTA setGeneralInfoAval ::: ", e);
			}
	    	avalPaymentAddRq.setBankInfo(bankInfo);
	    	
	    	OrderInfoType orderInfo = new OrderInfoType();
	    	orderInfo.setOrderId(Long.valueOf(consulta.getTransaccion().getNumeroOrden()));
	    	orderInfo.setDesc(consulta.getTransaccion().getDescripcion());
	    	if(consulta.getTransaccion().getFechaVencimiento()!=null){
		    	gregory = new GregorianCalendar();
		    	gregory.setTime(consulta.getTransaccion().getFechaVencimiento());
		    	calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
		    	orderInfo.setExpDt(calendar);
	    	}
	    	if(consulta.getTransaccion().getFechaLimitePago()!=null){
		    	gregory = new GregorianCalendar();
		    	gregory.setTime(consulta.getTransaccion().getFechaLimitePago());
		    	calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
		    	orderInfo.setEndDt(calendar);
	    	}
	    	avalPaymentAddRq.setOrderInfo(orderInfo);

	    	FeeType fee = new FeeType();
	    	fee.setAmt(consulta.getTransaccion().getValorTotal());
	    	fee.setCurCode(consulta.getTransaccion().getMoneda());
	    	fee.setCurRate(consulta.getTransaccion().getTaza());
	    	avalPaymentAddRq.setFee(fee);
	    	
	    	TaxFeeType taxFee = new TaxFeeType();
	    	if(consulta.getTransaccion().getImpuesto()!=null){
		    	taxFee.setAmt(consulta.getTransaccion().getImpuesto().getValorImpuesto());
		    	taxFee.setCurCode(consulta.getTransaccion().getImpuesto().getMoneda());
		    	taxFee.setCurRate(consulta.getTransaccion().getImpuesto().getTaza());
	    	}
	    	
	    	avalPaymentAddRq.setTaxFee(taxFee);
	    	
	    	//RQ25542 MotorDeRiesgosPortal
	    	ReferenceType referenciaDevice = new ReferenceType();
	    	referenciaDevice.setRefId(IConstants.MR_NOM_DEVICE_PRINT);
	    	referenciaDevice.setRefType(consulta.getDevicePrint());
	    	
	    	//RQ25542 MotorDeRiesgosPortal
	    	ReferenceType referenciaCookie = new ReferenceType();
	    	referenciaCookie.setRefId(IConstants.MR_NOM_DEVICE_TOKEN_COOKIE);
	    	referenciaCookie.setRefType(consulta.getDeviceToken());
	    	
	    	ReferenceType referenciaHttpAccept = new ReferenceType();
	    	referenciaHttpAccept.setRefId(IConstants.MR_HEADER_HTTP_ACCEPT);
	    	referenciaHttpAccept.setRefType(consulta.getHttpAccept());
	    	
	    	ReferenceType referenciaHttpAcceptLanguage = new ReferenceType();
	    	referenciaHttpAcceptLanguage.setRefId(IConstants.MR_HEADER_HTTP_ACCEPT_LANG);
	    	referenciaHttpAcceptLanguage.setRefType(consulta.getHttpAcceptLanguage());
	    	
	    	ReferenceType referenciaHttpReferrer = new ReferenceType();
	    	referenciaHttpReferrer.setRefId(IConstants.MR_HEADER_REFERER);
	    	referenciaHttpReferrer.setRefType(consulta.getHttpReferrer());
	    	
	    	ReferenceType referenciaUserAgent = new ReferenceType();
	    	referenciaUserAgent.setRefId(IConstants.MR_HEADER_USER_AGENT);
	    	referenciaUserAgent.setRefType(consulta.getUserAgent());
	    	
	    	//RQ25542 MotorDeRiesgosPortal
	    	avalPaymentAddRq.getReference().add(referenciaDevice);
	    	avalPaymentAddRq.getReference().add(referenciaCookie);
	    	
	    	if(referenciaHttpAccept.getRefType() != null && !referenciaHttpAccept.getRefType().isEmpty())
	    		avalPaymentAddRq.getReference().add(referenciaHttpAccept);
	    	if(referenciaHttpAcceptLanguage.getRefType() != null && !referenciaHttpAcceptLanguage.getRefType().isEmpty())
	    		avalPaymentAddRq.getReference().add(referenciaHttpAcceptLanguage);
	    	if(referenciaHttpReferrer.getRefType() != null && !referenciaHttpReferrer.getRefType().isEmpty())
	    		avalPaymentAddRq.getReference().add(referenciaHttpReferrer);
	    	if(referenciaUserAgent.getRefType() != null && !referenciaUserAgent.getRefType().isEmpty())
	    		avalPaymentAddRq.getReference().add(referenciaUserAgent);
	    	
    	}catch (Exception e) {
			log.error("::: SE PRESENTARON PROBLEMAS AL MOMENTO DE ADICIONAR LA INFORMACION GENERAL DEL MENSAEJE setGeneralInfoAval ::: ", e);
		}
    	return avalPaymentAddRq;
    }
    
    /**
     * Convierte un tipo de dato AVALPaymentAddRsType a uno WSPagosResponseDTO
     * @param transactionInqRs AVALPaymentAddRsType Respuesta del WS que se quiere convertir en un WSPagosResponseDTO 
     * @return WSPagosResponseDTO 
     */
    private WSPagosResponseDTO wsResponseToAVALPagosDTO(AVALPaymentAddRsType avalPaymentAddRs){
    	WSPagosResponseDTO pagoResponse = new WSPagosResponseDTO();
    	TransaccionesDTO transactionInfo = new TransaccionesDTO();
    	pagoResponse.setStatusCode(avalPaymentAddRs.getStatusCode());
    	pagoResponse.setStatusDesc(avalPaymentAddRs.getStatusDesc());
    	pagoResponse.setRqUID(avalPaymentAddRs.getRqUID());
    	 //RQ25542 Motor de Riego Actualizacion INI
    	pagoResponse.setToken(avalPaymentAddRs.getToken());
    	 //RQ25542 Motor de Riego Actualizacion FIN
    	if(avalPaymentAddRs.getPmtId()!=null){
	    	try{
	    		transactionInfo.setPmtId(avalPaymentAddRs.getPmtId());
	    	}catch (Exception e) {
	    		log.error("::: EL ID DE LA TRANSACCION NO ES UN NUMERO VALIDO :::", e);
			}
    	}
    	if(avalPaymentAddRs.getTransactionStatus()!=null){
    		EstadoPagoDTO estadoTransaccion = new EstadoPagoDTO();
    		if(avalPaymentAddRs.getTransactionStatus().getTrnStatusCode()!=null){
    			estadoTransaccion.setId(avalPaymentAddRs.getTransactionStatus().getTrnStatusCode().intValue());
    		}
    		estadoTransaccion.setEstado(avalPaymentAddRs.getTransactionStatus().getTrnStatusDesc());
    		transactionInfo.setEstadoPago(estadoTransaccion);
    		pagoResponse.setServerStatusCode(avalPaymentAddRs.getTransactionStatus().getTrnServerStatusCode());
    		pagoResponse.setServerStatusDesc(avalPaymentAddRs.getTransactionStatus().getTrnServerStatusDesc());
    		if(avalPaymentAddRs.getTransactionStatus().getEffDt()!=null){
    			transactionInfo.setFechaPago(avalPaymentAddRs.getTransactionStatus().getEffDt().toGregorianCalendar().getTime());
    		}
    		if(avalPaymentAddRs.getTransactionStatus().getCompensationDt()!=null){
    			transactionInfo.setFechaCompensacion(avalPaymentAddRs.getTransactionStatus().getCompensationDt().toGregorianCalendar().getTime());
    		}
    		transactionInfo.setApprovalId(avalPaymentAddRs.getTransactionStatus().getApprovalId());
    	}
    	pagoResponse.setTransaccion(transactionInfo);
    	return pagoResponse;
    }   
}
