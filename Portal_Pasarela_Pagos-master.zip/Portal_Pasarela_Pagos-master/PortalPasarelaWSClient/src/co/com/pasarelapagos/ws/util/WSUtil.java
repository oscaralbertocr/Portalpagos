package co.com.pasarelapagos.ws.util;

import org.apache.log4j.Logger;

import co.com.portales.common.util.PropertiesLoader;

/**
 * Clase que contiene  metodos de utilidad para el procesamiento del servicio web
 * @author ATH  
 * @author Juan Carlos Ramirez.
 * @version 1.0
 * @create 21/08/2014
 */
public class WSUtil {

	/**
	 * Variable encargada de manejar los logs de la aplicaci�n.
	 */
	private static Logger log = Logger.getLogger(WSUtil.class);
    
    /**
     * M�todo que retorna la localizacion del WSDL del servicio de consultas de pagos seg�n la parametrizacion 
     * @return String, wsdl location
     */
    public static String getWsdlPaymentQueriesLocation(String configDir){
    	String url = "";
    	try{
    		url = PropertiesLoader.getInstance().getProperties(configDir, "webservice.properties").getProperty("wsdlPaymentQueriesLocation");
    	} catch (Exception e) {
    		log.error("::::: ERROR EJECUTANDO getWsdlPaymentQueriesLocation: ",e);
		}
    	return url;
    }
    
    /**
     * M�todo que retorna la localizacion del WSDL del servicio de pagos seg�n la parametrizacion 
     * @return String, wsdl location
     */
    public static String getWsdlPaymentLocation(String configDir){
    	String url = "";
    	try{
    		url = PropertiesLoader.getInstance().getProperties(configDir, "webservice.properties").getProperty("wsdlPaymentLocation");
    	} catch (Exception e) {
    		log.error("::::: ERROR EJECUTANDO getWsdlPaymentQueriesLocation: ",e);
		}
    	return url;
    }
    
    /**
     * 22 de Abril 2015
     * M�todo que retorna la localizacion del WSDL del servicio para la cancelaci�n de la transacci�n seg�n la parametrizacion 
     * @return String, wsdl location
     */
    public static String getWsdlCancelLocation(String configDir){
    	String url = "";
    	try{
    		url = PropertiesLoader.getInstance().getProperties(configDir, "webservice.properties").getProperty("wsdlCancelLocation");
    	} catch (Exception e) {
    		log.error("::::: ERROR EJECUTANDO getWsdlCancelLocation: ",e);
		}
    	return url;
    }
    
    
    /**
     * 13 de septiembre  2018
     * M�todo que retorna el endpoint del servicio gatewayPaymentQueries con la ip del DataPower
     * @return String, wsdl location
     */
    public static String getWsdlEndpointOperation(String configDir, String operation){
    	String url = "";
    	try{
    		url = PropertiesLoader.getInstance().getProperties(configDir, "webservice.properties").getProperty(operation);
    	} catch (Exception e) {
    		log.error("::::: ERROR EJECUTANDO getWsdlEndpointOperation: "+operation,e);
		}
    	return url;
    }
    /**
     * 13 de septiembre  2018
     * M�todo que retorna el endpoint del servicio gatewayPaymentQueries con la ip del DataPower
     * @return String, wsdl location
     */    
    public static String getWsdlPaymentRBMLocation(String configDir){
    	String url = "";
    	try{
    		url = PropertiesLoader.getInstance().getProperties(configDir, "webservice.properties").getProperty("wsdlCancelLocation");
    	} catch (Exception e) {
    		log.error("::::: ERROR EJECUTANDO getWsdlCancelLocation: ",e);
		}
    	return url;
    }
    
}
