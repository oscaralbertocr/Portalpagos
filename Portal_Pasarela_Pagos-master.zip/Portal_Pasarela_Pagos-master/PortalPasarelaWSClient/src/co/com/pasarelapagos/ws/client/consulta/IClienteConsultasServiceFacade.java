package co.com.pasarelapagos.ws.client.consulta;

import co.com.pasarelapagos.ws.dto.WSConsultasDTO;
import co.com.pasarelapagos.ws.dto.WSConsultasResponseDTO;
import co.com.pasarelapagos.ws.dto.WSRegistroTransacionesDTO;
import co.com.pasarelapagos.ws.dto.WSRegistroTransacionesResponseDTO;

/**
 * Interfaz que define los metodos que hacen uso de los servicios de consultas de la pasarela de pagos.
 * @author ATH
 * @author proveedor_jcramirez
 * @create 21/08/2014
 * @version 1.0
 */
public interface IClienteConsultasServiceFacade {
	
	/**
	 * Metodo encargado de consultar una transaccion asociada a un token especifico, por medio de un WS.
	 * @param wsInfo WSConsultasDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSConsultasResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	public WSConsultasResponseDTO getTransactionByToken(WSConsultasDTO consulta) throws Exception;
	
	/**
	 * Metodo encargado de consultar una transaccion asociada a un id especifico, por medio de un WS.
	 * @param wsInfo WSConsultasDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSConsultasResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	public WSConsultasResponseDTO getTransactionById(WSConsultasDTO consulta) throws Exception;
	
	/**
	 * Metodo encargado de consultar el estado de una transaccion asociada a un id especifico, por medio de un WS.
	 * @param wsInfo WSConsultasDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSConsultasResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	public WSConsultasResponseDTO getTransactionStatus(WSConsultasDTO consulta) throws Exception;
	
	/**
	 * Metodo encargado de consultar la lista de bancos asociados con los pagos PSE de un comercio, por medio de un WS.
	 * @param wsInfo WSConsultasDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSConsultasResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	public WSConsultasResponseDTO getBankListByCommerce(WSConsultasDTO consulta) throws Exception;
	/**
	 * Metodo encargado de consultar el hitorico de las transacciones 
	 * @param wsInfo WSConsultasDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSConsultasResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	public WSRegistroTransacionesResponseDTO getHistoricTransaction(WSRegistroTransacionesDTO  consulta)
			throws Exception;

}
