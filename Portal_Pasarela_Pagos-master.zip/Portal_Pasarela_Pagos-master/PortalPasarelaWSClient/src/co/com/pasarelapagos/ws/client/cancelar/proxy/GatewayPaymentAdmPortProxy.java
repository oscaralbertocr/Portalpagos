package co.com.pasarelapagos.ws.client.cancelar.proxy;

import java.net.URL;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;

import org.apache.log4j.Logger;

import co.com.pasarelapagos.dto.TransaccionesDTO;
import co.com.pasarelapagos.ws.client.cancelar.types.TransactionStatusType;
import co.com.pasarelapagos.ws.dto.WSCalcelarDTO;
import co.com.pasarelapagos.ws.dto.WSCancelarResponseDTO;
import co.com.pasarelapagos.ws.util.WSUtil;
import co.com.portales.common.util.XmlDataHandling;

/**
 * 
 * @author ATH
 * @version 1.0
 * @RQ27850 <strong>Autor</strong> Jonathan Rodriguez </br>
 *          <strong>Cambio de EndPoint en las operaciones definidas en la WSLD</strong>  </br>
 *          <strong>Numero de Cambios</strong> 1</br> <strong>Identificador
 *          corto</strong> C01</br>      
 */

public class GatewayPaymentAdmPortProxy{

	/**
	 * Variable para manejar los logs de la aplicaci�n.
	 */
	private static Logger log = Logger.getLogger(GatewayPaymentAdmPortProxy.class);
	
    protected Descriptor _descriptor;

    public class Descriptor {
    	private GatewayPaymentAdmService _service = null;
        private GatewayPaymentAdm _proxy = null;
        private Dispatch<Source> _dispatch = null;

        public Descriptor() {
            init();
        }

        public Descriptor(URL wsdlLocation, QName serviceName) {
            _service = new GatewayPaymentAdmService(wsdlLocation, serviceName);
            initCommon();
        }

        public void init() {
            _service = null;
            _proxy = null;
            _dispatch = null;
            _service = new GatewayPaymentAdmService();
            initCommon();
        }

        private void initCommon() {
            _proxy = _service.getGatewayPaymentAdmPort();
        }

        public GatewayPaymentAdm getProxy() {
            return _proxy;
        }

        public Dispatch<Source> getDispatch() {
            if (_dispatch == null ) {
                QName portQName = new QName("urn://ath.com.co/payments/v1/", "GatewayPaymentAdmPort");
                _dispatch = _service.createDispatch(portQName, Source.class, Service.Mode.MESSAGE);

                String proxyEndpointUrl = getEndpoint();
                BindingProvider bp = (BindingProvider) _dispatch;
                String dispatchEndpointUrl = (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
                if (!dispatchEndpointUrl.equals(proxyEndpointUrl))
                    bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, proxyEndpointUrl);
            }
            return _dispatch;
        }

        public String getEndpoint() {
            BindingProvider bp = (BindingProvider) _proxy;
            return (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
        }

        public void setEndpoint(String endpointUrl) {
            BindingProvider bp = (BindingProvider) _proxy;
            bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);

            if (_dispatch != null ) {
                bp = (BindingProvider) _dispatch;
                bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);
            }
        }

        public void setMTOMEnabled(boolean enable) {
            SOAPBinding binding = (SOAPBinding) ((BindingProvider) _proxy).getBinding();
            binding.setMTOMEnabled(enable);
        }
    }

    public GatewayPaymentAdmPortProxy() {
        _descriptor = new Descriptor();
        _descriptor.setMTOMEnabled(false);
        /** INICIO-C01 **/
        String endpointOperation = WSUtil.getWsdlEndpointOperation("PortalPasarelaConf","EndpointCancelLocation");
      		if(endpointOperation != null && !endpointOperation.equals("")){
      			_getDescriptor().setEndpoint(endpointOperation);
      			}
      		else
      			log.info("\n.. NO EXISTE EL ENDPOINT SOLICITADO EN  ARCHIVO PROPERTIES PARA EL SERVICIO ");
        /** FIN-C01 **/
    }

    public GatewayPaymentAdmPortProxy(URL wsdlLocation, QName serviceName) {
        _descriptor = new Descriptor(wsdlLocation, serviceName);
        _descriptor.setMTOMEnabled(false);
    }

    public Descriptor _getDescriptor() {
        return _descriptor;
    }
    
    public WSCancelarResponseDTO modTransactionInfo(WSCalcelarDTO cancelarRequest){
    	WSCancelarResponseDTO cancelarResponse = null;
    	try{
    		XmlDataHandling xmlDataHandler = new XmlDataHandling();
    		TransactionInfoModRqType transactionInfoModRq = dtoToCancelarWsRequest(cancelarRequest);
    		log.info("\n...EL MENSAJE ENVIADO A INTEGRADOR modTransactionInfo ES: \n" 
    		+ "\n wsdlEndPoint: "+_getDescriptor().getEndpoint()+"\n"
        	+ "\n Service:  "+_getDescriptor()._service+"\n"
    		+ new String(xmlDataHandler.marshalObject(transactionInfoModRq)));
    		// Modificacion para enmascarar datos sensibles.
    		
    		TransactionInfoModRsType transactionInfoModRs = _getDescriptor().getProxy().modTransactionInfo(transactionInfoModRq);
	    	
    		log.info("\n...EL MENSAJE RECIBIDO DE INTEGRADOR modTransactionInfo ES: \n\n" + new String(xmlDataHandler.marshalObject(transactionInfoModRs)));
	    	
    		cancelarResponse = wsResponseToCancelarDTO(transactionInfoModRs);
    	}catch (Exception exc) {
			log.error("::: ERROR EJECUTANDO modTransactionInfo ::: ", exc);
			return null;
		}
		return cancelarResponse;    	
    }
    
    /**
     * Metodo encargado de setear la informaci�n general (header) para todos los metodos
     * @param cancelar
     */
    private TransactionInfoModRqType dtoToCancelarWsRequest(WSCalcelarDTO cancelarRequest){
    	TransactionInfoModRqType transactionInfoModRq = null;
    	
    	try{
    		transactionInfoModRq = new TransactionInfoModRqType();
    		transactionInfoModRq.setRqUID(cancelarRequest.getRqUID());
    		transactionInfoModRq.setChannel(cancelarRequest.getChannel());
    		
    		GregorianCalendar gregory = new GregorianCalendar();
	    	gregory.setTime(cancelarRequest.getFechaSolicitud());
	    	XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);	    	
	    	transactionInfoModRq.setClientDt(calendar);
	    	
	    	transactionInfoModRq.setIPAddr(cancelarRequest.getIpOrigen());
	    	transactionInfoModRq.setPmtId(cancelarRequest.getTransaccion().getPmtId());
	    	
	    	TransactionStatusType transactionStatusType = new TransactionStatusType();
	    	transactionStatusType.setTrnStatusCode(cancelarRequest.getStatusCode());
	    	transactionStatusType.setTrnStatusDesc(cancelarRequest.getStatusDesc());
	    	transactionStatusType.setTrnServerStatusCode(cancelarRequest.getServerStatusCode());
	    	transactionStatusType.setTrnServerStatusDesc(cancelarRequest.getServerStatusDesc());
	    	transactionInfoModRq.setTransactionStatus(transactionStatusType);
    		
    	}catch (Exception e) {
			log.error("::: SE PRESENTARON PROBLEMAS AL MOMENTO DE ADICIONAR LA INFORMACION GENERAL DEL MENSAEJE dtoToCancelarWsRequest ::: ", e);
		}
    	
		return transactionInfoModRq;
    }
    
    /**
     * Convierte un tipo de dato TransactionInfoModRsType a uno WSCancWSCancelarResponseDTOelarResponseDTO
     * @param transactionInfoModRs TransactionInfoModRsType Respuesta del WS que se quiere convertir en un WSCancelarResponseDTO 
     * @return WSCancelarResponseDTO 
     */
    private WSCancelarResponseDTO wsResponseToCancelarDTO(TransactionInfoModRsType transactionInfoModRs){
    	WSCancelarResponseDTO cancelarResponse = null;
    	
    	try{
    		cancelarResponse = new WSCancelarResponseDTO(); 
    		cancelarResponse.setStatusCode(transactionInfoModRs.getStatusCode());
        	cancelarResponse.setStatusDesc(transactionInfoModRs.getStatusDesc());
        	cancelarResponse.setRqUID(transactionInfoModRs.getRqUID());
        	cancelarResponse.setServerStatusCode(transactionInfoModRs.getTransactionStatus().getTrnServerStatusCode());
        	cancelarResponse.setServerStatusDesc(transactionInfoModRs.getTransactionStatus().getTrnServerStatusDesc());
        	
        	TransaccionesDTO transactionInfo = new TransaccionesDTO();
        	transactionInfo.setPmtId(transactionInfoModRs.getPmtId());
    		
    	}catch (Exception e) {
			log.error("::: SE PRESENTARON PROBLEMAS AL MOMENTO DE ADICIONAR LA INFORMACION GENERAL DEL MENSAEJE dtoToCancelarWsRequest ::: ", e);
		}   	
    	
		return cancelarResponse;
    }
}
