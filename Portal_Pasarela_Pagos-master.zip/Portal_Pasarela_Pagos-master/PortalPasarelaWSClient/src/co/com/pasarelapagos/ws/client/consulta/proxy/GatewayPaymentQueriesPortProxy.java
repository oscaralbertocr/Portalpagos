package co.com.pasarelapagos.ws.client.consulta.proxy;

import static co.com.portales.common.util.UtilidadesTexto.enmascararCorreo;

import java.net.URL;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;
import org.apache.log4j.Logger;
import co.com.pasarelapagos.dto.BancoDTO;
import co.com.pasarelapagos.dto.ComercioDTO;
import co.com.pasarelapagos.dto.ConfiguracionDTO;
import co.com.pasarelapagos.dto.DatosPlantillaDTO;
import co.com.pasarelapagos.dto.EstadoPagoDTO;
import co.com.pasarelapagos.dto.ImpuestoDTO;
import co.com.pasarelapagos.dto.MedioPagoDTO;
import co.com.pasarelapagos.dto.PlantillaDTO;
import co.com.pasarelapagos.dto.TarjetaCreditoDTO;
import co.com.pasarelapagos.dto.TransaccionesDTO;
import co.com.pasarelapagos.dto.UsuarioDTO;
import co.com.pasarelapagos.ws.client.consulta.types.BankInfoType;
import co.com.pasarelapagos.ws.client.consulta.types.InvoiceReferenceType;
import co.com.pasarelapagos.ws.client.consulta.types.PmtWayType;
import co.com.pasarelapagos.ws.client.consulta.types.RecordTransactionInfoType;
import co.com.pasarelapagos.ws.client.consulta.types.ReferenceType;
import co.com.pasarelapagos.ws.client.consulta.types.UserIdType;
import co.com.pasarelapagos.ws.dto.WSConsultasDTO;
import co.com.pasarelapagos.ws.dto.WSConsultasResponseDTO;
import co.com.pasarelapagos.ws.dto.WSRegistroTransacionesDTO;
import co.com.pasarelapagos.ws.dto.WSRegistroTransacionesResponseDTO;
import co.com.pasarelapagos.ws.util.WSUtil;
import co.com.portales.common.contants.IConstants;
import co.com.portales.common.util.XmlDataHandling;

/**
 * 
 * @author ATH
 * @version 1.0
 * @RQ27850 <strong>Autor</strong> Jonathan Rodriguez </br>
 *          <strong>Cambio de EndPoint en las operaciones definidas en la WSLD</strong>  </br>
 *          <strong>Numero de Cambios</strong> 1</br> <strong>Identificador
 *          corto</strong> C01</br>      
 */

public class GatewayPaymentQueriesPortProxy{
	/**
	 * Variable para manejar los logs de la aplicaci�n.
	 */
	private static Logger log = Logger.getLogger(GatewayPaymentQueriesPortProxy.class);

    protected Descriptor _descriptor;

    public class Descriptor {
        private GatewayPaymentQueriesService _service = null;
        private GatewayPaymentQueries _proxy = null;
        private Dispatch<Source> _dispatch = null;
        

        public Descriptor() {
            init();
        }

        public Descriptor(URL wsdlLocation, QName serviceName) {
            _service = new GatewayPaymentQueriesService(wsdlLocation, serviceName);
            initCommon();
        }

        public void init() {
            _service = null;
            _proxy = null;
            _dispatch = null;
            _service = new GatewayPaymentQueriesService();
            initCommon();
          
            
        }

        private void initCommon() {
            _proxy = _service.getGatewayPaymentQueriesPort();
        }

        public GatewayPaymentQueries getProxy() {
            return _proxy;
        }
        
        
        public Dispatch<Source> getDispatch() {
            if (_dispatch == null ) {
                QName portQName = new QName("urn://ath.com.co/payments/v1/", "GatewayPaymentQueriesPort");
                _dispatch = _service.createDispatch(portQName, Source.class, Service.Mode.MESSAGE);

                String proxyEndpointUrl = getEndpoint();
                BindingProvider bp = (BindingProvider) _dispatch;
                String dispatchEndpointUrl = (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
                if (!dispatchEndpointUrl.equals(proxyEndpointUrl))
                    bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, proxyEndpointUrl);
            }
            return _dispatch;
        }

        public String getEndpoint() {
            BindingProvider bp = (BindingProvider) _proxy;
            return (String) bp.getRequestContext().get(BindingProvider.ENDPOINT_ADDRESS_PROPERTY);
        }

        public void setEndpoint(String endpointUrl) {
            BindingProvider bp = (BindingProvider) _proxy;
            bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);

            if (_dispatch != null ) {
                bp = (BindingProvider) _dispatch;
                bp.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointUrl);
            }
        }

        public void setMTOMEnabled(boolean enable) {
            SOAPBinding binding = (SOAPBinding) ((BindingProvider) _proxy).getBinding();
            binding.setMTOMEnabled(enable);
        }
    }

    public GatewayPaymentQueriesPortProxy() {
        _descriptor = new Descriptor();
        _descriptor.setMTOMEnabled(false);
        /** INICIO-C01 **/
        String endpointOperation = WSUtil.getWsdlEndpointOperation("PortalPasarelaConf","EndpointOperationQueries");
		if(endpointOperation != null && !endpointOperation.equals("")){
			_getDescriptor().setEndpoint(endpointOperation);
			}
		else
			log.info("\n.. NO EXISTE EL ENDPOINT SOLICITADO EN AL ARCHIVO PROPERTIES PARA EL SERVICIO ");
	/** FIN-C01 **/
    }

    public GatewayPaymentQueriesPortProxy(URL wsdlLocation, QName serviceName) {
        _descriptor = new Descriptor(wsdlLocation, serviceName);
        _descriptor.setMTOMEnabled(false);
    }

    public Descriptor _getDescriptor() {
        return _descriptor;
    }
    
    /**
	 * Metodo encargado de consultar una transaccion asociada a un token especifico, por medio de un WS.
	 * @param wsInfo WSConsultasDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSConsultasResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
    public WSConsultasResponseDTO getTransactionByToken(WSConsultasDTO consulta) {
    	WSConsultasResponseDTO consultaResponse = null;
    	try{
    		XmlDataHandling xmlDataHandler = new XmlDataHandling();
	    	TransactionInqRqType transactionInqRq = setGeneralInfo(consulta);
	    	transactionInqRq.setToken(consulta.getTransaccion().getToken());
	    	log.info("\n...EL MENSAJE ENVIADO A INTEGRADOR getTransactionByToken ES: " 
	    			+ "\n wsdlEndPoint: "+_getDescriptor().getEndpoint()
	    			+ "\n Service:  "+_getDescriptor()._service+"\n"
	    			+ new String(xmlDataHandler.marshalObject(transactionInqRq)));
	    	TransactionInqRsType transactionInqRs = _getDescriptor().getProxy().getTransactionByToken(transactionInqRq);
	    	String correoBeneficiario = "";
    		String correoPagador = "";
    		//int numPersonalData = 0;
	    	
	    	 //Modificacion para enmascarar datos sensibles.
    		if(transactionInqRs.getPersonalData()!=null){
    			for(int i= 0; i< transactionInqRs.getPersonalData().size(); i++){
    				if(transactionInqRs.getPersonalData().get(i) != null){
    					if(transactionInqRs.getPersonalData().get(i).getEmailAddr()!= null){
    						if(i == 0){
    							correoBeneficiario = transactionInqRs.getPersonalData().get(i).getEmailAddr();
    							transactionInqRs.getPersonalData().get(i).setEmailAddr(enmascararCorreo(correoBeneficiario));
            					transactionInqRs.getPersonalData().set(i , transactionInqRs.getPersonalData().get(i));
        					}
    						
    						if(i == 1){
    							correoPagador = transactionInqRs.getPersonalData().get(i).getEmailAddr();
    							transactionInqRs.getPersonalData().get(i).setEmailAddr(enmascararCorreo(correoPagador));
            					transactionInqRs.getPersonalData().set(i , transactionInqRs.getPersonalData().get(i));
        					}
    					}
    					
    				}
    			}
    		}
    		
    		log.info("\n...EL MENSAJE RECIBIDO DE INTEGRADOR getTransactionByToken ES: \n\n" 
	    			+ new String(xmlDataHandler.marshalObject(transactionInqRs)));
    		
    		if(transactionInqRs.getPersonalData()!=null){
    			for(int i= 0; i< transactionInqRs.getPersonalData().size(); i++){
    				if(transactionInqRs.getPersonalData().get(i) != null){
    					if(transactionInqRs.getPersonalData().get(i).getEmailAddr()!= null){
    						if(i == 0){
    							transactionInqRs.getPersonalData().get(i).setEmailAddr(correoBeneficiario);
            					transactionInqRs.getPersonalData().set(i , transactionInqRs.getPersonalData().get(i));
        					}
    						
    						if(i == 1){
    							transactionInqRs.getPersonalData().get(i).setEmailAddr(correoPagador);
            					transactionInqRs.getPersonalData().set(i , transactionInqRs.getPersonalData().get(i));
            				}
    					}
    					
    				}
    			}
    		}
    		
	    	consultaResponse = wsResponseToConsultaDTO(transactionInqRs);
    	}catch (Exception eExc) {
			log.error("::: ERROR EJECUTANDO getTransactionByToken: ", eExc);
			return null;
		}
        return consultaResponse;
    }
    
    /**
	 * Metodo encargado de consultar una transaccion asociada a un id especifico, por medio de un WS.
	 * @param wsInfo WSConsultasDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSConsultasResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	public WSConsultasResponseDTO getTransactionById(WSConsultasDTO consulta) {
		WSConsultasResponseDTO consultaResponse = null;
    	try{
    		XmlDataHandling xmlDataHandler = new XmlDataHandling();
    		TransactionInqRqType transactionInqRq = setGeneralInfo(consulta);
	    	transactionInqRq.setPmtId(consulta.getTransaccion().getPmtId());
	    	log.info("\n...EL MENSAJE ENVIADO A INTEGRADOR getTransactionById ES: \n\n" 
	    			+ "\n wsdlEndPoint: "+ _getDescriptor().getEndpoint()
	    			+ "\n Service: "+ _getDescriptor()._service
	    			+ new String(xmlDataHandler.marshalObject(transactionInqRq)
	    			));
	    	TransactionInqRsType transactionInqRs = _getDescriptor().getProxy().getTransactionById(transactionInqRq);
	    	
	    	try{
		    	// Modificacion para enmascarar datos sensibles.
	    		String correoBeneficiario = "";
	    		String correoPagador = "";
	    		//int numPersonalData = 0;
	    		
	    		if(transactionInqRs.getPersonalData()!=null){
	    			for(int i= 0; i< transactionInqRs.getPersonalData().size(); i++){
	    				if(transactionInqRs.getPersonalData().get(i) != null){
	    					if(transactionInqRs.getPersonalData().get(i).getEmailAddr()!= null){
	    						if(i == 0){
	    							correoBeneficiario = transactionInqRs.getPersonalData().get(i).getEmailAddr();
	    							transactionInqRs.getPersonalData().get(i).setEmailAddr(enmascararCorreo(correoBeneficiario));
	            					transactionInqRs.getPersonalData().set(i , transactionInqRs.getPersonalData().get(i));
	        					}
	    						
	    						if(i == 1){
	    							correoPagador = transactionInqRs.getPersonalData().get(i).getEmailAddr();
	    							transactionInqRs.getPersonalData().get(i).setEmailAddr(enmascararCorreo(correoPagador));
	            					transactionInqRs.getPersonalData().set(i , transactionInqRs.getPersonalData().get(i));
	        					}
	    					}
	    					
	    				}
	    			}
	    		}
	    		
	    		log.info("\n...EL MENSAJE RECIBIDO DE INTEGRADOR getTransactionById ES: \n\n" 
		    			+ new String(xmlDataHandler.marshalObject(transactionInqRs)));
	    		
	    		if(transactionInqRs.getPersonalData()!=null){
	    			for(int i= 0; i< transactionInqRs.getPersonalData().size(); i++){
	    				if(transactionInqRs.getPersonalData().get(i) != null){
	    					if(transactionInqRs.getPersonalData().get(i).getEmailAddr()!= null){
	    						if(i == 0){
	    							transactionInqRs.getPersonalData().get(i).setEmailAddr(correoBeneficiario);
	            					transactionInqRs.getPersonalData().set(i , transactionInqRs.getPersonalData().get(i));
	        					}
	    						
	    						if(i == 1){
	    							transactionInqRs.getPersonalData().get(i).setEmailAddr(correoPagador);
	            					transactionInqRs.getPersonalData().set(i , transactionInqRs.getPersonalData().get(i));
	        					}
	    					}
	    					
	    				}
	    			}
	    		}		    	
	    		
	    	}catch (Exception e) {
	    		log.info("\n...EL MENSAJE RECIBIDO DE INTEGRADOR getTransactionById ES: \n\n" 
		    			+ new String(xmlDataHandler.marshalObject(transactionInqRs)));
			}
	    	
	    	consultaResponse = wsResponseToConsultaDTO(transactionInqRs);
    	}catch (Exception eExc) {
			log.error("::: ERROR EJECUTANDO getTransactionById: ", eExc);
			return null;
		}
        return consultaResponse;
    }
	
	/**
	 * Metodo encargado de consultar el estado de una transaccion asociada a un id especifico, por medio de un WS.
	 * @param wsInfo WSConsultasDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSConsultasResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	public WSConsultasResponseDTO getTransactionStatus(WSConsultasDTO consulta){
		WSConsultasResponseDTO consultaResponse = null;
    	try{
    		XmlDataHandling xmlDataHandler = new XmlDataHandling();
    		TransactionStatusInqRqType transactionStatusInqRq = new TransactionStatusInqRqType();
    		transactionStatusInqRq.setRqUID(consulta.getRqUID());
    		transactionStatusInqRq.setChannel(consulta.getChannel());
	    	
	    	GregorianCalendar gregory = new GregorianCalendar();
	    	gregory.setTime(consulta.getFechaSolicitud());
	    	XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
	    	
	    	transactionStatusInqRq.setClientDt(calendar);
	    	transactionStatusInqRq.setIPAddr(consulta.getIpOrigen());
	    	transactionStatusInqRq.setAgreementId(consulta.getTransaccion().getComercio().getCodigoNura());
	    	transactionStatusInqRq.setPmtId(consulta.getTransaccion().getPmtId());
	    	log.info("\n...EL MENSAJE ENVIADO A INTEGRADOR getTransactionStatus ES: \n"
	    			+ "\n wsdlEndPoint: "+_getDescriptor().getEndpoint()
	    			+ "\n Service:  "+_getDescriptor()._service+"\n"
	    			+ new String(xmlDataHandler.marshalObject(transactionStatusInqRq)));
	    	TransactionStatusInqRsType transactionStatusInqRs = _getDescriptor().getProxy().getTransactionStatus(transactionStatusInqRq);
	    	log.info("\n...EL MENSAJE RECIBIDO DE INTEGRADOR getTransactionStatus ES: \n\n" 
	    			+ new String(xmlDataHandler.marshalObject(transactionStatusInqRs)));
	    	consultaResponse = wsResponseToConsultaDTO(transactionStatusInqRs);
    	}catch (Exception eExc) {
			log.error("::: ERROR EJECUTANDO getTransactionStatus: ", eExc);
			return null;
		}
        return consultaResponse;
    }
	
	/**
	 * Metodo encargado de consultar la lista de bancos asociados con los pagos PSE de un comercio, por medio de un WS.
	 * @param wsInfo WSConsultasDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSConsultasResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
    public WSConsultasResponseDTO getBankList(WSConsultasDTO consulta) {
    	WSConsultasResponseDTO consultaResponse = null;
    	try{
    		XmlDataHandling xmlDataHandler = new XmlDataHandling();
    		BankListInqRqType bankListInqRq = new BankListInqRqType();
    		bankListInqRq.setRqUID(consulta.getRqUID());
    		bankListInqRq.setChannel(consulta.getChannel());
	    	
	    	GregorianCalendar gregory = new GregorianCalendar();
	    	gregory.setTime(consulta.getFechaSolicitud());
	    	XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
	    	
	    	bankListInqRq.setClientDt(calendar);
	    	bankListInqRq.setIPAddr(consulta.getIpOrigen());
	    	bankListInqRq.setAgreementId(consulta.getTransaccion().getComercio().getCodigoNura());
	    	bankListInqRq.setNIT(String.valueOf(consulta.getTransaccion().getComercio().getNit()));
	    	log.info("\n...EL MENSAJE ENVIADO A INTEGRADOR getBankList ES: \n"
	    			+ "\n wsdlEndPoint: "+_getDescriptor().getEndpoint()
	    			+ "\n Service:  "+_getDescriptor()._service+"\n"
	    			+ new String(xmlDataHandler.marshalObject(bankListInqRq)));
	    	BankListInqRsType bankListInqRs = _getDescriptor().getProxy().getBankList(bankListInqRq);
	    	log.info("\n...EL MENSAJE RECIBIDO DE INTEGRADOR getBankList ES: \n\n" 
	    			+ new String(xmlDataHandler.marshalObject(bankListInqRs)));
	    	consultaResponse = wsResponseToConsultaDTO(bankListInqRs);
    	}catch (Exception eExc) {
			log.error("::: ERROR EJECUTANDO getBankList: ", eExc);
			return null;
		}
    	
        return consultaResponse;
    }
    
    public WSRegistroTransacionesResponseDTO getHistoricTransaction(WSRegistroTransacionesDTO consulta){
    	
    	WSRegistroTransacionesResponseDTO consultaResponse = null;
    	
    	try{
    		XmlDataHandling xmlDataHandler = new XmlDataHandling();
    		HistoricTransactionInqRqType historicTransactionInqRq = new HistoricTransactionInqRqType();
    		historicTransactionInqRq.setRqUID(consulta.getRqUID());
    		historicTransactionInqRq.setChannel(consulta.getChannel());
    		
    		GregorianCalendar gregory = new GregorianCalendar();
	    	gregory.setTime(consulta.getFechaSolicitud());
	    	XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);

	    	historicTransactionInqRq.setClientDt(calendar);
	    	historicTransactionInqRq.setIPAddr(consulta.getIpOrigen());	    	
	    	
	    	UserIdType userId = new UserIdType();
	    	userId.setCustIdType(consulta.getUsuario().getTipoDocumento());
	    	userId.setCustIdNum(consulta.getUsuario().getNoDocumento());
	    	userId.setCustLoginId(consulta.getUsuario().getUsuario());
	    	historicTransactionInqRq.setUserId(userId);
	    		    	
	    	GregorianCalendar gregoryInicial = new GregorianCalendar();
	    	gregoryInicial.setTime(consulta.getFechaInicial());
	    	XMLGregorianCalendar calendarInicial = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregoryInicial);
	    	historicTransactionInqRq.setStartDt(calendarInicial);
	    	
	    	GregorianCalendar gregoryFinal = new GregorianCalendar();
	    	gregoryFinal.setTime(consulta.getFechaFinal());
	    	XMLGregorianCalendar calendarFinal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregoryFinal);
	    	historicTransactionInqRq.setEndDt(calendarFinal);
	    	
	    	historicTransactionInqRq.setPmtWayId(consulta.getPmtWayId());
		    
	    	log.info("\n...EL MENSAJE ENVIADO A INTEGRADOR getHistoricTransaction ES: \n" 
	    	+ "\n wsdlEndPoint: "+_getDescriptor().getEndpoint()
	    	+ "\n Service:  "+_getDescriptor()._service+"\n"
	    	+ new String(xmlDataHandler.marshalObject(historicTransactionInqRq)));
	    	
	    	HistoricTransactionInqRsType historicTransactionInqRs = _getDescriptor().getProxy().getHistoricTransaction(historicTransactionInqRq);
	    	
	    	log.info("\n...EL MENSAJE RECIBIDO DE INTEGRADOR getHistoricTransaction ES: \n\n" + new String(xmlDataHandler.marshalObject(historicTransactionInqRs)));
	    	
	    	consultaResponse = wsResponseToRegistroTransaccionesDTO(historicTransactionInqRs);
    	}catch (Exception eExc) {
			log.error("::: ERROR EJECUTANDO getHistoricTransaction: ", eExc);
			return null;
		}
    	
        return consultaResponse;    	
    }
    
    /**
     * Convierte un tipo de dato TransactionInqRsType a uno WSConsultasResponseDTO
     * @param transactionInqRs TransactionInqRsType Respuesta del WS que se quiere convertir en un WSConsultasResponseDTO 
     * @return WSConsultasResponseDTO 
     */
    @SuppressWarnings("null")
	private WSConsultasResponseDTO wsResponseToConsultaDTO(TransactionInqRsType transactionInqRs){
    	WSConsultasResponseDTO consultaResponse = new WSConsultasResponseDTO();
    	TransaccionesDTO transactionInfo = new TransaccionesDTO();
    	//RQ26210 Ventanillas de Pago LGNC - Inicio
    	DatosPlantillaDTO datosplantillaInfo = new DatosPlantillaDTO();
    	//RQ26210 Ventanillas de Pago LGNC - Fin
    	ComercioDTO comercioInfo = new ComercioDTO();
    	consultaResponse.setStatusCode(transactionInqRs.getStatusCode());
    	consultaResponse.setStatusDesc(transactionInqRs.getStatusDesc());
    	consultaResponse.setRqUID(transactionInqRs.getRqUID());
    	
    	if(transactionInqRs.getTransactionStatus()!=null){
    		EstadoPagoDTO estadoTransaccion = new EstadoPagoDTO();
    		if(transactionInqRs.getTransactionStatus().getTrnStatusCode()!=null){
    			estadoTransaccion.setId(transactionInqRs.getTransactionStatus().getTrnStatusCode().intValue());
    		}
    		estadoTransaccion.setEstado(transactionInqRs.getTransactionStatus().getTrnStatusDesc());
    		transactionInfo.setEstadoPago(estadoTransaccion);
    		consultaResponse.setServerStatusCode(transactionInqRs.getTransactionStatus().getTrnServerStatusCode());
    		consultaResponse.setServerStatusDesc(transactionInqRs.getTransactionStatus().getTrnServerStatusDesc());
    		if(transactionInqRs.getTransactionStatus().getEffDt()!=null){
    			transactionInfo.setFechaTransaccion(transactionInqRs.getTransactionStatus().getEffDt().toGregorianCalendar().getTime());
    		}
    		transactionInfo.setApprovalId(transactionInqRs.getTransactionStatus().getApprovalId());
    	}
    	
    	UsuarioDTO usuario = new UsuarioDTO();
    	if(transactionInqRs.getUserId()!=null){
			usuario.setTipoDocumento(transactionInqRs.getUserId().getCustIdType());
			usuario.setNoDocumento(transactionInqRs.getUserId().getCustIdNum());
    		usuario.setUsuario(transactionInqRs.getUserId().getCustLoginId());
    	}
    	
    	usuario.setPrimerNombre("");
    	usuario.setSegundoNombre("");
    	usuario.setPrimerApellido("");
    	usuario.setSegundoApellido("");
    	usuario.setPrimerNombrePago("");
    	usuario.setSegundoNombrePago("");
    	usuario.setPrimerApellidoPago("");
    	usuario.setSegundoApellidoPago("");
    	    	
    	//Datos Beneficiario    	
		if(transactionInqRs.getPersonalData()!= null){
			for(int i= 0; i< transactionInqRs.getPersonalData().size(); i++){
				if(transactionInqRs.getPersonalData().get(i) != null){
					if(i == 0){
						if(transactionInqRs.getPersonalData().get(i).getCustName()!= null){
			    			usuario.setLegalName(transactionInqRs.getPersonalData().get(i).getCustName().getLegalName());
			    			
			    			if(transactionInqRs.getPersonalData().get(i).getCustName().getFirstName()!= null){
			    				usuario.setPrimerNombre(transactionInqRs.getPersonalData().get(i).getCustName().getFirstName());
			    			}
			    			if(transactionInqRs.getPersonalData().get(i).getCustName().getMiddleName()!= null){
			    				usuario.setSegundoNombre( transactionInqRs.getPersonalData().get(i).getCustName().getMiddleName());
			    			}
			    			if(transactionInqRs.getPersonalData().get(i).getCustName().getLastName()!= null){
			    				usuario.setPrimerApellido(transactionInqRs.getPersonalData().get(i).getCustName().getLastName());
			    			}
			    			if(transactionInqRs.getPersonalData().get(i).getCustName().getSecondLastName()!= null){
			    				usuario.setSegundoApellido(transactionInqRs.getPersonalData().get(i).getCustName().getSecondLastName());
			    			}
			    		}
						
			    		usuario.setGenero(transactionInqRs.getPersonalData().get(i).getGender());
			    		
			    		if(transactionInqRs.getPersonalData().get(i).getBirthDt()!= null){
			    			usuario.setFechaNacimiento(transactionInqRs.getPersonalData().get(i).getBirthDt().toGregorianCalendar().getTime());
			    		}
			    		
			    		usuario.setNombreCiudad(transactionInqRs.getPersonalData().get(i).getCityName());
			    		usuario.setNombreDepartamento(transactionInqRs.getPersonalData().get(i).getStateProvName());
			    		usuario.setPais(transactionInqRs.getPersonalData().get(i).getCountryName());
			    		usuario.setDireccion(transactionInqRs.getPersonalData().get(i).getAddress());
			    		usuario.setCorreoElectronico(transactionInqRs.getPersonalData().get(i).getEmailAddr());
			    		usuario.setTelefono(transactionInqRs.getPersonalData().get(i).getPhone());
			    		usuario.setTipoDocumento(transactionInqRs.getPersonalData().get(i).getCustIdType());
			    		usuario.setNoDocumento(transactionInqRs.getPersonalData().get(i).getCustIdNum());
					}
					if(i == 1){
						if(transactionInqRs.getPersonalData().get(i).getCustName()!= null){
			    			usuario.setLegalNamePago(transactionInqRs.getPersonalData().get(i).getCustName().getLegalName());

			    			if(transactionInqRs.getPersonalData().get(i).getCustName().getFirstName()!= null){
			    				usuario.setPrimerNombrePago(transactionInqRs.getPersonalData().get(i).getCustName().getFirstName());
			    			}
			    			if(transactionInqRs.getPersonalData().get(i).getCustName().getMiddleName()!= null){
			    				usuario.setSegundoNombrePago( transactionInqRs.getPersonalData().get(i).getCustName().getMiddleName());
			    			}
			    			if(transactionInqRs.getPersonalData().get(i).getCustName().getLastName()!= null){
			    				usuario.setPrimerApellidoPago(transactionInqRs.getPersonalData().get(i).getCustName().getLastName());
			    			}
			    			if(transactionInqRs.getPersonalData().get(i).getCustName().getSecondLastName()!= null){
			    				usuario.setSegundoApellidoPago(transactionInqRs.getPersonalData().get(i).getCustName().getSecondLastName());
			    			}
			    		}
						
			    		usuario.setGeneroPago(transactionInqRs.getPersonalData().get(i).getGender());
			    		
			    		if(transactionInqRs.getPersonalData().get(i).getBirthDt()!= null){
			    			usuario.setFechaNacimientoPago(transactionInqRs.getPersonalData().get(i).getBirthDt().toGregorianCalendar().getTime());
			    		}
			    		
			    		usuario.setNombreCiudadPago(transactionInqRs.getPersonalData().get(i).getCityName());
			    		usuario.setNombreDepartamentoPago(transactionInqRs.getPersonalData().get(i).getStateProvName());
			    		usuario.setPaisPago(transactionInqRs.getPersonalData().get(i).getCountryName());
			    		usuario.setDireccionPago(transactionInqRs.getPersonalData().get(i).getAddress());
			    		usuario.setCorreoElectronicoPago(transactionInqRs.getPersonalData().get(i).getEmailAddr());
			    		usuario.setTelefonoPago(transactionInqRs.getPersonalData().get(i).getPhone());
			    		usuario.setTipoDocumentoPago(transactionInqRs.getPersonalData().get(i).getCustIdType());
			    		usuario.setNoDocumentoPago(transactionInqRs.getPersonalData().get(i).getCustIdNum());
					}					
				}		
			}
		}
    	
		//Datos Referencias
    	int numReferencias = 0;    	
		if(transactionInqRs.getInvoiceReference()!= null){
			for(InvoiceReferenceType referencia : transactionInqRs.getInvoiceReference()){
				if(referencia != null){
					numReferencias++;
					if(numReferencias == 1){
						if(referencia.getPmtCodNIE()!= null){
							transactionInfo.setReferencia1(referencia.getPmtCodNIE());
						}
					}else if(numReferencias == 2){
						if(referencia.getPmtCodNIE()!= null){
							transactionInfo.setReferencia2(referencia.getPmtCodNIE());
							transactionInfo.setMultiplesrefe(referencia.getPmtCodNIE());
						}
					}else if(numReferencias == 3){
						if(referencia.getPmtCodNIE()!= null){
							transactionInfo.setReferencia3(referencia.getPmtCodNIE());
						}
					}else if(numReferencias == 4){
						if(referencia.getPmtCodNIE()!= null){
							transactionInfo.setReferencia4(referencia.getPmtCodNIE());
						}
					}
				}
			}
		}
		
    	transactionInfo.setUsuario(usuario);
    	if(transactionInqRs.getAgreementInfo()!=null){
	    	comercioInfo.setCodigoNura(transactionInqRs.getAgreementInfo().getAgreementId());
	    	comercioInfo.setDescripcion(transactionInqRs.getAgreementInfo().getName());
	    	if(transactionInqRs.getAgreementInfo().getNIT()!=null){
		    	try{
		    		comercioInfo.setNit(Long.parseLong(transactionInqRs.getAgreementInfo().getNIT()));
		    	}catch (Exception e) {
		    		log.error("::: EL NIT DEL COMERCIO NO ES UN NUMERO VALIDO :::", e);
				}
	    	}
	    	comercioInfo.setTelefono(transactionInqRs.getAgreementInfo().getPhone());
    	}
    	if(transactionInqRs.getPmtId()!=null){
	    	try{
	    		transactionInfo.setPmtId(transactionInqRs.getPmtId());
	    	}catch (Exception e) {
	    		log.error("::: EL ID DE LA TRANSACCION NO ES UN NUMERO VALIDO :::", e);
			}
    	}
    	if(transactionInqRs.getOrderInfo()!=null){
    		transactionInfo.setNumeroOrden(String.valueOf(transactionInqRs.getOrderInfo().getOrderId()));
    		transactionInfo.setDescripcion(transactionInqRs.getOrderInfo().getDesc());
    		if(transactionInqRs.getOrderInfo().getExpDt()!=null){
    			transactionInfo.setFechaVencimiento(transactionInqRs.getOrderInfo().getExpDt().toGregorianCalendar().getTime());
    		}
    		if(transactionInqRs.getOrderInfo().getEndDt()!=null){
    			transactionInfo.setFechaLimitePago(transactionInqRs.getOrderInfo().getEndDt().toGregorianCalendar().getTime());
    		}
    	}
    	if(transactionInqRs.getFee()!=null){
    		transactionInfo.setValorTotal(transactionInqRs.getFee().getAmt());
    		transactionInfo.setMoneda(transactionInqRs.getFee().getCurCode());
    		transactionInfo.setTaza(transactionInqRs.getFee().getCurRate());
    	}
    	ImpuestoDTO impuesto = new ImpuestoDTO();
    	if(transactionInqRs.getTaxFee()!=null){
    		impuesto.setValorImpuesto(transactionInqRs.getTaxFee().getAmt());
    		impuesto.setMoneda(transactionInqRs.getTaxFee().getCurCode());
    		impuesto.setTaza(transactionInqRs.getTaxFee().getCurRate());
    	}
    	
    	transactionInfo.setImpuesto(impuesto);
    	
    	if(transactionInqRs.getReference()!=null){
    		try{
    			BancoDTO banco = new BancoDTO();
    			for(ReferenceType referencia : transactionInqRs.getReference()){    				
    				if(referencia.getRefId()!=null && referencia.getRefId().equalsIgnoreCase("BankId")){    					
    					banco.setAch(referencia.getRefType());
    				}else if(referencia.getRefId()!=null && referencia.getRefId().equalsIgnoreCase("CardEmbossNum")){
    					if(transactionInfo.getTarjetaCredito()==null){
	    					TarjetaCreditoDTO tarjeta = new TarjetaCreditoDTO();
	    					tarjeta.setCardEmbossNum(referencia.getRefType());
	    					transactionInfo.setTarjetaCredito(tarjeta);
    					}else{
    						transactionInfo.getTarjetaCredito().setCardEmbossNum(referencia.getRefType());
    					}
    				}else if(referencia.getRefId()!=null && referencia.getRefId().equalsIgnoreCase("Brand")){
    					if(transactionInfo.getTarjetaCredito()==null){
	    					TarjetaCreditoDTO tarjeta = new TarjetaCreditoDTO();
	    					//tarjeta.setFranquicia(IConstants.tiposTarjeta.get(referencia.getRefType()));
	    					tarjeta.setFranquicia(referencia.getRefType());
	    					transactionInfo.setTarjetaCredito(tarjeta);
    					}else{
    						transactionInfo.getTarjetaCredito().setFranquicia(IConstants.tiposTarjeta.get(referencia.getRefType()));
    					}
    				}else if(referencia.getRefId()!=null && referencia.getRefId().equalsIgnoreCase("BankName")){
        				banco.setNombre(referencia.getRefType());
        			}
    				//RQ25542 MotorDeRiesgosPortal
    				else if(referencia.getRefId()!= null && referencia.getRefId().equalsIgnoreCase(IConstants.MR_NOM_DEVICE_TOKEN_COOKIE)){
        				transactionInfo.setDeviceToken(referencia.getRefType()); //DeviceTokenCookie de RSA
        			}else if(referencia.getRefId()!= null && referencia.getRefId().equalsIgnoreCase("Reference1")){
        				transactionInfo.setReferencia1(referencia.getRefType());
        			}else if(referencia.getRefId()!= null && referencia.getRefId().equalsIgnoreCase("Reference2")){
        				transactionInfo.setReferencia2(referencia.getRefType());
        			}else if(referencia.getRefId()!= null && referencia.getRefId().equalsIgnoreCase("Reference3")){
        				transactionInfo.setReferencia3(referencia.getRefType());
        			}
    			}
    			
    			transactionInfo.setBanco(banco);
    		}catch (Exception e) {
    			log.error("::: SE PRESENTARON PROBLEMAS OBTENIENDO LAS REFERENCIAS :::", e);
			}
    	}
    	//RQ26210 Ventanillas de Pago LGNC - Inicio
		if(transactionInqRs.getReference()!=null){
    		try{
    			DatosPlantillaDTO datosplantilla = new DatosPlantillaDTO();
    			for(ReferenceType referencia : transactionInqRs.getReference()){    				
    				if(referencia.getRefId()!= null && referencia.getRefId().equalsIgnoreCase("LogoURL")){
        				datosplantillaInfo.setURLTaquilla(referencia.getRefType());
        				log.info("Variable LogoURL "+ (referencia.getRefType()) );
        			}else if(referencia.getRefId()!= null && referencia.getRefId().equalsIgnoreCase("Theme")){
        				datosplantillaInfo.setTema(referencia.getRefType());
        				log.info("Variable Tema "+ (referencia.getRefType()) );
        			}else if(referencia.getRefId()!= null && referencia.getRefId().equalsIgnoreCase("Template")){
        				datosplantillaInfo.setTaquilla(referencia.getRefType());
        				log.info("Variable Template "+ (referencia.getRefType()) );
        			}
    			}
    			
    			transactionInfo.setDatosPlantillaDTO(datosplantilla);
    		}catch (Exception e) {
    			log.error("::: SE PRESENTARON PROBLEMAS OBTENIENDO LAS REFERENCIAS :::", e);
			}
    		transactionInfo.setDatosPlantillaDTO(datosplantillaInfo);
    	}
		//RQ26210 Ventanillas de Pago LGNC - Fin
    	
    	
    	if(transactionInqRs.getPmtWay()!=null){
    		List<MedioPagoDTO> mediosPagoDTO = new ArrayList<MedioPagoDTO>();
    		for(PmtWayType medioPagoWS : transactionInqRs.getPmtWay()){
    			MedioPagoDTO medioPago = new MedioPagoDTO();
    			if(medioPagoWS.getPmtWayId()!=null){
    				int pmtId = Integer.parseInt(medioPagoWS.getPmtWayId());
    				medioPago.setId(pmtId);
    			}
    			medioPago.setDescripcion(medioPagoWS.getPmtWayType());
    			mediosPagoDTO.add(medioPago);
    		}
    		comercioInfo.setMediosPagoDTO(mediosPagoDTO);
    	}

    	ConfiguracionDTO configuracionDTO = new ConfiguracionDTO();
    	PlantillaDTO plantillaDTO = new PlantillaDTO();
    	if(transactionInqRs.getCommerceSetting()!=null){
    		configuracionDTO.setLogo(transactionInqRs.getCommerceSetting().getLogoURL());
    		configuracionDTO.setTema(transactionInqRs.getCommerceSetting().getTheme());
    		plantillaDTO.setPlantilla(transactionInqRs.getCommerceSetting().getTemplate());
    	}
    	configuracionDTO.setPlantilla(plantillaDTO);
    	comercioInfo.setConfiguracion(configuracionDTO);
    	
    	transactionInfo.setComercio(comercioInfo);
    	
    	consultaResponse.setPortalURL(transactionInqRs.getPortalURL());
    	
    	if(transactionInqRs.getPmtType()!=null){
    		transactionInfo.setTipoPmt(transactionInqRs.getPmtType());
    	}
    	// NEXT DAY 26807 INI 
    	if ((transactionInqRs.getTransactionStatus() != null) && 
    			   (transactionInqRs.getTransactionStatus().getCompensationDt() != null)) {
    			         log.info("::: RESPUESTA SERVICIO Query getTransactionByToken FINAL: Fecha de Compensaci�n: " + transactionInqRs.getTransactionStatus().getCompensationDt());
    			         transactionInfo.setFechaCompensacion(transactionInqRs.getTransactionStatus().getCompensationDt().toGregorianCalendar().getTime());
        }
    	// NEXT DAY 26807 FIN 
    	consultaResponse.setTransaccion(transactionInfo);
    	
    	return consultaResponse;
    }
    
    /**
     * Metodo encargado de setear la informaci�n general (header) para todos los metodos
     * @param consulta
     */
    private TransactionInqRqType setGeneralInfo(WSConsultasDTO consulta){
    	TransactionInqRqType transactionInqRq = null;
    	try{
    		transactionInqRq = new TransactionInqRqType();
	    	transactionInqRq.setRqUID(consulta.getRqUID());
	    	transactionInqRq.setChannel(consulta.getChannel());
	    	
	    	GregorianCalendar gregory = new GregorianCalendar();
	    	gregory.setTime(consulta.getFechaSolicitud());
	    	XMLGregorianCalendar calendar = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregory);
	    	
	    	transactionInqRq.setClientDt(calendar);
	    	transactionInqRq.setIPAddr(consulta.getIpOrigen());
	    	transactionInqRq.setType(consulta.getTipo());
	    	
    	}catch (Exception e) {
			log.error("::: SE PRESENTARON PROBLEMAS AL MOMENTO DE ADICIONAR LA INFORMACION GENERAL DEL MENSAEJE ::: ", e);
		}
    	return transactionInqRq;
    }
    
    /**
     * Convierte un tipo de dato TransactionStatusInqRsType a uno WSConsultasResponseDTO
     * @param transactionInqRs TransactionStatusInqRsType Respuesta del WS que se quiere convertir en un WSConsultasResponseDTO 
     * @return WSConsultasResponseDTO 
     */
    private WSConsultasResponseDTO wsResponseToConsultaDTO(TransactionStatusInqRsType transactionInqRs){
    	WSConsultasResponseDTO consultaResponse = new WSConsultasResponseDTO();
    	TransaccionesDTO transactionInfo = new TransaccionesDTO();
    	consultaResponse.setStatusCode(transactionInqRs.getStatusCode());
    	consultaResponse.setStatusDesc(transactionInqRs.getStatusDesc());
    	consultaResponse.setRqUID(transactionInqRs.getRqUID());
    	
    	if(transactionInqRs.getTransactionStatus()!=null){
    		EstadoPagoDTO estadoTransaccion = new EstadoPagoDTO();
    		if(transactionInqRs.getTransactionStatus().getTrnStatusCode()!=null){
    			estadoTransaccion.setId(transactionInqRs.getTransactionStatus().getTrnStatusCode().intValue());
    		}
    		estadoTransaccion.setEstado(transactionInqRs.getTransactionStatus().getTrnStatusDesc());
    		transactionInfo.setEstadoPago(estadoTransaccion);
    		consultaResponse.setServerStatusCode(transactionInqRs.getTransactionStatus().getTrnServerStatusCode());
    		consultaResponse.setServerStatusDesc(transactionInqRs.getTransactionStatus().getTrnServerStatusDesc());
    		if(transactionInqRs.getTransactionStatus().getEffDt()!=null){
    			transactionInfo.setFechaPago(transactionInqRs.getTransactionStatus().getEffDt().toGregorianCalendar().getTime());
    		}
    		// NEXT DAY 26807 INI 
    		if ((transactionInqRs.getTransactionStatus() != null) && 
    			(transactionInqRs.getTransactionStatus().getCompensationDt() != null)) {
    				log.info("::: RESPUESTA SERVICIO Query Transaction-Status: Fecha de Compensaci�n: " + transactionInqRs.getTransactionStatus().getCompensationDt());
    				transactionInfo.setFechaCompensacion(transactionInqRs.getTransactionStatus().getCompensationDt().toGregorianCalendar().getTime());
    				}
    		// NEXT DAY 26807 FIN
    		transactionInfo.setApprovalId(transactionInqRs.getTransactionStatus().getApprovalId());
    	}
    	
		transactionInfo.setPmtId(transactionInqRs.getPmtId());
    	consultaResponse.setTransaccion(transactionInfo);
    	
    	return consultaResponse;
    }
    
    /**
     * Convierte un tipo de dato BankListInqRsType a uno WSConsultasResponseDTO
     * @param bankListInqRs BankListInqRsType Respuesta del WS que se quiere convertir en un WSConsultasResponseDTO 
     * @return WSConsultasResponseDTO 
     */
    private WSConsultasResponseDTO wsResponseToConsultaDTO(BankListInqRsType bankListInqRs){
    	WSConsultasResponseDTO consultaResponse = new WSConsultasResponseDTO();
    	TransaccionesDTO transactionInfo = new TransaccionesDTO();
    	consultaResponse.setStatusCode(bankListInqRs.getStatusCode());
    	consultaResponse.setStatusDesc(bankListInqRs.getStatusDesc());
    	List<BankInfoType> listaBancos = bankListInqRs.getBankInfo();
    	if(listaBancos!=null){
    		List<BancoDTO> bancos = new ArrayList<BancoDTO>();
    		BancoDTO bancoDTO = null;
    		for(BankInfoType bancoWS : listaBancos){
    			bancoDTO = new BancoDTO();
    			bancoDTO.setBankId(bancoWS.getBankId());
    			bancoDTO.setNombre(bancoWS.getName());
    			bancos.add(bancoDTO);
    		}
    		consultaResponse.setBancos(bancos);
    	}
    	consultaResponse.setTransaccion(transactionInfo);
    	return consultaResponse;
    }
    
    private WSRegistroTransacionesResponseDTO wsResponseToRegistroTransaccionesDTO(HistoricTransactionInqRsType historicTransactionInqRs){
    	WSRegistroTransacionesResponseDTO consultaResponse = new WSRegistroTransacionesResponseDTO();
    	
    	consultaResponse.setRqUID(historicTransactionInqRs.getRqUID());
    	consultaResponse.setStatusCode(historicTransactionInqRs.getStatus().getStatusCode());
    	consultaResponse.setStatusDesc(historicTransactionInqRs.getStatus().getStatusDesc());
    	consultaResponse.setServerStatusCode(historicTransactionInqRs.getStatus().getServerStatusCode());
    	consultaResponse.setServerStatusDesc(historicTransactionInqRs.getStatus().getServerStatusDesc());
    	
    	List<RecordTransactionInfoType> listaTransacciones = historicTransactionInqRs.getRecordTransactionInfo();
    	
    	if(listaTransacciones != null){
    		List<TransaccionesDTO> transacciones = new ArrayList<TransaccionesDTO>();
    		TransaccionesDTO transaccionesDTO = null;
    		for(RecordTransactionInfoType transaccionWS : listaTransacciones){
    			transaccionesDTO = new TransaccionesDTO();
    			transaccionesDTO.setFechaTransaccion(transaccionWS.getEffDt().toGregorianCalendar().getTime());
    			transaccionesDTO.setNumeroOrden(transaccionWS.getRefId());
    			transaccionesDTO.setValorTotal(transaccionWS.getAmt());
    			EstadoPagoDTO estadoTransaccion = new EstadoPagoDTO();
    			estadoTransaccion.setEstado(transaccionWS.getState());
    			transaccionesDTO.setEstadoPago(estadoTransaccion);
    			transaccionesDTO.setTrazabilityCode(transaccionWS.getTrazabilityCode());
    			transaccionesDTO.setPmtId(transaccionWS.getPmtId());
    			transaccionesDTO.setApprovalId(transaccionWS.getApprovalId());
    			transacciones.add(transaccionesDTO);
    		}
    		consultaResponse.setTransacciones(transacciones);
    	}
    	
    	return consultaResponse;
    }
}
