package co.com.pasarelapagos.ws.client.cancelar;

import co.com.pasarelapagos.ws.dto.WSCalcelarDTO;
import co.com.pasarelapagos.ws.dto.WSCancelarResponseDTO;

public interface IClienteCancelarServiceFacade {
	
	/**
	 * Metodo encargado de enviar la informaci�n de cancelacion de una transacci�n registrada en la aplicaci�n de la Pasarela de Pagos.
	 * @param transaccion WSCalcelarDTO Informaci�n necesaria para consumir el servicio.
	 * @return WSCancelarResponseDTO Informaci�n de respuesta del servicio.
	 * @throws Exception Si se presenta algun problema al momento de invocar el servicio.
	 */
	public WSCancelarResponseDTO modTransactionInfo(WSCalcelarDTO transaccion) throws Exception;

}
