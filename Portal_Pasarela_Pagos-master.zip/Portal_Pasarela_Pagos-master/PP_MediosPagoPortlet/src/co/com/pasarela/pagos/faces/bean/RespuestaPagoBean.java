package co.com.pasarela.pagos.faces.bean;
/* @RQ30800 <strong>Autor</strong>Dario Hernandez </br>
*          <strong>Descripcion</strong>Cambiar pocision y estil0 de como se muestra el estado de la transaccion</br> <strong>Numero de
*          Cambios</strong>2</br> <strong>Identificador corto</strong> C10</br>  
*/
import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.portlet.PortletRequest;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import co.com.pasarelapagos.dto.MedioPagoDTO;
import co.com.pasarelapagos.dto.PlantillaDTO;
import co.com.pasarelapagos.dto.TransaccionesDTO;
import co.com.pasarelapagos.dto.UsuarioDTO;
import co.com.pasarelapagos.ws.client.consulta.ClienteConsultasService;
import co.com.pasarelapagos.ws.dto.WSConsultasDTO;
import co.com.pasarelapagos.ws.dto.WSConsultasResponseDTO;
import co.com.pasarelapagos.ws.dto.WSRegistroTransacionesDTO;
import co.com.pasarelapagos.ws.dto.WSRegistroTransacionesResponseDTO;
import co.com.portales.common.contants.IConstants;
import co.com.portales.common.util.PropertiesLoader;
import co.com.portales.common.util.jms.JMSSendUtil;
import co.com.portales.commonweb.util.WebLocator;
import co.com.portalservicio.auditoria.dto.AuditoriaPasarelaMessage;

import com.google.gson.Gson;
import com.ibm.faces20.portlet.httpbridge.PortletRequestWrapper;
import com.ibm.wps.pb.utils.portlet.PortletUtils;

import static co.com.portales.common.util.UtilidadesTexto.enmascararCorreo;

@ManagedBean(name = "respuestaPagoBean")
@ViewScoped
public class RespuestaPagoBean implements Serializable {
	//Constantes tema 1
	String NAME_THEME_ONE = IConstants.NAME_THEME_ONE;
    String NAME_LAYAOUT_THEME_ONE = IConstants.NAME_LAYAOUT_THEME_ONE;
    String CSS_THEME_ONE = IConstants.CSS_THEME_ONE;
    String RESPONSE_LAYAOUT_THEME_ONE = IConstants.RESPONSE_LAYAOUT_THEME_ONE;
	    
    //Constantes tema 2
    String NAME_THEME_TWO = IConstants.NAME_THEME_TWO;
    String NAME_LAYAOUT_THEME_TWO = IConstants.NAME_LAYAOUT_THEME_TWO;
    String CSS_THEME_TWO = IConstants.CSS_THEME_TWO;
    String RESPONSE_LAYAOUT_THEME_TWO = IConstants.RESPONSE_LAYAOUT_THEME_TWO;
    
	/**INICIO-C01**/
	private static final String CODE_NURA_TOKENIZACION = "tokenizacion";
	// Nueva Referencia Principal RQ26727
	private String refprincipal;
	private String codigoNura;
	/**FIN-C01**/
    /**
	 * Constantes creadas RQ26210 Taquillas
	 */
	String ENCABEZADO_DEFAULT;
	String FOOTER_AZUL;
	String FOOTER_ROJO;
	String FOOTER_GRIS;
	String COLOR_AZUL;
	String COLOR_ROJO;
	String COLOR_GRIS;

	Properties propertiesTheme;
	Properties propertiesPlan;
    
  	/**
	 * Variables creadas RQ26210 Taquillas
	 */
	private String template;
	private String theme;
	private String logoUrl;
	private String footer ;
	private String estilocss;
	private String cabezote;
	private boolean templateTaq;
	private boolean footTaq;

	/**
	 * Variables creadas RQ26210 Taquillas
    /**
     /**INICIO-C10**/
	
	private boolean estadoRen1;
	private boolean estadoRen2;
	private boolean estadoRen3;
	
	
    
    public boolean isEstadoRen1() {
		return estadoRen1;
	}


	public void setEstadoRen1(boolean estadoRen1) {
		this.estadoRen1 = estadoRen1;
	}


	public boolean isEstadoRen2() {
		return estadoRen2;
	}


	public void setEstadoRen2(boolean estadoRen2) {
		this.estadoRen2 = estadoRen2;
	}


	public boolean isEstadoRen3() {
		return estadoRen3;
	}


	public void setEstadoRen3(boolean estadoRen3) {
		this.estadoRen3 = estadoRen3;
	}
	
	


	public  void estadoren(){
		
		log.info("::: entro en la funcion :"+this.getResponseWS().getTransaccion().getEstadoPago().getEstado()+":******:");
		log.info("::: entro en la funcion :"+getResponseWS().getTransaccion().getEstadoPago().getEstado()+":******:");
		
		if(this.getResponseWS().getTransaccion().getEstadoPago().getEstado().equalsIgnoreCase("APROBADA") || this.getResponseWS().getTransaccion().getEstadoPago().getId() == 4){
			
			estadoRen1=true;
			
			log.info("::: ingrega a metodo estadoren primer if :"+estadoRen1+":******:");
			
		}else{if(this.getResponseWS().getTransaccion().getEstadoPago().getEstado().equalsIgnoreCase("RECHAZADA")
				|| this.getResponseWS().getTransaccion().getEstadoPago().getEstado().equalsIgnoreCase("FALLIDA")
				|| this.getResponseWS().getTransaccion().getEstadoPago().getEstado().equalsIgnoreCase("NO_AUTORIZADA")
				|| this.getResponseWS().getTransaccion().getEstadoPago().getId() == 2 
				|| this.getResponseWS().getTransaccion().getEstadoPago().getId() == 3
				|| this.getResponseWS().getTransaccion().getEstadoPago().getId() == 6
				)
		
		{
			
			estadoRen2=true;
			
			log.info("::: ingrega a metodo estadoren segundo if :"+estadoRen2+":******:");
			
		}else{if(this.getResponseWS().getTransaccion().getEstadoPago().getEstado().equalsIgnoreCase("PENDIENTE") || this.getResponseWS().getTransaccion().getEstadoPago().getId() == 1){
			
			estadoRen3=true;
			
			log.info("::: ingrega a metodo estadoren tercer if :"+estadoRen3+":******:");
			
		}
			
		}
			
		}
		
	}
	/**FIN-C10**/

	/**
	 * Atributos para saber si se debe mostrar los diferentes  Layaout
	 */
	private String layaoutPortlet;
	
	/**
	 * Atributos para saber si se debe mostrar los diferentes  temas
	 */
	private String themePortlet;
	
	private static final long serialVersionUID = 1L;
	
	/**
	 * Variable encargada de manejar los logs de la aplicaci�n.
	 */
	private static Logger log = Logger.getLogger(RespuestaPagoBean.class);
	
	// Token para transacciones
	private String token;

	/**
	 *  Direcci�n IP desde donde se consulta el resultado de la transaccion
	 */
	private String dirIp;	
	
	private String errorCancel;

	/**
	 * Se almacena la injformacion de respuesta del servicio
	 */
	private WSConsultasResponseDTO responseWS; 
	private WSRegistroTransacionesResponseDTO responseWSRegistroTransaciones;
	/**
	 * Almacena el valor del monto con el formato necesario
	 */
	private BigDecimal monto;
	
	/**
	 * Atributo para saber si se debe mostrar la respuesta para un pago AVAL
	 */
	private boolean renderAval;
	
	/**
	 * Atributo para saber si se debe mostrar la respuesta para un pago Cancelado
	 */
	private boolean renderCancelacion;
	
	/**
	 * Atributo para saber si se debe mostrar el boton de volver
	 */
	private boolean renderBotonVolver;
	
	/**
	 * Atributo para saber si se debe mostrar la respuesta para un pago PSE
	 */
	private boolean renderPSE;
	
	/**
	 * Atributo para saber si se debe mostrar la respuesta para un pago con TC
	 */
	private boolean renderTC;
	
	/**
	 * Atributo para saber si se debe mostrar el mensaje del
	 * pago para el siguiente d�a h�bil
	 */
	private boolean pseSiguienteDiaHabil;

	/**
	 * Atributo para saber si se debe mostrar el panel donde
	 * se muestra el resultado de la compra
	 */
	private boolean renderInfo;
	
	private boolean renderLogo;
	
	
	private List<TransaccionesDTO> transacciones;
	
	private String mensajeErrorGeneral;	
	private String strEstado;	
	private String strError;	
	private String duracionSesion;	
	private String urlRedireccion;
	private String logoComercio;
	
	private boolean renderLabel;	
	private boolean renderCUS;	
	private boolean renderBanco;
	private boolean renderReferencia2;
	private boolean renderReferencia3;
	private boolean renderReferencia4;
	
   private String cookieValue; //RQ25542 MotorDeRiesgosPortal
// Variables Para Multiples Referencias 27225
		private String referencias;
		private List<String> refes; 
	
	public RespuestaPagoBean(){		
		log.info("::: INICIA METODO RespuestaPagoBean() DEL BEAN RespuestaPagoBean :::");
		
		StringBuilder mensajeInfo = new StringBuilder("");
		cargarVariables();
		
		HttpServletRequest requestBase = null;
		HttpServletRequest requestCompleto = null;
		
		FacesContext context = FacesContext.getCurrentInstance();
		requestBase = (HttpServletRequest) context.getExternalContext().getRequest();
		
		PortletRequestWrapper requestWrapper = (PortletRequestWrapper) requestBase;
		PortletRequest portletRequest = requestWrapper.getPortletRequest();
		requestCompleto = PortletUtils.getHttpServletRequest(portletRequest);		
		
		token = requestCompleto.getParameter("token");
		dirIp = getIpAddr(requestCompleto);		
		strError = requestCompleto.getParameter("error");
		
		mensajeInfo.setLength(0);
		mensajeInfo.append("::: TOKEN DE LA TRANSACCION: ");
		mensajeInfo.append(token);
		mensajeInfo.append(" :::\n");
		mensajeInfo.append("::: IP DE LA TRANSACCION: ");
		mensajeInfo.append(dirIp);
		mensajeInfo.append(" :::");
		log.info(mensajeInfo);
		
		ClienteConsultasService cs = new ClienteConsultasService();
		WSConsultasDTO consulta = null;
		WSRegistroTransacionesDTO historicoTransacciones = new WSRegistroTransacionesDTO();
		
		try{
			if(token == null){
				renderInfo = false;
				errorCancel = "1";
				// Auditoria portal pasarela
				auditarAccion(token==null?"NO ENTREGADO":token, dirIp, "Recibir redirect resultado", "N/A", "Mostrar pantalla resultado", "Fallido", "Token no valido");
				log.error("::: TOKEN NO VALIDO " + token + " :::");
				setRenderBotonVolver(true);
				printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO, IConstants.ERROR_TOKEN);
			}else{
				consulta = new WSConsultasDTO();
				TransaccionesDTO transaccionDTO = new TransaccionesDTO();
				transaccionDTO.setToken(token);
				consulta.setTransaccion(transaccionDTO);
				consulta.setIpOrigen(dirIp);
				consulta.setChannel(IConstants.CANAL_PASARELA);
				consulta.setTipo(IConstants.ESTADO_FINAL);
				
				// Auditoria portal pasarela
				auditarAccion(token==null?"NO ENTREGADO":token, dirIp, "Recibir redirect resultado", "N/A", "Mostrar pantalla resultado", "Exitoso", consulta);
				
				try{
					responseWS = cs.getTransactionByToken(consulta);
					/**INICIO-C10**/
					estadoren();
					/**FIN-C10**/
					getTheme();
					getLayaout();
			       //RQ 26210 Taquillas
					CargaTemplate();
					log.info("::: CARGA METODO CargaTemplate() DEL BEAN MediosPagoBean :::");
				}catch (Exception e) {
					log.error("::: ERROR AL CONSULTAR LA TRANSACCION CON TOKEN: " + token + " :::", e);
					errorCancel = "1";
					// Modificacion para enmascarar datos sensibles.
					try{
			    		String correoCliente = responseWS.getTransaccion().getUsuario().getCorreoElectronico();
			    		responseWS.getTransaccion().getUsuario().setCorreoElectronico(enmascararCorreo(correoCliente));    		
			    		// Auditoria portal pasarela
						auditarAccion(token==null?"NO ENTREGADO":token, dirIp, "recibir consulta transacci�n resultado", responseWS.getTransaccion().getComercio().getCodigoNura(), "Mostrar pantalla resultado", "Fallido", responseWS);
				    	// Modificacion para enmascarar datos sensibles.
						responseWS.getTransaccion().getUsuario().setCorreoElectronico(correoCliente);
					}catch (Exception eExc) {
						// Auditoria portal pasarela
						auditarAccion(token==null?"NO ENTREGADO":token, dirIp, "recibir consulta transacci�n resultado", responseWS.getTransaccion().getComercio().getCodigoNura(), "Mostrar pantalla resultado", "Fallido", responseWS);
					}
					
					throw e;
				}
				
				if(responseWS == null || responseWS.getStatusCode()!= Long.valueOf(IConstants.SSC_EXITOSO)){
					renderInfo = false;
					errorCancel = "1";
					
					if(responseWS != null){
						if(responseWS.getServerStatusCode()!=null){
							log.error("::: LA RESPUESTA DEL SERVICIO NO FUE SATISFACTORIA ERROR: " + responseWS.getServerStatusCode() + " :::" );
							if(IConstants.SSC_ERROR_TOKEN.equals(responseWS.getServerStatusCode())){
								setRenderBotonVolver(true);
								printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO, IConstants.erroresServer.get(responseWS.getServerStatusCode()));
							}else{
								setRenderBotonVolver(true);
								printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO, mensajeErrorGeneral + " - " + IConstants.erroresServer.get(responseWS.getServerStatusCode()));
							}
						}else{
							log.error("::: LA RESPUESTA DEL SERVICIO FUE NULL :::" );
							setRenderBotonVolver(true);
							printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO, mensajeErrorGeneral);
						}
					}else{
						log.error("::: LA RESPUESTA DEL SERVICIO FUE NULL :::" );
						setRenderBotonVolver(true);
						printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO, mensajeErrorGeneral);
					}
					
				}else{
					
					//Se configura la URL del logo del comercio.
					String urlLogo = responseWS.getTransaccion().getComercio().getConfiguracion().getLogo();
					if(null!=urlLogo && !"".equals(urlLogo)){
						setLogoConvenio(responseWS.getTransaccion().getComercio().getConfiguracion().getLogo());
					}
					
					if(responseWS.getTransaccion().getReferencia2() != null && !("".equals(responseWS.getTransaccion().getReferencia2()))){
						setRenderReferencia2(true);
					}					
					if(responseWS.getTransaccion().getReferencia3() != null && !("".equals(responseWS.getTransaccion().getReferencia3()))){
						setRenderReferencia3(true);
					}					
					if(responseWS.getTransaccion().getReferencia4() != null && !("".equals(responseWS.getTransaccion().getReferencia4()))){
						setRenderReferencia4(true);
					}
					if(responseWS.getTransaccion().getApprovalId() == null){
						setRenderCUS(false);
					}
					if(responseWS.getTransaccion().getBanco().getNombre() == null){
						setRenderBanco(false);
					}				
					if(Integer.valueOf(IConstants.ID_ESTADO_RECHAZADA).equals(responseWS.getTransaccion().getEstadoPago().getId()) || Integer.valueOf(IConstants.ID_ESTADO_FALLIDA).equals(responseWS.getTransaccion().getEstadoPago().getId())){
						setRenderLabel(false);
					}
					//Multiples Referencias 27225
					referencias = responseWS.getTransaccion().getMultiplesrefe();
					log.info("VERIFICACION LLEGADA DATOS" +  responseWS.getTransaccion().getMultiplesrefe());
					//Metodo de Split de Referencias 
					if ((responseWS.getTransaccion().getMultiplesrefe()== null )||(responseWS.getTransaccion().getMultiplesrefe().equals(""))){
						log.info("CONVENIO NO ES MULTIPLES REFERENCIAS");
					}
					else {
					SplitReferences();
						log.info("CONVENIO ES MULTIPLES REFERENCIAS");
					}

					setUrlRedireccion(responseWS.getPortalURL());
					
					if(strError != null)
					{
						log.error("::: LA RESPUESTA DEL SERVICIO NO FUE SATISFACTORIA ERROR:  " + strError + " :::");
						setRenderBotonVolver(true);
						printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO, IConstants.SSC_DESC_ERROR_LISTAS);
					}
					
					if(responseWS.getTransaccion().getComercio().getMediosPagoDTO().get(0).getId()==Integer.valueOf(IConstants.PAGOS_AVAL_ID)){
						renderAval = Boolean.TRUE;
						renderPSE = Boolean.FALSE;
						renderTC = Boolean.FALSE;
					}else if(responseWS.getTransaccion().getComercio().getMediosPagoDTO().get(0).getId()==Integer.valueOf(IConstants.PAGOS_PSE_ID)){
						pseSiguienteDiaHabil = false;
						Calendar calendar = Calendar.getInstance();
						Date fechaFinal = calendar.getTime();
						calendar.add(Calendar.DAY_OF_MONTH, -30);
						Date fechaInicial = calendar.getTime();

						historicoTransacciones.setChannel(IConstants.CANAL_PASARELA);
						historicoTransacciones.setIpOrigen(dirIp);
						historicoTransacciones.setUsuario(responseWS.getTransaccion().getUsuario());
						historicoTransacciones.setFechaInicial(fechaInicial);
						historicoTransacciones.setFechaFinal(fechaFinal);
						historicoTransacciones.setPmtWayId(IConstants.PAGOS_PSE_ID);
						responseWSRegistroTransaciones = cs.getHistoricTransaction(historicoTransacciones);
						transacciones = responseWSRegistroTransaciones.getTransacciones();
					
						renderAval = Boolean.FALSE;
						renderPSE = Boolean.TRUE;
						renderTC = Boolean.FALSE;
						
						strEstado = IConstants.estadosTransacciones.get(String.valueOf(responseWS.getTransaccion().getEstadoPago().getId()));
						// NEXT DAY 26807 INI 						
					   if(strEstado == IConstants.ESTADO_APROBADA || strEstado == IConstants.ESTADO_PENDIENTE){
	                            Date fechaCompensacion = responseWS.getTransaccion().getFechaCompensacion();
	                            mensajeInfo.append(strEstado);
	                            mensajeInfo.append(" ::: La obligacion es el siguiente: ");
	                            mensajeInfo.append(responseWS.getTransaccion().getComercio().getCodigoNura());
	                            log.info(mensajeInfo);
	                            if(fechaCompensacion != null && responseWS.getTransaccion().getComercio().getCodigoNura().startsWith(IConstants.PREFIJO_OBLIGACIONES_BBOG)){
	                                  if(fechaCompensacion.after(new Date())){
	                                	  	mensajeInfo.append("::: Se habilita el mensaje de siguiente d�a habil, la compensationDate es ::: ");
	                                	  	mensajeInfo.append(fechaCompensacion);
	                                        pseSiguienteDiaHabil = true;
	                                  }
	                            }
	                    // NEXT DAY 26807 FIN 
							if(IConstants.ESTADO_PENDIENTE.equals(strEstado)){
								printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO, IConstants.SSC_DESC_TRANSACCION_PENDIENTE);
							}							
						}
						
					}else if(responseWS.getTransaccion().getComercio().getMediosPagoDTO().get(0).getId()==Integer.valueOf(IConstants.PAGOS_TC_ID)){
						renderAval = false;
						renderPSE = false;
						renderTC = Boolean.TRUE;
						log.info("se ingreso a RBM");
					}
														
					// Modificacion para enmascarar datos sensibles.
					try{
			    		String correoCliente = responseWS.getTransaccion().getUsuario().getCorreoElectronico();
			    		responseWS.getTransaccion().getUsuario().setCorreoElectronico(enmascararCorreo(correoCliente));    		
			    		// Auditoria portal pasarela
						auditarAccion(token, dirIp, "recibir consulta transacci�n resultado", responseWS.getTransaccion().getComercio().getCodigoNura(), "Mostrar pantalla resultado", "Exitoso", responseWS);
				    	// Modificacion para enmascarar datos sensibles.
						responseWS.getTransaccion().getUsuario().setCorreoElectronico(correoCliente);
					}catch (Exception eExc) {
						// Auditoria portal pasarela
						auditarAccion(token, dirIp, "recibir consulta transacci�n resultado", responseWS.getTransaccion().getComercio().getCodigoNura(), "Mostrar pantalla resultado", "Exitoso", responseWS);
					}
					
					MedioPagoDTO medioPagoDTO = new MedioPagoDTO();
					responseWS.getTransaccion().setMedioPago(medioPagoDTO);
					
					if(responseWS.getTransaccion().getUsuario()!=null){
						if(responseWS.getTransaccion().getUsuario().getTipoUsuario()==null || "".equals(responseWS.getTransaccion().getUsuario().getTipoUsuario().trim())){
							responseWS.getTransaccion().getUsuario().setTipoUsuario(IConstants.PERSONA_NATURAL);
						}
					}else{
						UsuarioDTO usuario = new UsuarioDTO();
						usuario.setTipoUsuario(IConstants.PERSONA_NATURAL);
						responseWS.getTransaccion().setUsuario(usuario);
					}
					
					monto = responseWS.getTransaccion().getValorTotal();					
				
					//RQ25542 MotorDeRiesgosPortal
					//Recibe el deviceToken
					if(responseWS.getTransaccion().getDeviceToken() != null && responseWS.getTransaccion().getDeviceToken() != ""){
						log.info("El deviceTokenCookie fue recibido. " + responseWS.getTransaccion().getDeviceToken());
						setCookieValue(responseWS.getTransaccion().getDeviceToken());
					}
					else{
						log.error("No se recibio ningun DeviceTokenCookie.");
					}
					/* INI
					 * Valida si el convenio es Tokenizable para relizar el truncado de los Campos RQ27827
					 */
					codigoNura = responseWS.getTransaccion().getComercio().getCodigoNura();
					if(WebLocator.getPreferences().getValue(CODE_NURA_TOKENIZACION, "").contains(codigoNura)){
						log.info(" EL CONVENIO ES TRUNCABLE");
						truncarRefes();
						
					}
					else {
						refprincipal = responseWS.getTransaccion().getReferencia1();
					}
					/* FIN
					 * Valida si el convenio es Tokenizable para relizar el truncado de los Campos RQ27827
					 */
				}
				//RQ 26210 Taquillas
				CargaTemplate();
				log.info("::: CARGA METODO CargaTemplate() DEL BEAN MediosPagoBean :::");
			}
		}catch (Exception e) {
			renderInfo = false;
			errorCancel = "1";
			log.error("::: ERROR AL OBTENER LA TRANSACCION CON EL TOKEN: " + token + " :::", e);
			setRenderBotonVolver(true);
			printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO, mensajeErrorGeneral);
		}
		log.info("::: TERMINA METODO RespuestaPagoBean() DEL BEAN RespuestaPagoBean :::");
		log.info("VALOR ULTIMO SALIDA CARGA TEMPLATE:" + templateTaq + "\n" + footTaq + "\n" + theme + "\n" + footer + "\n" + estilocss + "\n" + cabezote);
	}
	

	//Configuracion para el logo del convenio
	private void setLogoConvenio(String logoUrl) {
		
		try {
            System.setProperty("java.net.useSystemProxies", "true");    

            URL url = new URL(logoUrl);
            URLConnection connection = url.openConnection();
            
            // Validar si se puede establecer conexion
            if(connection != null){
            	
            	String contentType = connection.getContentType();
            	if(contentType != null){
            		// Validar que el tipo de contenido no sea un mensaje HTML
                	if (contentType.contains("text/html")){
                    	log.error("::: ERROR AL TRAER LOGO CONVENIO ERROR DE SERVIDOR ::: " + contentType);
                    	setRenderLogo(false);
                    } else {
                    	// Si el contenido no es html mostrar logo
                    	setRenderLogo(true);
                    	setLogoComercio(logoUrl);
                    }
                } else if(logoUrl.toLowerCase().contains(".jpeg") || logoUrl.toLowerCase().contains(".jpg") || logoUrl.toLowerCase().contains(".png")){
                	// En caso de no resolver el tipo de contenido se valida si la URL tiene .jpeg .jpg o .png
                	setRenderLogo(true);
                	setLogoComercio(logoUrl);
                } else {
                	// Si no se puede resolver el tipo de contenido ni validar la extension 
                	log.error("::: NO SE PUEDE OBTENER EL LOGO ::: " + logoUrl);
                	setRenderLogo(false);
                }
                
            } else {
            	log.error("::: ERROR AL TRAER LOGO CONVENIO NO SE PUEDE ESTABLECER CONEXION ::: " + logoUrl);
            	setRenderLogo(false);
            }
            
		} catch (MalformedURLException e){
			log.error("::: URL DE LOGO NO VALIDA ::: " + logoUrl, e);
			setRenderLogo(false);
		} catch (IOException e) {
			log.error("::: ERROR I/O LOGO NO VALIDO ::: " + logoUrl, e);
			setRenderLogo(false);
		} catch (Exception e) {
			log.error("::: EXCEPCION NO CONTROLADA ::: " + logoUrl, e);
			setRenderLogo(false);
		}
	}

	//RQ25542 MotorDeRiesgosPortal
	/**
	 * @return el cookieValue
	 */
	public String getCookieValue() {
		return cookieValue;
	}

	//RQ25542 MotorDeRiesgosPortal
	/**
	 * Asigna el valor del DeviceTokenCookie
	 * @param deviceToken
	 */
	public void setCookieValue(String deviceToken) {
		String cookieValue = "";
		try {
			cookieValue = IConstants.MR_NOM_DEVICE_TOKEN_COOKIE + "=" + deviceToken ;
			cookieValue += "; max-age=" + IConstants.MR_NOM_DEVICE_TOKEN_COOKIE_MAX_AGE;
			cookieValue += "; path=/; secure;";
		}
		catch (Exception e) {
			log.error("No fue posible generar el valor del DeviceTokenCookie. " + e.getMessage());
		}
		finally{
			this.cookieValue = cookieValue;
		}
	}
	private void cargarVariables(){
		errorCancel = "0";
		setRenderInfo(true);
		setRenderLabel(true);
		setRenderCUS(true);
		setRenderBanco(true);
		setRenderReferencia2(false);
		setRenderReferencia3(false);
		setRenderReferencia4(false);
		setRenderBotonVolver(false);
		
		setDuracionSesion(WebLocator.getPreferences().getValue("duracionSession",null));
		setUrlRedireccion(WebLocator.getPreferences().getValue("urlRedireccion", null));
		String configPath =  WebLocator.getPreferences().getValue("configPath", null);
		PropertiesLoader propertiesLoader = PropertiesLoader.getInstance();			
		propertiesTheme = propertiesLoader.getProperties(configPath,"theme.properties");
		propertiesPlan = propertiesLoader.getProperties(configPath,"plantilla.properties"); // Constantes Taquilla RQ26210
		mensajeErrorGeneral = IConstants.SSC_DESC_ERROR_GENERAL_PP;
		
		//Constantes tema 1
		NAME_THEME_ONE = propertiesTheme.getProperty(IConstants.NAME_THEME_ONE);
	    NAME_LAYAOUT_THEME_ONE = propertiesTheme.getProperty(IConstants.NAME_LAYAOUT_THEME_ONE);
	    CSS_THEME_ONE = propertiesTheme.getProperty(IConstants.CSS_THEME_ONE);
	    RESPONSE_LAYAOUT_THEME_ONE = propertiesTheme.getProperty(IConstants.RESPONSE_LAYAOUT_THEME_ONE);
		    
	    //Constantes tema 2
	    NAME_THEME_TWO = propertiesTheme.getProperty(IConstants.NAME_THEME_TWO);
	    NAME_LAYAOUT_THEME_TWO = propertiesTheme.getProperty(IConstants.NAME_LAYAOUT_THEME_TWO);
	    CSS_THEME_TWO = propertiesTheme.getProperty(IConstants.CSS_THEME_TWO);
	    RESPONSE_LAYAOUT_THEME_TWO = propertiesTheme.getProperty(IConstants.RESPONSE_LAYAOUT_THEME_TWO);
		layaoutPortlet = RESPONSE_LAYAOUT_THEME_ONE;
		themePortlet = CSS_THEME_ONE;
		// Constantes Taquilla RQ26210
		ENCABEZADO_DEFAULT = propertiesPlan.getProperty(IConstants.ENCABEZADO_DEFAULT);
		FOOTER_AZUL = propertiesPlan.getProperty(IConstants.FOOTER_AZUL);
		FOOTER_ROJO = propertiesPlan.getProperty(IConstants.FOOTER_ROJO);
		FOOTER_GRIS = propertiesPlan.getProperty(IConstants.FOOTER_GRIS);
		COLOR_ROJO= propertiesPlan.getProperty(IConstants.COLOR_ROJO);
		COLOR_AZUL= propertiesPlan.getProperty(IConstants.COLOR_AZUL);
		COLOR_GRIS= propertiesPlan.getProperty(IConstants.COLOR_GRIS);
		templateTaq = false;
		footTaq = false; 
		
	}
	
	/**
	 * Metodo encargado de redireccionar al comercio
	 * @return
	 */
	public String volver(){
		log.info("::: INICIA METODO volver() DEL BEAN RespuestaPagoBean :::");
		String urlRedirect = responseWS.getPortalURL();
		FacesContext fc = FacesContext.getCurrentInstance();
		ExternalContext ec = fc.getExternalContext();		
		try {
			ec.redirect(urlRedirect);
		} catch (Exception ex) {
			log.error("::: ERROR AL REDIRECCIONAR A LA URL: " + urlRedirect + " :::", ex);
		}
		
		log.info("::: TERMINA METODO volver() DEL BEAN RespuestaPagoBean :::");
		
		return "RESPUESTA_PAGO";
	}
	
	private void auditarAccion(String pmtId, String dirIp, String accion, String idComercio, 
			String pantalla, String resultado, Object infoAdicional){
		try{
			JMSSendUtil su = new JMSSendUtil("PortalPasarelaConf", "PSAuditoriaPasarelaJMSQueue", "jmsQueuePasarelaSenderName");
			AuditoriaPasarelaMessage mensaje = new AuditoriaPasarelaMessage();
			mensaje.setToken(token);
			mensaje.setDireccionIp(dirIp);
			mensaje.setFechaRegistro(new Date());
			mensaje.setAccion(accion);
			mensaje.setComercio(idComercio);
			mensaje.setPantalla(pantalla);
			mensaje.setResultado(resultado);
			if(infoAdicional!=null){
				Gson gson = new Gson();
				mensaje.setInformacionAdicional(gson.toJson(infoAdicional));
			}
			su.sendMessage(mensaje);
		}catch (Exception eException) {
			log.error("::: ERROR AL ENVIAR AUDITORIA :::", eException);
		}
	}
	
	public static void printFacesMessage(FacesContext facesContext, FacesMessage.Severity severity, String idMensaje, String mensaje) {
		FacesMessage message = new FacesMessage(severity, mensaje, mensaje);
		facesContext.addMessage(idMensaje, message);    	
    }
	
	public static void printFacesMessage(FacesContext facesContext, FacesMessage.Severity severity, String mensaje) {
    	printFacesMessage(facesContext, severity, null, mensaje);
    }
	
	
	public void getLayaout(){
		try{
			PlantillaDTO plantilla = responseWS.getTransaccion().getComercio().getConfiguracion().getPlantilla();
			String nombrePlantilla = plantilla.getPlantilla();	
		
			if (nombrePlantilla.equals(NAME_LAYAOUT_THEME_ONE)){
				layaoutPortlet = RESPONSE_LAYAOUT_THEME_ONE;
			}else if(nombrePlantilla.equals(NAME_LAYAOUT_THEME_TWO)){
				layaoutPortlet = RESPONSE_LAYAOUT_THEME_TWO;
			}
		}catch (Exception e) {
			log.error("::: ERROR AL OBTENER EL LAYAOUT DEL PORTLET :::", e);
			layaoutPortlet = RESPONSE_LAYAOUT_THEME_ONE;
		}
		
	}
	
	public void getTheme(){
//		AJUSTE PARA MANEJO DE TEMAS POR BANCOS 11/04/2016
		try{
			String tema = responseWS.getPortalURL();
						
			if(tema.contains(IConstants.ESTILOSPP)){
				themePortlet = CSS_THEME_ONE;
			}else if(tema.contains(IConstants.ESTILOSBB)){
					themePortlet = propertiesTheme.getProperty(IConstants.CSS_BB);
			}else if(tema.contains(IConstants.ESTILOSBO)){
				themePortlet = propertiesTheme.getProperty(IConstants.CSS_BO);
			}else if(tema.contains(IConstants.ESTILOSBP)){
				themePortlet = propertiesTheme.getProperty(IConstants.CSS_BP);
			}else if(tema.contains(IConstants.ESTILOSBAV)){
				themePortlet = propertiesTheme.getProperty(IConstants.CSS_BAV);
			}
		}catch (Exception e) {
			log.error("::: ERROR AL OBTENER EL TEMA DEL PORTLET :::", e);
			themePortlet = CSS_THEME_ONE;
		}
	}
	 public void CargaTemplate() {
			
			// Taquillas RQ26210
			try {
				String template = responseWS.getTransaccion()
						.getDatosPlantillaDTO().getTaquilla();
				log.info("VALOR TEMPLATE:" + template);

				if (template.equals("1")) {
					templateTaq = true;
					footTaq = true; 
					getTemplate();
					themePortlet = estilocss;
					renderLogo=false;
					
				}
			
			} catch (Exception e) {
				log.error("::: ERROR AL CARGAR EL METODO TEMPLATE :::", e);
			}
		}
	
	
    public void getTemplate() {
    	
		// Taquillas RQ26210
		try {
			String template = responseWS.getTransaccion()
					.getDatosPlantillaDTO().getTaquilla();

			if (template.equals("1")) {
				String theme = responseWS.getTransaccion()
						.getDatosPlantillaDTO().getTema();
				if (theme.equals("2")) {
					footer = FOOTER_AZUL;
					estilocss = COLOR_AZUL;
				} else if (theme.equals("3")) {
					estilocss = COLOR_ROJO;
					footer = FOOTER_ROJO;
				} else if (theme.equals("4")) {
					footer = FOOTER_GRIS;
					estilocss = COLOR_GRIS;
				}
				else if (theme.equals("0")) {
					footer = FOOTER_GRIS;
					estilocss = COLOR_GRIS;
				}

				String LogoUrl = responseWS.getTransaccion()
						.getDatosPlantillaDTO().getURLTaquilla();
				cabezote = LogoUrl == null ? ENCABEZADO_DEFAULT: LogoUrl;
			}

		} catch (Exception e) {
			log.error("::: ERROR AL OBTENER LA PLANTILLA DEL PORTLET :::", e);
			
		}
	}
	public void SplitReferences() { //RQ27225 Multiples Referencias
		try {
			refes = Arrays.asList(referencias.split("\\s*;\\s*"));
			for(String a : refes){
				log.info("::: Referencias Partidas:" + a);
				}
			}
			catch (Exception e) {
			log.error("::: ERROR SPLIT REFERENCIAS :::", e);
		}
	}
	public void truncarRefes() { //RQ27827 Tokenizaci�n Pasarela de Pagos  INI 
		try {
				String truncado = responseWS.getTransaccion().getReferencia1();
				log.info(truncado);
				String cutString = truncado.substring(10);
				log.info("::: Referencias truncada:" + cutString);
				refprincipal = cutString;
			}
			catch (Exception e) {
			log.error("::: ERROR truncarRefes :::", e);
		}
	}//RQ27827 Tokenizaci�n Pasarela de Pagos  FIN
	public static String getIpAddr(HttpServletRequest request){
        final String WL_PROXY_CLIENT_IP = "WL-Proxy-Client-IP";
        final String PROXY_CLIENT_IP = "Proxy-Client-IP";
        final String X_FORWARDER_FOR = "X-Forwarded-For";
        final String HTTP_X_FORWARDED_FOR = "HTTP_X_FORWARDED_FOR";
        final String HTTP_CLIENT_IP = "HTTP_CLIENT_IP";
        
        String ip = request.getHeader(X_FORWARDER_FOR);
        
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
              ip = request.getHeader(WL_PROXY_CLIENT_IP);
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
              ip = request.getHeader(PROXY_CLIENT_IP);
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {           
              ip = request.getHeader(HTTP_X_FORWARDED_FOR);
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
              ip = request.getHeader(HTTP_CLIENT_IP);
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
              ip = request.getRemoteAddr();
        }        
        return ip;
	}
	
	public String getThemePortlet() {
		return themePortlet;
	}
	public void setThemePortlet(String themePortal) {
		this.themePortlet = themePortal;
	}
	/**
	 * @return the monto
	 */
	public BigDecimal getMonto() {
		return monto;
	}
	/**
	 * @param monto the monto to set
	 */
	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}	
	/**
	 * @return the responseWS
	 */
	public WSConsultasResponseDTO getResponseWS() {
		return responseWS;
	}
	/**
	 * @param responseWS the responseWS to set
	 */
	public void setResponseWS(WSConsultasResponseDTO responseWS) {
		this.responseWS = responseWS;
	}
	/**
	 * @return the renderAval
	 */
	public boolean isRenderAval() {
		return renderAval;
	}
	/**
	 * @param renderAval the renderAval to set
	 */
	public void setRenderAval(boolean renderAval) {
		this.renderAval = renderAval;
	}
	/**
	 * @return the renderPSE
	 */
	public boolean isRenderPSE() {
		return renderPSE;
	}
	/**
	 * @param renderPSE the renderPSE to set
	 */
	public void setRenderPSE(boolean renderPSE) {
		this.renderPSE = renderPSE;
	}
	/**
	 * @return the renderTC
	 */
	public boolean isRenderTC() {
		return renderTC;
	}
	/**
	 * @param renderTC the renderTC to set
	 */
	public void setRenderTC(boolean renderTC) {
		this.renderTC = renderTC;
	}
	/**
	 * @return the renderInfo
	 */
	public boolean isRenderInfo() {
		return renderInfo;
	}
	/**
	 * @param renderInfo the renderInfo to set
	 */
	public void setRenderInfo(boolean renderInfo) {
		this.renderInfo = renderInfo;
	}
	public String getLayaoutPortlet() {
		return layaoutPortlet;
	}
	public void setLayaoutPortlet(String layaoutPortlet) {
		this.layaoutPortlet = layaoutPortlet;
	}
	public String getStrEstado() {
		return strEstado;
	}
	public void setStrEstado(String strEstado) {
		this.strEstado = strEstado;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public boolean isRenderCancelacion() {
		return renderCancelacion;
	}
	public void setRenderCancelacion(boolean renderCancelacion) {
		this.renderCancelacion = renderCancelacion;
	}
	public List<TransaccionesDTO> getTransacciones() {
		return transacciones;
	}
	public void setTransacciones(List<TransaccionesDTO> transacciones) {
		this.transacciones = transacciones;
	}	
	public String getDirIp() {
		return dirIp;
	}
	public void setDirIp(String dirIp) {
		this.dirIp = dirIp;
	}
	public String getStrError() {
		return strError;
	}
	public void setStrError(String strError) {
		this.strError = strError;
	}
	public String getDuracionSesion() {
		return duracionSesion;
	}
	public void setDuracionSesion(String duracionSesion) {
		this.duracionSesion = duracionSesion;
	}
	public String getUrlRedireccion() {
		return urlRedireccion;
	}
	public void setUrlRedireccion(String urlRedireccion) {
		this.urlRedireccion = urlRedireccion;
	}
	public boolean isRenderLabel() {
		return renderLabel;
	}
	public void setRenderLabel(boolean renderLabel) {
		this.renderLabel = renderLabel;
	}

	public boolean isRenderCUS() {
		return renderCUS;
	}
	public void setRenderCUS(boolean renderCUS) {
		this.renderCUS = renderCUS;
	}
	public boolean isRenderBanco() {
		return renderBanco;
	}
	public void setRenderBanco(boolean renderBanco) {
		this.renderBanco = renderBanco;
	}
	
	public boolean isRenderReferencia2() {
		return renderReferencia2;
	}

	public void setRenderReferencia2(boolean renderReferencia2) {
		this.renderReferencia2 = renderReferencia2;
	}

	public boolean isRenderReferencia3() {
		return renderReferencia3;
	}

	public void setRenderReferencia3(boolean renderReferencia3) {
		this.renderReferencia3 = renderReferencia3;
	}

	public boolean isRenderReferencia4() {
		return renderReferencia4;
	}

	public void setRenderReferencia4(boolean renderReferencia4) {
		this.renderReferencia4 = renderReferencia4;
	}

	/**
	 * @return el errorCancel
	 */
	public String getErrorCancel() {
		return errorCancel;
	}

	/**
	 * @param errorCancel el errorCancel a establecer
	 */
	public void setErrorCancel(String errorCancel) {
		this.errorCancel = errorCancel;
	}

	/**
	 * @return el logoComercio
	 */
	public String getLogoComercio() {
		return logoComercio;
	}

	/**
	 * @param logoComercio el logoComercio a establecer
	 */
	public void setLogoComercio(String logoComercio) {
		this.logoComercio = logoComercio;
	}

	/**
	 * @return el renderBotonVolver
	 */
	public boolean isRenderBotonVolver() {
		return renderBotonVolver;
	}

	/**
	 * @param renderBotonVolver el renderBotonVolver a establecer
	 */
	public void setRenderBotonVolver(boolean renderBotonVolver) {
		this.renderBotonVolver = renderBotonVolver;
	}
	
	/**
	 * @return el renderLogo
	 */
	public boolean isRenderLogo() {
		return renderLogo;
	}

	/**
	 * @param renderLogo el renderLogo a establecer
	 */
	public void setRenderLogo(boolean renderLogo) {
		this.renderLogo = renderLogo;
	}

	/**
	 * @return el pseSiguienteDiaHabil
	 */
	public boolean isPseSiguienteDiaHabil() {
		return pseSiguienteDiaHabil;
	}

	/**
	 * @param pseSiguienteDiaHabil el pseSiguienteDiaHabil a establecer
	 */
	public void setPseSiguienteDiaHabil(boolean pseSiguienteDiaHabil) {
		this.pseSiguienteDiaHabil = pseSiguienteDiaHabil;
	}
	
	/**
	 * Variables creadas RQ26210 Taquillas
	 */

	public String template() {
		return template;
	}

	public void settemplate(String template) {
		this.template = template;
	}

	public String theme() {
		return theme;
	}

	public void settheme(String theme) {
		this.theme = theme;
	}

	public String logoUrl() {
		return logoUrl;
	}

	public void setlogoUrl(String logoUrl) {
		this.logoUrl = logoUrl;
	}

	public String getFooter() {
		return footer;
	}

	public void setFooter(String footer) {
		this.footer = footer;
	}

	public String getEstilocss() {
		return estilocss;
	}

	public void setEstilocss(String estilocss) {
		this.estilocss = estilocss;
	}

	public String getCabezote() {
		return cabezote;
	}

	public void setCabezote(String cabezote) {
		this.cabezote = cabezote;
	}

	public boolean isTemplateTaq() {
		return templateTaq;
	}

	public void setTemplateTaq(boolean templateTaq) {
		this.templateTaq = templateTaq;
	}

	public boolean isFootTaq() {
		return footTaq;
	}

	public void setFootTaq(boolean footTaq) {
		this.footTaq = footTaq;
	}
	
	public List<String> getRefes() {
		return refes;
	}

	public void setRefes(List<String> refes) {
		this.refes = refes;
	}
	public String getCodigoNura() {
		return codigoNura;
	}

	public void setCodigoNura(String codigoNura) {
		this.codigoNura = codigoNura;
	}
	public String getRefprincipal() {
		return refprincipal;
	}


	public void setRefprincipal(String refprincipal) {
		this.refprincipal = refprincipal;
	}
	
}
