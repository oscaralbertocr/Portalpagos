package co.com.pasarela.pagos.faces.bean;
import static co.com.portales.common.util.UtilidadesTexto.enmascararCVC;
import static co.com.portales.common.util.UtilidadesTexto.enmascararCorreo;
import static co.com.portales.common.util.UtilidadesTexto.enmascararTC;
import static java.util.Arrays.asList;

import java.io.IOException;
import java.io.Serializable;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.event.ValueChangeEvent;
import javax.portlet.PortletRequest;
import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.Logger;
import co.com.pasarelapagos.dto.BancoDTO;
import co.com.pasarelapagos.dto.CuentaDTO;
import co.com.pasarelapagos.dto.MedioPagoDTO;
import co.com.pasarelapagos.dto.PlantillaDTO;
import co.com.pasarelapagos.dto.TarjetaCreditoDTO;
import co.com.pasarelapagos.dto.TransaccionesDTO;
import co.com.pasarelapagos.dto.UsuarioDTO;
import co.com.pasarelapagos.ws.client.cancelar.ClienteCancelarService;
import co.com.pasarelapagos.ws.client.consulta.ClienteConsultasService;
import co.com.pasarelapagos.ws.client.pagarRBM.ClientePagoRBMService;
import co.com.pasarelapagos.ws.client.pagos.ClientePagosService;
import co.com.pasarelapagos.ws.dto.RbmDTO;
import co.com.pasarelapagos.ws.dto.WSCalcelarDTO;
import co.com.pasarelapagos.ws.dto.WSCancelarResponseDTO;
import co.com.pasarelapagos.ws.dto.WSConsultasDTO;
import co.com.pasarelapagos.ws.dto.WSConsultasResponseDTO;
import co.com.pasarelapagos.ws.dto.WSPagosDTO;
import co.com.pasarelapagos.ws.dto.WSPagosResponseDTO;
import co.com.portales.common.contants.IConstants;
import co.com.portales.common.util.PropertiesLoader;
import co.com.portales.common.util.jms.JMSSendUtil;
import co.com.portales.commonweb.util.WebLocator;
import co.com.portalservicio.auditoria.dto.AuditoriaPasarelaMessage;
import com.google.gson.Gson;
import com.ibm.faces20.portlet.httpbridge.PortletRequestWrapper;
import com.ibm.wps.pb.utils.portlet.PortletUtils;


/**
 * 
 * @author ATH
 * @version 1.0
 * @RQ27850 <strong>Autor</strong> Luis Bonilla </br>
 *          <strong>Descripcion</strong> FacilPass Recarga En Linea </br>
 *          <strong>Numero de Cambios</strong> 5</br> <strong>Identificador
 *          corto</strong> C01</br>
 * @RQ25542 <strong>Autor</strong> Luis Gabriel Nino </br>
 *          <strong>Descripcion</strong> Agregar Cabeceras para Motor de
 *          riesgo</br> <strong>Numero de Cambios</strong> 5</br>
 *          <strong>Identificador corto</strong> C06</br>
 * 
 * @RQ26730 <strong>Autor</strong> Luis Bonilla </br>
 *          <strong>Descripcion</strong> Ajuste campo nombre cuando se crea
 *          transaccion desde facilpass</br> <strong>Numero de
 *          Cambios</strong>9</br> <strong>Identificador corto</strong> C04</br>
 *          
 * @RQ30573 <strong>Autor</strong> Jonathan Rodriguez </br>
 *          <strong>Descripcion</strong> Mapeo de Errores RBM</br> <strong>Numero de
 *          Cambios</strong>5</br> <strong>Identificador corto</strong> C07</br>   
 *          
 * @IM24429 <strong>Autor</strong>Jonathan Rodriguez-Henry Hernandez </br>
 *          <strong>Descripcion</strong> Ajuste nombre pagador en comprobante de pago</br> <strong>Numero de
 *          Cambios</strong>4</br> <strong>Identificador corto</strong> C08</br>    
 *          
 * @IM24429 <strong>Autor</strong>Henry Hernandez </br>
 *          <strong>Descripcion</strong>abrir lightbox con medio de pago RBM</br> <strong>Numero de
 *          Cambios</strong>1</br> <strong>Identificador corto</strong> C09</br>   
 *          
 * @RQ30800 <strong>Autor</strong>Dario Hernandez </br>
 *          <strong>Descripcion</strong>Eliminar check de copiar datos de pagador a beneficiario</br> <strong>Numero de
 *          Cambios</strong>3</br> <strong>Identificador corto</strong> C10</br>  
 */
@ManagedBean(name = "mediosPagoBean")
@ViewScoped
public class MediosPagoBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/** INICIO-C01 **/
	private static final String CODE_NURA_FACILPASS = "facilPassNura";
	private static final String CODE_NURA_TOKENIZACION = "tokenizacion";
	/** FIN-C01 **/

	/** INICIO-C04 **/
	/** FIN-C04 **/
	private String auxPrimerNombrePagador;
	private String auxPrimerNombre;

	private static final String HEADER_USER_AGENT = "user-agent";
	private static final String HEADER_ACCEPT_LANGUAGE = "Accept-Language";
	private static final String HEADER_ACCEPT = "Accept";
	private static final String HEADER_REFERER = "Referer";

	/**
	 * Variable encargada de manejar los logs de la aplicaci�n.
	 */
	private static Logger log = Logger.getLogger(MediosPagoBean.class);

	/** INICIO-C01 **/
	private boolean disableBeneficiario;
	private boolean arrivalData;
	private boolean renderConfirmMail;
	private boolean renderConfirmCel;
	/** FIN-C01 **/

	// URl Redirect Motor de Riesgo
	private String deviceToken;
	private String urlRedirectPay;
	// Nueva Referencia Principal RQ26727
	private String refprincipal;
	// Token para transacciones
	private String token;

	// Id de transacciones
	private String pmtId;

	// Direcci�n IP
	private String dirIp;

	/**
	 * Tipo de documento del cliente
	 */
	private String tipoDocumento;

	/**
	 * Atributo asociado a los tipos de transaccion
	 */
	private Map<String, String> tiposDocumento;

	/**
	 * Atributo asociado a los bancos para pagos PSE
	 */
	private Map<String, String> bancosPSE;

	/**
	 * Atributo para saber si se debe mostrar el panel donde se solicita la
	 * informaci�n del comprador
	 */
	
	/**render para ocultar formulario datos beneficiario inicio*/
	/** INICIO-C10 **/
	private boolean rendercheck = false;
	private boolean checkBen = false;
	public boolean isCheckBen() {
		return checkBen;
	}


	public void setCheckBen(boolean checkBen) {
		this.checkBen = checkBen;
	}

	private String primerNombre;
	//private String tipoDocumento;
	private String noDocumetoBean;	
	private String correoElectronico;
	
	
	public String getPrimerNombre() {
		return primerNombre;
	}


	public void setPrimerNombre(String primerNombre) {
		this.primerNombre = primerNombre;
	}


	public String getNoDocumetoBean() {
		return noDocumetoBean;
	}


	public void setNoDocumetoBean(String noDocumetoBean) {
		this.noDocumetoBean = noDocumetoBean;
	}


	public String getCorreoElectronico() {
		return correoElectronico;
	}


	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}
	

	public void formComp(ValueChangeEvent event){
		rendercheck = Boolean.FALSE;
		rendercheck = (Boolean) event.getNewValue();
		System.out.println("### ---> rendercheck: "+rendercheck);

	}
	
	
	public boolean isRendercheck() {
		return rendercheck;
	}
	
	public void setRendercheck(boolean rendercheck) {
		this.rendercheck = rendercheck;
	}
	
	/**render para ocultar formulario datos beneficiario fin*/
	/** FIN-C10 **/
	private boolean renderInfoComprador;

	private boolean renderInfoMedioPago;

	private boolean renderInfoCompra;

	private boolean renderBotonError;

	private boolean renderBotonVolver;

	private String renderBotonVolverJS = "NO";

	private boolean renderMensaje;

	private boolean renderMensajeBancos;

	private boolean renderLogo;

	private String errorProceso;
	private String errorCancel;

	/**
	 * Atributos para saber si se debe mostrar los diferentes Layaout
	 */
	private String layaoutPortlet;

	/**
	 * Atributos para saber si se debe mostrar los diferentes temas
	 */
	private String themePortlet;

	/**
	 * Atributo para saber si se debe mostrar el panel donde se mestra la
	 * informacion para un pago con AVAL
	 */
	private boolean renderAval;

	/**
	 * Atributo para saber si se debe mostrar el panel donde se mestra la
	 * informacion para un pago con PSE
	 */
	private boolean renderPSE;

	/**
	 * Atributo para saber si se debe mostrar el panel donde se mestra la
	 * informacion para un pago con TC
	 */
	private boolean renderTC;

	/**
	 * Atributo para saber si se debe mostrar el mensaje del pago pra el
	 * siguiente d�a h�bil
	 */
	private boolean pseSiguienteDiaHabil;

	/**
	 * Atributo para saber si se debe mostrar el panel donde se el boton para
	 * realizar el pago
	 */
	private boolean renderPagar;

	/**
	 * Identificador del banco seleccionado para el pago AVAL
	 */
	private String bancoPagoAval;

	/**
	 * Almacena la informaci�n que esta almacenada en la preferencia del portlet
	 * para los tipos de documentos.
	 */
	private String documentosIdentidad;

	/**
	 * Almacena el valor del monto con el formato necesario
	 */
	private BigDecimal monto;

	/**
	 * Se almacena la injformacion de respuesta del servicio
	 */
	private WSConsultasResponseDTO responseWS;

	/**
	 * Se almacena el codigo nura del comercio
	 */
	private String codigoNura;

	/**
	 * Identificador del banco cuando se va a realizar un pago por medio de PSE
	 */
	private String idBancoPSE;

	/**
	 * Atributo para almacenar la informaci�n de pagos con tarjeta de credito
	 */
	private RbmDTO rbm;

	/**
	 * Atributo asociado a las cuotas en que va a ser diferido el pago
	 */
	private Map<String, String> cuotas;

	private String mesVencimientoTC;

	private String anioVencimientoTC;

	private String fechaVencimientoTC;

	private String numeroCuotas;

	private String mensajeErrorGeneral;

	private String mensajeErrorTopes;
	private String mensajeError;

	private String mensajeBancos;

	private String franquiciasValidas;

	private String PAGOS_AVAL_ID = IConstants.PAGOS_AVAL_ID;
	private String PAGOS_TC_ID = IConstants.PAGOS_TC_ID;
	private String PAGOS_PSE_ID = IConstants.PAGOS_PSE_ID;

	Properties propertiesTheme;
	Properties propertiesPlan; // RQ26210 Taquillas
	
	boolean renderMensajeTopes = false;

	// Constantes tema 1
	String NAME_THEME_ONE;
	String NAME_LAYAOUT_THEME_ONE;
	String CSS_THEME_ONE;
	String PAY_LAYAOUT_THEME_ONE;

	// Constantes tema 2
	String NAME_THEME_TWO;
	String NAME_LAYAOUT_THEME_TWO;
	String CSS_THEME_TWO;
	String PAY_LAYAOUT_THEME_TWO;
	/**
	 * Constantes creadas RQ26210 Taquillas
	 */
	String ENCABEZADO_DEFAULT;
	String FOOTER_AZUL;
	String FOOTER_ROJO;
	String FOOTER_GRIS;
	String COLOR_AZUL;
	String COLOR_ROJO;
	String COLOR_GRIS;

	// Variables Para Multiples Referencias 27225
	private String referencias;
	private List<String> refes;
	
	/**
	 * Variables creadas RQ30573 INI
	 */
	private int listaErrores;
	private List<String> erroresRBM1 = new ArrayList<String>(asList("01","02","03","05","06","13","14","31","45","48","51","54","55","56","57","62","65","66","67",
			"68","69","71","72","73","74","75","80","81","82","83","84","85","86","87","92","94","B1","B3","B6","B7","Q3","T2"));
	private List<String> erroresRBM2 = new ArrayList<String>(asList("07"));
	private List<String> erroresRBM3 = new ArrayList<String>(asList("09","12","15","16","19","25","30","49","50","58","61","76","77","78","79","88","89","90","91",
			"93","95","96","97","98","B2","B4","B5","B8","SD","Q1","M2","N0","N1","N2","N3","N4","N5","N6","N7","N8","N9","P0","P1","P2","P3","P4","P5","P6","P7",
			"P8","P9","Q0","Q1","Q2","Q4","Q5","Q6","Q7","Q8","Q9","R0","R1","R2","R3","R4","R5","R6","R7","R8","S4","S5","S6","S7","S8","S9","T1","T3","T4","T5",
			"T6","T7"));
	private List<String> erroresRBM4 = new ArrayList<String>(asList("41","43"));
	/**
	 * Variables creadas RQ30573 FIN
	 */
	
	private boolean renderMedioPagoAval;
	private boolean renderMedioPagoTC;
	private boolean renderMedioPagoPSE;

	private String estiloDiv;
	private String estiloBanco;
	private String logoComercio;
	private String estiloDescripcion;
	private String logoAval;
	private String logoPse;
	private String logoTc;
	private int actMensaje;

	private String correoBen;
	private String noDocumentoBen;

	private String primerNombrePago;
	private String segundoNombrePago;
	private String primerApellidoPago;
	private String segundoApellidoPago;

	private String nombrePago;
	private String telefonoPago;
	private String confirmacionTelefonoPago;
	private String tipoDocumentoPago;
	private String noDocumentoPago;
	private String correoPago;
	private String confirmacionCorreoPago;
	private String tipoPersona;

	private boolean opcion;

	private String duracionSesion;

	private String urlRedireccion;
	
	/**
	 * Variables creadas RQ26210 Taquillas INI
	 */
	private String template;
	private String theme;
	private String logoUrl;
	private String footer;
	private String estilocss;
	private String cabezote;
	private boolean templateTaq;
	private boolean footTaq;
	/**
	 * Variables creadas RQ26210 Taquillas FIN
	 */
	private String sDevicePrint; // RQ25542 MotorDeRiesgosPortal
	private boolean renderReferencia2;
	private boolean renderReferencia3;
	private boolean renderReferencia4;

	private boolean renderBancoBogota;
	private boolean renderBancoOccidente;

	private boolean disTipoBen;
	private boolean disTipoPago;
	private String mensajeValidacionDoc;

	private HttpServletRequest requestCompleto = null;
	
	private String urlLightboxredir;
	
	private String valPrueba="Prueba";
	
	private String urlResultPay;
	/**
	 * Constructor
	 */
	public MediosPagoBean() {
		inicializarRequest();
	}

	/**
	 * Inicializa los objetos
	 */
	@SuppressWarnings("unchecked")
	private void inicializarRequest() {
		log.info("::: INICIA METODO inicializarRequest() DEL BEAN MediosPagoBean :::");

		cargarVariables();

		HttpServletRequest requestBase = null;

		FacesContext context = FacesContext.getCurrentInstance();
		requestBase = (HttpServletRequest) context.getExternalContext().getRequest();

		PortletRequestWrapper requestWrapper = (PortletRequestWrapper) requestBase;
		PortletRequest portletRequest = requestWrapper.getPortletRequest();
		requestCompleto = PortletUtils.getHttpServletRequest(portletRequest);

		String completo = requestCompleto.getParameter("token");
		if (completo != null) {
			String[] params = completo.split("\\?");
			if (params != null && params.length > 1) {
				token = params[0];
				pmtId = params[1].split("=")[1];
			} else {
				token = requestCompleto.getParameter("token");
				pmtId = requestCompleto.getParameter("pmtId");
			}
		}

		dirIp = getIpAddr(requestCompleto);

		StringBuilder mensajeInfo = new StringBuilder("::: TOKEN DE LA TRANSACCION: ");
		mensajeInfo.append(token);
		mensajeInfo.append(" :::\n");
		mensajeInfo.append("::: ID DE LA TRANSACCION: ");
		mensajeInfo.append(pmtId);
		mensajeInfo.append(" :::\n");
		mensajeInfo.append("::: IP DE LA TRANSACCION: ");
		mensajeInfo.append(dirIp);
		mensajeInfo.append(" :::\n");

		log.info(mensajeInfo);

		cargarListas();

		ClienteConsultasService cs = new ClienteConsultasService();
		WSConsultasDTO consulta = null;

		// Se inicializan los valores por defecto
		rbm = new RbmDTO();
		TarjetaCreditoDTO tarjeta = new TarjetaCreditoDTO();
		tarjeta.setFranquicia("0");
		rbm.setTarjetaCredito(tarjeta);

		try {
			if (getSessionMap().get("transactionByToken") == null) {
				mensajeInfo.setLength(0);
				if (token == null) {
					renderInfoCompra = false;
					renderInfoComprador = false;
					renderInfoMedioPago = false;
					mensajeInfo.append("::: TOKEN NO VALIDO ");
					mensajeInfo.append(token);
					mensajeInfo.append(" :::");
					log.error(mensajeInfo);
					auditarAccion(token == null ? "NO ENTREGADO" : token, dirIp, "Recibir redirect", "N/A",
							"Mostrar pantalla para pago", "Fallido", "Token no valido");
					setRenderBotonVolver(true);
					printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO,
							IConstants.ERROR_TOKEN);
				} else {
					consulta = new WSConsultasDTO();
					TransaccionesDTO transaccionDTO = new TransaccionesDTO();
					transaccionDTO.setToken(token);
					consulta.setTransaccion(transaccionDTO);
					consulta.setIpOrigen(dirIp);
					consulta.setChannel(IConstants.CANAL_PASARELA);
					consulta.setTipo(IConstants.ESTADO_INICIAL);

					// Auditoria portal pasarela
					auditarAccion(token == null ? "NO ENTREGADO" : token, dirIp, "Consultar transaccion", "N/A",
							"Mostrar pantalla para pago", "Exitoso", consulta);

					try {
						responseWS = cs.getTransactionByToken(consulta);
						codigoNura = responseWS.getTransaccion().getComercio().getCodigoNura();
						/** INICIO-C01 **/
						checkEstadoBeneficiario();
						/** FIN-C01 **/

						checkEstadoForm();
						/* INI
						 * Valida si el convenio es Tokenizable para relizar el truncado de los Campos RQ27827
						 */

						if(WebLocator.getPreferences().getValue(CODE_NURA_TOKENIZACION, "").contains(codigoNura)){
							log.info(" EL CONVENIO ES TRUNCABLE");
							truncarRefes();
							
						}
						else {
							refprincipal = responseWS.getTransaccion().getReferencia1();
						}
						/* FIN
						 * Valida si el convenio es Tokenizable para relizar el truncado de los Campos RQ27827
						 */
					} catch (Exception e) {
						mensajeInfo.append("::: ERROR AL CONSULTAR LA TRANSACCION CON TOKEN ");
						mensajeInfo.append(token);
						mensajeInfo.append(" :::");
						log.error(mensajeInfo, e);
						// Auditoria portal pasarela
						auditarAccion(token == null ? "NO ENTREGADO" : token, dirIp, "Recibir consulta transaccion",
								"N/A", "Mostrar pantalla para pago", "Fallido", responseWS);
						throw e;
					}

					if (responseWS == null || responseWS.getStatusCode() != Long.valueOf(IConstants.SSC_EXITOSO)) {
						monto = new BigDecimal(0);
						renderInfoMedioPago = false;
						renderInfoCompra = false;
						renderInfoComprador = false;
						renderMensaje = false;

						if (responseWS != null) {
							if (responseWS.getServerStatusCode() != null) {
								log.error("::: LA RESPUESTA DEL SERVICIO NO FUE SATISFACTORIA ERROR: "
										+ responseWS.getServerStatusCode() + " :::");

								if (IConstants.SSC_ERROR_TOKEN.equals(responseWS.getServerStatusCode())) {
									setRenderBotonVolver(true);
									printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO,
											IConstants.erroresServer.get(responseWS.getServerStatusCode()));
								} else {
									setRenderBotonVolver(true);
									printFacesMessage(
											FacesContext.getCurrentInstance(),
											FacesMessage.SEVERITY_INFO,
											mensajeErrorGeneral + " - "
													+ IConstants.erroresServer.get(responseWS.getServerStatusCode()));
								}
							} else {
								log.error("::: LA RESPUESTA DEL SERVICIO FUE NULL :::: ");
								setRenderBotonVolver(true);
								printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO,
										mensajeErrorGeneral);
							}
						} else {
							log.error("::: LA RESPUESTA DEL SERVICIO FUE NULL :::: ");
							setRenderBotonVolver(true);
							printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO,
									mensajeErrorGeneral);
						}
						// Auditoria portal pasarela
						auditarAccion(token == null ? "NO ENTREGADO" : token, dirIp, "Recibir consulta transaccion",
								"N/A", "Mostrar pantalla para pago", "Fallido", responseWS);
					} else {

						setUrlRedireccion(responseWS.getPortalURL());

						// Se configura la URL del logo del comercio.
						String urlLogo = responseWS.getTransaccion().getComercio().getConfiguracion().getLogo();
						if (null != urlLogo && !"".equals(urlLogo)) {
							setLogoConvenio(responseWS.getTransaccion().getComercio().getConfiguracion().getLogo());
						}

						if (responseWS.getTransaccion().getReferencia2() != null
								&& !("".equals(responseWS.getTransaccion().getReferencia2()))) {
							setRenderReferencia2(true);
						}
						if (responseWS.getTransaccion().getReferencia3() != null
								&& !("".equals(responseWS.getTransaccion().getReferencia3()))) {
							setRenderReferencia3(true);
						}
						if (responseWS.getTransaccion().getReferencia4() != null
								&& !("".equals(responseWS.getTransaccion().getReferencia4()))) {
							setRenderReferencia4(true);
						}

						// Se estable tipo de documento CC 18/05/2016
						if ((responseWS.getTransaccion().getUsuario().getTipoDocumento() == null)
								|| ("".equals(responseWS.getTransaccion().getUsuario().getTipoDocumento()))) {
							responseWS.getTransaccion().getUsuario().setTipoDocumento("CC");
							disTipoBen = false;
						}

						if ((responseWS.getTransaccion().getUsuario().getTipoDocumentoPago() == null)
								|| ("".equals(responseWS.getTransaccion().getUsuario().getTipoDocumentoPago()))) {
							responseWS.getTransaccion().getUsuario().setTipoDocumentoPago("CC");
							disTipoPago = false;
						}
						// Multiples Referencias 27225
						referencias = responseWS.getTransaccion().getMultiplesrefe();
						log.info("VERIFICACION LLEGADA DATOS" + responseWS.getTransaccion().getMultiplesrefe());
						// Metodo de Split de Referencias
						if ((responseWS.getTransaccion().getMultiplesrefe() == null)
								|| (responseWS.getTransaccion().getMultiplesrefe().equals(""))) {
							log.info("CONVENIO NO ES MULTIPLES REFERENCIAS");
						} else {
							SplitReferences();
							log.info("CONVENIO ES MULTIPLES REFERENCIAS");
						}

						renderInfoComprador = true;

						tipoDocumento = responseWS.getTransaccion().getUsuario().getTipoDocumento();
						noDocumentoBen = responseWS.getTransaccion().getUsuario().getNoDocumento();
						primerNombrePago = responseWS.getTransaccion().getUsuario().getPrimerNombrePago();
						segundoNombrePago = responseWS.getTransaccion().getUsuario().getSegundoNombrePago();
						primerApellidoPago = responseWS.getTransaccion().getUsuario().getPrimerApellidoPago();
						segundoApellidoPago = responseWS.getTransaccion().getUsuario().getSegundoApellidoPago();
						/** INICIO-C04 **/
						auxPrimerNombrePagador = primerNombrePago;
						/** FIN-C04 **/
						primerNombrePago = primerNombrePago + " " + segundoNombrePago + " " + primerApellidoPago + " "
								+ segundoApellidoPago;
						log.info("::: primerNombrePago :::");
						telefonoPago = responseWS.getTransaccion().getUsuario().getTelefonoPago();
						tipoDocumentoPago = responseWS.getTransaccion().getUsuario().getTipoDocumentoPago();
						noDocumentoPago = responseWS.getTransaccion().getUsuario().getNoDocumentoPago();
						correoPago = responseWS.getTransaccion().getUsuario().getCorreoElectronicoPago();
						confirmacionCorreoPago = correoPago;
						confirmacionTelefonoPago = telefonoPago;
						// Cargar el tema
						getTheme();
						// Cargar la plantilla
						getLayaout();
						// Cargar la Taquilla RQ 26210
						CargaTemplate();
						log.info("::: CARGA METODO CargaTemplate() DEL BEAN MediosPagoBean :::");

						// Modificacion para enmascarar datos sensibles.
						try {
							String correoCliente = responseWS.getTransaccion().getUsuario().getCorreoElectronico();
							responseWS.getTransaccion().getUsuario()
									.setCorreoElectronico(enmascararCorreo(correoCliente));
							// Auditoria portal pasarela
							auditarAccion(token, dirIp, "recibir consulta transaccion", responseWS.getTransaccion()
									.getComercio().getCodigoNura(), "Mostrar pantalla para pago", "Exitoso", responseWS);
							// Modificacion para enmascarar datos sensibles.
							responseWS.getTransaccion().getUsuario().setCorreoElectronico(correoCliente);
						} catch (Exception e) {
							// Auditoria portal pasarela
							auditarAccion(token, dirIp, "recibir consulta transaccion", responseWS.getTransaccion()
									.getComercio().getCodigoNura(), "Mostrar pantalla para pago", "Exitoso", responseWS);
						}

						// Leer los medios de pago
						List<MedioPagoDTO> mediosPagoDTO = new ArrayList<MedioPagoDTO>();
						mediosPagoDTO = (List<MedioPagoDTO>) responseWS.getTransaccion().getComercio()
								.getMediosPagoDTO();

						int numMediosPago = mediosPagoDTO.size();

						switch (numMediosPago) {
						case 1:
							estiloDiv = "span12";
							break;
						case 2:
							estiloDiv = "span6";
							break;
						case 3:
							estiloDiv = "span4";
							break;
						default:
							break;
						}
						for (MedioPagoDTO medioPagoNew : mediosPagoDTO) {
							if (medioPagoNew.getId() == Integer.valueOf(IConstants.PAGOS_AVAL_ID)) {
								renderMedioPagoAval = true;
							} else if (medioPagoNew.getId() == Integer.valueOf(IConstants.PAGOS_TC_ID)) {
								renderMedioPagoTC = true;
							} else if (medioPagoNew.getId() == Integer.valueOf(IConstants.PAGOS_PSE_ID)) {
								renderMedioPagoPSE = true;
							}
						}

						if (renderMedioPagoAval) {
							MedioPagoDTO medioPagoDTO = new MedioPagoDTO();
							medioPagoDTO.setId(Integer.valueOf(IConstants.PAGOS_AVAL_ID));
							responseWS.getTransaccion().setMedioPago(medioPagoDTO);
							renderAval = true;
							logoAval = "logo-grupo-aval";
							logoPse = "logo-tarjeta-pse-deshabilitado";
							logoTc = "logo-tarjetas-credito-deshabilitado";

						} else if (!renderMedioPagoAval && renderMedioPagoTC) {
							MedioPagoDTO medioPagoDTO = new MedioPagoDTO();
							medioPagoDTO.setId(Integer.valueOf(IConstants.PAGOS_TC_ID));
							responseWS.getTransaccion().setMedioPago(medioPagoDTO);
							renderTC = true;
							logoTc = "logo-tarjetas-credito";
							logoAval = "logo-grupo-aval-deshabilitado";
							logoPse = "logo-tarjeta-pse-deshabilitado";
						} else if (!renderMedioPagoTC && renderMedioPagoPSE) {
							MedioPagoDTO medioPagoDTO = new MedioPagoDTO();
							medioPagoDTO.setId(Integer.valueOf(IConstants.PAGOS_PSE_ID));
							responseWS.getTransaccion().setMedioPago(medioPagoDTO);
							renderPSE = true;
							logoPse = "logo-tarjeta-pse";
							logoAval = "logo-grupo-aval-deshabilitado";
							logoTc = "logo-tarjetas-credito-deshabilitado";
						}

						if ("0".equals(responseWS.getTransaccion().getUsuario().getNoDocumento())) {
							noDocumentoBen = "";
						} else {
							noDocumentoBen = responseWS.getTransaccion().getUsuario().getNoDocumento();
						}

						if (responseWS.getTransaccion().getUsuario() != null) {
							if (responseWS.getTransaccion().getUsuario().getTipoUsuario() == null
									|| "".equals(responseWS.getTransaccion().getUsuario().getTipoUsuario().trim())) {
								responseWS.getTransaccion().getUsuario().setTipoUsuario(IConstants.PERSONA_JURIDICA);
							}
						} else {
							UsuarioDTO usuario = new UsuarioDTO();
							usuario.setTipoUsuario(IConstants.PERSONA_NATURAL);
							responseWS.getTransaccion().setUsuario(usuario);
						}

						monto = responseWS.getTransaccion().getValorTotal();

						// Se consulta la lista de bancos para pagos PSE
						if (renderMedioPagoPSE) {
							try {

								consulta.setTransaccion(responseWS.getTransaccion());

								// Modificacion para enmascarar datos sensibles.
								try {
									String correoCliente = consulta.getTransaccion().getUsuario()
											.getCorreoElectronico();
									consulta.getTransaccion().getUsuario()
											.setCorreoElectronico(enmascararCorreo(correoCliente));
									// Auditoria portal pasarela
									auditarAccion(token, dirIp, "consultar lista banco", responseWS.getTransaccion()
											.getComercio().getCodigoNura(), "Seleccionar Medio de pago", "Exitoso",
											consulta);
									// Modificacion para enmascarar datos
									// sensibles.
									consulta.getTransaccion().getUsuario().setCorreoElectronico(correoCliente);
								} catch (Exception e) {
									// Auditoria portal pasarela
									auditarAccion(token, dirIp, "consultar lista banco", responseWS.getTransaccion()
											.getComercio().getCodigoNura(), "Seleccionar Medio de pago", "Exitoso",
											consulta);
								}

								WSConsultasResponseDTO consultaBancos = cs.getBankListByCommerce(consulta);

								// Modificacion para enmascarar datos sensibles.
								try {
									String correoCliente = consulta.getTransaccion().getUsuario()
											.getCorreoElectronico();
									consulta.getTransaccion().getUsuario()
											.setCorreoElectronico(enmascararCorreo(correoCliente));
									// Auditoria portal pasarela
									auditarAccion(token, dirIp, "recibir lista bancos", responseWS.getTransaccion()
											.getComercio().getCodigoNura(), "Seleccionar Medio de pago", "Exitoso",
											consulta);
									// Modificacion para enmascarar datos
									// sensibles.
									consulta.getTransaccion().getUsuario().setCorreoElectronico(correoCliente);
								} catch (Exception e) {
									// Auditoria portal pasarela
									auditarAccion(token, dirIp, "recibir lista bancos", responseWS.getTransaccion()
											.getComercio().getCodigoNura(), "Seleccionar Medio de pago", "Exitoso",
											consulta);
								}

								bancosPSE = new LinkedHashMap<String, String>();

								if (consultaBancos.getStatusCode() != Long.valueOf(IConstants.SSC_EXITOSO)) {
									actMensaje = 1;
									renderMensajeBancos = true;
								} else {
									renderMensajeBancos = false;
									List<BancoDTO> bancos = consultaBancos.getBancos();
									for (BancoDTO banco : bancos) {
										bancosPSE.put(banco.getBankId(), banco.getNombre());
									}
								}

							} catch (Exception e) {
								actMensaje = 1;
								renderMensajeBancos = true;
								// Auditoria portal pasarela
								auditarAccion(token, dirIp, "recibir lista bancos", responseWS.getTransaccion()
										.getComercio().getCodigoNura(), "Seleccionar Medio de pago", "Fallido",
										consulta);
								log.error("::: ERROR AL OBTENER LA LISTA DE BANCOS PARA PAGOS PSE :::");
							}
						}
					}
				}
			} else {
				mensajeInfo.setLength(0);
				mensajeInfo.append("::: ERROR AL CONSULTAR SESION DEL TOKEN: ");
				mensajeInfo.append(token);
				mensajeInfo.append(" :::");
				log.error(mensajeInfo);
				renderInfoCompra = false;
				renderInfoComprador = false;
				renderInfoMedioPago = false;
				token = getSessionMap().get("transactionToken").toString();
				responseWS = (WSConsultasResponseDTO) getSessionMap().get("transactionByToken");
				renderBotonError = true;

				getSessionMap().put("transactionByToken", null);
				getSessionMap().put("bankList", null);
				getSessionMap().put("transactionToken", null);
				getSessionMap().put("transactionToken", null);
			}

		} catch (Exception e) {
			mensajeInfo.setLength(0);
			mensajeInfo.append("::: ERROR AL OBTENER LA TRANSACCION CON EL TOKEN: ");
			mensajeInfo.append(token);
			mensajeInfo.append(" :::");
			log.error(mensajeInfo, e);
			setRenderBotonVolver(true);
			setRenderInfoCompra(Boolean.FALSE);
			printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO, mensajeErrorGeneral);
		}

		log.info("::: TERMINA METODO inicializarRequest() DEL BEAN MediosPagoBean :::");
		log.info("VALOR ULTIMO SALIDA CARGA TEMPLATE:" + templateTaq + "\n" + footTaq + "\n" + theme + "\n" + footer
				+ "\n" + estilocss + "\n" + cabezote);
	}

	// Configuracion para el logo del convenio
	private void setLogoConvenio(String logoUrl) {

		try {

			System.setProperty("java.net.useSystemProxies", "true");

			URL url = new URL(logoUrl);
			URLConnection connection = url.openConnection();

			StringBuilder mensajeInfo = new StringBuilder();

			// Validar si se puede establecer conexion
			if (connection != null) {

				String contentType = connection.getContentType();
				if (contentType != null) {
					// Validar que el tipo de contenido no sea un mensaje HTML
					if (contentType.contains("text/html")) {
						mensajeInfo.setLength(0);
						mensajeInfo.append("::: ERROR AL TRAER LOGO CONVENIO ERROR DE SERVIDOR ::: ");
						mensajeInfo.append(contentType);
						log.error(mensajeInfo);
						setRenderLogo(false);
					} else {
						// Si el contenido no es html mostrar logo
						setRenderLogo(true);
					}
				} else if (logoUrl.toLowerCase().contains(".jpeg") || logoUrl.toLowerCase().contains(".jpg")
						|| logoUrl.toLowerCase().contains(".png")) {
					// En caso de no resolver el tipo de contenido se valida si
					// la URL tiene .jpeg .jpg o .png
					setRenderLogo(true);
				} else {
					// Si no se puede resolver el tipo de contenido ni validar
					// la extension
					log.error("::: NO SE PUEDE OBTENER EL LOGO ::: " + logoUrl);
					setRenderLogo(false);
				}

			} else {
				log.error("::: ERROR AL TRAER LOGO CONVENIO NO SE PUEDE ESTABLECER CONEXION ::: " + logoUrl);
				setRenderLogo(false);
			}

		} catch (MalformedURLException e) {
			log.error("::: URL DE LOGO NO VALIDA ::: " + logoUrl, e);
			setRenderLogo(false);
		} catch (IOException e) {
			log.error("::: ERROR I/O LOGO NO VALIDO ::: " + logoUrl, e);
			setRenderLogo(false);
		} catch (Exception e) {
			log.error("::: EXCEPCION NO CONTROLADA ::: " + logoUrl, e);
			setRenderLogo(false);
		}

		if (renderLogo) {
			setLogoComercio(logoUrl);
		}

	}

	private void cargarVariables() {
		bancoPagoAval = "0";

		opcion = false;

		logoAval = "logo-grupo-aval";
		logoPse = "logo-tarjeta-pse";
		logoTc = "logo-tarjetas-credito";

		setRenderBotonVolver(false);
		renderInfoMedioPago = true;
		renderInfoCompra = true;
		renderAval = false;
		renderBotonError = false;
		renderMensaje = false;
		renderMensajeBancos = false;
		errorProceso = "0";
		errorCancel = "0";
		renderMedioPagoAval = false;
		renderMedioPagoTC = false;
		renderMedioPagoPSE = false;
		setRenderReferencia2(false);
		setRenderReferencia3(false);
		setRenderReferencia4(false);
		setRenderBancoBogota(true);
		setRenderBancoOccidente(true);
		disTipoBen = true;
		disTipoPago = true;
		setTipoPersona("1");
		setEstiloBanco("banco");
		setDuracionSesion(WebLocator.getPreferences().getValue("duracionSession", null));
		setUrlRedireccion(WebLocator.getPreferences().getValue("urlRedireccion", null));
		franquiciasValidas = WebLocator.getPreferences().getValue("franquiciasValidas", "");
		String configPath = WebLocator.getPreferences().getValue("configPath", null);
		PropertiesLoader propertiesLoader = PropertiesLoader.getInstance();
		propertiesTheme = propertiesLoader.getProperties(configPath, "theme.properties");
		propertiesPlan = propertiesLoader.getProperties(configPath, "plantilla.properties");// RQ26210
		mensajeErrorGeneral = IConstants.SSC_DESC_ERROR_GENERAL_PP;
		mensajeError = IConstants.SSC_DESC_ERROR_PP;
		mensajeBancos = IConstants.SSC_DESC_ERROR_BANCOS;

		// Constantes tema 1
		NAME_THEME_ONE = propertiesTheme.getProperty(IConstants.NAME_THEME_ONE);
		NAME_LAYAOUT_THEME_ONE = propertiesTheme.getProperty(IConstants.NAME_LAYAOUT_THEME_ONE);
		CSS_THEME_ONE = propertiesTheme.getProperty(IConstants.CSS_THEME_ONE);
		PAY_LAYAOUT_THEME_ONE = propertiesTheme.getProperty(IConstants.PAY_LAYAOUT_THEME_ONE);

		// Constantes tema 2
		NAME_THEME_TWO = propertiesTheme.getProperty(IConstants.NAME_THEME_TWO);
		NAME_LAYAOUT_THEME_TWO = propertiesTheme.getProperty(IConstants.NAME_LAYAOUT_THEME_TWO);
		CSS_THEME_TWO = propertiesTheme.getProperty(IConstants.CSS_THEME_TWO);
		PAY_LAYAOUT_THEME_TWO = propertiesTheme.getProperty(IConstants.PAY_LAYAOUT_THEME_TWO);

		layaoutPortlet = PAY_LAYAOUT_THEME_ONE;

		themePortlet = CSS_THEME_ONE;
		// Constantes Taquilla RQ26210
		ENCABEZADO_DEFAULT = propertiesPlan.getProperty(IConstants.ENCABEZADO_DEFAULT);
		FOOTER_AZUL = propertiesPlan.getProperty(IConstants.FOOTER_AZUL);
		FOOTER_ROJO = propertiesPlan.getProperty(IConstants.FOOTER_ROJO);
		FOOTER_GRIS = propertiesPlan.getProperty(IConstants.FOOTER_GRIS);
		COLOR_ROJO = propertiesPlan.getProperty(IConstants.COLOR_ROJO);
		COLOR_AZUL = propertiesPlan.getProperty(IConstants.COLOR_AZUL);
		COLOR_GRIS = propertiesPlan.getProperty(IConstants.COLOR_GRIS);
		templateTaq = false;
		footTaq = false;
	}

	/**
	 * Metodo encargado de cargar las listas que se usan en la aplicacion
	 */
	private void cargarListas() {
		documentosIdentidad = WebLocator.getPreferences().getValue("documentosIdentidad", "");
		tiposDocumento = new LinkedHashMap<String, String>();
		if (documentosIdentidad != null) {
			try {
				for (String documento : documentosIdentidad.split("-")) {
					tiposDocumento.put(documento.substring(0, documento.indexOf(";")),
							documento.substring(documento.indexOf(";") + 1));
				}
			} catch (Exception e) {
				log.error("::: ERROR AL PROCESAR LOS DOCUMENTOS DE IDENTIDAD ::: ", e);
			}
		}

		cuotas = new LinkedHashMap<String, String>();
		Integer cantidadCuotas = Integer.valueOf(WebLocator.getPreferences().getValue("cantidadCuotas", ""));
		for (int i = 1; i <= cantidadCuotas; i++) {
			cuotas.put(String.valueOf(i), String.valueOf(i));
		}
	}

	/**
	 * Metodo que se ejecuta cuando se selecciona un medio de pago, y se encarga
	 * de mostrar la informaci�n necesaria en pantalla
	 */
	public void actualizarMedioPago() {
		Integer idMedio = responseWS.getTransaccion().getMedioPago().getId();
		pseSiguienteDiaHabil = false;
		if (idMedio != null) {
			if (idMedio == Integer.valueOf(IConstants.PAGOS_AVAL_ID)) {
				renderAval = true;
				renderPSE = false;
				renderTC = false;
				renderPagar = true;
				logoAval = "logo-grupo-aval";
				logoPse = "logo-tarjeta-pse-deshabilitado";
				logoTc = "logo-tarjetas-credito-deshabilitado";
			} else if (idMedio == Integer.valueOf(IConstants.PAGOS_PSE_ID)) {
				renderAval = false;
				renderPSE = true;
				renderTC = false;
				renderPagar = true;
				logoPse = "logo-tarjeta-pse";
				logoAval = "logo-grupo-aval-deshabilitado";
				logoTc = "logo-tarjetas-credito-deshabilitado";

				int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
				int minute = Calendar.getInstance().get(Calendar.MINUTE);

				String maxHourACHString = WebLocator.getPreferences().getValue("maxHourACH", null);
				String maxMinuteACHString = WebLocator.getPreferences().getValue("maxMinuteACH", null);
				String nextDayACH = WebLocator.getPreferences().getValue("nextDayACH", null);

				int maxHourACH = 17;
				int maxMinuteACH = 30;

				try {
					if (maxHourACHString != null && maxMinuteACHString != null) {
						maxHourACH = Integer.valueOf(maxHourACHString);
						maxMinuteACH = Integer.valueOf(maxMinuteACHString);
					}
				} catch (NumberFormatException ex) {
					log.error("::: ERROR AL OBTENER LAS PREFERENCIAS DE HORA PARA ACH :::", ex);
				}

				if (hour > maxHourACH) {
					// Si la hora es mayor a la definida se muestra el mensaje
					// Ej 18 > 17
					pseSiguienteDiaHabil = true;
				} else if (hour == maxHourACH && minute >= maxMinuteACH) {
					// Si la hora igual a la definida se muestra el mensaje Ej
					// 17 == 17 && 20 > 30
					pseSiguienteDiaHabil = true;
				} else {
					pseSiguienteDiaHabil = false;
				}

				if (pseSiguienteDiaHabil && codigoNura != null && nextDayACH.contains(codigoNura)) {
					// Si la condicion por hora se cumple, validar el ID del
					// convenio
					pseSiguienteDiaHabil = true;
				} else {
					pseSiguienteDiaHabil = false;
				}

			} else if (idMedio == Integer.valueOf(IConstants.PAGOS_TC_ID)) {
				renderAval = false;
				renderPSE = false;
				renderTC = true;
				renderPagar = true;
				logoTc = "logo-tarjetas-credito";
				logoAval = "logo-grupo-aval-deshabilitado";
				logoPse = "logo-tarjeta-pse-deshabilitado";
			} else {
				renderAval = false;
				renderPSE = false;
				renderTC = false;
				renderPagar = false;
			}
		} else {
			renderAval = false;
			renderPSE = false;
			renderTC = false;
			renderPagar = false;
		}
		// Comentarios siguiente d?a habil
		log.info("::: MEDIO PAGO ::: Siguiente d?a: " + pseSiguienteDiaHabil);
	}

	@SuppressWarnings("unchecked")
	public void pagarAval() {
		log.info("::: INICIA METODO pagarAval() DEL BEAN MediosPagoBean :::");

		/** INICIO-C02 **/
		FacesContext context = FacesContext.getCurrentInstance();
		HttpServletRequest requestBase = (HttpServletRequest) context.getExternalContext().getRequest();
		PortletRequestWrapper requestWrapper = (PortletRequestWrapper) requestBase;
		PortletRequest portletRequest = requestWrapper.getPortletRequest();
		requestCompleto = PortletUtils.getHttpServletRequest(portletRequest);
		/** FIN-C02 **/

		String urlRedirect = "";
		WSPagosResponseDTO responseWS = null;
		UsuarioDTO usuario = new UsuarioDTO();
		StringBuilder mensajeInfo = new StringBuilder();

		try {
			ClientePagosService cs = new ClientePagosService();
			WSPagosDTO pago = new WSPagosDTO();

			MedioPagoDTO medioPagoDTO = new MedioPagoDTO();
			medioPagoDTO.setId(Integer.valueOf(IConstants.PAGOS_AVAL_ID));
			this.responseWS.getTransaccion().setMedioPago(medioPagoDTO);

			pago.setDeviceToken(obtenerVariable()); // RQ25542
													// MotorDeRiesgosPortal
			pago.setDevicePrint(sDevicePrint); // RQ25542 MotorDeRiesgosPortal
			deviceToken = pago.getDeviceToken(); // RQ25542 MotorDeRiesgosPortal

			pago.setTransaccion(this.responseWS.getTransaccion());

			// Modificacion para enmascarar datos sensibles.
			String correoCliente = pago.getTransaccion().getUsuario().getCorreoElectronico();
			pago.getTransaccion().getUsuario().setCorreoElectronico(enmascararCorreo(correoCliente));

			usuario = pago.getTransaccion().getUsuario();
			usuario.setNoDocumento(noDocumentoBen.trim());
			/** INICIO-C08 **/
			usuario.setPrimerNombrePago(primerNombrePago);
			/** FIN-C08 **/
			usuario.setSegundoNombrePago(segundoNombrePago);
			usuario.setPrimerApellidoPago(primerApellidoPago);
			usuario.setSegundoApellidoPago(segundoApellidoPago);
			usuario.setTelefonoPago(telefonoPago);
			usuario.setTipoDocumentoPago(tipoDocumentoPago);
			usuario.setNoDocumentoPago(noDocumentoPago.trim());
			usuario.setCorreoElectronicoPago(enmascararCorreo(correoPago));

			pago.setIpOrigen(dirIp);
			pago.setChannel(IConstants.CANAL_PASARELA);

			/** INICIO-C02 **/
			pago.setUserAgent(requestCompleto.getHeader(HEADER_USER_AGENT));
			pago.setHttpAccept(requestCompleto.getHeader(HEADER_ACCEPT));
			pago.setHttpAcceptLanguage(requestCompleto.getHeader(HEADER_ACCEPT_LANGUAGE));
			pago.setHttpReferrer(requestCompleto.getHeader(HEADER_REFERER));
			/** FIN-C02 **/
			/*
			 * Se cambia el nombre por el valor original recibido en la
			 * respuesta del servicio getTransactionById almacenado en la carga
			 * del formulario en una variable auxiliar
			 */
			/** INICIO-C04 **/
			if (WebLocator.getPreferences().getValue(CODE_NURA_FACILPASS, "").equals(codigoNura)) {
				if (this.responseWS.getTransaccion().getUsuario() != null) {
					this.responseWS.getTransaccion().getUsuario().setPrimerNombre(auxPrimerNombre);
				}

			}
			/** INICIO-C10 **/
			else{
				if(rendercheck==false){
					
					usuario.setPrimerNombre(primerNombrePago);
					usuario.setTipoDocumento(tipoDocumentoPago);
					usuario.setNoDocumento(noDocumentoPago);
					usuario.setCorreoElectronico(correoPago);
					

					log.info("::: Primer nombre :::"+primerNombrePago );
					log.info("::: tipoDocumento :::"+ tipoDocumentoPago);
					log.info("::: noDocumento :::"+ noDocumentoPago);
					log.info("::: correoElectronico :::"+ correoPago );	
					
				}
			}

			/** FIN-C10 **/

			CuentaDTO cuenta = new CuentaDTO();
			BancoDTO banco = new BancoDTO();

			if (IConstants.AVVILLAS.equals(bancoPagoAval)) {
				urlRedirect = WebLocator.getPreferences().getValue("urlAVVillas", "");
				banco.setBankId(IConstants.AVVILLAS_BANK_ID);
			} else if (IConstants.POPULAR.equals(bancoPagoAval)) {
				urlRedirect = WebLocator.getPreferences().getValue("urlPopular", "");
				banco.setBankId(IConstants.POPULAR_BANK_ID);
			} else if (IConstants.OCCIDENTE.equals(bancoPagoAval)) {
				urlRedirect = WebLocator.getPreferences().getValue("urlOccidente", "");
				banco.setBankId(IConstants.OCCIDENTE_BANK_ID);
			} else if (IConstants.BOGOTA.equals(bancoPagoAval)) {
				urlRedirect = WebLocator.getPreferences().getValue("urlBogota", "");
				banco.setBankId(IConstants.BOGOTA_BANK_ID);
			}

			cuenta.setBanco(banco);
			pago.setCuenta(cuenta);

			pago.getTransaccion().setUsuario(usuario);

			// Auditoria portal pasarela
			auditarAccion(token, dirIp, "realizar pago",
					this.responseWS.getTransaccion().getComercio().getCodigoNura(), "Seleccionar Medio de pago",
					"Exitoso", pago);

			// Modificacion para enmascarar datos sensibles.
			usuario.setCorreoElectronico(correoCliente);
			usuario.setCorreoElectronicoPago(correoPago);

			pago.getTransaccion().setUsuario(usuario);

			responseWS = cs.addAvalPayment(pago);

			if (responseWS == null
					|| responseWS.getStatusCode() != Long.valueOf(IConstants.SSC_EXITOSO)
					|| Integer.valueOf(IConstants.SSC_ERROR_LISTAS_NEGRAS).equals(
							responseWS.getTransaccion().getEstadoPago().getId())) {
				errorProceso = "1";
				getSessionMap().put("transactionByToken", this.responseWS);
				getSessionMap().put("bankList", this.bancosPSE);
				getSessionMap().put("transactionToken", this.token);

				// Modificacion para enmascarar datos sensibles.
				correoCliente = pago.getTransaccion().getUsuario().getCorreoElectronico();
				pago.getTransaccion().getUsuario().setCorreoElectronico(enmascararCorreo(correoCliente));
				pago.getTransaccion().getUsuario().setCorreoElectronicoPago(enmascararCorreo(correoPago));

				// Auditoria portal pasarela
				auditarAccion(token, dirIp, "realizar pago", this.responseWS.getTransaccion().getComercio()
						.getCodigoNura(), "Seleccionar Medio de pago", "Fallido", pago);

				// Modificacion para enmascarar datos sensibles.
				pago.getTransaccion().getUsuario().setCorreoElectronico(correoCliente);
				pago.getTransaccion().getUsuario().setCorreoElectronicoPago(correoPago);

				// Modificacion Motor de Riesgo 25542.
				pago.setDeviceToken(responseWS.getToken());

				if (responseWS.getServerStatusCode() != null) {
					setRenderBotonVolver(true);
					printFacesMessage(
							FacesContext.getCurrentInstance(),
							FacesMessage.SEVERITY_INFO,
							mensajeErrorGeneral + " - "
									+ IConstants.erroresServer.get(responseWS.getServerStatusCode()));
					log.error("::: ERROR LA RESPUESTA DEL SERVICIO addAvalPayment NO FUE EXITOSA ERROR:  "
							+ responseWS.getServerStatusCode() + " :::");
				} else {
					if (Integer.valueOf(IConstants.SSC_ERROR_LISTAS_NEGRAS).equals(
							responseWS.getTransaccion().getEstadoPago().getId())) {
						log.error("::: ERROR LA RESPUESTA DEL SERVICIO addAvalPayment NO FUE EXITOSA ERROR:  "
								+ IConstants.SSC_ERROR_LISTAS_NEGRAS + " :::");
						// Hacer redirect al resultado de pago
						urlRedirect = WebLocator.getPreferences().getValue("urlRedirectPagoRBM", "");
						urlRedirect = urlRedirect + token + "&error=30";
						FacesContext fc = FacesContext.getCurrentInstance();
						ExternalContext ec = fc.getExternalContext();
						ec.redirect(urlRedirect);
					} 
					else {
						log.error("::: ERROR LA RESPUESTA DEL SERVICIO addAvalPayment FUE NULL :::");
						setRenderBotonVolver(true);
						printFacesMessage(
								FacesContext.getCurrentInstance(),
								FacesMessage.SEVERITY_INFO,
								mensajeErrorGeneral + " - "
										+ IConstants.erroresServer.get(String.valueOf(responseWS.getStatusCode())));
					}
				}
			} else {
				// Auditoria portal pasarela
				try {

					auditarAccion(token, dirIp, "recibir realizar pago", this.responseWS.getTransaccion().getComercio()
							.getCodigoNura(), "Seleccionar Medio de pago", "Exitoso", responseWS);

					urlRedirect = urlRedirect.replaceAll("#", "&");
					urlRedirect = String.format(urlRedirect, responseWS.getTransaccion().getPmtId());
					// Motor de Riego INI
					setCookieValue(responseWS.getToken());
					urlRedirectPay = urlRedirect;
					FacesContext fc = FacesContext.getCurrentInstance();
					// fc.release();
					// Motor de Riego FIN
					// ExternalContext ec = fc.getExternalContext();
					getSessionMap().put("transactionByToken", null);
					// ec.redirect(urlRedirect);
				} catch (Exception ex) {
					getSessionMap().put("transactionByToken", this.responseWS);
					getSessionMap().put("bankList", this.bancosPSE);
					getSessionMap().put("transactionToken", this.token);
					log.error("::: ERROR AL REDIRECCIONAR A LA URL DE PAGO : " + urlRedirect + " :::", ex);
				}
			}
			log.info("::: TERMINA METODO pagarAval() DEL BEAN MediosPagoBean :::");

		} catch (Exception e) {
			errorProceso = "1";
			getSessionMap().put("transactionByToken", this.responseWS);
			getSessionMap().put("bankList", this.bancosPSE);
			getSessionMap().put("transactionToken", this.token);
			// Auditoria portal pasarela
			auditarAccion(token, dirIp, "realizar pago",
					this.responseWS.getTransaccion().getComercio().getCodigoNura(), "Seleccionar Medio de pago",
					"Fallido", responseWS == null ? this.responseWS : responseWS);
			mensajeInfo.setLength(0);
			mensajeInfo.append("::: ERROR PAGO: ");
			mensajeInfo.append(e.getMessage());

			log.error(mensajeInfo);
			mensajeInfo.setLength(0);
			mensajeInfo.append("::: ERROR AL CREAR PAGO AVAL: ");
			mensajeInfo.append(token);
			mensajeInfo.append(" :::");
			log.error(mensajeInfo);
			setRenderBotonVolver(true);
			printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO, mensajeErrorGeneral);
		}

	}

	@SuppressWarnings("unchecked")
	public void pagarPSE() {
		log.info("::: INICIA METODO pagarPSE() DEL BEAN MediosPagoBean :::");

		String urlRedirect = "";
		WSPagosResponseDTO responseWS = null;
		UsuarioDTO usuario = new UsuarioDTO();

		/** INICIO-C02 **/
		FacesContext context = FacesContext.getCurrentInstance();
		HttpServletRequest requestBase = (HttpServletRequest) context.getExternalContext().getRequest();
		PortletRequestWrapper requestWrapper = (PortletRequestWrapper) requestBase;
		PortletRequest portletRequest = requestWrapper.getPortletRequest();
		requestCompleto = PortletUtils.getHttpServletRequest(portletRequest);
		/** FIN-C02 **/

		renderInfoMedioPago = true;
		renderInfoCompra = true;
		renderInfoComprador = true;

		StringBuilder mensajeInfo = new StringBuilder("");

		try {
			ClientePagosService cs = new ClientePagosService();
			WSPagosDTO pago = new WSPagosDTO();

			MedioPagoDTO medioPagoDTO = new MedioPagoDTO();
			medioPagoDTO.setId(Integer.valueOf(IConstants.PAGOS_PSE_ID));
			this.responseWS.getTransaccion().setMedioPago(medioPagoDTO);

			pago.setDeviceToken(obtenerVariable()); // RQ25542
													// MotorDeRiesgosPortal
			pago.setDevicePrint(sDevicePrint); // RQ25542 MotorDeRiesgosPortal
			deviceToken = pago.getDeviceToken(); // RQ25542 MotorDeRiesgosPortal

			pago.setTransaccion(this.responseWS.getTransaccion());

			// Modificacion para enmascarar datos sensibles.
			String correoCliente = pago.getTransaccion().getUsuario().getCorreoElectronico();
			pago.getTransaccion().getUsuario().setCorreoElectronico(enmascararCorreo(correoCliente));

			usuario = pago.getTransaccion().getUsuario();
			usuario.setNoDocumento(noDocumentoBen.trim());
			/** INICIO-C08 **/
			usuario.setPrimerNombrePago(primerNombrePago);
			/** FIN-C08 **/
			usuario.setSegundoNombrePago(segundoNombrePago);
			usuario.setPrimerApellidoPago(primerApellidoPago);
			usuario.setSegundoApellidoPago(segundoApellidoPago);
			usuario.setTelefonoPago(telefonoPago);
			usuario.setTipoDocumentoPago(tipoDocumentoPago);
			usuario.setNoDocumentoPago(noDocumentoPago.trim());
			usuario.setCorreoElectronicoPago(enmascararCorreo(correoPago));
			usuario.setTipoUsuario(tipoPersona);

			pago.setIpOrigen(dirIp);
			pago.setChannel(IConstants.CANAL_PASARELA);
			CuentaDTO cuenta = new CuentaDTO();
			BancoDTO banco = new BancoDTO();
			banco.setBankId(idBancoPSE);
			cuenta.setBanco(banco);
			pago.setCuenta(cuenta);

			/** INICIO-C02 **/
			try {
				pago.setUserAgent(requestCompleto.getHeader(HEADER_USER_AGENT));
				pago.setHttpAccept(requestCompleto.getHeader(HEADER_ACCEPT));
				pago.setHttpAcceptLanguage(requestCompleto.getHeader(HEADER_ACCEPT_LANGUAGE));
				pago.setHttpReferrer(requestCompleto.getHeader(HEADER_REFERER));
			} catch (Exception e) {
				log.error("NO SE PUEDEN OBTENER LAS CABECERAS HTTP MOTOR DE RIESGO");
			}

			/** FIN-C02 **/
			/*
			 * Se cambia el nombre por el valor original recibido en la
			 * respuesta del servicio getTransactionById almacenado en la carga
			 * del formulario en una variable auxiliar
			 */
			/** INICIO-C04 **/
			if (WebLocator.getPreferences().getValue(CODE_NURA_FACILPASS, "").equals(codigoNura)) {
				if (this.responseWS.getTransaccion().getUsuario() != null) {
					this.responseWS.getTransaccion().getUsuario().setPrimerNombre(auxPrimerNombre);
				}

			}
			/** FIN-C04 **/
			/** INICIO-C10 **/
			else{
				if(rendercheck==false){
					
					usuario.setPrimerNombre(primerNombrePago);
					usuario.setTipoDocumento(tipoDocumentoPago);
					usuario.setNoDocumento(noDocumentoPago);
					usuario.setCorreoElectronico(correoPago);
					

					log.info("::: Primer nombre :::"+primerNombrePago );
					log.info("::: tipoDocumento :::"+ tipoDocumentoPago);
					log.info("::: noDocumento :::"+ noDocumentoPago);
					log.info("::: correoElectronico :::"+ correoPago );	
					
				}
			}
			/** FIN-C10 **/
			pago.getTransaccion().setUsuario(usuario);

			// Auditoria portal pasarela
			auditarAccion(token, dirIp, "realizar pago",
					this.responseWS.getTransaccion().getComercio().getCodigoNura(), "Seleccionar Medio de pago",
					"Exitoso", pago);

			// Modificacion para enmascarar datos sensibles.
			pago.getTransaccion().getUsuario().setCorreoElectronico(correoCliente);
			pago.getTransaccion().getUsuario().setCorreoElectronicoPago(correoPago);

			responseWS = cs.addPSETransaction(pago);

			if (responseWS == null || responseWS.getStatusCode() != Long.valueOf(IConstants.SSC_EXITOSO)) {

				log.error("::: ERROR LA RESPUESTA DEL SERVICIO addPSETransaction NO FUE EXITOSA :::");
				errorProceso = "1";
				getSessionMap().put("transactionByToken", this.responseWS);
				getSessionMap().put("bankList", this.bancosPSE);
				getSessionMap().put("transactionToken", this.token);

				// Modificacion para enmascarar datos sensibles.
				correoCliente = pago.getTransaccion().getUsuario().getCorreoElectronico();
				pago.getTransaccion().getUsuario().setCorreoElectronico(enmascararCorreo(correoCliente));
				pago.getTransaccion().getUsuario().setCorreoElectronicoPago(enmascararCorreo(correoPago));

				// Auditoria portal pasarela
				auditarAccion(token, dirIp, "realizar pago", this.responseWS.getTransaccion().getComercio()
						.getCodigoNura(), "Seleccionar Medio de pago", "Fallido", pago);

				// Modificacion para enmascarar datos sensibles.
				pago.getTransaccion().getUsuario().setCorreoElectronico(correoCliente);
				pago.getTransaccion().getUsuario().setCorreoElectronicoPago(correoPago);

				// Ajuste para el mapeo de errores ACH
				if (responseWS != null) {
					mensajeInfo.setLength(0);
					mensajeInfo.append("::: ERROR LA RESPUESTA DEL SERVICIO addPSETransaction NO FUE EXITOSA ERROR:  ");
					mensajeInfo.append(responseWS.getStatusCode());
					mensajeInfo.append(" :::");

					log.error(mensajeInfo);

					// Error 400
					if (responseWS.getStatusCode() == Long.valueOf(IConstants.SSC_ACH_ERROR_FAIL)) {
						mensajeInfo.setLength(0);
						mensajeInfo
								.append("::: ERROR LA RESPUESTA DEL SERVICIO addPSETransaction NO FUE EXITOSA DETALLE ERROR ACH:  ");
						mensajeInfo.append(responseWS.getStatusCode());
						mensajeInfo.append(" :::");
						log.error(mensajeInfo);

						if (IConstants.ACH_PAGO_COD_FAIL_EXCEEDED.equals(responseWS.getServerStatusCode())) {
							printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO,
									IConstants.estadoPago.get(String.valueOf(responseWS.getServerStatusCode())) + " "
											+ mensajeError);
						} else if (IConstants.ACH_PAGO_COD_FAIL_BANK.equals(responseWS.getServerStatusCode())) {
							printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO,
									IConstants.estadoPago.get(String.valueOf(responseWS.getServerStatusCode())));
						} else {
							printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO,
									IConstants.ACH_PAGO_DESC_FAIL_GENERAL + " " + mensajeError);
						}
						setRenderBotonVolver(true);
						// Error 30
					} else if (responseWS.getStatusCode() == Long.valueOf(IConstants.SSC_ERROR_LISTAS_NEGRAS)) {
						// Hacer redirect al resultado de pago
						urlRedirect = WebLocator.getPreferences().getValue("urlRedirectPagoRBM", "");
						urlRedirect = urlRedirect + token + "&error=30";
						FacesContext fc = FacesContext.getCurrentInstance();
						ExternalContext ec = fc.getExternalContext();
						ec.redirect(urlRedirect);
						// Error 27
					} else if (responseWS.getStatusCode() == Long.valueOf(IConstants.SSC_ERROR_TRANS_PENDIENTE)) {
						setRenderBotonVolver(true);
						printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO,
								IConstants.SSC_DESC_ERROR_TRANS_PENDIENTE + " "
										+ responseWS.getTransaccion().getNumeroOrden() + " "
										+ IConstants.SSC_DESC_CONTACTO_TRANS_PENDIENTE);
					} 	 
							 
						// Error 300
					else {
						setRenderBotonVolver(true);
						printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO,
								IConstants.ACH_PAGO_DESC_FAIL_GENERAL + " " + mensajeError);
					}
				} else {
					log.error("::: ERROR LA RESPUESTA DEL SERVICIO addPSETransaction FUE NULL :::");
					setRenderBotonVolver(true);
					printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO,
							IConstants.ACH_PAGO_DESC_FAIL_GENERAL + " " + mensajeError);
				}
			} else {
				// Auditoria portal pasarela
				auditarAccion(token, dirIp, "recibir realizar pago", this.responseWS.getTransaccion().getComercio()
						.getCodigoNura(), "Seleccionar Medio de pago", "Exitoso", responseWS);

				urlRedirect = responseWS.getPortalURL();
				// Motor de Riego INI
				setCookieValue(responseWS.getToken());
				urlRedirectPay = urlRedirect;
				FacesContext fc = FacesContext.getCurrentInstance();
				// Motor de Riego FIN
				// ExternalContext ec = fc.getExternalContext();

				try {
					getSessionMap().put("transactionByToken", null);
					// ec.redirect(urlRedirect);
				} catch (Exception ex) {
					getSessionMap().put("transactionByToken", this.responseWS);
					getSessionMap().put("bankList", this.bancosPSE);
					getSessionMap().put("transactionToken", this.token);

					mensajeInfo.setLength(0);
					mensajeInfo.append("::: ERROR AL REDIRECCIONAR A LA URL DE PAGO: ");
					mensajeInfo.append(urlRedirect);
					mensajeInfo.append(" :::");

					log.error(mensajeInfo, ex);
					setRenderBotonVolver(true);
					printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO,
							IConstants.ACH_PAGO_DESC_FAIL_GENERAL + " " + mensajeError);
				}
			}
			log.info("::: TERMINA METODO pagarPSE() DEL BEAN MediosPagoBean :::");
		} catch (Exception e) {
			errorProceso = "1";
			getSessionMap().put("transactionByToken", this.responseWS);
			getSessionMap().put("bankList", this.bancosPSE);
			getSessionMap().put("transactionToken", this.token);

			// Auditoria portal pasarela
			auditarAccion(token, dirIp, "realizar pago",
					this.responseWS.getTransaccion().getComercio().getCodigoNura(), "Seleccionar Medio de pago",
					"Fallido", responseWS == null ? this.responseWS : responseWS);
			mensajeInfo.setLength(0);
			mensajeInfo.append("::: ERROR PAGO: ");
			mensajeInfo.append(e.getMessage());
			log.error(mensajeInfo);
			mensajeInfo.setLength(0);
			mensajeInfo.append("::: ERROR AL CREAR EL PAGO PSE: ");
			mensajeInfo.append(token);
			mensajeInfo.append(" :::");
			log.error(mensajeInfo);
			setRenderBotonVolver(true);
			printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO,
					IConstants.ACH_PAGO_DESC_FAIL_GENERAL + " " + mensajeError);
		}
	}
	
	
	/** INICIO-C09 **/
	@SuppressWarnings("unchecked")
	public void pagarRBMLight() {
		log.info("::: INICIA METODO pagarRBMLight() DEL BEAN MediosPagoBean :::");
		WSPagosResponseDTO responseWS = null;
		UsuarioDTO usuario = new UsuarioDTO();

		StringBuilder mensajeInfo = new StringBuilder("");
		
		/** INICIO-C02 **/
		FacesContext context = FacesContext.getCurrentInstance();
		HttpServletRequest requestBase = (HttpServletRequest) context.getExternalContext().getRequest();
		PortletRequestWrapper requestWrapper = (PortletRequestWrapper) requestBase;
		PortletRequest portletRequest = requestWrapper.getPortletRequest();
		requestCompleto = PortletUtils.getHttpServletRequest(portletRequest);
		/** FIN-C02 **/		
		
		try {
	
			ClientePagoRBMService cs = new ClientePagoRBMService();
			WSPagosDTO pago = new WSPagosDTO();
			MedioPagoDTO medioPagoDTO = new MedioPagoDTO();
			medioPagoDTO.setId(Integer.valueOf(IConstants.PAGOS_TC_ID));
			
			this.responseWS.getTransaccion().setMedioPago(medioPagoDTO);

			pago.setDeviceToken(obtenerVariable()); // RQ25542
													// MotorDeRiesgosPortal
			pago.setDevicePrint(sDevicePrint); // RQ25542 MotorDeRiesgosPortal
			deviceToken = pago.getDeviceToken(); // RQ25542 MotorDeRiesgosPortal

			pago.setTransaccion(this.responseWS.getTransaccion());

			usuario = pago.getTransaccion().getUsuario();
			usuario.setNoDocumento(noDocumentoBen.trim());
			/** INICIO-C08 **/
			usuario.setPrimerNombrePago(primerNombrePago);
			/** FIN-C08 **/
			usuario.setSegundoNombrePago(segundoNombrePago);
			usuario.setPrimerApellidoPago(primerApellidoPago);
			usuario.setSegundoApellidoPago(segundoApellidoPago);
			usuario.setTelefonoPago(telefonoPago);
			usuario.setTipoDocumentoPago(tipoDocumentoPago);
			usuario.setNoDocumentoPago(noDocumentoPago.trim());
			usuario.setCorreoElectronicoPago(enmascararCorreo(correoPago));
			pago.getTransaccion().setUsuario(usuario);

			/** INICIO-C02 **/
			pago.setUserAgent(requestCompleto.getHeader(HEADER_USER_AGENT));
			pago.setHttpAccept(requestCompleto.getHeader(HEADER_ACCEPT));
			pago.setHttpAcceptLanguage(requestCompleto.getHeader(HEADER_ACCEPT_LANGUAGE));
			pago.setHttpReferrer(requestCompleto.getHeader(HEADER_REFERER));
			/** FIN-C02 **/
			/*
			 * Se cambia el nombre por el valor original recibido en la
			 * respuesta del servicio getTransactionById almacenado en la carga
			 * del formulario en una variable auxiliar
			 */
			/** INICIO-C04 **/
			if (WebLocator.getPreferences().getValue(CODE_NURA_FACILPASS, "").equals(codigoNura)) {
				if (this.responseWS.getTransaccion().getUsuario() != null) {
					this.responseWS.getTransaccion().getUsuario().setPrimerNombre(auxPrimerNombre);
				}
				
			}
			/** FIN-C04 **/
			/** INICIO-C10 **/
			else{
				if(rendercheck==false){
					
					usuario.setPrimerNombre(primerNombrePago);
					usuario.setTipoDocumento(tipoDocumentoPago);
					usuario.setNoDocumento(noDocumentoPago);
					usuario.setCorreoElectronico(correoPago);
					

					log.info("::: Primer nombre :::"+primerNombrePago );
					log.info("::: tipoDocumento :::"+ tipoDocumentoPago);
					log.info("::: noDocumento :::"+ noDocumentoPago);
					log.info("::: correoElectronico :::"+ correoPago );	
					
				}
			}
			/** FIN-C10 **/
			pago.setIpOrigen(dirIp);
			pago.setChannel(IConstants.CANAL_PASARELA);
			
			CuentaDTO cuenta = new CuentaDTO();
			BancoDTO banco = new BancoDTO();
			banco.setBankId(idBancoPSE);
			cuenta.setBanco(banco);
			pago.setCuenta(cuenta);

			// Modificacion para enmascarar datos sensibles.
			String correoCliente = pago.getTransaccion().getUsuario().getCorreoElectronico();
			pago.getTransaccion().getUsuario().setCorreoElectronico(enmascararCorreo(correoCliente));
			pago.getTransaccion().getUsuario().setCorreoElectronicoPago(enmascararCorreo(correoPago));

			// Auditoria portal pasarela
			auditarAccion(token, dirIp, "realizar pago",
					this.responseWS.getTransaccion().getComercio().getCodigoNura(), "Seleccionar Medio de pago",
					"Exitoso", pago);

			// Modificacion para enmascarar datos sensibles.
			pago.getTransaccion().getUsuario().setCorreoElectronico(correoCliente);
			pago.getTransaccion().getUsuario().setCorreoElectronicoPago(correoPago);
			
			
			responseWS = cs.initTransactionRbm(pago);
			
			log.info("StatusCode: "+responseWS.getStatusCode()+
					"\n..StatusCode: "+responseWS.getStatusCode()+
					"\n..StatusDesc: "+responseWS.getStatusDesc());
			
			log.info("StatusCode: "+responseWS.getStatusCode()+
					"\n..ServerStatusCode: "+responseWS.getServerStatusCode()+
					"\n..ServerStatusDesc: "+responseWS.getServerStatusDesc());
			
			

			if (responseWS == null
					|| responseWS.getStatusCode() != Long.valueOf(IConstants.SSC_EXITOSO)) {

				errorProceso = "1";
				getSessionMap().put("transactionByToken", this.responseWS);
				getSessionMap().put("bankList", this.bancosPSE);
				getSessionMap().put("transactionToken", this.token);

				// Modificacion para enmascarar datos sensibles.
				correoCliente = pago.getTransaccion().getUsuario().getCorreoElectronico();
				pago.getTransaccion().getUsuario().setCorreoElectronico(enmascararCorreo(correoCliente));
				pago.getTransaccion().getUsuario().setCorreoElectronicoPago(enmascararCorreo(correoPago));

				// Auditoria portal pasarela
				auditarAccion(token, dirIp, "realizar pago", this.responseWS.getTransaccion().getComercio()
						.getCodigoNura(), "Seleccionar Medio de pago", "Fallido", pago);

				// Modificacion para enmascarar datos sensibles.
				pago.getTransaccion().getUsuario().setCorreoElectronico(correoCliente);
				pago.getTransaccion().getUsuario().setCorreoElectronicoPago(correoPago);

				// Mapeo de Errores RBM RQ30573 INI
				if ((responseWS.getServerStatusCode() != null) && (responseWS.getServerStatusDesc() != null)) {
					mensajeInfo.setLength(0);
					mensajeInfo.append("::: ERROR LA RESPUESTA DEL SERVICIO InitTrx NO FUE EXITOSA ERROR:  ");
					mensajeInfo.append(responseWS.getServerStatusCode() + responseWS.getServerStatusDesc());
					
					mensajeInfo.append(" :::");
					log.error(mensajeInfo);
					setRenderBotonVolver(true);

					listaErrores = buscarErrorRBM(responseWS.getServerStatusCode());
					switch (listaErrores) {
						
						case 1:
							log.info(("::: case 1:  "+IConstants.SSC_DESC_ERROR_PAGO_RECHAZADO + " ("	+ (responseWS.getServerStatusCode() + ")")));
							printFacesMessage(
									FacesContext.getCurrentInstance(),
									FacesMessage.SEVERITY_INFO,
									IConstants.SSC_DESC_ERROR_PAGO_RECHAZADO + " ("	+ (responseWS.getServerStatusCode() + ")"));
							break;
							
						case 2:
							log.info(("::: case 2:  "+IConstants.SSC_DESC_ERROR_PAGO_RECHAZADO + " ("	+ (responseWS.getServerStatusCode() + ")")));
							printFacesMessage(
									FacesContext.getCurrentInstance(),
									FacesMessage.SEVERITY_INFO,
									IConstants.SSC_DESC_ERROR_TARJETA_RESTRINGIDA + " ("	+ (responseWS.getServerStatusCode() + ")"));
							break;
							
						case 3:
							log.info(("::: case 3:  "+IConstants.SSC_DESC_ERROR_PAGO_RECHAZADO + " ("	+ (responseWS.getServerStatusCode() + ")")));
							printFacesMessage(
									FacesContext.getCurrentInstance(),
									FacesMessage.SEVERITY_INFO,
									IConstants.SSC_DESC_ERROR_PROBLEMA_TECNICO + " ("	+ (responseWS.getServerStatusCode() + ")"));
							break;
							
						case 4:
							log.info(("::: case 4:  "+IConstants.SSC_DESC_ERROR_PAGO_RECHAZADO + " ("	+ (responseWS.getServerStatusCode() + ")")));
							printFacesMessage(
									FacesContext.getCurrentInstance(),
									FacesMessage.SEVERITY_INFO,
									IConstants.SSC_DESC_ERROR_PROCESO_VALIDACION + " ("	+ (responseWS.getServerStatusCode() + ")"));
							break;
							
						default:
							log.info(("::: case default :  "+IConstants.SSC_DESC_ERROR_PAGO_RECHAZADO + " ("	+ (responseWS.getServerStatusCode() + ")")));
							printFacesMessage(FacesContext.getCurrentInstance(),
									FacesMessage.SEVERITY_INFO, mensajeErrorGeneral + " (" +
									(responseWS.getServerStatusCode() + ")"));
							break;
					}
					// Mapeo de Errores RBM RQ30573 FIN
				} else {
					if (responseWS.getTransaccion().getEstadoPago().getId()
							.equals(Integer.valueOf(IConstants.SSC_ERROR_LISTAS_NEGRAS))) {
						mensajeInfo.setLength(0);
						mensajeInfo.append("::: ERROR LA RESPUESTA DEL SERVICIO InitTrx NO FUE EXITOSA ERROR:  ");
						mensajeInfo.append(IConstants.SSC_ERROR_LISTAS_NEGRAS);
						mensajeInfo.append(" :::");
						log.error(mensajeInfo);
						// Hacer redirect al resultado de pago
						String urlRedirect = WebLocator.getPreferences().getValue("urlRedirectPagoRBM", "");
						urlRedirect = urlRedirect + token + "&error=30";
						// Motor de Riego INI
						FacesContext fc = FacesContext.getCurrentInstance();
						// Motor de Riego FIN
						ExternalContext ec = fc.getExternalContext();
						ec.redirect(urlRedirect);
					} else if (responseWS.getTransaccion().getEstadoPago().getId()
							.equals(Integer.valueOf(IConstants.SSC_ERROR_IVA))
							|| responseWS.getTransaccion().getEstadoPago().getId()
									.equals(Integer.valueOf(IConstants.SSC_ERROR_DOCUMENTO))) {
						mensajeInfo.setLength(0);
						mensajeInfo.append("::: ERROR LA RESPUESTA DEL SERVICIO InitTrx NO FUE EXITOSA ERROR:  ");
						mensajeInfo.append(responseWS.getTransaccion().getEstadoPago().getId());
						mensajeInfo.append(" :::");
						log.error(mensajeInfo);
						setRenderBotonVolver(true);
						printFacesMessage(
								FacesContext.getCurrentInstance(),
								FacesMessage.SEVERITY_INFO,
								mensajeErrorGeneral
										+ " - "
										+ IConstants.erroresServer.get(String.valueOf(responseWS.getTransaccion()
												.getEstadoPago().getId())));
					} 
					else {
						mensajeInfo.setLength(0);
						mensajeInfo.append("::: ERROR LA RESPUESTA DEL SERVICIO InitTrx NO FUE EXITOSA ERROR:  ");
						mensajeInfo.append(responseWS.getStatusCode());
						mensajeInfo.append(" :::");
						log.error(mensajeInfo);
						setRenderBotonVolver(true);
						printFacesMessage(
								FacesContext.getCurrentInstance(),
								FacesMessage.SEVERITY_INFO,
								mensajeErrorGeneral + " - "
										+ IConstants.erroresServer.get(String.valueOf(responseWS.getStatusCode())));
					}
				}
			} else {
				// Auditoria portal pasarela
				auditarAccion(token, dirIp, "recibir realizar pago", this.responseWS.getTransaccion().getComercio()
						.getCodigoNura(), "Seleccionar Medio de pago", "Exitoso", responseWS);

				log.info("::: INICIA urlLightbox :::");
				setUrlLightboxredir(responseWS.getPortalURL().replace("*", "&"));
				String urlRedirect = WebLocator.getPreferences().getValue("UrlLightboxredir", "");
				
				urlRedirect = urlRedirect + token;
				log.info("::: Url preferences :::"+urlRedirect);
				FacesContext fc = FacesContext.getCurrentInstance();
				setCookieValue(responseWS.getToken());
				urlResultPay = urlRedirect;
				ExternalContext ec = fc.getExternalContext();
				
				try {
					getSessionMap().put("transactionByToken", null);
					// ec.redirect(urlRedirect);
				} catch (Exception ex) {
					getSessionMap().put("transactionByToken", this.responseWS);
					getSessionMap().put("bankList", this.bancosPSE);
					getSessionMap().put("transactionToken", this.token);
					mensajeInfo.setLength(0);
					mensajeInfo.append("::: ERROR AL REDIRECCIONAR A LA URL DE PAGO: ");
					mensajeInfo.append(urlRedirect);
					mensajeInfo.append(" :::");
					log.error(mensajeInfo, ex);
				}
			}
			log.info("::: TERMINA METODO pagarRBMLight() DEL BEAN MediosPagoBean :::");
		} catch (Exception e) {

			errorProceso = "1";
			getSessionMap().put("transactionByToken", this.responseWS);
			getSessionMap().put("bankList", this.bancosPSE);
			getSessionMap().put("transactionToken", this.token);
			// Auditoria portal pasarela
			auditarAccion(token, dirIp, "realizar pago",
					this.responseWS.getTransaccion().getComercio().getCodigoNura(), "Seleccionar Medio de pago",
					"Fallido", responseWS == null ? this.responseWS : responseWS);
			mensajeInfo.setLength(0);
			mensajeInfo.append(":::ERROR AL CREAR EL PAGO RBMLight: ");
			mensajeInfo.append(token);
			mensajeInfo.append(" :::");
			log.error(mensajeInfo);
			mensajeInfo.setLength(0);
			mensajeInfo.append("::: ERROR PAGO:  ");
			mensajeInfo.append(e.getMessage());
			mensajeInfo.append(" :::");

			log.error(mensajeInfo);
			setRenderBotonVolver(true);
			log.error("EXCEPCION GENERADA METODO pagarRBMLight",e);
			printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO, mensajeErrorGeneral);
		}
		
	}
	/** FIN-C09 **/

	@SuppressWarnings("unchecked")
	public void pagarRBM() {
		log.info("::: INICIA METODO pagarRBM() DEL BEAN MediosPagoBean :::");

		WSPagosResponseDTO responseWS = null;
		UsuarioDTO usuario = new UsuarioDTO();

		StringBuilder mensajeInfo = new StringBuilder("");

		/** INICIO-C02 **/
		FacesContext context = FacesContext.getCurrentInstance();
		HttpServletRequest requestBase = (HttpServletRequest) context.getExternalContext().getRequest();
		PortletRequestWrapper requestWrapper = (PortletRequestWrapper) requestBase;
		PortletRequest portletRequest = requestWrapper.getPortletRequest();
		requestCompleto = PortletUtils.getHttpServletRequest(portletRequest);
		/** FIN-C02 **/

		try {
			
			ClientePagosService cs = new ClientePagosService();
			WSPagosDTO pago = new WSPagosDTO();
			MedioPagoDTO medioPagoDTO = new MedioPagoDTO();
			medioPagoDTO.setId(Integer.valueOf(IConstants.PAGOS_TC_ID));
			
			this.responseWS.getTransaccion().setMedioPago(medioPagoDTO);

			pago.setDeviceToken(obtenerVariable()); // RQ25542
													// MotorDeRiesgosPortal
			pago.setDevicePrint(sDevicePrint); // RQ25542 MotorDeRiesgosPortal
			deviceToken = pago.getDeviceToken(); // RQ25542 MotorDeRiesgosPortal

			pago.setTransaccion(this.responseWS.getTransaccion());

			usuario = pago.getTransaccion().getUsuario();
			usuario.setNoDocumento(noDocumentoBen.trim());
			/** INICIO-C08 **/
			usuario.setPrimerNombrePago(primerNombrePago);
			/** FIN-C08 **/
			usuario.setSegundoNombrePago(segundoNombrePago);
			usuario.setPrimerApellidoPago(primerApellidoPago);
			usuario.setSegundoApellidoPago(segundoApellidoPago);
			usuario.setTelefonoPago(telefonoPago);
			usuario.setTipoDocumentoPago(tipoDocumentoPago);
			usuario.setNoDocumentoPago(noDocumentoPago.trim());
			usuario.setCorreoElectronicoPago(enmascararCorreo(correoPago));
			pago.getTransaccion().setUsuario(usuario);

			/** INICIO-C02 **/
			pago.setUserAgent(requestCompleto.getHeader(HEADER_USER_AGENT));
			pago.setHttpAccept(requestCompleto.getHeader(HEADER_ACCEPT));
			pago.setHttpAcceptLanguage(requestCompleto.getHeader(HEADER_ACCEPT_LANGUAGE));
			pago.setHttpReferrer(requestCompleto.getHeader(HEADER_REFERER));
			/** FIN-C02 **/
			/*
			 * Se cambia el nombre por el valor original recibido en la
			 * respuesta del servicio getTransactionById almacenado en la carga
			 * del formulario en una variable auxiliar
			 */
			/** INICIO-C04 **/
			if (WebLocator.getPreferences().getValue(CODE_NURA_FACILPASS, "").equals(codigoNura)) {
				if (this.responseWS.getTransaccion().getUsuario() != null) {
					this.responseWS.getTransaccion().getUsuario().setPrimerNombre(auxPrimerNombre);
				}

			}
			/** FIN-C04 **/

			pago.setIpOrigen(dirIp);
			pago.setChannel(IConstants.CANAL_PASARELA);
			rbm.setNumCuotas(Integer.valueOf(numeroCuotas));
			DateFormat df = new SimpleDateFormat("MM/yyyy");
			Calendar now = Calendar.getInstance(); // Gets the current date and
													// time
			String century = String.valueOf(now.get(Calendar.YEAR)).substring(0, 2);
			String expDate = fechaVencimientoTC.substring(0, 3) + century + fechaVencimientoTC.substring(3, 5);
			Date fechaVencimiento = df.parse(expDate);
			rbm.getTarjetaCredito().setFechaVencimiento(fechaVencimiento);
			pago.setRbm(rbm);
			CuentaDTO cuenta = new CuentaDTO();
			BancoDTO banco = new BancoDTO();
			banco.setBankId(idBancoPSE);
			cuenta.setBanco(banco);
			pago.setCuenta(cuenta);

			// Modificacion para enmascarar datos sensibles.
			String correoCliente = pago.getTransaccion().getUsuario().getCorreoElectronico();
			pago.getTransaccion().getUsuario().setCorreoElectronico(enmascararCorreo(correoCliente));
			pago.getTransaccion().getUsuario().setCorreoElectronicoPago(enmascararCorreo(correoPago));

			String cvc = pago.getRbm().getTarjetaCredito().getCodigoVerificacion();
			pago.getRbm().getTarjetaCredito().setCodigoVerificacion(enmascararCVC(cvc));
			String numeroTarjeta = pago.getRbm().getTarjetaCredito().getNumeroTarjeta();
			pago.getRbm().getTarjetaCredito().setNumeroTarjeta(enmascararTC(numeroTarjeta));

			// Auditoria portal pasarela
			auditarAccion(token, dirIp, "realizar pago",
					this.responseWS.getTransaccion().getComercio().getCodigoNura(), "Seleccionar Medio de pago",
					"Exitoso", pago);

			// Modificacion para enmascarar datos sensibles.
			pago.getTransaccion().getUsuario().setCorreoElectronico(correoCliente);
			pago.getTransaccion().getUsuario().setCorreoElectronicoPago(correoPago);
			pago.getRbm().getTarjetaCredito().setCodigoVerificacion(cvc);
			pago.getRbm().getTarjetaCredito().setNumeroTarjeta(numeroTarjeta);

			responseWS = cs.addRBMPayment(pago);
			
			log.info("StatusCode: "+responseWS.getStatusCode()+
					"\n..ServerStatusCode: "+responseWS.getServerStatusCode()+
					"\n..ServerStatusDesc: "+responseWS.getServerStatusDesc());

			if (responseWS == null
					|| responseWS.getStatusCode() != Long.valueOf(IConstants.SSC_EXITOSO)
					|| responseWS.getTransaccion().getEstadoPago().getId()
							.equals(Integer.valueOf(IConstants.SSC_ERROR_LISTAS_NEGRAS))
					|| responseWS.getTransaccion().getEstadoPago().getId()
							.equals(Integer.valueOf(IConstants.SSC_ERROR_IVA))
					|| responseWS.getTransaccion().getEstadoPago().getId()
							.equals(Integer.valueOf(IConstants.SSC_ERROR_DOCUMENTO))) {

				errorProceso = "1";
				getSessionMap().put("transactionByToken", this.responseWS);
				getSessionMap().put("bankList", this.bancosPSE);
				getSessionMap().put("transactionToken", this.token);

				// Modificacion para enmascarar datos sensibles.
				correoCliente = pago.getTransaccion().getUsuario().getCorreoElectronico();
				pago.getTransaccion().getUsuario().setCorreoElectronico(enmascararCorreo(correoCliente));
				pago.getTransaccion().getUsuario().setCorreoElectronicoPago(enmascararCorreo(correoPago));

				cvc = pago.getRbm().getTarjetaCredito().getCodigoVerificacion();
				pago.getRbm().getTarjetaCredito().setCodigoVerificacion(enmascararCVC(cvc));
				numeroTarjeta = pago.getRbm().getTarjetaCredito().getNumeroTarjeta();
				pago.getRbm().getTarjetaCredito().setNumeroTarjeta(enmascararTC(numeroTarjeta));

				// Auditoria portal pasarela
				auditarAccion(token, dirIp, "realizar pago", this.responseWS.getTransaccion().getComercio()
						.getCodigoNura(), "Seleccionar Medio de pago", "Fallido", pago);

				// Modificacion para enmascarar datos sensibles.
				pago.getTransaccion().getUsuario().setCorreoElectronico(correoCliente);
				pago.getTransaccion().getUsuario().setCorreoElectronicoPago(correoPago);

				pago.getRbm().getTarjetaCredito().setCodigoVerificacion(cvc);
				pago.getRbm().getTarjetaCredito().setNumeroTarjeta(numeroTarjeta);
				// Mapeo de Errores RBM RQ30573 INI
				if ((responseWS.getServerStatusCode() != null) && (responseWS.getServerStatusDesc() != null)) {
					mensajeInfo.setLength(0);
					mensajeInfo.append("::: ERROR LA RESPUESTA DEL SERVICIO addRBMPayment NO FUE EXITOSA ERROR:  ");
					mensajeInfo.append(responseWS.getServerStatusCode() + responseWS.getServerStatusDesc());
					mensajeInfo.append(" :::");
					log.error(mensajeInfo);
					setRenderBotonVolver(true);
					// printFacesMessage(FacesContext.getCurrentInstance(),
					// FacesMessage.SEVERITY_INFO, mensajeErrorGeneral + " - " +
					// IConstants.erroresServer.get(responseWS.getServerStatusCode()));
					listaErrores = buscarErrorRBM(responseWS.getServerStatusCode());
					switch (listaErrores) {
						
						case 1:
							log.info(("::: case 1:  "+IConstants.SSC_DESC_ERROR_PAGO_RECHAZADO + " ("	+ (responseWS.getServerStatusCode() + ")")));
							printFacesMessage(
									FacesContext.getCurrentInstance(),
									FacesMessage.SEVERITY_INFO,
									IConstants.SSC_DESC_ERROR_PAGO_RECHAZADO + " ("	+ (responseWS.getServerStatusCode() + ")"));
							break;
							
						case 2:
							log.info(("::: case 2:  "+IConstants.SSC_DESC_ERROR_PAGO_RECHAZADO + " ("	+ (responseWS.getServerStatusCode() + ")")));
							printFacesMessage(
									FacesContext.getCurrentInstance(),
									FacesMessage.SEVERITY_INFO,
									IConstants.SSC_DESC_ERROR_TARJETA_RESTRINGIDA + " ("	+ (responseWS.getServerStatusCode() + ")"));
							break;
							
						case 3:
							log.info(("::: case 3:  "+IConstants.SSC_DESC_ERROR_PAGO_RECHAZADO + " ("	+ (responseWS.getServerStatusCode() + ")")));
							printFacesMessage(
									FacesContext.getCurrentInstance(),
									FacesMessage.SEVERITY_INFO,
									IConstants.SSC_DESC_ERROR_PROBLEMA_TECNICO + " ("	+ (responseWS.getServerStatusCode() + ")"));
							break;
							
						case 4:
							log.info(("::: case 4:  "+IConstants.SSC_DESC_ERROR_PAGO_RECHAZADO + " ("	+ (responseWS.getServerStatusCode() + ")")));
							printFacesMessage(
									FacesContext.getCurrentInstance(),
									FacesMessage.SEVERITY_INFO,
									IConstants.SSC_DESC_ERROR_PROCESO_VALIDACION + " ("	+ (responseWS.getServerStatusCode() + ")"));
							break;
							
						default:
							log.info(("::: case default :  "+IConstants.SSC_DESC_ERROR_PAGO_RECHAZADO + " ("	+ (responseWS.getServerStatusCode() + ")")));
							printFacesMessage(FacesContext.getCurrentInstance(),
									FacesMessage.SEVERITY_INFO, mensajeErrorGeneral + " (" +
									(responseWS.getServerStatusCode() + ")"));
							break;
					}
					// Mapeo de Errores RBM RQ30573 FIN
				} else {
					if (responseWS.getTransaccion().getEstadoPago().getId()
							.equals(Integer.valueOf(IConstants.SSC_ERROR_LISTAS_NEGRAS))) {
						mensajeInfo.setLength(0);
						mensajeInfo.append("::: ERROR LA RESPUESTA DEL SERVICIO addRBMPayment NO FUE EXITOSA ERROR:  ");
						mensajeInfo.append(IConstants.SSC_ERROR_LISTAS_NEGRAS);
						mensajeInfo.append(" :::");
						log.error(mensajeInfo);
						// Hacer redirect al resultado de pago
						String urlRedirect = WebLocator.getPreferences().getValue("urlRedirectPagoRBM", "");
						urlRedirect = urlRedirect + token + "&error=30";
						// Motor de Riego INI
						FacesContext fc = FacesContext.getCurrentInstance();
						// Motor de Riego FIN
						ExternalContext ec = fc.getExternalContext();
						ec.redirect(urlRedirect);
					} else if (responseWS.getTransaccion().getEstadoPago().getId()
							.equals(Integer.valueOf(IConstants.SSC_ERROR_IVA))
							|| responseWS.getTransaccion().getEstadoPago().getId()
									.equals(Integer.valueOf(IConstants.SSC_ERROR_DOCUMENTO))) {
						mensajeInfo.setLength(0);
						mensajeInfo.append("::: ERROR LA RESPUESTA DEL SERVICIO addRBMPayment NO FUE EXITOSA ERROR:  ");
						mensajeInfo.append(responseWS.getTransaccion().getEstadoPago().getId());
						mensajeInfo.append(" :::");
						log.error(mensajeInfo);
						setRenderBotonVolver(true);
						printFacesMessage(
								FacesContext.getCurrentInstance(),
								FacesMessage.SEVERITY_INFO,
								mensajeErrorGeneral
										+ " - "
										+ IConstants.erroresServer.get(String.valueOf(responseWS.getTransaccion()
												.getEstadoPago().getId())));
					} 
					else {
						mensajeInfo.setLength(0);
						mensajeInfo.append("::: ERROR LA RESPUESTA DEL SERVICIO addRBMPayment NO FUE EXITOSA ERROR:  ");
						mensajeInfo.append(responseWS.getStatusCode());
						mensajeInfo.append(" :::");
						log.error(mensajeInfo);
						setRenderBotonVolver(true);
						printFacesMessage(
								FacesContext.getCurrentInstance(),
								FacesMessage.SEVERITY_INFO,
								mensajeErrorGeneral + " - "
										+ IConstants.erroresServer.get(String.valueOf(responseWS.getStatusCode())));
					}
				}
			} else {
				// Auditoria portal pasarela
				auditarAccion(token, dirIp, "recibir realizar pago", this.responseWS.getTransaccion().getComercio()
						.getCodigoNura(), "Seleccionar Medio de pago", "Exitoso", responseWS);

				String urlRedirect = WebLocator.getPreferences().getValue("urlRedirectPagoRBM", "");
				urlRedirect = urlRedirect + token;
				FacesContext fc = FacesContext.getCurrentInstance();
				setCookieValue(responseWS.getToken());
				urlRedirectPay = urlRedirect;
				ExternalContext ec = fc.getExternalContext();

				try {
					getSessionMap().put("transactionByToken", null);
					// ec.redirect(urlRedirect);
				} catch (Exception ex) {
					getSessionMap().put("transactionByToken", this.responseWS);
					getSessionMap().put("bankList", this.bancosPSE);
					getSessionMap().put("transactionToken", this.token);
					mensajeInfo.setLength(0);
					mensajeInfo.append("::: ERROR AL REDIRECCIONAR A LA URL DE PAGO: ");
					mensajeInfo.append(urlRedirect);
					mensajeInfo.append(" :::");
					log.error(mensajeInfo, ex);
				}
			}
			log.info("::: TERMINA METODO pagarRBM() DEL BEAN MediosPagoBean :::");
		} catch (Exception e) {

			errorProceso = "1";
			getSessionMap().put("transactionByToken", this.responseWS);
			getSessionMap().put("bankList", this.bancosPSE);
			getSessionMap().put("transactionToken", this.token);
			// Auditoria portal pasarela
			auditarAccion(token, dirIp, "realizar pago",
					this.responseWS.getTransaccion().getComercio().getCodigoNura(), "Seleccionar Medio de pago",
					"Fallido", responseWS == null ? this.responseWS : responseWS);
			mensajeInfo.setLength(0);
			mensajeInfo.append(":::ERROR AL CREAR EL PAGO RBM: ");
			mensajeInfo.append(token);
			mensajeInfo.append(" :::");
			log.error(mensajeInfo);
			mensajeInfo.setLength(0);
			mensajeInfo.append("::: ERROR PAGO:  ");
			mensajeInfo.append(e.getMessage());
			mensajeInfo.append(" :::");

			log.error(mensajeInfo);
			setRenderBotonVolver(true);
			log.error("EXCEPCION GENERADA METODO pagarRBM",e);
			printFacesMessage(FacesContext.getCurrentInstance(), FacesMessage.SEVERITY_INFO, mensajeErrorGeneral);
		}
	}

	/**
	 * Metodo encargado de redireccionar al comercio
	 * 
	 * @return
	 * @throws Exception
	 */
	public void volver() {

		log.info("::: INICIA METODO volver() DEL BEAN MediosPagoBean :::");

		StringBuilder mensajeInfo = new StringBuilder("");

		if (pmtId != null) {

			ClienteConsultasService cs = new ClienteConsultasService();
			WSConsultasDTO consulta = new WSConsultasDTO();

			TransaccionesDTO transaccionDTO = new TransaccionesDTO();
			transaccionDTO.setPmtId(pmtId);

			consulta.setTransaccion(transaccionDTO);
			consulta.setIpOrigen(dirIp);
			consulta.setChannel(IConstants.CANAL_PASARELA);
			consulta.setTipo(IConstants.ESTADO_INICIAL);

			// Auditoria portal pasarela
			auditarAccion(pmtId == null ? "NO ENTREGADO" : pmtId, dirIp, "Consultar transaccion", "N/A",
					"Mostrar pantalla para pago", "Exitoso", consulta);

			try {
				WSConsultasResponseDTO responseByIdWS = cs.getTransactionById(consulta);

				if (responseByIdWS == null || responseByIdWS.getStatusCode() != Long.valueOf(IConstants.SSC_EXITOSO)) {

					if (responseByIdWS != null) {
						if (responseByIdWS.getServerStatusCode() != null) {
							mensajeInfo.setLength(0);
							mensajeInfo.append("::: ERROR LA RESPUESTA DEL SERVICIO NO FUE SATISFACTORIA ERROR: ");
							mensajeInfo.append(responseByIdWS.getServerStatusCode());
							mensajeInfo.append(" :::");
							log.error(mensajeInfo);
						} else {
							mensajeInfo.setLength(0);
							mensajeInfo.append("::: ERROR LA RESPUESTA DEL SERVICIO NO FUE SATISFACTORIA ERROR: ");
							mensajeInfo.append(responseByIdWS.getStatusCode());
							mensajeInfo.append(" :::");
							log.error(mensajeInfo);
						}
					} else {
						log.error("::: ERROR LA RESPUESTA DEL SERVICIO FUE NULL :::");
					}

					setRenderBotonVolver(true);
					setRenderBotonVolverJS("SI");

				} else {
					ClienteCancelarService ccs = new ClienteCancelarService();
					WSCancelarResponseDTO cancelarResponse;
					WSCalcelarDTO transaccion = new WSCalcelarDTO();

					transaccion.setIpOrigen(dirIp);
					transaccion.setChannel(IConstants.CANAL_PASARELA);
					transaccion.setStatusCode(IConstants.STATUS_CODE_DECLINADA);
					transaccion.setStatusDesc(IConstants.STATUS_DESCRIPTION_DECLINADA);
					transaccion.setServerStatusCode(responseByIdWS.getServerStatusCode());
					transaccion.setServerStatusDesc(responseByIdWS.getServerStatusDesc());
					transaccion.setTransaccion(responseByIdWS.getTransaccion());

					mensajeInfo.setLength(0);
					mensajeInfo.append("+++++ ISM transaccion: ");
					mensajeInfo.append(transaccion.toString());
					mensajeInfo.append("++++++");
					log.info(mensajeInfo);
					cancelarResponse = ccs.modTransactionInfo(transaccion);
					log.info(mensajeInfo);

					if (cancelarResponse == null
							|| cancelarResponse.getStatusCode() != Long.valueOf(IConstants.SSC_EXITOSO)) {
						errorCancel = "1";
						if (cancelarResponse != null) {
							mensajeInfo.setLength(0);
							if (cancelarResponse.getServerStatusCode() != null) {
								mensajeInfo.append("::: ERROR LA RESPUESTA DEL SERVICIO NO FUE SATISFACTORIA ERROR: ");
								mensajeInfo.append(cancelarResponse.getServerStatusCode());
								mensajeInfo.append(" :::");
								log.error(mensajeInfo);
							} else {
								mensajeInfo.append("::: ERROR LA RESPUESTA DEL SERVICIO NO FUE SATISFACTORIA ERROR: ");
								mensajeInfo.append(cancelarResponse.getStatusCode());
								mensajeInfo.append(" :::");
								log.error(mensajeInfo);
							}
						} else {
							log.error("::: ERROR LA RESPUESTA DEL SERVICIO FUE NULL :::");
						}
						setRenderBotonVolver(true);
						setRenderBotonVolverJS("SI");
					} else {
						String urlRedirect = responseWS.getPortalURL();
						try {
							FacesContext fc = FacesContext.getCurrentInstance();
							ExternalContext ec = fc.getExternalContext();
							ec.redirect(responseByIdWS.getPortalURL());
							return;
						} catch (Exception ex) {
							mensajeInfo.setLength(0);
							mensajeInfo.append("::: ERROR AL REDIRECCIONAR A LA URL: ");
							mensajeInfo.append(urlRedirect);
							mensajeInfo.append(" :::");
							log.error(mensajeInfo, ex);
							errorCancel = "1";
							setRenderBotonVolver(true);
							setRenderBotonVolverJS("SI");
						}
					}
				}
				setRenderBotonVolver(true);

			} catch (Exception e) {
				mensajeInfo.setLength(0);
				mensajeInfo.append("::: ERROR AL CONSULTAR LA TRANSACCION CON PMTID ");
				mensajeInfo.append(pmtId);
				mensajeInfo.append(" :::");
				log.error(mensajeInfo, e);
				// Auditoria portal pasarela
				auditarAccion(pmtId == null ? "NO ENTREGADO" : pmtId, dirIp, "Recibir consulta transaccion", "N/A",
						"Mostrar pantalla para pago", "Fallido", responseWS);
				setRenderBotonVolver(true);
				setRenderBotonVolverJS("SI");
			}
		} else {
			// setRenderBotonVolver(true);
			setRenderBotonVolverJS("SI");
		}
	}

	/** INICIO-C01 **/

	/**
	 * 
	 * 1.Verificacion de tipo y numero de documento para habilitar/deshabilitar
	 * funcionalidad
	 * 
	 * de copiar los datos del pagador en el beneficiario
	 */

	public void checkNumeroDocumento(ValueChangeEvent event) {

		disableBeneficiario = Boolean.TRUE;

		if (event.getNewValue().equals(noDocumentoBen)
				&& tipoDocumentoPago.equals(responseWS.getTransaccion().getUsuario().getTipoDocumento())) {
			disableBeneficiario = Boolean.FALSE;
		}

	} 

	public void checkTipoDocumento(ValueChangeEvent event) {

		disableBeneficiario = Boolean.TRUE;

		if (noDocumentoPago.equals(noDocumentoBen)
				&& event.getNewValue().equals(responseWS.getTransaccion().getUsuario().getTipoDocumento())) {
			disableBeneficiario = Boolean.FALSE;
		}

	}

	private void auditarAccion(String token, String dirIp, String accion, String idComercio, String pantalla,
			String resultado, Object infoAdicional) {
		try {
			JMSSendUtil su = new JMSSendUtil("PortalPasarelaConf", "PSAuditoriaPasarelaJMSQueue",
					"jmsQueuePasarelaSenderName");
			AuditoriaPasarelaMessage mensaje = new AuditoriaPasarelaMessage();
			mensaje.setToken(token);
			mensaje.setDireccionIp(dirIp);
			mensaje.setFechaRegistro(new Date());
			mensaje.setAccion(accion);
			mensaje.setComercio(idComercio);
			mensaje.setPantalla(pantalla);
			mensaje.setResultado(resultado);
			if (infoAdicional != null) {
				Gson gson = new Gson();
				mensaje.setInformacionAdicional(gson.toJson(infoAdicional));
			}
			su.sendMessage(mensaje);
		} catch (Exception eException) {
			log.error("::: ERROR AL ENVIAR AUDITORIA :::", eException);
		}
	}

	public static void printFacesMessage(FacesContext facesContext, FacesMessage.Severity severity, String idMensaje,
			String mensaje) {
		FacesMessage message = new FacesMessage(severity, mensaje, mensaje);
		facesContext.addMessage(idMensaje, message);
	}

	public static void printFacesMessage(FacesContext facesContext, FacesMessage.Severity severity, String mensaje) {
		printFacesMessage(facesContext, severity, null, mensaje);
	}

	/**
	 * Recupera el objeto SessionMap
	 * 
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static Map getSessionMap() {
		try {
			FacesContext context = FacesContext.getCurrentInstance();
			Map session = context.getExternalContext().getSessionMap();
			return session;
		} catch (Throwable t) {
			log.error("::: ERROR AL OBTENER EL SESSION MAP :::", t);
		}
		return null;
	}

	/**
	 * Iniciliza los renders cargando el layaout por default
	 */
	public void getLayaout() {
		try {
			PlantillaDTO plantilla = responseWS.getTransaccion().getComercio().getConfiguracion().getPlantilla();
			String nombrePlantilla = plantilla.getPlantilla();

			if (nombrePlantilla.equals(NAME_LAYAOUT_THEME_ONE)) {
				layaoutPortlet = PAY_LAYAOUT_THEME_ONE;
			} else if (nombrePlantilla.equals(NAME_LAYAOUT_THEME_TWO)) {
				layaoutPortlet = PAY_LAYAOUT_THEME_TWO;
			}
		} catch (Exception e) {
			log.error("::: ERROR AL OBTENER EL LAYAOUT DEL PORTLET :::", e);
			layaoutPortlet = PAY_LAYAOUT_THEME_ONE;
		}
	}

	public void getTheme() {
		// AJUSTE PARA MANEJO DE TEMAS POR BANCOS 11/04/2016
		try {
			String tema = responseWS.getPortalURL();

			if (tema.contains(IConstants.ESTILOSPP)) {
				themePortlet = CSS_THEME_ONE;
			} else if (tema.contains(IConstants.ESTILOSBB)) {
				themePortlet = propertiesTheme.getProperty(IConstants.CSS_BB);
			} else if (tema.contains(IConstants.ESTILOSBO)) {
				themePortlet = propertiesTheme.getProperty(IConstants.CSS_BO);
			} else if (tema.contains(IConstants.ESTILOSBP)) {
				themePortlet = propertiesTheme.getProperty(IConstants.CSS_BP);
			} else if (tema.contains(IConstants.ESTILOSBAV)) {
				themePortlet = propertiesTheme.getProperty(IConstants.CSS_BAV);
			}
		} catch (Exception e) {
			log.error("::: ERROR AL OBTENER EL TEMA DEL PORTLET :::", e);
			themePortlet = CSS_THEME_ONE;
		}
	}

	public void SplitReferences() { // RQ27225 Multiples Referencias
		try {
			refes = Arrays.asList(referencias.split("\\s*;\\s*"));
			for (String a : refes) {
				log.info("::: Referencias Partidas:" + a);
			}
		} catch (Exception e) {
			log.error("::: ERROR SPLIT REFERENCIAS :::", e);
		}
	}

	public void CargaTemplate() {

		// Taquillas RQ26210
		try {
			String template = responseWS.getTransaccion().getDatosPlantillaDTO().getTaquilla();
			log.info("VALOR TEMPLATE:" + template);

			if (template.equals("1")) {
				templateTaq = true;
				footTaq = true;
				getTemplate();
				themePortlet = estilocss;
				renderLogo = false;

			}
		} catch (Exception e) {
			log.error("::: ERROR AL CARGAR EL METODO TEMPLATE :::", e);
		}
	}

	public void getTemplate() {

		// Taquillas RQ26210
		try {
			String template = responseWS.getTransaccion().getDatosPlantillaDTO().getTaquilla();

			if (template.equals("1")) {
				String theme = responseWS.getTransaccion().getDatosPlantillaDTO().getTema();
				if (theme.equals("2")) {
					footer = FOOTER_AZUL;
					estilocss = COLOR_AZUL;
				} else if (theme.equals("3")) {
					estilocss = COLOR_ROJO;
					footer = FOOTER_ROJO;
				} else if (theme.equals("4")) {
					footer = FOOTER_GRIS;
					estilocss = COLOR_GRIS;
				} else if (theme.equals("0")) {
					footer = FOOTER_GRIS;
					estilocss = COLOR_GRIS;
				}

				String LogoUrl = responseWS.getTransaccion().getDatosPlantillaDTO().getURLTaquilla();
				cabezote = LogoUrl == null ? ENCABEZADO_DEFAULT : LogoUrl;

			}

		} catch (Exception e) {
			log.error("::: ERROR AL OBTENER LA PLANTILLA DEL PORTLET :::", e);

		}
	}

	public void checkboxChanged(ValueChangeEvent event) {
		if (opcion) {
			// Limpiar valores
			primerNombrePago = "";
			segundoNombrePago = "";
			primerApellidoPago = "";
			segundoApellidoPago = "";
			telefonoPago = "";
			tipoDocumentoPago = "";
			noDocumentoPago = "";
			correoPago = "";
			confirmacionCorreoPago = "";
			confirmacionTelefonoPago = "";
		} else {
			// Asignar valores
			primerNombrePago = responseWS.getTransaccion().getUsuario().getPrimerNombrePago();
			segundoNombrePago = responseWS.getTransaccion().getUsuario().getSegundoNombrePago();
			primerApellidoPago = responseWS.getTransaccion().getUsuario().getPrimerApellidoPago();
			segundoApellidoPago = responseWS.getTransaccion().getUsuario().getSegundoApellidoPago();
			telefonoPago = responseWS.getTransaccion().getUsuario().getTelefono();
			tipoDocumentoPago = responseWS.getTransaccion().getUsuario().getTipoDocumento();
			noDocumentoPago = responseWS.getTransaccion().getUsuario().getNoDocumento();
			correoPago = responseWS.getTransaccion().getUsuario().getCorreoElectronico();
			confirmacionCorreoPago = correoPago;
			confirmacionTelefonoPago = telefonoPago;
		}
	}

	public static String getIpAddr(HttpServletRequest request) {
		final String WL_PROXY_CLIENT_IP = "WL-Proxy-Client-IP";
		final String PROXY_CLIENT_IP = "Proxy-Client-IP";
		final String X_FORWARDER_FOR = "X-Forwarded-For";
		final String HTTP_X_FORWARDED_FOR = "HTTP_X_FORWARDED_FOR";
		final String HTTP_CLIENT_IP = "HTTP_CLIENT_IP";

		String ip = request.getHeader(X_FORWARDER_FOR);

		log.info("IP INICIAL: " + ip);

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader(WL_PROXY_CLIENT_IP);
			log.info("WL-Proxy-Client-IP: " + ip);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader(PROXY_CLIENT_IP);
			log.info("Proxy-Client-IP: " + ip);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader(HTTP_X_FORWARDED_FOR);
			log.info("HTTP_X_FORWARDED_FOR: " + ip);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader(HTTP_CLIENT_IP);
			log.info("HTTP_CLIENT_IP: " + ip);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
			log.info("getRemoteAddr: " + ip);
		}
		return ip;
	}

	// RQ25542 MotorDeRiesgosPortal
	@SuppressWarnings("rawtypes")
	private String obtenerVariable() {
		String sValorDeviceTokenCookie = "";
		// lectura de cookie sacando su valor
		Map listCookies = (Map) WebLocator.getExternalContext().getRequestCookieMap();
		javax.servlet.http.Cookie ck = null;
		if (!listCookies.isEmpty()) {
			try {
				Iterator iterador = listCookies.keySet().iterator();
				while (iterador.hasNext()) {
					String key = (String) iterador.next();
					ck = (javax.servlet.http.Cookie) listCookies.get(key);
					if (ck.getName().startsWith(IConstants.MR_NOM_DEVICE_TOKEN_COOKIE)) {
						sValorDeviceTokenCookie = ck.getValue();
						break;
					}
				}
			} catch (Exception e) {
				log.info("No se logro leer las cookies de sesion para el motor de riesgo");
			}
		}

		return sValorDeviceTokenCookie;
	}// obtenerVariable

	public static boolean validarCadenaNulaVacia(String cadena) {
		return cadena != null && !"".equals(cadena.trim()) && !cadena.equals(null);
	}

	public void validar(AjaxBehaviorEvent e) {
	}

	/** INICIO-C01 **/
	/**
	 * 1.Verificacion de tipo y numero de documento para habilitar/deshabilitar
	 * funcionalidad de copiar los datos del pagador en el beneficiario
	 * 
	 * 2. habilitar/deshabilitar funcionalidad de copiar los datos del pagador
	 * en el beneficiario para convenio de facilpass
	 */
	private void checkEstadoBeneficiario() {

		if (!responseWS.getTransaccion().getUsuario().getNoDocumento().isEmpty()
				&& !responseWS.getTransaccion().getUsuario().getTipoDocumento().isEmpty()) {

			arrivalData = true;
			log.info("::: Entro a Check Beneficiario");
			disableBeneficiario = !responseWS.getTransaccion().getUsuario().getTipoDocumento()
					.equals(responseWS.getTransaccion().getUsuario().getTipoDocumentoPago())
					|| !responseWS.getTransaccion().getUsuario().getNoDocumento()
							.equals(responseWS.getTransaccion().getUsuario().getNoDocumentoPago());

		}

		/*
		 * Valida si el convenio es FACILPASS para deshabilitar la funcionalidad
		 * "Los datos del beneficiario son los mismos del pagador"
		 */
		if (WebLocator.getPreferences().getValue(CODE_NURA_FACILPASS, "").equals(codigoNura)) {
			disableBeneficiario = Boolean.TRUE;

			/** INICIO-C04 **/
			if (responseWS.getTransaccion().getUsuario() != null) {

				auxPrimerNombre = responseWS.getTransaccion().getUsuario().getPrimerNombre();
				StringBuilder name = new StringBuilder(auxPrimerNombre);

				name.append(responseWS.getTransaccion().getUsuario().getSegundoNombre() != null ? " ".concat(responseWS
						.getTransaccion().getUsuario().getSegundoNombre()) : "");
				name.append(responseWS.getTransaccion().getUsuario().getPrimerApellido() != null ? " "
						.concat(responseWS.getTransaccion().getUsuario().getPrimerApellido()) : "");
				name.append(responseWS.getTransaccion().getUsuario().getSegundoApellido() != null ? " "
						.concat(responseWS.getTransaccion().getUsuario().getSegundoApellido()) : "");
				responseWS.getTransaccion().getUsuario().setPrimerNombre(name.toString());
			}
			/** FIN-C04 **/
		}

	}

	/** FIN-C01 **/

	private void checkEstadoForm() {
		log.info("::: Elimino los Campos de Confirmaci�n");
		
		if (!validarCadenaNulaVacia(responseWS.getTransaccion().getUsuario().getCorreoElectronicoPago())) {
			renderConfirmMail = Boolean.TRUE;
		}

		if (!validarCadenaNulaVacia(responseWS.getTransaccion().getUsuario().getTelefonoPago())) {
			renderConfirmCel = Boolean.TRUE;
		}

	}

	public void truncarRefes() { //RQ27827 Tokenizaci�n Pasarela de Pagos  INI 
		try {
				String truncado = responseWS.getTransaccion().getReferencia1();
				log.info(truncado);
				String cutString = (truncado.substring(10));
				log.info("::: Referencias truncada:" + cutString);
				refprincipal = cutString;
			}
			catch (Exception e) {
			log.error("::: ERROR truncarRefes :::", e);
		}
	}//RQ27827 Tokenizaci�n Pasarela de Pagos  FIN
	
	/**FIN-C01**/
	
	/** INICIO-C07 **/
	public int buscarErrorRBM(String codigoError) {
		log.info("::: INICIO METODO buscarErrorRBM con codigo Error:  " + codigoError);
		
        int listaError = 0;
		for (int i = 0; i < erroresRBM1.size(); i++) {
            if (erroresRBM1.get(i).equals(codigoError)) {
                listaError = 1;
                return listaError;
            } 
        }
		for (int i = 0; i < erroresRBM2.size(); i++) {
            if (erroresRBM2.get(i).equals(codigoError)) {
                listaError = 2;
                return listaError;
            } 
        }
		for (int i = 0; i < erroresRBM3.size(); i++) {
            if (erroresRBM3.get(i).equals(codigoError)) {
                listaError = 3;
                return listaError;
            } 
        }
		for (int i = 0; i < erroresRBM4.size(); i++) {
            if (erroresRBM4.get(i).equals(codigoError)) {
                listaError = 4;
                return listaError;
            } 
        }
		
		log.info(":::FIN METODO buscarErrorRBM con codigo Error:  " + listaError);
		return listaError;
    }
	/** FIN-C07 **/
	
	/**
	 * @return the tipoDocumento
	 */
	public String getTipoDocumento() {
		return tipoDocumento;
	}

	/**
	 * @param tipoDocumento
	 *            the tipoDocumento to set
	 */
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	/**
	 * @return the tiposDocumento
	 */
	public Map<String, String> getTiposDocumento() {
		return tiposDocumento;
	}

	/**
	 * @param tiposDocumento
	 *            the tiposDocumento to set
	 */
	public void setTiposDocumento(Map<String, String> tiposDocumento) {
		this.tiposDocumento = tiposDocumento;
	}

	/**
	 * @return the renderInfoComprador
	 */
	public boolean isRenderInfoComprador() {
		return renderInfoComprador;
	}

	/**
	 * @param renderInfoComprador
	 *            the renderInfoComprador to set
	 */
	public void setRenderInfoComprador(boolean renderInfoComprador) {
		this.renderInfoComprador = renderInfoComprador;
	}

	/**
	 * @return the bancosPSE
	 */
	public Map<String, String> getBancosPSE() {
		return bancosPSE;
	}

	/**
	 * @param bancosPSE
	 *            the bancosPSE to set
	 */
	public void setBancosPSE(Map<String, String> bancosPSE) {
		this.bancosPSE = bancosPSE;
	}

	/**
	 * @return the renderAval
	 */
	public boolean isRenderAval() {
		return renderAval;
	}

	/**
	 * @param renderAval
	 *            the renderAval to set
	 */
	public void setRenderAval(boolean renderAval) {
		this.renderAval = renderAval;
	}

	/**
	 * @return the renderPSE
	 */
	public boolean isRenderPSE() {
		return renderPSE;
	}

	/**
	 * @param renderPSE
	 *            the renderPSE to set
	 */
	public void setRenderPSE(boolean renderPSE) {
		this.renderPSE = renderPSE;
	}

	/**
	 * @return the renderTC
	 */
	public boolean isRenderTC() {
		return renderTC;
	}

	/**
	 * @param renderTC
	 *            the renderTC to set
	 */
	public void setRenderTC(boolean renderTC) {
		this.renderTC = renderTC;
	}

	/**
	 * @return the bancoPagoAval
	 */
	public String getBancoPagoAval() {
		return bancoPagoAval;
	}

	/**
	 * @param bancoPagoAval
	 *            the bancoPagoAval to set
	 */
	public void setBancoPagoAval(String bancoPagoAval) {
		this.bancoPagoAval = bancoPagoAval;
	}

	/**
	 * @return the documentosIdentidad
	 */
	public String getDocumentosIdentidad() {
		return documentosIdentidad;
	}

	/**
	 * @param documentosIdentidad
	 *            the documentosIdentidad to set
	 */
	public void setDocumentosIdentidad(String documentosIdentidad) {
		this.documentosIdentidad = documentosIdentidad;
	}

	/**
	 * @return the monto
	 */
	public BigDecimal getMonto() {
		return monto;
	}

	/**
	 * @param monto
	 *            the monto to set
	 */
	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}

	/**
	 * @return the idBancoPSE
	 */
	public String getIdBancoPSE() {
		return idBancoPSE;
	}

	/**
	 * @param idBancoPSE
	 *            the idBancoPSE to set
	 */
	public void setIdBancoPSE(String idBancoPSE) {
		this.idBancoPSE = idBancoPSE;
	}

	/**
	 * @return the responseWS
	 */
	public WSConsultasResponseDTO getResponseWS() {
		return responseWS;
	}

	/**
	 * @param responseWS
	 *            the responseWS to set
	 */
	public void setResponseWS(WSConsultasResponseDTO responseWS) {
		this.responseWS = responseWS;
	}

	/**
	 * @return the cuotas
	 */
	public Map<String, String> getCuotas() {
		return cuotas;
	}

	/**
	 * @param cuotas
	 *            the cuotas to set
	 */
	public void setCuotas(Map<String, String> cuotas) {
		this.cuotas = cuotas;
	}

	/**
	 * @return the rbm
	 */
	public RbmDTO getRbm() {
		return rbm;
	}

	/**
	 * @param rbm
	 *            the rbm to set
	 */
	public void setRbm(RbmDTO rbm) {
		this.rbm = rbm;
	}

	/**
	 * @return the mesVencimientoTC
	 */
	public String getMesVencimientoTC() {
		return mesVencimientoTC;
	}

	/**
	 * @param mesVencimientoTC
	 *            the mesVencimientoTC to set
	 */
	public void setMesVencimientoTC(String mesVencimientoTC) {
		this.mesVencimientoTC = mesVencimientoTC;
	}

	/**
	 * @return the anioVencimientoTC
	 */
	public String getAnioVencimientoTC() {
		return anioVencimientoTC;
	}

	/**
	 * @param anioVencimientoTC
	 *            the anioVencimientoTC to set
	 */
	public void setAnioVencimientoTC(String anioVencimientoTC) {
		this.anioVencimientoTC = anioVencimientoTC;
	}

	/**
	 * @return the numeroCuotas
	 */
	public String getNumeroCuotas() {
		return numeroCuotas;
	}

	/**
	 * @param numeroCuotas
	 *            the numeroCuotas to set
	 */
	public void setNumeroCuotas(String numeroCuotas) {
		this.numeroCuotas = numeroCuotas;
	}

	/**
	 * @return the renderPagar
	 */
	public boolean isRenderPagar() {
		return renderPagar;
	}

	/**
	 * @param renderPagar
	 *            the renderPagar to set
	 */
	public void setRenderPagar(boolean renderPagar) {
		this.renderPagar = renderPagar;
	}

	/**
	 * @return the renderInfoMedioPago
	 */
	public boolean isRenderInfoMedioPago() {
		return renderInfoMedioPago;
	}

	/**
	 * @param renderInfoMedioPago
	 *            the renderInfoMedioPago to set
	 */
	public void setRenderInfoMedioPago(boolean renderInfoMedioPago) {
		this.renderInfoMedioPago = renderInfoMedioPago;
	}

	/**
	 * @return the renderInfoCompra
	 */
	public boolean isRenderInfoCompra() {
		return renderInfoCompra;
	}

	/**
	 * @param renderInfoCompra
	 *            the renderInfoCompra to set
	 */
	public void setRenderInfoCompra(boolean renderInfoCompra) {
		this.renderInfoCompra = renderInfoCompra;
	}

	/**
	 * @return the fechaVencimientoTC
	 */
	public String getFechaVencimientoTC() {
		return fechaVencimientoTC;
	}

	/**
	 * @param fechaVencimientoTC
	 *            the fechaVencimientoTC to set
	 */
	public void setFechaVencimientoTC(String fechaVencimientoTC) {
		this.fechaVencimientoTC = fechaVencimientoTC;
	}

	/**
	 * @return the pAGOS_AVAL_ID
	 */
	public String getPAGOS_AVAL_ID() {
		return PAGOS_AVAL_ID;
	}

	/**
	 * @return the pAGOS_TC_ID
	 */
	public String getPAGOS_TC_ID() {
		return PAGOS_TC_ID;
	}

	/**
	 * @return the pAGOS_PSE_ID
	 */
	public String getPAGOS_PSE_ID() {
		return PAGOS_PSE_ID;
	}

	/**
	 * @return the renderBotonError
	 */
	public boolean isRenderBotonError() {
		return renderBotonError;
	}

	/**
	 * @param renderBotonError
	 *            the renderBotonError to set
	 */
	public void setRenderBotonError(boolean renderBotonError) {
		this.renderBotonError = renderBotonError;
	}

	/**
	 * @return the errorProceso
	 */
	public String getErrorProceso() {
		return errorProceso;
	}

	/**
	 * @param errorProceso
	 *            the errorProceso to set
	 */
	public void setErrorProceso(String errorProceso) {
		this.errorProceso = errorProceso;
	}

	/**
	 * @return the franquiciasValidas
	 */
	public String getFranquiciasValidas() {
		return franquiciasValidas;
	}

	/**
	 * @param franquiciasValidas
	 *            the franquiciasValidas to set
	 */
	public void setFranquiciasValidas(String franquiciasValidas) {
		this.franquiciasValidas = franquiciasValidas;
	}

	/**
	 * @return the renderMensaje
	 */
	public boolean isRenderMensaje() {
		return renderMensaje;
	}

	/**
	 * @param renderMensaje
	 *            the renderMensaje to set
	 */
	public void setRenderMensaje(boolean renderMensaje) {
		this.renderMensaje = renderMensaje;
	}

	public boolean isRenderMedioPagoAval() {
		return renderMedioPagoAval;
	}

	public void setRenderMedioPagoAval(boolean renderMedioPagoAval) {
		this.renderMedioPagoAval = renderMedioPagoAval;
	}

	public boolean isRenderMedioPagoTC() {
		return renderMedioPagoTC;
	}

	public void setRenderMedioPagoTC(boolean renderMedioPagoTC) {
		this.renderMedioPagoTC = renderMedioPagoTC;
	}

	public boolean isRenderMedioPagoPSE() {
		return renderMedioPagoPSE;
	}

	public void setRenderMedioPagoPSE(boolean renderMedioPagoPSE) {
		this.renderMedioPagoPSE = renderMedioPagoPSE;
	}

	public String getEstiloDiv() {
		return estiloDiv;
	}

	public void setEstiloDiv(String estiloDiv) {
		this.estiloDiv = estiloDiv;
	}

	public String getLogoAval() {
		return logoAval;
	}

	public void setLogoAval(String logoAval) {
		this.logoAval = logoAval;
	}

	public String getLogoPse() {
		return logoPse;
	}

	public void setLogoPse(String logoPse) {
		this.logoPse = logoPse;
	}

	public String getLogoTc() {
		return logoTc;
	}

	public void setLogoTc(String logoTc) {
		this.logoTc = logoTc;
	}

	public String getLayaoutPortlet() {
		return layaoutPortlet;
	}

	public void setLayaoutPortlet(String layaoutPortlet) {
		this.layaoutPortlet = layaoutPortlet;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public int getActMensaje() {
		return actMensaje;
	}

	public void setActMensaje(int actMensaje) {
		this.actMensaje = actMensaje;
	}

	public String getMensajeBancos() {
		return mensajeBancos;
	}

	public void setMensajeBancos(String mensajeBancos) {
		this.mensajeBancos = mensajeBancos;
	}

	public boolean isRenderMensajeBancos() {
		return renderMensajeBancos;
	}

	public void setRenderMensajeBancos(boolean renderMensajeBancos) {
		this.renderMensajeBancos = renderMensajeBancos;
	}

	public String getCorreoBen() {
		return correoBen;
	}

	public void setCorreoBen(String correoBen) {
		this.correoBen = correoBen;
	}

	public String getNombrePago() {
		return nombrePago;
	}

	public void setNombrePago(String nombrePago) {
		this.nombrePago = nombrePago;
	}

	public String getTelefonoPago() {
		return telefonoPago;
	}

	public void setTelefonoPago(String telefonoPago) {
		this.telefonoPago = telefonoPago;
	}

	public String getTipoDocumentoPago() {
		return tipoDocumentoPago;
	}

	public void setTipoDocumentoPago(String tipoDocumentoPago) {
		this.tipoDocumentoPago = tipoDocumentoPago;
	}

	public String getNoDocumentoPago() {
		return noDocumentoPago;
	}

	public void setNoDocumentoPago(String noDocumentoPago) {
		this.noDocumentoPago = noDocumentoPago;
	}

	public String getCorreoPago() {
		return correoPago;
	}

	public void setCorreoPago(String correoPago) {
		this.correoPago = correoPago;
	}

	public String getConfirmacionCorreoPago() {
		return confirmacionCorreoPago;
	}

	public void setConfirmacionCorreoPago(String confirmacionCorreoPago) {
		this.confirmacionCorreoPago = confirmacionCorreoPago;
	}

	public boolean isOpcion() {
		return opcion;
	}

	public void setOpcion(boolean opcion) {
		this.opcion = opcion;
	}

	public String getDuracionSesion() {
		return duracionSesion;
	}

	public void setDuracionSesion(String duracionSesion) {
		this.duracionSesion = duracionSesion;
	}

	public String getUrlRedireccion() {
		return urlRedireccion;
	}

	public void setUrlRedireccion(String urlRedireccion) {
		this.urlRedireccion = urlRedireccion;
	}

	public String getNoDocumentoBen() {
		return noDocumentoBen;
	}

	public void setNoDocumentoBen(String noDocumentoBen) {
		this.noDocumentoBen = noDocumentoBen;
	}

	public String getThemePortlet() {
		return themePortlet;
	}

	public void setThemePortlet(String themePortal) {
		this.themePortlet = themePortal;
	}

	public String getToken() {
		return token;
	}

	public String getPmtId() {
		return pmtId;
	}

	public void setPmtId(String pmtId) {
		this.pmtId = pmtId;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getDirIp() {
		return dirIp;
	}

	public void setDirIp(String dirIp) {
		this.dirIp = dirIp;
	}

	public boolean isRenderReferencia2() {
		return renderReferencia2;
	}

	public void setRenderReferencia2(boolean renderReferencia2) {
		this.renderReferencia2 = renderReferencia2;
	}

	public boolean isRenderReferencia3() {
		return renderReferencia3;
	}

	public void setRenderReferencia3(boolean renderReferencia3) {
		this.renderReferencia3 = renderReferencia3;
	}

	public String getTipoPersona() {
		return tipoPersona;
	}

	public void setTipoPersona(String tipoPersona) {
		this.tipoPersona = tipoPersona;
	}

	public boolean isRenderReferencia4() {
		return renderReferencia4;
	}

	public void setRenderReferencia4(boolean renderReferencia4) {
		this.renderReferencia4 = renderReferencia4;
	}

	public boolean isRenderBancoBogota() {
		return renderBancoBogota;
	}

	public void setRenderBancoBogota(boolean renderBancoBogota) {
		this.renderBancoBogota = renderBancoBogota;
	}

	public boolean isRenderBancoOccidente() {
		return renderBancoOccidente;
	}

	public void setRenderBancoOccidente(boolean renderBancoOccidente) {
		this.renderBancoOccidente = renderBancoOccidente;
	}

	public String getEstiloBanco() {
		return estiloBanco;
	}

	public void setEstiloBanco(String estiloBanco) {
		this.estiloBanco = estiloBanco;
	}

	/**
	 * @return el disTipoPago
	 */
	public boolean isDisTipoPago() {
		return disTipoPago;
	}

	/**
	 * @param disTipoPago
	 *            el disTipoPago a establecer
	 */
	public void setDisTipoPago(boolean disTipoPago) {
		this.disTipoPago = disTipoPago;
	}

	/**
	 * @return el disTipoBen
	 */
	public boolean isDisTipoBen() {
		return disTipoBen;
	}

	/**
	 * @param disTipoBen
	 *            el disTipoBen a establecer
	 */
	public void setDisTipoBen(boolean disTipoBen) {
		this.disTipoBen = disTipoBen;
	}

	/**
	 * @return el segundoApellidoPago
	 */
	public String getSegundoApellidoPago() {
		return segundoApellidoPago;
	}

	/**
	 * @param segundoApellidoPago
	 *            el segundoApellidoPago a establecer
	 */
	public void setSegundoApellidoPago(String segundoApellidoPago) {
		this.segundoApellidoPago = segundoApellidoPago;
	}

	/**
	 * @return el primerApellidoPago
	 */
	public String getPrimerApellidoPago() {
		return primerApellidoPago;
	}

	/**
	 * @param primerApellidoPago
	 *            el primerApellidoPago a establecer
	 */
	public void setPrimerApellidoPago(String primerApellidoPago) {
		this.primerApellidoPago = primerApellidoPago;
	}

	/**
	 * @return el segundoNombrePago
	 */
	public String getSegundoNombrePago() {
		return segundoNombrePago;
	}

	/**
	 * @param segundoNombrePago
	 *            el segundoNombrePago a establecer
	 */
	public void setSegundoNombrePago(String segundoNombrePago) {
		this.segundoNombrePago = segundoNombrePago;
	}

	/**
	 * @return el primerNombrePago
	 */
	public String getPrimerNombrePago() {
		return primerNombrePago;
	}

	/**
	 * @param primerNombrePago
	 *            el primerNombrePago a establecer
	 */
	public void setPrimerNombrePago(String primerNombrePago) {
		this.primerNombrePago = primerNombrePago;
	}

	/**
	 * @param confirmacionTelefonoPago
	 *            el confirmacionTelefonoPago a establecer
	 */
	public void setConfirmacionTelefonoPago(String confirmacionTelefonoPago) {
		this.confirmacionTelefonoPago = confirmacionTelefonoPago;
	}

	/**
	 * @return el confirmacionTelefonoPago
	 */
	public String getConfirmacionTelefonoPago() {
		return confirmacionTelefonoPago;
	}

	/**
	 * @return el errorCancel
	 */
	public String getErrorCancel() {
		return errorCancel;
	}

	/**
	 * @param errorCancel
	 *            el errorCancel a establecer
	 */
	public void setErrorCancel(String errorCancel) {
		this.errorCancel = errorCancel;
	}

	// RQ25542 MotorDeRiesgosPortal
	public String getsDevicePrint() {
		return sDevicePrint;
	}

	// RQ25542 MotorDeRiesgosPortal
	public void setsDevicePrint(String sDevicePrint) {
		this.sDevicePrint = sDevicePrint;
	}

	public String getLogoComercio() {
		return logoComercio;
	}

	public void setLogoComercio(String logoComercio) {
		this.logoComercio = logoComercio;
	}

	/**
	 * @return el renderBotonVolver
	 */
	public boolean isRenderBotonVolver() {
		return renderBotonVolver;
	}

	/**
	 * @param renderBotonVolver
	 *            el renderBotonVolver a establecer
	 */
	public void setRenderBotonVolver(boolean renderBotonVolver) {
		this.renderBotonVolver = renderBotonVolver;
	}

	/**
	 * @return el renderBotonVolverJS
	 */
	public String getRenderBotonVolverJS() {
		return renderBotonVolverJS;
	}

	/**
	 * @param renderBotonVolverJS
	 *            el renderBotonVolverJS a establecer
	 */
	public void setRenderBotonVolverJS(String renderBotonVolverJS) {
		this.renderBotonVolverJS = renderBotonVolverJS;
	}

	/**
	 * @return el renderLogo
	 */
	public boolean isRenderLogo() {
		return renderLogo;
	}

	/**
	 * @param renderLogo
	 *            el renderLogo a establecer
	 */
	public void setRenderLogo(boolean renderLogo) {
		this.renderLogo = renderLogo;
	}

	/**
	 * @return el estiloDescripcion
	 */
	public String getEstiloDescripcion() {
		return estiloDescripcion;
	}

	/**
	 * @param estiloDescripcion
	 *            el estiloDescripcion a establecer
	 */
	public void setEstiloDescripcion(String estiloDescripcion) {
		this.estiloDescripcion = estiloDescripcion;
	}

	/**
	 * @return el pseSiguienteDiaHabil
	 */
	public boolean isPseSiguienteDiaHabil() {
		return pseSiguienteDiaHabil;
	}

	/**
	 * @param pseSiguienteDiaHabil
	 *            el pseSiguienteDiaHabil a establecer
	 */
	public void setPseSiguienteDiaHabil(boolean pseSiguienteDiaHabil) {
		this.pseSiguienteDiaHabil = pseSiguienteDiaHabil;
	}

	public String getCodigoNura() {
		return codigoNura;
	}

	public void setCodigoNura(String codigoNura) {
		this.codigoNura = codigoNura;
	}

	/**
	 * Variables creadas RQ26210 Taquillas
	 */

	public String template() {
		return template;
	}

	public void settemplate(String template) {
		this.template = template;
	}

	public String theme() {
		return theme;
	}

	public void settheme(String theme) {
		this.theme = theme;
	}

	public String logoUrl() {
		return logoUrl;
	}

	public void setlogoUrl(String logoUrl) {
		this.logoUrl = logoUrl;
	}

	public String getFooter() {
		return footer;
	}

	public void setFooter(String footer) {
		this.footer = footer;
	}

	public String getEstilocss() {
		return estilocss;
	}

	public void setEstilocss(String estilocss) {
		this.estilocss = estilocss;
	}

	public String getCabezote() {
		return cabezote;
	}

	public void setCabezote(String cabezote) {
		this.cabezote = cabezote;
	}

	public boolean isTemplateTaq() {
		return templateTaq;
	}

	public void setTemplateTaq(boolean templateTaq) {
		this.templateTaq = templateTaq;
	}

	public boolean isFootTaq() {
		return footTaq;
	}

	public void setFootTaq(boolean footTaq) {
		this.footTaq = footTaq;
	}

	/**
	 * Variables creadas RQ27225 Multiples Referencias
	 */
	public List<String> getRefes() {
		return refes;
	}

	public void setRefes(List<String> refes) {
		this.refes = refes;
	}

	/** INICIO-C07 **/
	public int getListaErrores() {
		return listaErrores;
	}

	public void setListaErrores(int listaErrores) {
		this.listaErrores = listaErrores;
	}

	public List<String> getErroresRBM1() {
		return erroresRBM1;
	}

	public void setErroresRBM1(List<String> erroresRBM1) {
		this.erroresRBM1 = erroresRBM1;
	}

	public List<String> getErroresRBM2() {
		return erroresRBM2;
	}

	public void setErroresRBM2(List<String> erroresRBM2) {
		this.erroresRBM2 = erroresRBM2;
	}

	public List<String> getErroresRBM3() {
		return erroresRBM3;
	}

	public void setErroresRBM3(List<String> erroresRBM3) {
		this.erroresRBM3 = erroresRBM3;
	}

	public List<String> getErroresRBM4() {
		return erroresRBM4;
	}

	public void setErroresRBM4(List<String> erroresRBM4) {
		this.erroresRBM4 = erroresRBM4;
	}
	/** FIN-C07 **/
	
	/** INICIO-C01 **/
	public boolean isDisableBeneficiario() {
		return disableBeneficiario;
	}

	public void setDisableBeneficiario(boolean disableBeneficiario) {
		this.disableBeneficiario = disableBeneficiario;
	}

	public boolean isArrivalData() {
		return arrivalData;
	}

	public void setArrivalData(boolean arrivalData) {
		this.arrivalData = arrivalData;
	}
	public String getRefprincipal() {
		return refprincipal;
	}

	public void setRefprincipal(String refprincipal) {
		this.refprincipal = refprincipal;
	}
	
	
	/**FIN-C01**/
	
	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public String getUrlRedirectPay() {
		return urlRedirectPay;
	}

	public void setUrlRedirectPay(String urlRedirectPay) {
		this.urlRedirectPay = urlRedirectPay;
	}

	/** FIN-C01 **/

	/**
	 * Asigna el valor del DeviceTokenCookie
	 * 
	 * @param deviceToken
	 */
	public void setCookieValue(String deviceToken) {
		String cookieValue = "";
		try {
			cookieValue = IConstants.MR_NOM_DEVICE_TOKEN_COOKIE + "=" + deviceToken;
			cookieValue += "; path=/; secure;";
			cookieValue += "; max-age=" + IConstants.MR_NOM_DEVICE_TOKEN_COOKIE_MAX_AGE;
		} catch (Exception e) {
			log.error("No fue posible generar el valor del DeviceTokenCookie. " + e.getMessage());
		} finally {
			this.deviceToken = cookieValue;
		}
	}

	public boolean isRenderConfirmCel() {
		return renderConfirmCel;
	}

	public void setRenderConfirmCel(boolean renderConfirmCel) {
		this.renderConfirmCel = renderConfirmCel;
	}

	public boolean isRenderConfirmMail() {
		return renderConfirmMail;
	}

	public void setRenderConfirmMail(boolean renderConfirmMail) {
		this.renderConfirmMail = renderConfirmMail;
	}
	
	public boolean isRenderMensajeTopes()
	{
		return renderMensajeTopes;
	}
	   
	public void setRenderMensajeTopes(boolean renderMensajeTopes) {
	     renderMensajeTopes = renderMensajeTopes;
	}

	public String getUrlLightboxredir() {
		return urlLightboxredir;
	}

	public void setUrlLightboxredir(String urlLightboxredir) {
		
		this.urlLightboxredir = urlLightboxredir;
		log.info("::: set urlLightbox :::"+this.urlLightboxredir);
	}

	public String getValPrueba() {
		return valPrueba;
	}

	public void setValPrueba(String valPrueba) {
		this.valPrueba = valPrueba;
	}

	public String getUrlResultPay() {
		return urlResultPay;
	}

	public void setUrlResultPay(String urlResultPay) {
		this.urlResultPay = urlResultPay;
	}
	
	
	
	
	

}
