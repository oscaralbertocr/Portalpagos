package co.com.pasarela.pagos.faces.renderer;

import java.io.IOException;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;

import org.apache.myfaces.renderkit.html.HtmlTextRenderer;

public class InputRenderer extends HtmlTextRenderer {
    @Override
    protected void renderInputBegin(FacesContext context, UIComponent component) throws IOException {
        super.renderInputBegin(context, component);
	    Object placeholder = component.getAttributes().get("placeholder");
	    if(placeholder != null) { 
	        ResponseWriter writer = context.getResponseWriter();
	        writer.writeAttribute("placeholder", placeholder, "placeholder");
	    }

    }
}