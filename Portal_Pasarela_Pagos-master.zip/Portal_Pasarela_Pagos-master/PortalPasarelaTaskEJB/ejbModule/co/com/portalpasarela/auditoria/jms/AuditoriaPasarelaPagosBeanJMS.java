package co.com.portalpasarela.auditoria.jms;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import org.apache.log4j.Logger;

import com.ibm.xtq.bcel.generic.INSTANCEOF;

import co.com.portalpasarela.auditoria.datos.AuditoriaPortalPasarelaDAO;
import co.com.portalservicio.auditoria.dto.AuditoriaPasarelaMessage;

/**
 * Message-Driven Bean implementation class for: AuditoriaPasarelaPagosBeanJMS
 *
 */
@MessageDriven(
		activationConfig = 
		{ @ActivationConfigProperty(propertyName = "destinationType",propertyValue = "javax.jms.Queue"),
		  @ActivationConfigProperty(propertyName = "acknowledgeMode",propertyValue = "Auto-acknowledge")}, 
		mappedName = "jms/AuditoriaPasarelaPagosBeanJMS")
public class AuditoriaPasarelaPagosBeanJMS implements MessageListener {
	
	/**
	 * Variable encargada de manejar los logs de la aplicaci�n.
	 */
	private static Logger log = Logger.getLogger(AuditoriaPasarelaPagosBeanJMS.class);

    /**
     * Default constructor. 
     */
    public AuditoriaPasarelaPagosBeanJMS() {
    }
	
	/**
     * @see MessageListener#onMessage(Message)
     */
    public void onMessage(Message message) {
    	StringBuilder mensaje = new StringBuilder("");
    	try{
    		ObjectMessage objMsg = (ObjectMessage)message;
    		AuditoriaPasarelaMessage auditoriaMessage = null;
    		//Comprobaci�n de Objeto del mensaje para saber si es de tipo Auditor�a Pasarela
			if(objMsg instanceof AuditoriaPasarelaMessage)
				auditoriaMessage = (AuditoriaPasarelaMessage) objMsg.getObject();
			else
				throw new IllegalArgumentException("EL MENSAJE EN LA COLA NO ES DEL TIPO ESPERADO");
    		mensaje.append("EL MENSAJE FUE RECIBIDO: ");
    		mensaje.append(auditoriaMessage);
    		log.info(mensaje);
    		AuditoriaPortalPasarelaDAO daoAuditoria = new AuditoriaPortalPasarelaDAO();
    		daoAuditoria.insertAuditoria(auditoriaMessage);
    	}catch(Exception e){
    		mensaje.setLength(0);
    		mensaje.append("::: SE PRESENTARON PROBLEMAS AL PROCESAR EL MENSAJE RECIBIDO POR LA COLA DE AUDITORIA PASARELA ");
    		mensaje.append(message);
    		mensaje.append(" :::");
    		log.error(mensaje.toString(), e);
    	}
    }
}
