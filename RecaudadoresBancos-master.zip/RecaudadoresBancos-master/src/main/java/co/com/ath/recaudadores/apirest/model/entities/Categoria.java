package co.com.ath.recaudadores.apirest.model.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.recaudadores.apirest.model.dto.CategoriaDTO;

/*
 * Clase : Categoria
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Entity
@Table(name = "EXT_CATEGORIA")
public class Categoria implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CAT_ID", nullable = false)
	private Long id;

	@Column(name = "CAT_NOMBRE", nullable = false)
	private String nombre;

	@Column(name = "CAT_USUARIO_CREACION", nullable = false)
	private String userCreacion;

	@Column(name = "CAT_USUARIO_MODIF")
	private String userModificacion;

	@Column(name = "CAT_FEC_CREACION", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaCreacion;

	@Column(name = "CAT_FEC_MODIF")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaModificacion;

	@Column(name = "CAT_ID_PADRE")
	private Long categoriaPadre;

	@Column(name = "CAT_ORDEN")
	private int orden;

	public Categoria() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getUserCreacion() {
		return userCreacion;
	}

	public void setUserCreacion(String userCreacion) {
		this.userCreacion = userCreacion;
	}

	public String getUserModificacion() {
		return userModificacion;
	}

	public void setUserModificacion(String userModificacion) {
		this.userModificacion = userModificacion;
	}

	public Long getCategoriaPadre() {
		return categoriaPadre;
	}

	public void setCategoriaPadre(Long categoriaPadre) {
		this.categoriaPadre = categoriaPadre;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public int getOrden() {
		return orden;
	}

	public void setOrden(int orden) {
		this.orden = orden;
	}

	@Override
	public String toString() {
		return "Categoria [id=" + id + ", nombre=" + nombre + ", userCreacion=" + userCreacion + ", userModificacion="
				+ userModificacion + ", categoriaPadre=" + categoriaPadre + ", fechaCreacion=" + fechaCreacion
				+ ", fechaModificacion=" + fechaModificacion + ", orden=" + orden + "]";
	}

	/**
	 * @return
	 */
	public CategoriaDTO toCategoriaTO() {
		CategoriaDTO categoriaTO = new CategoriaDTO();
		
		categoriaTO.setId(this.id);
		categoriaTO.setNombre(this.nombre);
		return categoriaTO;
	}

	private static final long serialVersionUID = 1L;

}
