package co.com.ath.recaudadores.apirest.manager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dto.MailServiceInDTO;
import co.com.ath.recaudadores.apirest.util.Constants;
import co.com.ath.recaudadores.apirest.util.CustomException;
import co.com.ath.recaudadores.apirest.util.MailService;

/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 15/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
@Service
@StepScope
public class MailTask implements Tasklet{
	

	static Logger logger = LoggerFactory.getLogger(MailTask.class);
	
	@Value("#{jobParameters[fileNameInput]}")
	private String fileNameInput;
	
	@Value("#{jobParameters[fileNameOutput]}")
	private String fileNameOutput;
	
	@Value("#{jobParameters[fileOriginalName]}")
	private String fileOriginalName;
	
	@Value("#{jobParameters[messageTo]}")
	private String messageTo;
	
	@Value("#{jobParameters[messageContentSuccess]}")
	private String messageContentSuccess;
	
	@Autowired
	MailService mailService;
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		try {
			MailServiceInDTO m = new MailServiceInDTO();
			m.setTo(messageTo);
			m.setText(messageContentSuccess.replace("#fileName", fileOriginalName));
			mailService.sendMail(m);
		}catch (Exception e) {
			throw new CustomException(Constants.MAIL_ERROR);
		}
		return null;
	}

}
