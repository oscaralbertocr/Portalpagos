package co.com.ath.recaudadores.apirest.config;

import java.util.HashMap;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.explore.support.JobExplorerFactoryBean;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.batch.support.DatabaseType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jndi.JndiTemplate;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
/**
 * Configuracion dataSource para el api pgw agreement.
 * @author SophosSolutions
 * @version 1.0 17/06/2019
 */


@Configuration
@EnableJpaRepositories(
	basePackages = "co.com.ath.recaudadores.apirest.model", 
	entityManagerFactoryRef = "prvEntityManager", 
	transactionManagerRef = "prvTransactionManager")
public class DataSourceConfig  implements BatchConfigurer{

	@Autowired
	private Environment env;

	/**
	 * obtencion de entityManager.
	 * @return LocalContainerEntityManagerFactoryBean
	 */	
	@Bean
	public LocalContainerEntityManagerFactoryBean prvEntityManager() {
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		try {
			em.setDataSource(prvDataSource());
		} catch (NamingException e) {
			e.printStackTrace();
		}
		em.setPackagesToScan(new String[] { "co.com.ath.recaudadores.apirest.model.entities" });

		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		HashMap<String, Object> properties = new HashMap<>();
		properties.put("hibernate.hbm2ddl.auto", env.getProperty("hibernate.hbm2ddl.auto"));
		properties.put("hibernate.dialect", env.getProperty("hibernate.dialect"));
		properties.put("hibernate.connection.release_mode", "after_transaction");
		em.setJpaPropertyMap(properties);

		return em;
	}


	/**
	 * obtencion de Datasource.
	 * @return DataSource
	 */	
	@Bean (destroyMethod = "")
	public DataSource prvDataSource() throws NamingException {
		return (DataSource) new JndiTemplate().lookup(env.getProperty("jdbc.url"));

	}

	
	/**
	 * persistencia del datasource.
	 * @return PlatformTransactionManager
	 */	
	@Bean
	public PlatformTransactionManager prvTransactionManager() {

		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(prvEntityManager().getObject());
		return transactionManager;
	}

	@Override
	public JobExplorer getJobExplorer() throws Exception {
		JobExplorerFactoryBean factory = new JobExplorerFactoryBean();
		factory.setDataSource(prvDataSource());
		factory.afterPropertiesSet();
		return factory.getObject();
	}

	@Override
	public JobLauncher getJobLauncher() throws Exception {
		SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
		jobLauncher.setJobRepository(getJobRepository());
		jobLauncher.setTaskExecutor(new SimpleAsyncTaskExecutor());
		jobLauncher.afterPropertiesSet();
		return jobLauncher;
	}

	@Override
	public JobRepository getJobRepository() throws Exception {
		JobRepositoryFactoryBean factory = new JobRepositoryFactoryBean();
		factory.setDataSource(prvDataSource());
		factory.setIsolationLevelForCreate("ISOLATION_DEFAULT");
		factory.setTransactionManager(getTransactionManager());
		factory.setDatabaseType(DatabaseType.ORACLE.toString());
		factory.setTablePrefix("BATCH_");
		factory.afterPropertiesSet();
		return factory.getObject();
	}

	@Override
	public PlatformTransactionManager getTransactionManager() throws Exception {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(prvEntityManager().getObject());
		return transactionManager;
	}
}
