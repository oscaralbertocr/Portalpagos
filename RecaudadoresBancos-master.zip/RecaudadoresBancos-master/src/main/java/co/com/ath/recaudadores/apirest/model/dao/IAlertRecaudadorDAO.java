package co.com.ath.recaudadores.apirest.model.dao;

import org.springframework.data.repository.CrudRepository;

import co.com.ath.recaudadores.apirest.model.entities.AlertRecaudador;

public interface IAlertRecaudadorDAO extends CrudRepository<AlertRecaudador, String>{

}
