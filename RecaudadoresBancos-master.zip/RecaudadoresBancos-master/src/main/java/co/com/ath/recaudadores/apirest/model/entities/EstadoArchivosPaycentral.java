package co.com.ath.recaudadores.apirest.model.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
@Entity(name = "EstadoArchivosPaycentral")
@Table(name = "EXT_ESTADO_ARCHIVOS_PAYCENTRAL")
public class EstadoArchivosPaycentral {

	@SequenceGenerator(name = "sequence_es_apc", sequenceName = "SEQ_ESTADO_ARCHIVO_PAYCENTRAL")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequence_es_apc")
	@Column(name = "ARCH_ID", nullable = false)
	@Id
	private Long id;

	@Column(name = "ARCH_FECHA_ARCHIVO")
	private String fechaArchivo;

	@Column(name = "ARCH_NOMBRE_ARCHIVO")
	private String nombreArchivo;

	@Column(name = "ARCH_ESTADO_PAYCENTRAL")
	private String estadoPaycentral;

	@Column(name = "ARCH_EXT_CONVENIOS_CNV_ID")
	private String convenioID;

	@Column(name = "ARCH_FECHA_ACTUALIZACION")
	private String fechaActualizacion;
	
	@Column(name = "FLAG_CORREO")
	private Integer flagCorreo;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFechaArchivo() {
		return fechaArchivo;
	}

	public void setFechaArchivo(String fechaArchivo) {
		this.fechaArchivo = fechaArchivo;
	}

	public String getNombreArchivo() {
		return nombreArchivo;
	}

	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}

	public String getEstadoPaycentral() {
		return estadoPaycentral;
	}

	public void setEstadoPaycentral(String estadoPaycentral) {
		this.estadoPaycentral = estadoPaycentral;
	}

	public String getConvenioID() {
		return convenioID;
	}

	public void setConvenioID(String convenioID) {
		this.convenioID = convenioID;
	}

	public String getFechaActualizacion() {
		return fechaActualizacion;
	}

	public void setFechaActualizacion(String fechaActualizacion) {
		this.fechaActualizacion = fechaActualizacion;
	}

	public int getFlagCorreo() {
		return flagCorreo;
	}

	public void setFlagCorreo(Integer flagCorreo) {
		this.flagCorreo = flagCorreo;
	}
	
}
