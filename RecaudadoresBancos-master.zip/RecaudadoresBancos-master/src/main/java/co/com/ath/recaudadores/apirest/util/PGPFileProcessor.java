package co.com.ath.recaudadores.apirest.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPSecretKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/  
public class PGPFileProcessor {
 
	static Logger LOGGER = LoggerFactory.getLogger(PGPFileProcessor.class);
	
    private String ring;
    private String publicKeyFileName;
    private String secretKeyFileName;
    private String inputFileName;
    private String outputFileName;
    private boolean asciiArmored = false;
    private boolean integrityCheck = true;
 
    /**
	 * Encrypta el archivo. Retorna true si el encriptado es correcto, false en otro caso 
	 * @return boolean
	*/
    public boolean encrypt() {
    	FileInputStream keyIn = null;
    	FileOutputStream out = null;
    	try {
    		LOGGER.info(Constants.HEADER_LOG);
    		LOGGER.info("	LEYENDO EL ARCHIVO: " + this.inputFileName);
    		LOGGER.info("	USANDO LLAVE PUBLICA: " + this.publicKeyFileName);
    		keyIn = new FileInputStream(this.publicKeyFileName);
    		LOGGER.info("	GENERANDO ARCHIVO ENCRIPTADO: " + this.outputFileName);
            out = new FileOutputStream(this.outputFileName);
           PGPUtils.encryptFile(out, this.inputFileName, PGPUtils.readPublicKey(keyIn), this.asciiArmored, this.integrityCheck); 
            LOGGER.info("	TERMINANDO PROCESO DE ENCRIPTADO");
            out.close();
            keyIn.close();
            LOGGER.info(Constants.HEADER_LOG);
            return true;
		} catch (Exception e) {
			LOGGER.info("	ERROR EN EL PROCESO DE ENCRIPTADO");
			LOGGER.info("	TERMINANDO PROCESO");
			LOGGER.info(Constants.HEADER_LOG);
			return false;
		}finally {
			out = null;
			keyIn = null;
		}
    }
    /**
     * Firma el archivo
     * @return boolean
     * @throws Exception
     */
    public boolean signEncrypt() throws Exception {
        FileOutputStream out = new FileOutputStream(this.outputFileName);
        FileInputStream publicKeyIn = new FileInputStream(this.publicKeyFileName);
        FileInputStream secretKeyIn = new FileInputStream(this.secretKeyFileName);
 
        PGPPublicKey publicKey = PGPUtils.readPublicKey(publicKeyIn);
        PGPSecretKey secretKey = PGPUtils.readSecretKey(secretKeyIn);
 
        PGPUtils.signEncryptFile(
                out,
                this.getInputFileName(),
                publicKey,
                secretKey,
                this.getRing(),
                this.isAsciiArmored(),
                this.isIntegrityCheck() );
 
        out.close();
        publicKeyIn.close();
        secretKeyIn.close();
 
        return true;
    }
 
    /**
	 * Desencrita el archivo. Retorna true si el desencriptado es correcto, false en otro caso 
	 * @return boolean
	*/
    public boolean decrypt() throws Exception {
    	FileInputStream in = null;
    	FileInputStream keyIn = null;
    	FileOutputStream out = null;
    	try {
    		LOGGER.info(Constants.HEADER_LOG);
    		LOGGER.info("	LEYENDO EL ARCHIVO: {}",  this.inputFileName);
    		LOGGER.info("	USANDO LLAVE SECRETA: {}", this.secretKeyFileName);
            in = new FileInputStream(this.inputFileName);
            LOGGER.info("	GENERANDO ARCHIVO DESENCRIPTADO: {}", this.outputFileName);
            keyIn = new FileInputStream(this.secretKeyFileName);
            out = new FileOutputStream(this.outputFileName);
            PGPUtils.decryptFile(in, out, keyIn, this.ring.toCharArray());
            LOGGER.info("	TERMINANDO PROCESO DE ENCRIPTADO");
            in.close();
            out.close();
            keyIn.close();
            LOGGER.info(Constants.HEADER_LOG);
            return true;
		} catch (Exception e) {
			LOGGER.info("	ERROR EN EL PROCESO DE DESENCRIPTADO");
			LOGGER.info("	TERMINANDO PROCESO");
			LOGGER.info(Constants.HEADER_LOG);
			return false;
		} finally {
			if(in != null) {
				in.close();
			}
			if(keyIn != null) {
				keyIn.close();
			}
			if(out != null) {
				out.close();
			}
		}
    }
    
    public boolean verify(InputStream lin, InputStream publicKey) {
    	try {
    		return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
    }
 
    public boolean isAsciiArmored() {
            return this.asciiArmored;
    }
 
    public void setAsciiArmored(boolean asciiArmored) {
            this.asciiArmored = asciiArmored;
    }
 
    public boolean isIntegrityCheck() {
            return this.integrityCheck;
    }
 
    public void setIntegrityCheck(boolean integrityCheck) {
            this.integrityCheck = integrityCheck;
    }
 
    public String getRing() {
            return this.ring;
    }
 
    public void setRing(String ring) {
            this.ring = ring;
    }
 
    public String getPublicKeyFileName() {
            return this.publicKeyFileName;
    }
 
    public void setPublicKeyFileName(String publicKeyFileName) {
            this.publicKeyFileName = publicKeyFileName;
    }
 
    public String getSecretKeyFileName() {
            return this.secretKeyFileName;
    }
 
    public void setSecretKeyFileName(String secretKeyFileName) {
            this.secretKeyFileName = secretKeyFileName;
    }
 
    public String getInputFileName() {
            return this.inputFileName;
    }
 
    public void setInputFileName(String inputFileName) {
            this.inputFileName = inputFileName;
    }
 
    public String getOutputFileName() {
            return this.outputFileName;
    }
 
    public void setOutputFileName(String outputFileName) {
            this.outputFileName = outputFileName;
    }
 
}