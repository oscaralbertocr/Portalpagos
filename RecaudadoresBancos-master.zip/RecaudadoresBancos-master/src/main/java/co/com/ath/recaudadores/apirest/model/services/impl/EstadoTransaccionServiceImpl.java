package co.com.ath.recaudadores.apirest.model.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dao.IEstadoTransaccionDAO;
import co.com.ath.recaudadores.apirest.model.dto.EstadoTransaccionDTO;
import co.com.ath.recaudadores.apirest.model.entities.EstadoTransaccion;
import co.com.ath.recaudadores.apirest.model.services.IEstadoTransaccionService;
import co.com.ath.recaudadores.apirest.util.Constants;

@Service
public class EstadoTransaccionServiceImpl implements IEstadoTransaccionService {
	static Logger logger = LoggerFactory.getLogger(EstadoTransaccionServiceImpl.class);

	@Autowired
	private IEstadoTransaccionDAO estadoTransaccionDao;

	@Override
	public List<EstadoTransaccionDTO> findAll() {
		List<EstadoTransaccion> lst = (List<EstadoTransaccion>) estadoTransaccionDao.findAll();
		List<EstadoTransaccionDTO> listaEstados = new ArrayList<>();
		if (lst.size() > 0) {
			EstadoTransaccionDTO estadoTransaccionDTO = new EstadoTransaccionDTO();
			for (EstadoTransaccion e : lst) {
				estadoTransaccionDTO = e.toEstadoTransaccionDTO();
				if (estadoTransaccionDTO != null) {
					listaEstados.add(estadoTransaccionDTO);
				}
			}
			estadoTransaccionDTO = new EstadoTransaccionDTO();
			estadoTransaccionDTO.setId(Constants.TODOS_ID);
			estadoTransaccionDTO.setNombre(Constants.ESTADOS_TX_TODOS_TXT);
			listaEstados.add(estadoTransaccionDTO);
		}
		return listaEstados;
	}

}
