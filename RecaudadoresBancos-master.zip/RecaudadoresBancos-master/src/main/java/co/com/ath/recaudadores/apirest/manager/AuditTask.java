package co.com.ath.recaudadores.apirest.manager;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.entities.ArchivoFacturacion;
import co.com.ath.recaudadores.apirest.model.services.impl.ArchivoFacturacionServiceImpl;
import co.com.ath.recaudadores.apirest.util.AuditException;
import co.com.ath.recaudadores.apirest.util.Constants;
/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
@Service
@StepScope
public class AuditTask implements Tasklet{


	static Logger logger = LoggerFactory.getLogger(AuditTask.class);
	
	@Value("#{jobParameters[fileNameInput]}")
	private String fileNameInput;
	
	@Value("#{jobParameters[fileNameOutput]}")
	private String fileNameOutput;
	
	@Value("#{jobParameters[idConvenio]}")
	private String idConvenio;
	
	@Value("#{jobParameters[fileOriginalName]}")
	private String fileOriginalName;
	
	@Value("#{jobParameters[fileSize]}")
	private String fileSize;
	
	@Value("#{jobParameters[userNickName]}")
	private String userNickName;
	
	@Value("#{jobParameters[ciclo]}")
	private String ciclo;
	
	@Value("#{jobParameters[messageTo]}")
	private String email;
	
	@Value("#{jobParameters[userFullName]}")
	private String userFullName;
	
	@Value("#{jobExecutionContext['referenciaPrincipal']}")
	private String referenciaPrincipal;
	
	@Autowired
	private ArchivoFacturacionServiceImpl archivoFacturacionImpl;
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws AuditException {
		try {
			ArchivoFacturacion archivoFacturacion = new ArchivoFacturacion();
			archivoFacturacion.setConvenioID(idConvenio);
			archivoFacturacion.setNombreOriginal(fileOriginalName);
			archivoFacturacion.setNombreATH(fileNameOutput);
			archivoFacturacion.setTamano(String.valueOf(fileSize));
			archivoFacturacion.setUsuario(userNickName);
			archivoFacturacion.setCiclo(ciclo);
			archivoFacturacion.setCorreoUsuario(email);
			archivoFacturacion.setNombreUsuario(userFullName);
			archivoFacturacion.setEmailNotificacionEnviado(0);
			archivoFacturacion.setIntentosConsulta(0);
			archivoFacturacion.setReferenciaPrincipal(referenciaPrincipal);
			archivoFacturacion.setFechaCarga(new Date());
			archivoFacturacion.setFechaActualizacion(null);
			archivoFacturacion.setFechaNotificacionEmail(null);
			archivoFacturacion.setEnvioPaycentral("1");
			archivoFacturacion.setEstadoPaycentral(Constants.firsStateFile);
			archivoFacturacion.setAccion("Carga de archivo");
			archivoFacturacion.setComentarios("Se carga archivo desde el Front");
			archivoFacturacion.setHash("0");
			archivoFacturacionImpl.guardar(archivoFacturacion);
		}catch (Exception e) {
			logger.error("Error en la auditoria del proceso. Archivo: {}", fileOriginalName);
			logger.error(e.getMessage());
			throw new AuditException(Constants.AUDIT_ERROR);
		}
		return RepeatStatus.FINISHED;
	}
	
}
