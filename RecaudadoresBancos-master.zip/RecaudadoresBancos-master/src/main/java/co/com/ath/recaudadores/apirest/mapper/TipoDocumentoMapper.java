package co.com.ath.recaudadores.apirest.mapper;

import java.util.ArrayList;
import java.util.List;

import co.com.ath.recaudadores.apirest.model.dto.TipoDocumentoDTO;
import co.com.ath.recaudadores.apirest.model.entities.TipoDocumento;

public class TipoDocumentoMapper {
	
	private TipoDocumentoMapper() {}
	
	public static List<TipoDocumentoDTO> mapListEntityToDto(List<TipoDocumento> tipoDocumento) {
		List<TipoDocumentoDTO> bancosDto = new ArrayList<TipoDocumentoDTO>();
		if (tipoDocumento != null && !tipoDocumento.isEmpty()) {
			for (TipoDocumento banco : tipoDocumento) {
				bancosDto.add(mapEntityToDto(banco));
			}
		}
		return bancosDto;
	}
	
	public static TipoDocumentoDTO mapEntityToDto(TipoDocumento tipoDocumento) {
		TipoDocumentoDTO tipoDocumentoDto = null;
		if(tipoDocumento != null) {
			tipoDocumentoDto = new TipoDocumentoDTO();
			tipoDocumentoDto.setTipdocId(tipoDocumento.getTipdocId());
			tipoDocumentoDto.setTipdocDescripcion(tipoDocumento.getTipdocDescripcion());
			tipoDocumentoDto.setTipodocCodigo(tipoDocumento.getTipodocCodigo());
		}
		return tipoDocumentoDto;
	}
}
