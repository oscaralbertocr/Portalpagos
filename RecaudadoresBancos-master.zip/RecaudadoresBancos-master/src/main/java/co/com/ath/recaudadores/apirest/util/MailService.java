package co.com.ath.recaudadores.apirest.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dto.MailServiceInDTO;
import co.com.ath.recaudadores.apirest.model.services.IParametroService;

@Service
public class MailService {
	
	static Logger logger = LoggerFactory.getLogger(MailService.class);

	JavaMailSenderImpl mailSenderImpl;

	@Autowired
	private IParametroService parametroService;
	
	private JavaMailSender javaMailSender;
	
	private Path path;
	private byte[] sourceAtt;
	
	@PostConstruct
	public void init() {
		mailSenderImpl = new JavaMailSenderImpl();
		mailSenderImpl.setHost(parametroService.find("SMTPHost").getValor());
		mailSenderImpl.setPort(Integer.parseInt(parametroService.find("SMTPPort").getValor()));
		if(parametroService.find("SMTPUser") != null && !parametroService.find("SMTPUser").getValor().isEmpty()) {
			mailSenderImpl.setUsername(parametroService.find("SMTPUser").getValor());
		}
		if(parametroService.find("SMTPPass") != null && !parametroService.find("SMTPPass").getValor().isEmpty()) {
			mailSenderImpl.setUsername(parametroService.find("SMTPPass").getValor());
		}
		mailSenderImpl.setProtocol(parametroService.find("SMTPProtocol").getValor());
		mailSenderImpl.setJavaMailProperties(this.getMailProperties());
		javaMailSender = mailSenderImpl;
	}
	
	@Async
	public void sendMail(MailServiceInDTO inDTO) throws CustomException{
		logger.info("Inicio envio de mensaje");
		MimeMessage message = javaMailSender.createMimeMessage();
		MimeMessageHelper mime;
		try {
			String fromEmail = parametroService.find("SMTPFrom").getValor();
			String subjectEmail = parametroService.find("SMTPSubject").getValor();
			mime = new MimeMessageHelper(message, true, "UTF-8");
			mime.setFrom(fromEmail);
			mime.setSubject((inDTO.getSubject()==null)?subjectEmail:inDTO.getSubject());
			mime.setTo(inDTO.getTo());
			if(inDTO.getCc() != null){
				mime.setCc(inDTO.getCc());
			}
			if(inDTO.getBcc() != null){
				mime.setBcc(inDTO.getBcc());
			}
			mime.setText(inDTO.getText(),true);
			logger.info("Se enviara el mensaje: {}, al destinatario: {}",inDTO.getText(), inDTO.getTo());
			mailSenderImpl.send(message);
		} catch (MessagingException e) {
			logger.info("Error Enviando Correo");
			logger.error(e.getMessage());
			logger.error(e.getLocalizedMessage());
			throw new CustomException();
		}
		logger.info("Fin envio de mensaje. Envio Exitoso");
	}
	
	@Async
	public void sendMailWithFile(MailServiceInDTO inDTO, String rutaArchivo, String nombreArchivo) throws CustomException{
		logger.info("Inicio envio de mensaje");
		MimeMessage message = javaMailSender.createMimeMessage();
		MimeMessageHelper mime;
		try {
			String fromEmail = parametroService.find("SMTPFrom").getValor();
			String subjectEmail = parametroService.find("SMTPSubject").getValor();
			mime = new MimeMessageHelper(message, true, "UTF-8");
			mime.setFrom(fromEmail);
			mime.setSubject((inDTO.getSubject()==null)?subjectEmail:inDTO.getSubject());
			mime.setTo(inDTO.getTo());
			if(inDTO.getCc() != null){
				mime.setCc(inDTO.getCc());
			}
			if(inDTO.getBcc() != null){
				mime.setBcc(inDTO.getBcc());
			}
			if(!nombreArchivo.isEmpty()) {
				path = Paths.get(rutaArchivo);
				sourceAtt = Files.readAllBytes(path);
				mime.addAttachment(nombreArchivo, new ByteArrayResource(sourceAtt));
			}			
			mime.setText(inDTO.getText(),true);
			logger.info("Se enviara el mensaje: {}, al destinatario: {}",inDTO.getText(), inDTO.getTo());
			try {
				mailSenderImpl.send(message);
			} catch (Exception e) {
				logger.error("Error tratando de enviar el correo", e);
			}
		
			//Se realiza eliminación del archivo
			File file = new File(rutaArchivo);
			if (file.exists()) {
				if (file.delete()) {
					logger.info("Archivo eliminado: {}", rutaArchivo);
				}
			}
			
		} catch (MessagingException e) {
			logger.info("Error Enviando Correo");
			logger.error(e.getMessage());
			logger.error(e.getLocalizedMessage());
			throw new CustomException();
		} catch (Exception e) {
			logger.error("Error creando correo {}", e);
		}
		logger.info("Fin envio de mensaje. Envio Exitoso");
	}
	
	private Properties getMailProperties() {
		Properties mailProperties = new Properties();
		mailProperties.put("mail.smtp.auth",  parametroService.find("SMTPAuth").getValor());
		mailProperties.put("mail.smtp.starttls.enable",  parametroService.find("SMTPStartTLS").getValor());
		mailProperties.put("mail.smtp.ssl.trust",  parametroService.find("SMTPSSLTrust").getValor());
		
		return mailProperties;
	}

}
