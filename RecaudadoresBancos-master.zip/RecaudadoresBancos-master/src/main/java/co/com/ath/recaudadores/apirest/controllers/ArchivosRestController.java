package co.com.ath.recaudadores.apirest.controllers;

import java.io.File;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import org.apache.poi.util.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.CacheControl;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.jcraft.jsch.ChannelSftp.LsEntry;

import co.com.ath.recaudadores.apirest.manager.FileManager;
import co.com.ath.recaudadores.apirest.model.dao.IConvenioDAO;
import co.com.ath.recaudadores.apirest.model.dto.RequestDownloadFile;
import co.com.ath.recaudadores.apirest.model.entities.Convenio;
import co.com.ath.recaudadores.apirest.model.services.IParametroService;
import co.com.ath.recaudadores.apirest.util.Constants;
import co.com.ath.recaudadores.apirest.util.FTPconnection;

/**
 * Endpoint para la descarga de archivos de reportes
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 26/11/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 

@RestController
@RequestMapping("/rest")
public class ArchivosRestController {
	
	static Logger logger = LoggerFactory.getLogger(ArchivosRestController.class);
	
	@Autowired
	private IParametroService parametroService;
	
	@Autowired
	private IConvenioDAO convenioDao;
	
	@Autowired
	private FileManager fileManager;
	
	@PostMapping("/file/download")
	public ResponseEntity<byte[]> download(@RequestBody RequestDownloadFile request) {
		FTPconnection conection = null;
		try {
			logger.info("DownloadService Input: {}", request);
			String nameFile = generateNameFile(request);
			String host = parametroService.find("SFTPhost").getValor();
			String port = parametroService.find("SFTPport").getValor();
			String user = parametroService.find("SFTPuser").getValor();
			String pass = parametroService.find("SFTPpass").getValor();
			String base = parametroService.find("SFTPbase").getValor();
			if(request.getPaymentWay().equalsIgnoreCase(Constants.PSEname)) {
				base = base.concat(Constants.PSEname+"/"+request.getDate()+"/");
			}else if(request.getPaymentWay().equalsIgnoreCase(Constants.TCname)) {
				base = base.concat(Constants.TCname+"/"+request.getDate()+"/");
			}else if(request.getPaymentWay().equalsIgnoreCase(Constants.AVALname)) {
				base = base.concat(Constants.AVALname+"/"+request.getDate()+"/");
			}
			logger.info("Iniciando conexion al SFTP");
			conection = new FTPconnection(host, user, pass, base, port);
			logger.info("Se realiza la conexion al SFTP. Path: {}", base);	
			LsEntry fileFtp = null;
			ArrayList<LsEntry> vectorOne =  conection.listFiles("*");
			if(vectorOne != null && !vectorOne.isEmpty()) {
				logger.info("Buscando archivo... {}", nameFile);
				for(LsEntry ls : vectorOne) {
			        if(ls.getFilename().matches(nameFile)) {
			        	logger.info("Archivo encontrado: {}", ls.getFilename());
			        	fileFtp = ls;
			        	break;
			        }
				}
			}
			
			if(fileFtp != null) {
				byte[] file = IOUtils.toByteArray(conection.downloadFile(fileFtp.getFilename())); 
				conection.close();
				HttpHeaders httpHeaders = new HttpHeaders();
				httpHeaders.add("Access-Control-Expose-Headers", "*,FileNameDownload");
				httpHeaders.add(HttpHeaders.CONTENT_DISPOSITION, Constants.dispositionFile);
				httpHeaders.add("FileNameDownload", fileFtp.getFilename());
				return ResponseEntity.ok()
						.header(HttpHeaders.CONTENT_DISPOSITION, Constants.dispositionFile)
						.headers(httpHeaders)
						.contentType(MediaType.parseMediaType(Constants.typeFile))
						.cacheControl(CacheControl.noCache())
						.body(file);
			} else {
				logger.info("No se encontro ningun archivo");
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
		}catch(Exception e) {
			logger.error(e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		} finally {
			if(conection != null) {
				conection.close();
			}
		}
	}

	@PostMapping(value = "/file/upload", consumes = "multipart/form-data")
	public ResponseEntity<byte[]> upload(@RequestPart("File") MultipartFile file, 
			@RequestParam("IDConvenio") String idConvenio, @RequestParam("Ciclo") String ciclo,
			@RequestParam("Email") String email, @RequestParam("UserNickName") String userNickName,
			@RequestParam("UserFullName") String userFullName) {
		try {
			String workSpaceInitial = parametroService.find("workSpaceUploadFiles").getValor();
			String workSpaceFinal = validatePath(workSpaceInitial);
			String keyPublicPGP = parametroService.find("keyPublicPGP").getValor();
			SecureRandom secureRandom = new SecureRandom();
			String nameInput = file.getOriginalFilename().concat(String.valueOf(secureRandom.nextInt()));
			String nameOutput = this.generateOutputFileUpload(idConvenio, ciclo);
			logger.info("Inicio de carga de archivo: {}", file.getOriginalFilename());
			file.transferTo(new File(workSpaceFinal, nameInput));
			logger.info("Archivo Guardado en WorkSpace: {}", file.getOriginalFilename());
			fileManager.run(this.generateParameters(workSpaceFinal, nameInput, file, nameOutput, 
						keyPublicPGP, email, idConvenio, userNickName, ciclo, userFullName));
			return new ResponseEntity<>(HttpStatus.OK);
		} catch (Exception e) {
			logger.error(e.getMessage());
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	private String validatePath(String workSpaceInitial) {
		String workSpaceFinal = (workSpaceInitial.endsWith("\\"))?workSpaceInitial.concat(this.generateDate()): workSpaceInitial.concat("\\"+this.generateDate());
		try {
			File path = new File(workSpaceFinal);
			if(!path.exists() || !path.isDirectory()) {
				logger.info("Directorio No encontrado");
				path.mkdirs();
				logger.info("Directorio De fecha Creado");
			}
		}catch(Exception e) {
			logger.error("Error generando ruta para el archivo");
			logger.error(e.getMessage());
		}
		return workSpaceFinal.concat("\\");
	}
	
	private String generateDate() {
		Calendar calendar = Calendar.getInstance();
		String day = String.valueOf(calendar.get(Calendar.DATE));
		String month = String.valueOf(calendar.get(Calendar.MONTH)+1);
		if((calendar.get(Calendar.MONTH)+1) < 10) {
			month = "0".concat(month);
		}
		if(calendar.get(Calendar.DATE) < 10) {
			day = "0".concat(day);
		}
		String year = String.valueOf(calendar.get(Calendar.YEAR));
		return (year).concat(month).concat(day);
	}
	
	private String generateNameFile(RequestDownloadFile request) {
		String name = "";
		Convenio conv = convenioDao.findOne(request.getIdConv());
		String nameConv = conv.getNombre().replaceAll(Constants.spaFile,"");
		nameConv = (nameConv.length()>14)?nameConv.substring(0, 14):nameConv;
		String date = Constants.sepaFile.concat(request.getDate().concat(Constants.sepaFile));
		String structure = request.getStructure();
		String regex =  parametroService.find("RegexFileName").getValor();
		name = String.format(regex, conv.getId(), date, (request.getPaymentWay().equalsIgnoreCase(Constants.TCname) || 
																request.getPaymentWay().equalsIgnoreCase(Constants.PSEname)) ? structure : "");
		logger.info("Regex construido: {}", name);
		return name;
	}
	
	private String generateOutputFileUpload(String nura, String ciclo) {
		Convenio conv = convenioDao.findOne(nura);
		String sigla = conv.getSigla();
		if(sigla.contains("/")) {
			sigla = sigla.replace("/", "");
		}
		return nura.concat(sigla).concat(ciclo).concat(".dat");
	}
	
	private HashMap<String, String> generateParameters(String workSpace, String nameInput, 
			MultipartFile file, String nameOutput, String keyPublicPGP, String email, String idConvenio,
			String userNickName, String ciclo, String userFullName) {
		HashMap<String, String> parameters = new HashMap<>();
		parameters.put("pathInput", workSpace);
		parameters.put("fileNameInput", nameInput);
		parameters.put("fileOriginalName", file.getOriginalFilename());
		parameters.put("pathOutput", workSpace);
		parameters.put("fileNameOutput", nameOutput);
		parameters.put("keyPublicPGP", keyPublicPGP);
		parameters.put("urlFileStructure",  parametroService.find("UrlArchivoPlantilla").getValor());
		parameters.put("messageTo", email);
		parameters.put("messageContentSuccess", parametroService.find("MailMessageSuccess").getValor());
		parameters.put("messageContentError", parametroService.find("MailMessageError").getValor());
		parameters.put("idConvenio", idConvenio);
		parameters.put("nit", convenioDao.findOne(idConvenio).getNit());
		parameters.put("ean", convenioDao.findOne(idConvenio).getCodEan());
		parameters.put("fileSize", String.valueOf(file.getSize()));
		parameters.put("userNickName", userNickName);
		parameters.put("ciclo", ciclo);
		parameters.put("userFullName", userFullName);
		return parameters;
	}
	
	
}

