package co.com.ath.recaudadores.apirest.model.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entity class for ReferenciaTX table
 * @author javier.florez
 * 25-oct-2020
 */
@Entity
@Table(name = "REFERENCIA_TX")
public class ReferenciaTx implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="TX_ID", insertable=false, updatable=false)
	private long txId;

	@Id
	@Column(name = "REFERENCIA")
	private String referencia;

	@Id
	@Column(name = "POSICION")
	private long posicion;

	@Column(name = "REFERENCIA_TOKEN")
	private String referenciaToken;

	public long getTxId() {
		return txId;
	}

	public void setTxId(long txId) {
		this.txId = txId;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public long getPosicion() {
		return posicion;
	}

	public void setPosicion(long posicion) {
		this.posicion = posicion;
	}

	public String getReferenciaToken() {
		return referenciaToken;
	}

	public void setReferenciaToken(String referenciaToken) {
		this.referenciaToken = referenciaToken;
	}
	
	

}
