package co.com.ath.recaudadores.apirest.model.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dao.IEstadoConvenioDAO;
import co.com.ath.recaudadores.apirest.model.dto.EstadoConvenioDTO;
import co.com.ath.recaudadores.apirest.model.entities.EstadoConvenio;
import co.com.ath.recaudadores.apirest.model.services.IEstadoConvenioService;

/*
 * Clase : EstadoConvenioServiceImpl
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */

@Service
public class EstadoConvenioServiceImpl implements IEstadoConvenioService {
	static Logger logger = LoggerFactory.getLogger(EstadoConvenioServiceImpl.class);

	@Autowired
	private IEstadoConvenioDAO estadoConvenioDao;

	@Override
	public List<EstadoConvenioDTO> findAll() {
		List<EstadoConvenio> lst = (List<EstadoConvenio>) estadoConvenioDao.findAll();
		List<EstadoConvenioDTO> listaEstadoCovenio = new ArrayList<>();

		for (EstadoConvenio e : lst) {
			listaEstadoCovenio.add(e.toEstadoConvenioTO());
		}
		return listaEstadoCovenio;
	}

}
