package co.com.ath.recaudadores.apirest.model.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/*
 * Clase : ConvenioConf
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Entity
@Table(name = "EXT_CONVENIO_CONF")
public class ConvenioConf {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CNV_ID", nullable = false)
	private String id;

	@Column(name = "CNV_PERMITE_PAGO_PARCIAL", nullable = false)
	private Long permitePagoParcial;

	@Column(name = "CNV_REQ_DOC_USUARIO", nullable = false)
	private Long docUsuario;

	@Column(name = "CNV_REQ_INTENCION_PAGO", nullable = false)
	private Long intencionPago;

	@Column(name = "CNV_BANK_ID")
	private String banco;

	@Column(name = "CNV_EXT_CONVENIO_ASOCIADO")
	private String convenioAsociado;

	@Column(name = "CNV_LIMITE_TRANSACCIONES")
	private String limiteTransacciones;

	@Column(name = "CNV_PERMITE_PAGO_DOLARES", nullable=true, length=16, columnDefinition="CHAR")
	private String aceptaDolares;

	@Column(name = "CNV_TIPO_OBLIGACION_ID")
	private Long tipoObligacion;

	@Column(name = "CNV_NUMERO_CUENTA_RECAUDO")
	private String cuentaRecaudo;

	@Column(name = "CNV_EXT_CNV_ASO_DOLARES")
	private String asoDolares;

	@Column(name = "TIPO_CARGUE_ID")
	private String tipoCargue;

	@Column(name = "COSTO_TRANSACCION")
	private Long costoTransaccion;

	@Column(name = "MULTI_REF", nullable=true, length=16, columnDefinition="CHAR")
	private String multiRefer;

	@Column(name = "PERMITE_CONCEPTOS_PAGO", nullable=true, length=16, columnDefinition="CHAR")
	private String permiteConceptosPagos;

	@Column(name = "LABEL_VALOR_PAGO")
	private String textoValor;

	@Column(name = "CONV_VALID_BIN", nullable=true, length=16, columnDefinition="CHAR")
	private String validBin;

	@Column(name = "VALID_BIN_TC", nullable=true, length=16, columnDefinition="CHAR")
	private String validBinTc;

	@Column(name = "CLAVE_HTTPS")
	private String claveHttps;

	@Column(name = "URL_CONVENIO_CPV")
	private String urlConvenio;

	@Column(name = "PILOTO", nullable=true, length=16, columnDefinition="CHAR")
	private String piloto;

	@Column(name = "VALID_TOPE", nullable=true, length=16, columnDefinition="CHAR")
	private String validTope;

	@Column(name = "PORCENTAJE_VALOR_PAGAR")
	private Long porcentajeValorCarga;
	
    @OneToOne
    @JoinColumn(name="CNV_ID")
    private Convenio convenio;

	public ConvenioConf() {

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Long getPermitePagoParcial() {
		return permitePagoParcial;
	}

	public void setPermitePagoParcial(Long permitePagoParcial) {
		this.permitePagoParcial = permitePagoParcial;
	}

	public Long getDocUsuario() {
		return docUsuario;
	}

	public void setDocUsuario(Long docUsuario) {
		this.docUsuario = docUsuario;
	}

	public Long getIntencionPago() {
		return intencionPago;
	}

	public void setIntencionPago(Long intencionPago) {
		this.intencionPago = intencionPago;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getConvenioAsociado() {
		return convenioAsociado;
	}

	public void setConvenioAsociado(String convenioAsociado) {
		this.convenioAsociado = convenioAsociado;
	}

	public String getLimiteTransacciones() {
		return limiteTransacciones;
	}

	public void setLimiteTransacciones(String limiteTransacciones) {
		this.limiteTransacciones = limiteTransacciones;
	}

	public String getAceptaDolares() {
		return aceptaDolares;
	}

	public void setAceptaDolares(String aceptaDolares) {
		this.aceptaDolares = aceptaDolares;
	}

	public Long getTipoObligacion() {
		return tipoObligacion;
	}

	public void setTipoObligacion(Long tipoObligacion) {
		this.tipoObligacion = tipoObligacion;
	}

	public String getCuentaRecaudo() {
		return cuentaRecaudo;
	}

	public void setCuentaRecaudo(String cuentaRecaudo) {
		this.cuentaRecaudo = cuentaRecaudo;
	}

	public String getAsoDolares() {
		return asoDolares;
	}

	public void setAsoDolares(String asoDolares) {
		this.asoDolares = asoDolares;
	}

	public String getTipoCargue() {
		return tipoCargue;
	}

	public void setTipoCargue(String tipoCargue) {
		this.tipoCargue = tipoCargue;
	}

	public Long getCostoTransaccion() {
		return costoTransaccion;
	}

	public void setCostoTransaccion(Long costoTransaccion) {
		this.costoTransaccion = costoTransaccion;
	}

	public String getMultiRefer() {
		return multiRefer;
	}

	public void setMultiRefer(String multiRefer) {
		this.multiRefer = multiRefer;
	}

	public String getPermiteConceptosPagos() {
		return permiteConceptosPagos;
	}

	public void setPermiteConceptosPagos(String permiteConceptosPagos) {
		this.permiteConceptosPagos = permiteConceptosPagos;
	}

	public String getTextoValor() {
		return textoValor;
	}

	public void setTextoValor(String textoValor) {
		this.textoValor = textoValor;
	}

	public String getValidBin() {
		return validBin;
	}

	public void setValidBin(String validBin) {
		this.validBin = validBin;
	}

	public String getValidBinTc() {
		return validBinTc;
	}

	public void setValidBinTc(String validBinTc) {
		this.validBinTc = validBinTc;
	}

	public String getClaveHttps() {
		return claveHttps;
	}

	public void setClaveHttps(String claveHttps) {
		this.claveHttps = claveHttps;
	}

	public String getUrlConvenio() {
		return urlConvenio;
	}

	public void setUrlConvenio(String urlConvenio) {
		this.urlConvenio = urlConvenio;
	}

	public String getPiloto() {
		return piloto;
	}

	public void setPiloto(String piloto) {
		this.piloto = piloto;
	}

	public String getValidTope() {
		return validTope;
	}

	public void setValidTope(String validTope) {
		this.validTope = validTope;
	}

	public Long getPorcentajeValorCarga() {
		return porcentajeValorCarga;
	}

	public void setPorcentajeValorCarga(Long porcentajeValorCarga) {
		this.porcentajeValorCarga = porcentajeValorCarga;
	}

	public Convenio getConvenio() {
		return convenio;
	}

	public void setConvenio(Convenio convenio) {
		this.convenio = convenio;
	}

	@Override
	public String toString() {
		return "ConvenioConf [id=" + id + ", banco=" + banco + ", convenioAsociado=" + convenioAsociado
				+ ", tipoObligacion=" + tipoObligacion + ", cuentaRecaudo=" + cuentaRecaudo + "]";
	}

}
