package co.com.ath.recaudadores.apirest.model.services.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dao.ITransaccionDAO;
import co.com.ath.recaudadores.apirest.model.dto.PreferenciaConsultaDTO;
import co.com.ath.recaudadores.apirest.model.dto.TransaccionConsultaDTO;
import co.com.ath.recaudadores.apirest.model.entities.Transaccion;
import co.com.ath.recaudadores.apirest.model.services.ITransaccionService;
import co.com.ath.recaudadores.apirest.util.Constants;
import co.com.ath.recaudadores.apirest.util.FilterTransaccion;

/**
 * Service class for transaccion bussiness
 * 
 * @author javier.florez 23-oct-2020
 */
@Service
public class TransaccionServiceImpl implements ITransaccionService {

	static Logger logger = LoggerFactory.getLogger(TransaccionServiceImpl.class);
	private Map<String, Boolean> column = new HashMap<>();

	private final ITransaccionDAO transaccionDao;

	@Autowired
	public TransaccionServiceImpl(ITransaccionDAO transaccionDao) {
		this.transaccionDao = transaccionDao;
	}

	@Override
	public JSONArray getTxByFilters(FilterTransaccion filter) throws Exception {
		logger.info("Iniciando búsqueda de tx");
		List<Transaccion> entities = null;

		if (filter.getFechaInicio() != null && filter.getFechaFin() != null) {
			convertir(filter.getParametrias());
			SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd");
			String fechaI = dt1.format(filter.getFechaInicio());

			SimpleDateFormat dt2 = new SimpleDateFormat("yyyy-MM-dd");
			String fechaF = dt2.format(filter.getFechaFin());

			logger.info(fechaI);
			logger.info(fechaF);

			entities = transaccionDao.getTxByFilters(fechaI, fechaF, filter.getMedioPago(), filter.getEstadoTx(),
					filter.getConvenio(), filter.getNumRef(), filter.getValorPago(), filter.getIdTx(), filter.getCus());

		}
		return toTransaccionConsultaJSon(entities);
	}

	/**
	 * @param lst
	 */
	private void convertir(List<PreferenciaConsultaDTO> lst) {
		for (PreferenciaConsultaDTO p : lst) {
			if (p.isActivo()) {
				column.put(p.getNombreParametro(), true);
			}
		}
	}

	@Override
	public List<TransaccionConsultaDTO> getAllTxByFilter(FilterTransaccion filter) throws Exception {
		logger.info("Iniciando búsqueda de tx");
		List<TransaccionConsultaDTO> response = new ArrayList<TransaccionConsultaDTO>();
		if (filter.getFechaInicio() != null && filter.getFechaFin() != null) {
			try {
				
				Calendar clInicio = Calendar.getInstance();
				clInicio.setTime(filter.getFechaInicio());
				clInicio.add(Calendar.DATE, 1);
				SimpleDateFormat dt1 = new SimpleDateFormat("yyyy-MM-dd");
				String fechaI = dt1.format(clInicio.getTime());

				Calendar clFin = Calendar.getInstance();
				clFin.setTime(filter.getFechaFin());
				clFin.add(Calendar.DATE, 1);
				SimpleDateFormat dt2 = new SimpleDateFormat("yyyy-MM-dd");
				String fechaF = dt2.format(clFin.getTime());

				logger.info("Fecha i: " + clInicio.toString() + " :: " + clFin.toString());
				logger.info(fechaI);
				logger.info(fechaF);

				List<Object[]> listaTransacciones = transaccionDao.getAllTxByFilters(fechaI, fechaF,
						filter.getMedioPago(), filter.getEstadoTx(), filter.getConvenio(), filter.getNumRef(),
						filter.getValorPago(), filter.getIdTx(), filter.getCus());

				if (listaTransacciones != null && listaTransacciones.size() > 0) {
					response = mapearCampos(listaTransacciones);
				}

			} catch (Exception e) {
				logger.error("Error procesando los datos: " + e.getMessage());
			}
		}
		return response;
	}

	public List<TransaccionConsultaDTO> mapearCampos(List<Object[]> listaTransacciones) {

		String fechaString;
		String referencia;
		TransaccionConsultaDTO transaccionMapeada;
		SimpleDateFormat formatoFecha = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss aa");
		List<TransaccionConsultaDTO> listaTransaccionesMapeadas = new ArrayList<TransaccionConsultaDTO>();

		for (Object[] transaccion : listaTransacciones) {
			transaccionMapeada = new TransaccionConsultaDTO();

			String idTx = ((String) transaccion[0]);
			transaccionMapeada.setIdTx(idTx);
			transaccionMapeada.setNombreConvenio((String) transaccion[1]);

			referencia = ((String) transaccion[2]);
			if (referencia != null && !referencia.equals("")) {
				referencia = referencia.substring(0, referencia.length() - 1);
			}
			transaccionMapeada.setReferenciasConcatenadas(referencia);

			transaccionMapeada.setValor((BigDecimal) transaccion[3]);
			transaccionMapeada.setBancoAutorizacion((String) transaccion[4]);
			transaccionMapeada.setNumAutorizacion((String) transaccion[5]);
			transaccionMapeada.setCorreo((String) transaccion[6]);
			transaccionMapeada.setIp((String) transaccion[7]);
			transaccionMapeada.setNombre((String) transaccion[8]);

			fechaString = formatoFecha.format((Date) transaccion[9]);
			transaccionMapeada.setFechaPago(fechaString);

			transaccionMapeada.setEstado((String) transaccion[10]);
			transaccionMapeada.setTipoPago((String) transaccion[11]);

			if(transaccionMapeada.getTipoPago() != null && transaccionMapeada.getTipoPago().equals("PSE")) {
				transaccionMapeada.setCiclo((String) transaccion[12]);	
			}else {
				transaccionMapeada.setCiclo(" ");
			}

			transaccionMapeada.setObservaciones((String) transaccion[13]);
			transaccionMapeada.setConcepto((String) transaccion[14]);

			fechaString = formatoFecha.format((Date) transaccion[15]);
			transaccionMapeada.setFechaCreacionConvenio(fechaString);

			transaccionMapeada.setCuentaRecaudo((String) transaccion[16]);
			transaccionMapeada.setPseudocuenta("0000000000000000");
			transaccionMapeada.setIncocredito((String) transaccion[17]);
			transaccionMapeada.setCus((String) transaccion[5]);
			listaTransaccionesMapeadas.add(transaccionMapeada);
		}

		return listaTransaccionesMapeadas;
	}

	/**
	 * @param lst
	 * @param filter
	 * @return
	 */
	private JSONArray toTransaccionConsultaJSon(List<Transaccion> lst) {
		JSONArray jArray = new JSONArray();

		try {
			for (Transaccion tx : lst) {
				JSONObject transaccionJSON = new JSONObject();

				if (column.containsKey(Constants.ID_TRANSACCION)) {
					transaccionJSON.put("idTx", tx.getId());
				}

				if (column.containsKey(Constants.NOMBRE_CONVENIO)) {
					transaccionJSON.put("nombreConvenio", "");
					if (tx.getConvenio() != null) {
						transaccionJSON.put("nombreConvenio", tx.getConvenio().getNombre());
					}
				}

				if (column.containsKey(Constants.REFERENCIAS_TX)) {
					transaccionJSON.put("referencias", tx.getReferenciaTxs());
				}

				if (column.containsKey(Constants.VALOR_TRANSACCION)) {
					transaccionJSON.put("valor", tx.getValor());
				}

				if (column.containsKey(Constants.BANCO_AUTORIZADOR)) {
					transaccionJSON.put("bancoAutorizacion", tx.getBankName());
				}

				if (column.containsKey(Constants.NUMERO_AUTORIZACION)) {
					transaccionJSON.put("numAutorizacion", tx.getNumAuth());
				}

				if (column.containsKey(Constants.CORREO_ELECTRONICO)) {
					transaccionJSON.put("correo", tx.getEmailCliente());
				}

				if (column.containsKey(Constants.NOMBRE_CLIENTE)) {
					transaccionJSON.put("nombre", tx.getNombreCliente() + " " + tx.getApellidoCliente());
				}

				if (column.containsKey(Constants.IP_TRANSACCION)) {
					transaccionJSON.put("ip", tx.getIpCliente());
				}

				if (column.containsKey(Constants.FECHA_PAGO)) {
					transaccionJSON.put("fechaPago", tx.getFechaInicioPago() + ",000000000");
				}

				if (column.containsKey(Constants.ESTADO_TRANSACCION)) {
					transaccionJSON.put("estado", "");
					if (tx.getEstadoTx() != null) {
						transaccionJSON.put("estado", tx.getEstadoTx().getNombre());
					}
				}

				if (column.containsKey(Constants.TIPO_PAGO)) {
					transaccionJSON.put("tipoPago", Constants.SIN_MEDIO_PAGO_TXT);
					if (tx.getMedioPago() != null) {
						transaccionJSON.put("tipoPago", tx.getMedioPago().getNombre());
					}
				}

				if (column.containsKey(Constants.CICLO_PAGO)) {
					transaccionJSON.put("ciclo", tx.getCicloAch());
				}

				if (column.containsKey(Constants.OBSERVACIONES_TRANSACCION)) {
					String nombre = "";

					if (tx.getComentario() != null) {
						nombre = tx.getComentario();
					}
					transaccionJSON.put("observaciones", nombre);
				}

				if (column.containsKey(Constants.CONCEPTO_TRANSACCION)) {
					transaccionJSON.put("concepto", "");
					if (tx.getConceptoPago() != null) {
						transaccionJSON.put("concepto", tx.getConceptoPago());
					}
				}

				if (column.containsKey(Constants.INCOCREDITO_TX)) {
					transaccionJSON.put("incocredito", "");
					if (tx.getConvenio() != null && tx.getConvenio().getConvenioInfo() != null) {
						transaccionJSON.put("incocredito", tx.getConvenio().getConvenioInfo().getIncocredito());
					}
				}

				if (column.containsKey(Constants.FECHA_CONVENIO_TX)) {
					transaccionJSON.put("fechaConvenio", "");
					if (tx.getConvenio() != null) {
						transaccionJSON.put("fechaConvenio", tx.getConvenio().getFechaCreacion() + ",000000000");
					}
				}

				if (column.containsKey(Constants.CUENTA_RECAUDO_TX)) {
					transaccionJSON.put("cuentaRecaudo", "");
					if (tx.getConvenio().getConf() != null) {
						transaccionJSON.put("cuentaRecaudo", tx.getConvenio().getConf().getCuentaRecaudo());
					}
				}

				if (column.containsKey(Constants.PSEUDO_CUENTA_TX)) {
					transaccionJSON.put("pseudocuenta", "0000000000000000");
				}

				if (column.containsKey(Constants.CUS_TX)) {
					transaccionJSON.put("cus", tx.getNumAuth());
				}
				jArray.put(transaccionJSON);
			}

		} catch (JSONException jse) {
			jse.printStackTrace();
		}
		return jArray;
	}
}
