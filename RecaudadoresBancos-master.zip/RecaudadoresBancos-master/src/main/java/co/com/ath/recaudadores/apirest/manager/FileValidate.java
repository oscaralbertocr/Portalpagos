package co.com.ath.recaudadores.apirest.manager;

import java.text.SimpleDateFormat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dto.ArchivoInputDTO;
import co.com.ath.recaudadores.apirest.model.dto.ArchivoOutputDTO;
import co.com.ath.recaudadores.apirest.util.Constants;
import co.com.ath.recaudadores.apirest.util.CustomException;
import co.com.ath.recaudadores.apirest.util.StringsUtil;
/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
 */
@Service
@StepScope
public class FileValidate implements ItemProcessor<ArchivoInputDTO, ArchivoOutputDTO>, StepExecutionListener{

	private String message;

	@Autowired
	private StringsUtil str;

	static Logger logger = LoggerFactory.getLogger(FileValidate.class);
	
	private String referenciaPrincipal = null;
	
	@Override
	public ArchivoOutputDTO process(ArchivoInputDTO item) throws Exception {
		if(this.isValid(item)) {
			ArchivoOutputDTO archivoOutputDTO = new ArchivoOutputDTO();
			archivoOutputDTO.setIdenType("CC");
			archivoOutputDTO.setIdenNumber(str.deleteFilled(str.obtain(item.getReferenceOne().trim(), 16)));
			archivoOutputDTO.setDescription("CPV");
			archivoOutputDTO.setIdenBusiness(str.deleteFilled(str.obtain(item.getReferenceOne().trim(), 16)));
			archivoOutputDTO.setInvoiceNumber(str.deleteFilled(str.obtain(item.getReferenceOne().trim(), 48)));
			archivoOutputDTO.setValueOne(str.deleteFilled(str.obtain(item.getValueOne().trim(), 16, true)));
			archivoOutputDTO.setTaxOne("0");
			archivoOutputDTO.setAdditionalFieldOne(str.deleteFilled(str.obtain(item.getReferenceTwo().trim(), 50)));
			archivoOutputDTO.setAdditionalFieldTwo(str.deleteFilled(str.obtain(item.getReferenceThree().trim(), 50)));
			archivoOutputDTO.setAdditionalFieldThree(str.deleteFilled(str.obtain(item.getReferenceFour().trim(), 50)));
			archivoOutputDTO.setAdditionalFieldFour("");
			archivoOutputDTO.setAdditionalFieldFive("");
			archivoOutputDTO.setAdditionalFieldSix("");
			archivoOutputDTO.setAdditionalFieldSeven("");
			archivoOutputDTO.setAdditionalFieldEight("");
			archivoOutputDTO.setAdditionalFieldNine("");
			archivoOutputDTO.setExpirationDateOne(str.deleteFilled(str.obtain(item.getDateOne().trim(), 8)));
			archivoOutputDTO.setValueTwo(str.deleteFilled(str.obtain(item.getValueTwo().trim(), 16)).isEmpty() ? 
					archivoOutputDTO.getValueOne().trim(): str.deleteFilled(str.obtain(item.getValueTwo().trim(), 16, true)));
			archivoOutputDTO.setTaxTwo("0");
			archivoOutputDTO.setExpirationDateTwo(str.deleteFilled(str.obtain(item.getDateTwo().trim(), 8)).isEmpty() ? 
					archivoOutputDTO.getExpirationDateOne().trim() : str.deleteFilled(str.obtain(item.getDateTwo().trim(), 8)));
			archivoOutputDTO.setValueThree(str.deleteFilled(str.obtain(item.getValueThree().trim(), 16)).isEmpty() ? 
					archivoOutputDTO.getValueTwo().trim(): str.deleteFilled(str.obtain(item.getValueThree().trim(), 16, true)));
			archivoOutputDTO.setTaxThree("0");
			archivoOutputDTO.setExpirationDateThree(str.deleteFilled(str.obtain(item.getDateThree().trim(), 8)).isEmpty() ?
					archivoOutputDTO.getExpirationDateTwo().trim() : str.deleteFilled(str.obtain(item.getDateThree().trim(), 8)));
			archivoOutputDTO.setValueFour(str.deleteFilled(str.obtain(item.getValueFour().trim(), 16)).isEmpty() ? 
					archivoOutputDTO.getValueThree().trim(): str.deleteFilled(str.obtain(item.getValueFour().trim(), 16, true)));
			archivoOutputDTO.setTaxFour("0");
			archivoOutputDTO.setExpirationDateFour(str.deleteFilled(str.obtain(item.getDateFour().trim(), 8)).isEmpty() ? 
					archivoOutputDTO.getExpirationDateThree().trim() : str.deleteFilled(str.obtain(item.getDateFour().trim(), 8)));
			if(this.referenciaPrincipal == null || this.referenciaPrincipal.isEmpty()) {
				this.referenciaPrincipal = str.deleteFilled(str.obtain(item.getReferenceOne().trim(), 16));
			}
			return archivoOutputDTO;
		}else {
			throw new CustomException(this.message);
		}
	}

	private boolean isValid(ArchivoInputDTO item) {
		return  this.validateType(item.getType()) && 
				this.validateAcountNumber(item.getAcountNumber()) &&
				this.validateReferenceOne(item.getReferenceOne()) &&
				this.validateDateOne(item.getDateOne()) &&
				this.validateValueOne(item.getValueOne()) &&
				this.validateDateTwo(item.getDateTwo(),item.getDateOne()) &&
				this.validateValueTwo(item.getValueTwo()) &&
				this.validateDateThree(item.getDateThree(),item.getDateTwo()) &&
				this.validateValueThree(item.getValueThree()) &&
				this.validateDateFour(item.getDateFour(),item.getDateThree()) &&
				this.validateValueFour(item.getValueFour()) &&
				this.validateReferenceTwo(item.getReferenceTwo()) &&
				this.validateReferenceThree(item.getReferenceThree()) &&
				this.validateReferenceFour(item.getReferenceFour()) &&
				this.validateBillingCycle(item.getBillingCycle()) &&
				this.validateCycleEffectiveDate(item.getCycleEffectiveDate()) &&
				this.validateFiller(item.getFiller()); 
	}

	private boolean validateType(String type) {
		boolean ret = true;
		if(!type.equals("R")) {
			ret = false;
			this.message = Constants.AGREEMENT_TYPE_INVALID;
		}
		return ret;
	}

	private boolean validateAcountNumber(String acountNumber) {
		boolean ret = true;
		if(!this.validateOnlyNumbers(acountNumber)) {
			ret = false;
			this.message = Constants.ACOUNT_NUMBER_INVALID;
		}
		return ret;
	}

	private boolean validateReferenceOne(String referenceOne) {
		boolean ret = true;
		if(!this.validateOnlyNumbers(referenceOne)) {
			ret = false;
			this.message = Constants.REFERENCE_ONE_INVALID;
		}
		return ret;
	}

	private boolean validateDateOne(String dateOne) {
		boolean ret = true;
		if(!this.validateIsDate(dateOne)) {
			ret = false;
			this.message = Constants.DATE_ONE_INVALID;
		}
		return ret;
	}

	private boolean validateValueOne(String valueOne) {
		boolean ret = true;
		if(!this.validateOnlyNumbers(valueOne)) {
			ret = false;
			this.message = Constants.VALUE_ONE_INVALID;
		}
		return ret;
	}

	private boolean validateDateTwo(String dateTwo ,String dateOne) {
		boolean ret = true;
		if(!this.validateIsDateOptional(dateTwo, dateOne)) {
			ret = false;
			this.message = Constants.DATE_TWO_INVALID;
		}
		return ret;
	}

	private boolean validateValueTwo(String valueTwo) {
		boolean ret = true;
		if(!this.validateOnlyNumbers(valueTwo)) {
			ret = false;
			this.message = Constants.VALUE_TWO_INVALID;
		}
		return ret;
	}

	private boolean validateDateThree(String dateThree, String dateTwo) {
		boolean ret = true;
		if(!this.validateIsDateOptional(dateThree,dateTwo)) {
			ret = false;
			this.message = Constants.DATE_THREE_INVALID;
		}
		return ret;
	}

	private boolean validateValueThree(String valueThree) {
		boolean ret = true;
		if(!this.validateOnlyNumbers(valueThree)) {
			ret = false;
			this.message = Constants.VALUE_THREE_INVALID;
		}
		return ret;
	}

	private boolean validateDateFour(String dateFour, String dateThree) {
		boolean ret = true;
		if(!this.validateIsDateOptional(dateFour, dateThree)) {
			ret = false;
			this.message = Constants.DATE_FOUR_INVALID;
		}
		return ret;
	}

	private boolean validateValueFour(String valueFour) {
		boolean ret = true;
		if(!this.validateOnlyNumbers(valueFour)) {
			ret = false;
			this.message = Constants.VALUE_FOUR_INVALID;
		}
		return ret;
	}

	private boolean validateReferenceTwo(String referenceTwo) {
		boolean ret = true;
		if(!this.validateOnlyNumbers(referenceTwo)) {
			ret = false;
			this.message = Constants.REFERENCE_TWO_INVALID;
		}
		return ret;
	}

	private boolean validateReferenceThree(String referenceThree) {
		boolean ret = true;
		if(!(this.validateOnlyNumbersOrSpaces(referenceThree))) {
			ret = false;
			this.message = Constants.REFERENCE_THREE_INVALID;
		}
		return ret;
	}

	private boolean validateReferenceFour(String referenceFour) {
		boolean ret = true;
		if(!(this.validateOnlyNumbersOrSpaces(referenceFour))) {
			ret = false;
			this.message = Constants.REFERENCE_FOUR_INVALID;
		}
		return ret;
	}

	private boolean validateBillingCycle(String billingCycle) {
		boolean ret = true;
		if(!this.validateOnlyNumbers(billingCycle)) {
			ret = false;
			this.message = Constants.BILLING_CYCLE_INVALID;
		}
		return ret;
	}

	private boolean validateCycleEffectiveDate(String cycleEffectiveDate) {
		boolean ret = true;
		if(!this.validateIsDate(cycleEffectiveDate)) {
			ret = false;
			this.message = Constants.CYCLE_EFFECTIVE_DATE_INVALID;
		}
		return ret;
	}

	private boolean validateFiller(String filler) {
		boolean ret = true;
		if(!this.validateOnlySpaces(filler)) {
			ret = false;
			this.message = Constants.FILLER_INVALID;
		}
		return ret;
	}

	private boolean validateOnlyNumbers(String string) {
		boolean ret = true;
		for(char c : string.toCharArray()) {
			if(!Character.isDigit(c)) {
				ret = false;
			}
		}
		return ret;
	}
	
	private boolean validateOnlyNumbersOrSpaces(String string) {
		boolean ret = true;
		for(char c : string.toCharArray()) {
			if(!Character.isDigit(c) && !Character.isWhitespace(c)) {
				ret = false;
			}
		}
		return ret;
	}

	private boolean validateIsDate(String string) {
		boolean ret = true;
		try {
			String month = string.substring(4,6);
			String day = string.substring(6,8);
			if(!(this.validateOnlyNumbers(string)) || (Integer.parseInt(month) > 12) || (Integer.parseInt(day)>31)) {
				ret = false;
			}
		}catch(Exception e) {
			ret = false;
		}
		return ret;
	}
	
	private boolean validateIsDateOptional(String current, String compare) {
		boolean ret = true;
		try {
			if(!(this.validateOnlyZero(current))) {
				String month = current.substring(4,6);
				String day = current.substring(6,8);
				if(!(this.validateOnlyNumbers(current)) || (Integer.parseInt(month) > 12) || (Integer.parseInt(day)>31) 
						|| (new SimpleDateFormat("yyyyMMdd").parse(current).compareTo(new SimpleDateFormat("yyyyMMdd").parse(compare)) < 1)) {
					ret = false;
				}
			}
		}catch(Exception e) {
			ret = false;
		}
		return ret;
	}

	private boolean validateOnlySpaces(String string) {
		boolean ret = true;
		for(char c : string.toCharArray()) {
			if(!Character.isWhitespace(c)) {
				ret = false;
			}
		}
		return ret;
	}
	
	private boolean validateOnlyZero(String string) {
		boolean ret = true;
		for(char c : string.toCharArray()) {
			if(c != '0') {
				ret = false;
			}
		}
		return ret;
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		this.referenciaPrincipal = null;
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		JobExecution jobExecution = stepExecution.getJobExecution();
		ExecutionContext executionContext = jobExecution.getExecutionContext();
		executionContext.put("referenciaPrincipal", this.referenciaPrincipal);
		return null;
	}

}
