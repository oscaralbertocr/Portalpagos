package co.com.ath.recaudadores.apirest.model.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
public class ArchivoFacturacionDTO implements Serializable{

	private static final long serialVersionUID = 1L;

	private Long id;
	
	private String convenioID;
	
	private String nombreOriginal;
	
	private String nombreATH;
	
	private Date fechaCarga;
	
	private String tamano;
	
	private String usuario;
	
	private String envioPaycentral;
	
	private String estadoPaycentral;
	
	private String accion;
	
	private String comentarios;
	
	private String ciclo;
	
	private String correoUsuario;
	
	private String nombreUsuario;
	
	private String hash;
	
	private int emailNotificacionEnviado;
	
	private String referenciaPrincipal;
	
	private int intentosConsulta;

	private Date fechaActualizacion;
	
	private Date fechaNotificacionEmail;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getConvenioID() {
		return convenioID;
	}
	public void setConvenioID(String convenioID) {
		this.convenioID = convenioID;
	}
	public String getNombreOriginal() {
		return nombreOriginal;
	}
	public void setNombreOriginal(String nombreOriginal) {
		this.nombreOriginal = nombreOriginal;
	}
	public String getNombreATH() {
		return nombreATH;
	}
	public void setNombreATH(String nombreATH) {
		this.nombreATH = nombreATH;
	}
	public Date getFechaCarga() {
		return fechaCarga;
	}
	public void setFechaCarga(Date fechaCarga) {
		this.fechaCarga = fechaCarga;
	}
	public String getTamano() {
		return tamano;
	}
	public void setTamano(String tamano) {
		this.tamano = tamano;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getEnvioPaycentral() {
		return envioPaycentral;
	}
	public void setEnvioPaycentral(String envioPaycentral) {
		this.envioPaycentral = envioPaycentral;
	}
	public String getEstadoPaycentral() {
		return estadoPaycentral;
	}
	public void setEstadoPaycentral(String estadoPaycentral) {
		this.estadoPaycentral = estadoPaycentral;
	}
	public String getAccion() {
		return accion;
	}
	public void setAccion(String accion) {
		this.accion = accion;
	}
	public String getComentarios() {
		return comentarios;
	}
	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}
	public String getCiclo() {
		return ciclo;
	}
	public void setCiclo(String ciclo) {
		this.ciclo = ciclo;
	}
	public String getCorreoUsuario() {
		return correoUsuario;
	}
	public void setCorreoUsuario(String correoUsuario) {
		this.correoUsuario = correoUsuario;
	}
	public String getNombreUsuario() {
		return nombreUsuario;
	}
	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}
	public String getHash() {
		return hash;
	}
	public void setHash(String hash) {
		this.hash = hash;
	}
	public int getEmailNotificacionEnviado() {
		return emailNotificacionEnviado;
	}
	public void setEmailNotificacionEnviado(int emailNotificacionEnviado) {
		this.emailNotificacionEnviado = emailNotificacionEnviado;
	}
	public String getReferenciaPrincipal() {
		return referenciaPrincipal;
	}
	public void setReferenciaPrincipal(String referenciaPrincipal) {
		this.referenciaPrincipal = referenciaPrincipal;
	}
	public int getIntentosConsulta() {
		return intentosConsulta;
	}
	public void setIntentosConsulta(int intentosConsulta) {
		this.intentosConsulta = intentosConsulta;
	}
	public Date getFechaActualizacion() {
		return fechaActualizacion;
	}
	public void setFechaActualizacion(Date fechaActualizacion) {
		this.fechaActualizacion = fechaActualizacion;
	}
	public Date getFechaNotificacionEmail() {
		return fechaNotificacionEmail;
	}
	public void setFechaNotificacionEmail(Date fechaNotificacionEmail) {
		this.fechaNotificacionEmail = fechaNotificacionEmail;
	}
	
}
