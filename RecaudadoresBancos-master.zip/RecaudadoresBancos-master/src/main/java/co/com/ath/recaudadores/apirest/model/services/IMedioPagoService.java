package co.com.ath.recaudadores.apirest.model.services;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.dto.MedioPagoDTO;

/*
 * Clase : IMedioPagoService
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Transactional(value = "prvTransactionManager")
public interface IMedioPagoService {
	public List<MedioPagoDTO> findAll();
}
