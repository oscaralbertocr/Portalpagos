package co.com.ath.recaudadores.apirest.model.dto;

import java.math.BigDecimal;
import java.util.List;

public class TransaccionConsultaDTO {

	private String idTx;
	
	private String nombreConvenio;
	
	private List<ReferenciaTxDTO> referencias;
	
	private BigDecimal valor;
	
	private String bancoAutorizacion;
	
	private String numAutorizacion;
	
	private String correo;
	
	private String nombre;
	
	private String ip;
	
	private String fechaPago;
	
	private String estado;
	
	private String tipoPago;
	
	private String ciclo;
	
	private String observaciones;
	
	private String concepto;
	
	private String incocredito;
	
	private String referenciasConcatenadas;
	
	private String fechaCreacionConvenio;
	
	private String cuentaRecaudo;
	
	private String pseudocuenta;
	
	private String cus;

	public String getIdTx() {
		return idTx;
	}

	public void setIdTx(String idTx) {
		this.idTx = idTx;
	}

	public String getNombreConvenio() {
		return nombreConvenio;
	}

	public void setNombreConvenio(String nombreConvenio) {
		this.nombreConvenio = nombreConvenio;
	}

	public List<ReferenciaTxDTO> getReferencias() {
		return referencias;
	}

	public void setReferencias(List<ReferenciaTxDTO> referencias) {
		this.referencias = referencias;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public String getBancoAutorizacion() {
		return bancoAutorizacion;
	}

	public void setBancoAutorizacion(String bancoAutorizacion) {
		this.bancoAutorizacion = bancoAutorizacion;
	}

	public String getNumAutorizacion() {
		return numAutorizacion;
	}

	public void setNumAutorizacion(String numAutorizacion) {
		this.numAutorizacion = numAutorizacion;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getFechaPago() {
		return fechaPago;
	}

	public void setFechaPago(String fechaPago) {
		this.fechaPago = fechaPago;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getTipoPago() {
		return tipoPago;
	}

	public void setTipoPago(String tipoPago) {
		this.tipoPago = tipoPago;
	}

	public String getCiclo() {
		return ciclo;
	}

	public void setCiclo(String ciclo) {
		this.ciclo = ciclo;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getIncocredito() {
		return incocredito;
	}

	public void setIncocredito(String incocredito) {
		this.incocredito = incocredito;
	}

	public String getReferenciasConcatenadas() {
		return referenciasConcatenadas;
	}

	public void setReferenciasConcatenadas(String referenciasConcatenadas) {
		this.referenciasConcatenadas = referenciasConcatenadas;
	}

	public String getCuentaRecaudo() {
		return cuentaRecaudo;
	}

	public String getPseudocuenta() {
		return pseudocuenta;
	}

	public String getCus() {
		return cus;
	}

	public void setCuentaRecaudo(String cuentaRecaudo) {
		this.cuentaRecaudo = cuentaRecaudo;
	}

	public void setPseudocuenta(String pseudocuenta) {
		this.pseudocuenta = pseudocuenta;
	}

	public void setCus(String cus) {
		this.cus = cus;
	}

	public String getFechaCreacionConvenio() {
		return fechaCreacionConvenio;
	}

	public void setFechaCreacionConvenio(String fechaCreacionConvenio) {
		this.fechaCreacionConvenio = fechaCreacionConvenio;
	}
}
