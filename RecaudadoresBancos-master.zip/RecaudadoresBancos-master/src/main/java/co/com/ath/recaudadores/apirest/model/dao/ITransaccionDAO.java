package co.com.ath.recaudadores.apirest.model.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.entities.Transaccion;

/**
 * Class for TransaccionDAO
 * @author javier.florez
 * 22-Oct-2020
 */
@Repository
@Transactional(value = "prvTransactionManager", readOnly = true)
public interface ITransaccionDAO extends CrudRepository<Transaccion, Long> {
	
	@Query(value = "select * from ext_transaccion tx \r\n" + 
			"			left join medio_pago mp on (mp.mp_id = tx.ext_medio_pago_mp_id ) \r\n" + 
			"			left join ext_convenios cn on (cn.cnv_id = tx.ext_convenios_cnv_id) \r\n" + 
			"			left join referencia_tx rf on (rf.tx_id = tx.tx_id) \r\n" + 
			"			left join ext_convenios_others info ON info.cnv_id = cn.cnv_id \r\n" + 
			"			where (tx_fec_inicio_pago between to_timestamp(?1, 'yyyy-mm-dd') \r\n" + 
			"			and to_timestamp(?2, 'yyyy-mm-dd')) and (tx.ext_medio_pago_mp_id = ?3 or ?3=99 \r\n" + 
			"           or ?3=0 or (?3=98 and tx.ext_medio_pago_mp_id is null )) \r\n" + 
			"			and (( tx.ext_estado_tx_est_id = ?4 or ?4 = 99 or ?4 = 0) \r\n" + 
			"           and tx.ext_estado_tx_est_id != 7 ) and (cn.cnv_id=?5 or ?5 is null) \r\n" + 
			"			and (rf.referencia = ?6 or ?6 is null) and (tx.tx_valor = ?7 or ?7 = 0) \r\n" + 
			"			and (tx.tx_id = ?8 or ?8 = 0) and (tx.tx_aprobacion_id = ?9 or ?9 is null)",nativeQuery = true)
	public List<Transaccion> getTxByFilters(String fechaInicio, String fechaFin, Long medioPago, long estadoTx, 
			String nombreConvenio, String numRef, double valorPago, long idTx, String cus);
	
	@Query(value = "SELECT\r\n" + 
	"             DISTINCT T.TX_PAGO_ID\r\n" + 
	"            ,C.CNV_NOMBRE\r\n" + 
	"            ,(select LISTAGG(REFERENCIA || '-')\r\n" + 
	"              WITHIN GROUP (ORDER BY POSICION) from REFERENCIA_TX tx where tx.TX_ID = T.TX_ID ) as referencias\r\n" + 
	"            ,T.TX_VALOR\r\n" + 
	"            ,T.TX_BANK_NAME\r\n" + 
	"            ,T.TX_NUM_AUTH\r\n" + 
	"            ,T.TX_EMAIL_CLIENTE\r\n" + 
	"            ,T.TX_IP_CLIENTE\r\n" + 
	"            ,T.TX_NOMBRE_CLIENTE\r\n" + 
	"            ,T.TX_FEC_INICIO_PAGO\r\n" + 
	"            ,E.EST_NOMBRE \r\n" + 
	"            ,MP.MP_MEDIO_PAGO\r\n" + 
	"            ,T.CICLO_ACH\r\n" + 
	"            ,T.TX_COMENTARIO\r\n" + 
	"            ,T.CONCEPTO_PAGO\r\n" + 
	"			 ,C.CNV_FEC_CREACION\r\n" +			
	"			 ,CC.CNV_NUMERO_CUENTA_RECAUDO\r\n" +
	"			 ,CO.INCOCREDITO\r\n"+
	"            FROM EXT_TRANSACCION T\r\n" + 
	"            	LEFT JOIN EXT_CONVENIOS C ON T.EXT_CONVENIOS_CNV_ID = C.CNV_ID\r\n" + 
	"           	LEFT JOIN EXT_ESTADO_TX E ON E.EST_ID = T.EXT_ESTADO_TX_EST_ID\r\n" + 
	"            	LEFT JOIN MEDIO_PAGO MP ON MP.MP_ID = T.EXT_MEDIO_PAGO_MP_ID\r\n" +
	"				LEFT JOIN REFERENCIA_TX RF ON RF.TX_ID = T.TX_ID\r\n" +
	" 				LEFT JOIN EXT_CONVENIOS_OTHERS CO ON C.CNV_ID = CO.CNV_ID\r\n" +
	"				LEFT JOIN EXT_CONVENIO_CONF CC ON CC.CNV_ID = C.CNV_ID\r\n" +	
	"            WHERE T.TX_FEC_INICIO_PAGO BETWEEN  TO_DATE(CONCAT(?1, '00:00:00') ,'YYYY-MM-DD HH24:MI:SS') \r\n" + 
	"               AND TO_DATE(CONCAT(?2, '23:59:59') ,'YYYY-MM-DD HH24:MI:SS') \r\n" + 
	"            	AND (MP.MP_ID = ?3 OR ?3=99 OR ?3=0 OR (?3=98 and t.ext_medio_pago_mp_id is null ))\r\n" + 
	"            	AND (T.EXT_ESTADO_TX_EST_ID = ?4 OR ?4=99 OR ?4=0)\r\n" + 
	"           	AND (C.CNV_ID = ?5 OR ?5 IS NULL)\r\n" +
	"            	AND (RF.REFERENCIA = ?6 or ?6 IS NULL)" +
	" 				AND (T.TX_VALOR = ?7 OR ?7=0)" +
	"				AND (T.TX_PAGO_ID = ?8 OR ?8=0)" +
	"				AND (T.TX_APROBACION_ID = ?9 or ?9 IS NULL)" +
	"				AND CC.CNV_BANK_ID ='00010524'", nativeQuery = true)
	public List<Object[]> getAllTxByFilters(String fechaInicio, String fechaFin, long medioPago, long estadoTx, 
			String nombreConvenio, String numRef, double valorPago, long idTx, String cus);
	
}
