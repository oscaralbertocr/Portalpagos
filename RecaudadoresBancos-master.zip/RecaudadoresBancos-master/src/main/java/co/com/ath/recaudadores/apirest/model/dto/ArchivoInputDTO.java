package co.com.ath.recaudadores.apirest.model.dto;

import java.io.Serializable;

/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
public class ArchivoInputDTO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String type;
	
	private String acountNumber;
	
	private String referenceOne;
	
	private String dateOne;
	
	private String valueOne;
	
	private String dateTwo;
	
	private String valueTwo;
	
	private String dateThree;
	
	private String valueThree;
	
	private String dateFour;
	
	private String valueFour;
	
	private String referenceTwo;
	
	private String referenceThree;
	
	private String referenceFour;
	
	private String billingCycle;
	
	private String cycleEffectiveDate;
	
	private String filler;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getAcountNumber() {
		return acountNumber;
	}

	public void setAcountNumber(String acountNumber) {
		this.acountNumber = acountNumber;
	}

	public String getReferenceOne() {
		return referenceOne;
	}

	public void setReferenceOne(String referenceOne) {
		this.referenceOne = referenceOne;
	}

	public String getDateOne() {
		return dateOne;
	}

	public void setDateOne(String dateOne) {
		this.dateOne = dateOne;
	}

	public String getValueOne() {
		return valueOne;
	}

	public void setValueOne(String valueOne) {
		this.valueOne = valueOne;
	}

	public String getDateTwo() {
		return dateTwo;
	}

	public void setDateTwo(String dateTwo) {
		this.dateTwo = dateTwo;
	}

	public String getValueTwo() {
		return valueTwo;
	}

	public void setValueTwo(String valueTwo) {
		this.valueTwo = valueTwo;
	}

	public String getDateThree() {
		return dateThree;
	}

	public void setDateThree(String dateThree) {
		this.dateThree = dateThree;
	}

	public String getValueThree() {
		return valueThree;
	}

	public void setValueThree(String valueThree) {
		this.valueThree = valueThree;
	}

	public String getDateFour() {
		return dateFour;
	}

	public void setDateFour(String dateFour) {
		this.dateFour = dateFour;
	}

	public String getValueFour() {
		return valueFour;
	}

	public void setValueFour(String valueFour) {
		this.valueFour = valueFour;
	}

	public String getReferenceTwo() {
		return referenceTwo;
	}

	public void setReferenceTwo(String referenceTwo) {
		this.referenceTwo = referenceTwo;
	}

	public String getReferenceThree() {
		return referenceThree;
	}

	public void setReferenceThree(String referenceThree) {
		this.referenceThree = referenceThree;
	}

	public String getReferenceFour() {
		return referenceFour;
	}

	public void setReferenceFour(String referenceFour) {
		this.referenceFour = referenceFour;
	}

	public String getBillingCycle() {
		return billingCycle;
	}

	public void setBillingCycle(String billingCycle) {
		this.billingCycle = billingCycle;
	}

	public String getCycleEffectiveDate() {
		return cycleEffectiveDate;
	}

	public void setCycleEffectiveDate(String cycleEffectiveDate) {
		this.cycleEffectiveDate = cycleEffectiveDate;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}
	
//	@Override
//	public String toString() {
//		return this.type + this.acountNumber + this.referenceOne + this.dateOne + this.valueOne + this.dateTwo 
//				+ this.valueTwo + this.dateThree + this.valueThree + this.dateFour + this.valueFour + this.referenceTwo
//				+ this.referenceThree + this.referenceFour + this.billingCycle + this.cycleEffectiveDate + this.filler;
//	}
	
	@Override
	public String toString() {
		return this.type.concat(";") + this.acountNumber.concat(";") + this.referenceOne.concat(";") + this.dateOne.concat(";") + this.valueOne.concat(";") + this.dateTwo.concat(";") 
				+ this.valueTwo.concat(";") + this.dateThree.concat(";") + this.valueThree.concat(";") + this.dateFour.concat(";") + this.valueFour.concat(";") + this.referenceTwo.concat(";")
				+ this.referenceThree.concat(";") + this.referenceFour.concat(";") + this.billingCycle.concat(";") + this.cycleEffectiveDate.concat(";") + this.filler;
	}
	
}
