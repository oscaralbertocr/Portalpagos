package co.com.ath.recaudadores.apirest.model.dto;

import java.io.Serializable;
import java.math.BigDecimal;

/*
 * Clase : ParametriasConsultaDTO
 * Date  : 24-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
public class PreferenciaConsultaDTO implements Serializable {

	private Long id;
	private String usuario;
	private String convenio;
	private Long idIdentificador;
	private Long idParametro;
	private Double estado;
	private boolean activo;
	private String nombreParametro;

	public PreferenciaConsultaDTO() {
	}

	public PreferenciaConsultaDTO(BigDecimal id, String usuario, String convenio, BigDecimal idIdentificador,
			BigDecimal idParametro, BigDecimal estado, String nombreParametro) {

		this.id = id.longValue();
		this.usuario = usuario;
		this.convenio = convenio;
		this.idIdentificador = idIdentificador.longValue();
		this.idParametro = idParametro.longValue();
		this.estado = estado.doubleValue();
		this.nombreParametro = nombreParametro;
		this.activo = false;
		if (this.estado >= 1.0D) {
			this.activo = true;
		}
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getConvenio() {
		return convenio;
	}

	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}

	public Long getIdIdentificador() {
		return idIdentificador;
	}

	public void setIdIdentificador(Long idIdentificador) {
		this.idIdentificador = idIdentificador;
	}

	public Long getIdParametro() {
		return idParametro;
	}

	public void setIdParametro(Long idParametro) {
		this.idParametro = idParametro;
	}

	public Double getEstado() {
		return estado;
	}

	public void setEstado(Double estado) {
		this.estado = estado;
	}

	public boolean isActivo() {
		return activo;
	}

	public void setActivo(boolean activo) {
		this.activo = activo;
	}

	public String getNombreParametro() {
		return nombreParametro;
	}

	public void setNombreParametro(String nombreParametro) {
		this.nombreParametro = nombreParametro;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
