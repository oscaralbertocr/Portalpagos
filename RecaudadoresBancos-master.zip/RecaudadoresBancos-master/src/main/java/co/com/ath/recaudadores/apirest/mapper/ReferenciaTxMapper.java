package co.com.ath.recaudadores.apirest.mapper;

import java.util.ArrayList;
import java.util.List;

import co.com.ath.recaudadores.apirest.model.dto.ReferenciaTxDTO;
import co.com.ath.recaudadores.apirest.model.entities.ReferenciaTx;

public class ReferenciaTxMapper {
	
	private ReferenciaTxMapper() {}
	
	public static List<ReferenciaTxDTO> mapListEntityToDto(List<ReferenciaTx> referencias) {
		List<ReferenciaTxDTO> referenciasDto = new ArrayList<ReferenciaTxDTO>();
		if (referencias != null && !referencias.isEmpty()) {
			for (ReferenciaTx referencia : referencias) {
				referenciasDto.add(mapEntityToDto(referencia));
			}
		}
		return referenciasDto;
	}
	
	public static ReferenciaTxDTO mapEntityToDto(ReferenciaTx referencia) {
		ReferenciaTxDTO referenciaDto = null;
		if(referencia != null) {
			referenciaDto = new ReferenciaTxDTO();
			referenciaDto.setTxId(referencia.getTxId());
			referenciaDto.setReferencia(referencia.getReferencia());
			referenciaDto.setReferenciaToken(referencia.getReferenciaToken());
			referenciaDto.setPosicion(referencia.getPosicion());
		}
		return referenciaDto;
	}

}
