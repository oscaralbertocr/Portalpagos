package co.com.ath.recaudadores.apirest.manager;

import java.io.File;

import javax.annotation.PostConstruct;

import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemWriter;
import org.springframework.batch.item.file.transform.DelimitedLineAggregator;
import org.springframework.batch.item.file.transform.FieldExtractor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dto.ArchivoOutputDTO;
/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
@Service
@StepScope
public class FileOutput extends FlatFileItemWriter<ArchivoOutputDTO>{

	@Value("#{jobParameters[pathOutput]}")
	private String pathOutput;

	@Value("#{jobParameters[fileNameOutput]}")
	private String fileNameOutput;

	@PostConstruct
	public void init() {
		Resource resource = new FileSystemResource(new File(pathOutput, this.fileNameOutput));
		this.setResource(resource);
		this.setLineAggregator(this.delimitedLineAggregator());
	}

	DelimitedLineAggregator<ArchivoOutputDTO> delimitedLineAggregator() {
		DelimitedLineAggregator<ArchivoOutputDTO> delimitedLineAggregator = new DelimitedLineAggregator<>();
		delimitedLineAggregator.setDelimiter("");
		delimitedLineAggregator.setFieldExtractor(new FieldExtractor<ArchivoOutputDTO>() {

			@Override
			public Object[] extract(ArchivoOutputDTO item) {

				return new Object[] { item.toString()};
			}
		});
		return delimitedLineAggregator;
	}

}
