package co.com.ath.recaudadores.apirest.util;

public class MensajeError {

}
