package co.com.ath.recaudadores.apirest.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.com.ath.recaudadores.apirest.model.dto.EstadoTransaccionDTO;
import co.com.ath.recaudadores.apirest.model.services.IEstadoTransaccionService;
/*
 * Clase : EstadoTransaccionController
 * Date  : 22-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */

@RestController
@RequestMapping("/rest")
public class EstadoTransaccionController {
	static Logger logger = LoggerFactory.getLogger(EstadoTransaccionController.class);

	@Autowired
	private IEstadoTransaccionService estadoTransaccionService;
	
	@Autowired
	private MessageSource mensaje;
	
	private Locale locale = LocaleContextHolder.getLocale();
	private Map<String, Object> response = new HashMap<>();
	
	
	/**
	 * @return
	 */
	@GetMapping("/transacciones/estados")
	public ResponseEntity<?> index() {	
		List<EstadoTransaccionDTO> lst;

		try {
			
			lst = estadoTransaccionService.findAll();

			if (lst.isEmpty() || lst == null) {
				response.put(mensaje.getMessage("msg.titulo", null, locale), mensaje.getMessage("msg.estado.transaccion.vacio",null, locale));
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
			}
		} catch (Exception ex) {
			response.put(mensaje.getMessage("msg.titulo", null, locale), mensaje.getMessage("msg.estado.transaccion.error", null, locale));
			
			if (ex.getMessage() != null && ex.getCause() != null) {
				response.put(mensaje.getMessage("msg.titulo.error", null, locale),
						ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			} else {
				response.put(mensaje.getMessage("msg.titulo.error", null, locale),
						mensaje.getMessage("msg.general.error", null, locale));
			}
			
			logger.error(mensaje.getMessage("msg.estado.transaccion.error", null, locale), ex.getCause());
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<List<EstadoTransaccionDTO>>(lst, HttpStatus.OK);
	}

}
