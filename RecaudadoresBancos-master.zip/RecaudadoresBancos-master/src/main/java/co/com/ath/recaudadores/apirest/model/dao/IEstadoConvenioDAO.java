package co.com.ath.recaudadores.apirest.model.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.entities.EstadoConvenio;

/*
 * Clase : IEstadoConvenioDao
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Transactional(value = "prvTransactionManager", readOnly = true)
public interface IEstadoConvenioDAO extends CrudRepository<EstadoConvenio, Long> {

}