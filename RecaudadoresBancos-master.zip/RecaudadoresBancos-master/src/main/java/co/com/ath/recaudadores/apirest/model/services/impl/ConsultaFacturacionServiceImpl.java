package co.com.ath.recaudadores.apirest.model.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import co.com.ath.recaudadores.apirest.model.dao.IConsultaFacturacionDAO;
import co.com.ath.recaudadores.apirest.model.dto.ConsultaFacturacionDTO;
import co.com.ath.recaudadores.apirest.model.entities.Facturacion;
import co.com.ath.recaudadores.apirest.model.services.IConsultaFacturacionService;
import co.com.ath.recaudadores.apirest.util.ConsultaFacturacionFiltro;

@Service
public class ConsultaFacturacionServiceImpl implements IConsultaFacturacionService {

	static Logger logger = LoggerFactory.getLogger(ConsultaFacturacionServiceImpl.class);
	
	@Autowired
	private IConsultaFacturacionDAO consultaFacturacionDAO;

	@Override
	public List<ConsultaFacturacionDTO> consultarFacturacion(ConsultaFacturacionFiltro filtro) {
		logger.info("Iniciando búsqueda de transacciones");
		List<ConsultaFacturacionDTO> consulta = new ArrayList<>();
		List<Facturacion> lst;	
		String fechaI =filtro.getFechaDesde();
		String fechaF = filtro.getFechaHasta().concat(" 23:59");
		String nura = filtro.getNuraConvenio();
		logger.info("La consulta se realizara con los siguientes parametros: "
				+ "fechaInicial:{}, fechaFinal: {}, nura: {}", fechaI, fechaF, nura);
		lst = consultaFacturacionDAO.consultaFacturacion(fechaI, fechaF, nura);

		for (Facturacion f : lst) {
			consulta.add(f.toConsultaConvenioDTO());
		}
		return consulta;
	}

}
