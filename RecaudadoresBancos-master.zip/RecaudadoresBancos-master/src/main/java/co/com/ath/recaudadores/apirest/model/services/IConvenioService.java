package co.com.ath.recaudadores.apirest.model.services;

import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.dto.ConsultaConvenioDTO;
import co.com.ath.recaudadores.apirest.model.dto.ConvenioDTO;
import co.com.ath.recaudadores.apirest.util.Filtro;

/*
 * Clase : IConvenioService
 * Date  : 16-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Transactional(value = "prvTransactionManager")
public interface IConvenioService {

	public List<ConvenioDTO> findAll(int banco);

	public List<ConsultaConvenioDTO> consultaConvenios(Filtro filtroTo, Pageable pageable);
}
