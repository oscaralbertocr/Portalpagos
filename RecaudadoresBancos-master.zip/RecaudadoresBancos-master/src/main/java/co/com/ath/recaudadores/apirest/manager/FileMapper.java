package co.com.ath.recaudadores.apirest.manager;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import co.com.ath.recaudadores.apirest.model.dto.ArchivoInputDTO;
/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
public class FileMapper implements FieldSetMapper<ArchivoInputDTO>{

	@Override
	public ArchivoInputDTO mapFieldSet(FieldSet fieldSet) throws BindException {
		ArchivoInputDTO aid = new ArchivoInputDTO();
		aid.setType(fieldSet.readRawString("type"));
		aid.setAcountNumber(fieldSet.readRawString("acountNumber"));
		aid.setReferenceOne(fieldSet.readRawString("referenceOne"));
		aid.setDateOne(fieldSet.readRawString("dateOne"));
		aid.setValueOne(fieldSet.readRawString("valueOne"));
		aid.setDateTwo(fieldSet.readRawString("dateTwo"));
		aid.setValueTwo(fieldSet.readRawString("valueTwo"));
		aid.setDateThree(fieldSet.readRawString("dateThree"));
		aid.setValueThree(fieldSet.readRawString("valueThree"));
		aid.setDateFour(fieldSet.readRawString("dateFour"));
		aid.setValueFour(fieldSet.readRawString("valueFour"));
		aid.setReferenceTwo(fieldSet.readRawString("referenceTwo"));
		aid.setReferenceThree(fieldSet.readRawString("referenceThree"));
		aid.setReferenceFour(fieldSet.readRawString("referenceFour"));
		aid.setBillingCycle(fieldSet.readRawString("billingCycle"));
		aid.setCycleEffectiveDate(fieldSet.readRawString("cycleEffectiveDate"));
		aid.setFiller(fieldSet.readRawString("filler"));
		return aid;
	}

	
}
