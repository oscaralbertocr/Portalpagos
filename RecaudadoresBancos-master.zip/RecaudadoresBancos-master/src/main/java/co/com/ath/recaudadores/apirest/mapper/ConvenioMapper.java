package co.com.ath.recaudadores.apirest.mapper;

import java.util.ArrayList;
import java.util.List;

import co.com.ath.recaudadores.apirest.model.dto.ConvenioDTO;
import co.com.ath.recaudadores.apirest.model.entities.Convenio;

public class ConvenioMapper {

	private ConvenioMapper() {}
	
	public static List<ConvenioDTO> mapListEntityToDto(List<Convenio> convenios) {
		List<ConvenioDTO> convenioDto = new ArrayList<ConvenioDTO>();
		if (convenios != null && !convenios.isEmpty()) {
			for (Convenio convenio : convenios) {
				convenioDto.add(mapEntityToDto(convenio));
			}
		}
		return convenioDto;
	}
	
	public static ConvenioDTO mapEntityToDto(Convenio convenio) {
		ConvenioDTO convenioDto = null;
		if(convenio != null) {
			convenioDto = new ConvenioDTO();
			convenioDto.setId(convenio.getId());
			convenioDto.setNombre(convenio.getNombre());
		}
		return convenioDto;
	}
}
