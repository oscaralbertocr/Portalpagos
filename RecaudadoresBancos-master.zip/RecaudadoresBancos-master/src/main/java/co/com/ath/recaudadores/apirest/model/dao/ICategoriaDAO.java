package co.com.ath.recaudadores.apirest.model.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.entities.Categoria;

/*
 * Clase : ICategoriaDao
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Transactional(value = "prvTransactionManager", readOnly = true)
public interface ICategoriaDAO extends CrudRepository<Categoria, Long> {

}
