package co.com.ath.recaudadores.apirest.model.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dao.ICategoriaDAO;
import co.com.ath.recaudadores.apirest.model.dto.CategoriaDTO;
import co.com.ath.recaudadores.apirest.model.entities.Categoria;
import co.com.ath.recaudadores.apirest.model.services.ICategoriaService;
import co.com.ath.recaudadores.apirest.util.Constants;

/*
 * Clase : CategoriaServiceImpl
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Service
public class CategoriaServiceImpl implements ICategoriaService {
	static Logger logger = LoggerFactory.getLogger(CategoriaServiceImpl.class);

	@Autowired
	private ICategoriaDAO categoriaDao;

	@Override
	public List<CategoriaDTO> findAll() {
		List<Categoria> lst = (List<Categoria>) categoriaDao.findAll();
		List<CategoriaDTO> listaCategorias = new ArrayList<>();
		if (lst != null && lst.size() > 0) {
			for (Categoria c : lst) {
				listaCategorias.add(c.toCategoriaTO());
			}
			CategoriaDTO cat = new CategoriaDTO();
			cat.setId(Constants.TODOS_ID);
			cat.setNombre(Constants.CATEGORIA_TODOS_TXT);
			listaCategorias.add(cat);
		}
		return listaCategorias;
	}

}
