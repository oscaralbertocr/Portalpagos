package co.com.ath.recaudadores.apirest.model.services;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.dto.ArchivoFacturacionDTO;
import co.com.ath.recaudadores.apirest.model.entities.ArchivoFacturacion;
/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
@Transactional(value = "prvTransactionManager")
public interface IArchivoFacturacionService {
	
 public List<ArchivoFacturacionDTO> findByName(String name);

 public boolean guardar(ArchivoFacturacion archivoFacturacion);
 
}
