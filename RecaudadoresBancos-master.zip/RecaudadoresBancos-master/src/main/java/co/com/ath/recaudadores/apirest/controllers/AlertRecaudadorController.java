package co.com.ath.recaudadores.apirest.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import co.com.ath.recaudadores.apirest.model.dto.AlertRecaudadorDTO;
import co.com.ath.recaudadores.apirest.model.services.IAlertRecaudadorService;
import co.com.ath.recaudadores.apirest.util.Constants;

/*
 * Clase : AlertRecaudadorController
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@RestController
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT })
@RequestMapping("/rest")
public class AlertRecaudadorController {
	static Logger logger = LoggerFactory.getLogger(AlertRecaudadorController.class);

	@Autowired
	private IAlertRecaudadorService alertRecaudadorService;

	private Map<String, Object> response = new HashMap<>();

	/**
	 * @param id
	 * @return
	 */
	@GetMapping("/mensaje")
	public ResponseEntity<?> findAll() {

		List<AlertRecaudadorDTO> lst = new ArrayList<>();
		response = new HashMap<>();

		try {
			lst = alertRecaudadorService.findAll();
			if (lst == null || lst.isEmpty()) {
				response.put(Constants.MSG_ALERT_TXT, Constants.INF_ALERT_01);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}

		} catch (DataAccessException ex) {
			response.put(Constants.MSG_ALERT_TXT, Constants.ERR_ALERT_01);
			response.put(Constants.ERR_ALERT_TXT, ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			logger.error(Constants.ERR_ALERT_TXT + " =>",
					ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			ex.printStackTrace();
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<List<AlertRecaudadorDTO>>(lst, HttpStatus.OK);
	}

	/**
	 * @param id
	 * @return
	 */
	@GetMapping("/mensaje/{id}")
	public ResponseEntity<?> show(@PathVariable String id) {
		AlertRecaudadorDTO alertRecaudadorDTO = new AlertRecaudadorDTO();
		response = new HashMap<>();

		try {
			alertRecaudadorDTO = alertRecaudadorService.find(id);
			if (alertRecaudadorDTO == null) {
				response.put(Constants.MSG_ALERT_TXT, Constants.INF_ALERT_01);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}

		} catch (DataAccessException ex) {
			response.put(Constants.MSG_ALERT_TXT, Constants.ERR_ALERT_01);
			response.put(Constants.ERR_ALERT_TXT, ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			logger.error(Constants.ERR_ALERT_TXT + " =>",
					ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			ex.printStackTrace();
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<AlertRecaudadorDTO>(alertRecaudadorDTO, HttpStatus.OK);
	}

	/**
	 * @param alertRecaudadorDTO
	 * @return
	 */
	@PostMapping("/mensaje")
	public ResponseEntity<?> create(@RequestBody AlertRecaudadorDTO alertRecaudadorDTO) {
		response = new HashMap<>();

		try {

			if (alertRecaudadorDTO == null) {
				response.put(Constants.MSG_ALERT_TXT, Constants.INF_ALERT_07);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}

			if ((alertRecaudadorDTO.getId() == null || alertRecaudadorDTO.getId().isEmpty())
					|| (alertRecaudadorDTO.getMensaje() == null || alertRecaudadorDTO.getMensaje().isEmpty())
					|| (alertRecaudadorDTO.getTipo() == null || alertRecaudadorDTO.getTipo().isEmpty())) {
				response.put(Constants.MSG_ALERT_TXT, Constants.INF_ALERT_06);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}

			alertRecaudadorDTO = alertRecaudadorService.save(alertRecaudadorDTO);
			if (alertRecaudadorDTO == null) {
				response.put(Constants.MSG_ALERT_TXT, Constants.INF_ALERT_02);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}
		} catch (DataAccessException ex) {
			response.put(Constants.MSG_ALERT_TXT, Constants.ERR_ALERT_01);
			response.put(Constants.ERR_ALERT_TXT, ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			logger.error(Constants.ERR_ALERT_TXT + " =>",
					ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<AlertRecaudadorDTO>(alertRecaudadorDTO, HttpStatus.OK);
	}

	/**
	 * @param parametroDTO
	 * @param id
	 * @return
	 */
	@PutMapping("/mensaje")
	public ResponseEntity<?> update(@RequestBody AlertRecaudadorDTO alertRecaudadorDTO) {
		response = new HashMap<>();

		try {
			if (alertRecaudadorService.find(alertRecaudadorDTO.getId()) == null) {
				response.put(Constants.MSG_ALERT_TXT, Constants.INF_ALERT_03);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}

			if ((alertRecaudadorDTO.getId() == null || alertRecaudadorDTO.getId().isEmpty())
					|| (alertRecaudadorDTO.getMensaje() == null || alertRecaudadorDTO.getMensaje().isEmpty())
					|| (alertRecaudadorDTO.getTipo() == null || alertRecaudadorDTO.getTipo().isEmpty())) {
				response.put(Constants.MSG_ALERT_TXT, Constants.INF_ALERT_06);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}

			alertRecaudadorDTO = alertRecaudadorService.update(alertRecaudadorDTO);
			if (alertRecaudadorDTO == null) {
				response.put(Constants.MSG_ALERT_TXT, Constants.INF_ALERT_05);
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.ACCEPTED);
			}
		} catch (DataAccessException ex) {
			response.put(Constants.MSG_ALERT_TXT, Constants.ERR_ALERT_01);
			response.put(Constants.ERR_ALERT_TXT, ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			logger.error(Constants.ERR_ALERT_TXT + " =>",
					ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<AlertRecaudadorDTO>(alertRecaudadorDTO, HttpStatus.OK);
	}

}
