package co.com.ath.recaudadores.apirest.model.dto;

import java.io.Serializable;

public class ReferenciaTxDTO implements Serializable{

	private static final long serialVersionUID = 1L;

	private long txId;

	private String referencia;

	private long posicion;

	private String referenciaToken;

	public long getTxId() {
		return txId;
	}

	public void setTxId(long txId) {
		this.txId = txId;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public long getPosicion() {
		return posicion;
	}

	public void setPosicion(long posicion) {
		this.posicion = posicion;
	}

	public String getReferenciaToken() {
		return referenciaToken;
	}

	public void setReferenciaToken(String referenciaToken) {
		this.referenciaToken = referenciaToken;
	}
	
	
	
}
