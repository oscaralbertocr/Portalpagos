package co.com.ath.recaudadores.apirest.model.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import co.com.ath.recaudadores.apirest.model.dto.EstadoConvenioDTO;
import co.com.ath.recaudadores.apirest.util.Constants;

/*
 * Clase : EstadoConvenio
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Entity
@Table(name = "EXT_ESTADO_CONVENIOS")
public class EstadoConvenio implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "EC_ID", nullable = false)
	private Long id;

	@Column(name = "EC_ESTADO", nullable = false)
	private String nombre;

	public EstadoConvenio() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "EstadoConvenio [id=" + id + ", nombre=" + nombre + "]";
	}

	/**
	 * @return
	 */
	public EstadoConvenioDTO toEstadoConvenioTO() {
		EstadoConvenioDTO estadoConvenioTO = new EstadoConvenioDTO();
		if (this.id != Constants.ESTADO_ELIMINADO) {
			estadoConvenioTO.setId(this.id);
			estadoConvenioTO.setNombre(this.nombre);
		} else {
			estadoConvenioTO.setId(Constants.TODOS_ID);
			estadoConvenioTO.setNombre(Constants.ESTADO_TODOS_TXT);			
		}
		return estadoConvenioTO;	
	}

	private static final long serialVersionUID = 1L;
}
