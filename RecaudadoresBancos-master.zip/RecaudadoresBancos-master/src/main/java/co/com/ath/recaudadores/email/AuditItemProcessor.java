package co.com.ath.recaudadores.email;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dto.MailServiceInDTO;
import co.com.ath.recaudadores.apirest.model.entities.ArchivoFacturacion;
import co.com.ath.recaudadores.apirest.model.services.IParametroService;
import co.com.ath.recaudadores.apirest.util.Constants;
import co.com.ath.recaudadores.apirest.util.MailService;

/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
 */

@Service
public class AuditItemProcessor implements ItemProcessor<ArchivoFacturacion, ArchivoFacturacion>{

	static Logger logger = LoggerFactory.getLogger(AuditItemProcessor.class);

	@Autowired
	MailService mailService;

	@Autowired
	private IParametroService parametroService;

	@Override
	public ArchivoFacturacion process(ArchivoFacturacion item) throws Exception {
		try {
			MailServiceInDTO mail = new MailServiceInDTO();
			logger.info("Inicia el proceso del registro de la tabla Archivo_Facturacion identificado con el ID: {} ", item.getId());
			String message = parametroService.find("MailMessageSuccess").getValor();
			logger.info("Mensaje exitoso cargado");
			String messageError = parametroService.find("MailMessageErrorPYC").getValor();
			logger.info("Mensaje Error cargado");
			String subject = parametroService.find("SMTPSubject").getValor();
			logger.info("Asunto cargado");
			if(item.getCorreoUsuario()!=null) {
				mail.setTo(item.getCorreoUsuario());
				if(item.getEstadoPaycentral()!=null && item.getEstadoPaycentral().equalsIgnoreCase(Constants.aplicado)) {
					mail.setText(message.replace("#fileName", (item.getNombreATH()!=null)?item.getNombreATH():""));
				}else if(item.getEstadoPaycentral()!=null && item.getEstadoPaycentral().equalsIgnoreCase(Constants.rechazado)) {
					mail.setText(messageError.replace("#fileName", (item.getNombreATH()!=null)?item.getNombreATH():""));
				}
				mail.setSubject((subject!=null)?subject:"");
				mailService.sendMail(mail);
			}else {
				logger.info("no se encontro correo para el destinatario");
			}
			item.setFechaCarga(item.getFechaCarga());
			item.setFechaActualizacion(item.getFechaActualizacion());
			item.setFechaNotificacionEmail(new Date());
			item.setEmailNotificacionEnviado(1);
			return item;
		} catch (Exception e) {
			logger.error("Error procesando el registro identificado con el ID: {}", item.getId());
			logger.error(e.getMessage());
			return null;
		}
	}
}
