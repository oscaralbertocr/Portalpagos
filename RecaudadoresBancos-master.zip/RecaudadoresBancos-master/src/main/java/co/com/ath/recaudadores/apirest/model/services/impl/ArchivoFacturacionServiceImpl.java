package co.com.ath.recaudadores.apirest.model.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dao.IArchivoFacturacionDAO;
import co.com.ath.recaudadores.apirest.model.dto.ArchivoFacturacionDTO;
import co.com.ath.recaudadores.apirest.model.entities.ArchivoFacturacion;
import co.com.ath.recaudadores.apirest.model.services.IArchivoFacturacionService;

/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
 */ 
@Service
public class ArchivoFacturacionServiceImpl implements IArchivoFacturacionService {
	static Logger logger = LoggerFactory.getLogger(ArchivoFacturacionServiceImpl.class);

	@Autowired
	private IArchivoFacturacionDAO archivoFacturacionDAO;

	@Override
	public List<ArchivoFacturacionDTO> findByName(String name) {

		List<ArchivoFacturacionDTO> lst = new ArrayList<>();

		List<ArchivoFacturacion> lstArchFact = archivoFacturacionDAO.obtenerRegistrosPorNombreArchivo(name);
		for (ArchivoFacturacion af : lstArchFact) {
			ArchivoFacturacionDTO archivoFacturacionDTO = new ArchivoFacturacionDTO();
			archivoFacturacionDTO.setId(af.getId());
			archivoFacturacionDTO.setConvenioID(af.getConvenioID());
			archivoFacturacionDTO.setNombreOriginal(af.getNombreOriginal());
			archivoFacturacionDTO.setNombreATH(af.getNombreATH());
			archivoFacturacionDTO.setFechaCarga(af.getFechaCarga());
			archivoFacturacionDTO.setFechaActualizacion(af.getFechaActualizacion());
			archivoFacturacionDTO.setFechaNotificacionEmail(af.getFechaNotificacionEmail());
			archivoFacturacionDTO.setTamano(af.getTamano());
			archivoFacturacionDTO.setUsuario(af.getUsuario());
			archivoFacturacionDTO.setEnvioPaycentral(af.getEnvioPaycentral());
			archivoFacturacionDTO.setEstadoPaycentral(af.getEstadoPaycentral());
			archivoFacturacionDTO.setAccion(af.getAccion());
			archivoFacturacionDTO.setComentarios(af.getComentarios());
			archivoFacturacionDTO.setCiclo(af.getCiclo());
			archivoFacturacionDTO.setCorreoUsuario(af.getCorreoUsuario());
			archivoFacturacionDTO.setNombreUsuario(af.getNombreUsuario());
			archivoFacturacionDTO.setHash(af.getHash());
			archivoFacturacionDTO.setEmailNotificacionEnviado(af.getEmailNotificacionEnviado());
			archivoFacturacionDTO.setReferenciaPrincipal(af.getReferenciaPrincipal());
			archivoFacturacionDTO.setIntentosConsulta(af.getIntentosConsulta());
			lst.add(archivoFacturacionDTO);
		}
		return lst;

	}

	@Override
	public boolean guardar(ArchivoFacturacion archivoFacturacion) {
		try {
			archivoFacturacionDAO.save(archivoFacturacion);
			return true;
		}catch (Exception e) {
			logger.error(e.getMessage());
			return false;
		}
	}

}
