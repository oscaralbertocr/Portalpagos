package co.com.ath.recaudadores.apirest.util;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;

import co.com.ath.recaudadores.apirest.model.dto.PreferenciaConsultaDTO;
import co.com.ath.recaudadores.apirest.model.dto.TransaccionConsultaDTO;
/**
 * Class for create dynamic JSON Response
 * @author javier.florez
 * 30-oct-2020
 */
public class DynamicResponse {

	public static JSONArray createReponse(List<PreferenciaConsultaDTO> params, List<TransaccionConsultaDTO> data) throws Exception {
		JSONArray jsonObject = null;
		try {
			String jsonString = createJsonString(params, data);
			 jsonObject = new JSONArray(jsonString);
		} catch (JSONException e) {
			throw new Exception("Error procesando la respuesta: " + e.getMessage());
		}
		return jsonObject;
	}
	
	private static String createJsonString(List<PreferenciaConsultaDTO> params, List<TransaccionConsultaDTO> data) {
		StringBuilder response = new StringBuilder("[");
		if (data != null && !data.isEmpty()) {
			for (TransaccionConsultaDTO tx : data) {
				if (params != null && !params.isEmpty()) {
					response.append("{");
					for (PreferenciaConsultaDTO param : params) {
						if (param.isActivo()) {
							switch (param.getNombreParametro()) {
							case "ID transaccion":
								response.append(createLine("idTx", tx.getIdTx() + ""));
								break;
							case "Nombre del convenio": 
								response.append(createLine("nombreConvenio", tx.getNombreConvenio()));
								break;
							case "Referencias":
								response.append(createLine("referencias", tx.getIdTx() + ""));
								break;
							case "Valor de la transacción": 
								response.append(createLine("valor", tx.getValor() + ""));
								break;
							case "Banco Autorizador": 
								response.append(createLine("bancoAutorizacion", tx.getBancoAutorizacion()));
								break;
							case "N° Autorización": 
								response.append(createLine("numAutorizacion", tx.getNumAutorizacion()));
								break;
							case "Correo electrónico": 
								response.append(createLine("correo", tx.getCorreo()));
								break;
							case "Nombre": 
								response.append(createLine("nombre", tx.getNombre()));
								break;
							case "IP": 
								response.append(createLine("ip", tx.getIp()));
								break;
							case "Fecha de Pago": 
								response.append(createLine("fechaPago", tx.getFechaPago()));
								break;
							case "Estado de la Transacción": 
								response.append(createLine("estado", tx.getEstado()));
								break;
							case "Tipo de pago": 
								response.append(createLine("tipoPago", tx.getTipoPago()));
								break;
							case "Ciclo": 
								response.append(createLine("ciclo", tx.getCiclo()));
								break;
							case "Observaciones": 
								response.append(createLine("observaciones", tx.getObservaciones()));
								break;
							case "Concepto": 
								response.append(createLine("concepto", tx.getConcepto()));
								break;
							case "Incocredito": 
								response.append(createLine("incocredito", tx.getIncocredito()));
								break;	
							}
						}
					}
					response.append("},");
				}
			}
		}
		response.append("]");
		return response.toString().replace(",]", "]").replace(",}", "}");
	}
	
	private static String createLine(String key, String value) {
		String line = "";
		line = "\"" + key + "\":" + "\"" + value + "\",";
		return line;
	}

}
