package co.com.ath.recaudadores.apirest.model.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.entities.MedioPago;

/*
 * Clase : IMedioPagoDTO
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Transactional(value = "prvTransactionManager", readOnly = true)
public interface IMedioPagoDAO extends CrudRepository<MedioPago, Long> {

}
