package co.com.ath.recaudadores.checkstatus;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBElement;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.s2.AgrPmtReferencesType;
import com.s2.Agreement;
import com.s2.BankInfoType;
import com.s2.CustIdType;
import com.s2.InvoiceInfoType;
import com.s2.InvoicePmtType;
import com.s2.InvoiceSender;
import com.s2.OrgId;
import com.s2.PSPInvoicesInqInp;
import com.s2.PSPInvoicesInqOut;
import com.s2.PSPInvoicesInqRq;
import com.s2.SessionType;
import com.s2.TotalCurAmt;

import co.com.ath.mp.wsclient.service.IWSServiceGatewayPaymentInvoice;
import co.com.ath.mp.wsclient.service.WSServiceGatewayPaymentInvoice;
import co.com.ath.recaudadores.apirest.model.entities.ArchivoFacturacion;
import co.com.ath.recaudadores.apirest.util.Constants;

/**
*
* @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
* @version 1.0 12/05/2021
* 
* @sophosSolutions
* <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
* <strong>Numero de Cambios: </strong>0</br>
* 	
*/ 

@Service
@StepScope
public class CheckStatusItemProcessor implements ItemProcessor<ArchivoFacturacion, ArchivoFacturacion>{

	static Logger logger = LoggerFactory.getLogger(CheckStatusItemProcessor.class);

	private IWSServiceGatewayPaymentInvoice wsclientInvoice;

	private int rquid;

	@Value("#{jobParameters[gatewayPaymentInvoiceEndPoint]}")
	private String gatewayPaymentInvoiceEndPoint;

	@Value("#{jobParameters[gatewayPaymentInvoiceConnectionTimeout]}")
	private String gatewayPaymentInvoiceConnectionTimeout;

	@Value("#{jobParameters[gatewayPaymentInvoiceRequestTimeout]}")
	private String gatewayPaymentInvoiceRequestTimeout;

	@Value("#{jobParameters[attempsCheck]}")
	private String attempsCheck;
	
	private final String nameSpace = "http://www.s2.com";
	
	@PostConstruct
	public void init() {
		try {
			SecureRandom number = SecureRandom.getInstance("SHA1PRNG");
			this.rquid = number.nextInt(32750);
			this.wsclientInvoice = WSServiceGatewayPaymentInvoice.getInstance(
					this.gatewayPaymentInvoiceEndPoint,
					Integer.parseInt(this.gatewayPaymentInvoiceConnectionTimeout),
					Integer.parseInt(this.gatewayPaymentInvoiceRequestTimeout));
		} catch (Exception e) {
			logger.error(e.getMessage());
		} 
	}

	@Override
	public ArchivoFacturacion process(ArchivoFacturacion item) throws Exception {
		logger.info("Id del registro en la tabla Archivo Facturacion es: {}", item.getId());
		logger.info("Se realiza la consulta en BillPay de la Referencia Principal: {}, intento. {}", item.getReferenciaPrincipal(), item.getIntentosConsulta());
		if(item.getIntentosConsulta() < this.obtainAttemps()){
			PSPInvoicesInqInp pspInvoicePurchasesRequest = this.mappingRequestGetPSPInvoicePurchases(item);
			try {
				PSPInvoicesInqOut pspInvoicePurchasesResponse = this.wsclientInvoice.getPSPInvoicePurchases(pspInvoicePurchasesRequest, String.valueOf(this.rquid), null);
				if (pspInvoicePurchasesResponse != null && pspInvoicePurchasesResponse.getStatus() != null 
						&& (pspInvoicePurchasesResponse.getStatus().getStatusCode() == 0 && pspInvoicePurchasesResponse.getStatus().getServerStatusCode().equalsIgnoreCase("0"))) {
					logger.info("Respuesta Correcta de parte de servicio PSPInvoicePurchases. "
							+ "Se cambia el estado a Aplicado.");
					item.setEstadoPaycentral(Constants.aplicado);
				}else {
					logger.info("No se obtiene respuesta Correcta de parte de servicio PSPInvoicePurchases, Quedan mas intentos "
							+ "por lo que no se cambia el estado y se consultara en la proxima activacion.");
				}
			} catch (Exception e) {
				logger.info("Error de conexion con el servicio, revisar conexion. Quedan mas intentos "
						+ "por lo que no se cambia el estado y se consultara en la proxima activacion.");
			}
			item.setIntentosConsulta(item.getIntentosConsulta()+1);
		}else {
			logger.info("No se obtiene respuesta Correcta de parte de servicio PSPInvoicePurchases, no quedan mas intentos por "
					+ "lo que se cambia el estado a Rechazado.");
			item.setEstadoPaycentral(Constants.rechazado);
		}
		item.setFechaCarga(item.getFechaCarga());
		item.setFechaActualizacion(new Date());
		item.setFechaNotificacionEmail(null);
		return item;
	}

	private PSPInvoicesInqInp mappingRequestGetPSPInvoicePurchases(ArchivoFacturacion item) {
		PSPInvoicesInqInp request = new PSPInvoicesInqInp();
		request.setPSPInvoicesInqRq(this.mappingPSPInvoicesInqRq(item));
		request.setSession(this.mappingSessionType());
		return request;
	}

	private PSPInvoicesInqRq mappingPSPInvoicesInqRq(ArchivoFacturacion item) {
		PSPInvoicesInqRq pspInvoicesInqRq = new PSPInvoicesInqRq();
		BankInfoType bankInfoType = new BankInfoType();
		pspInvoicesInqRq.setChannel(Constants.CHANNEL_INVOICES_INQ_RQ);
		pspInvoicesInqRq.setCode(Constants.CODE_INVOICES_INQ_RQ);
		pspInvoicesInqRq.setCustId(this.mappingCustIdType());
		bankInfoType.setBankId(Constants.BANKID_INVOICES_INQ_RQ);
		pspInvoicesInqRq.setBankInfo(bankInfoType);
		pspInvoicesInqRq.getInvoiceInfo().add(this.mappingInvoiceInfo(item));
		pspInvoicesInqRq.setAgrPmtReferences(this.mappingAgrPmtReferences());
		pspInvoicesInqRq.setInvoicePmtType(this.mappingInvoicePmtType());
		return pspInvoicesInqRq;
	}

	private SessionType mappingSessionType() {
		SessionType sessionType = new SessionType();
		sessionType.setCustId(this.mappingCustIdType());
		sessionType.setCurDt(this.getDate());
		sessionType.setRqUID(this.rquid);
		return sessionType;
	}

	private CustIdType mappingCustIdType() {
		CustIdType custIdType = new CustIdType();
		QName custIdTypeN = new QName(this.nameSpace, "CustIdType");
		JAXBElement<String> custIdTypeValue = new JAXBElement<>(custIdTypeN, String.class, "GUEST");
		QName custIdNumN = new QName(this.nameSpace, "CustIdNum");
		JAXBElement<String> custIdNumValue = new JAXBElement<>(custIdNumN,String.class, "0");
		custIdType.getContent().add(custIdTypeValue);
		custIdType.getContent().add(custIdNumValue);
		return custIdType;
	}

	private InvoiceInfoType mappingInvoiceInfo(ArchivoFacturacion item) {
		InvoiceInfoType invoiceInfoType = new InvoiceInfoType();
		invoiceInfoType.setInvoiceNum(item.getReferenciaPrincipal());
		invoiceInfoType.setNIE(item.getReferenciaPrincipal());
		invoiceInfoType.setInvoiceSender(this.mappingInvoiceSender(item));
		invoiceInfoType.setTotalCurAmt(this.mappingTotalCurAmt());
		return invoiceInfoType;
	}
	
	private AgrPmtReferencesType mappingAgrPmtReferences() {
		final String nameType = "Reference";
		AgrPmtReferencesType agrPmtReferencesType = new AgrPmtReferencesType();
		JAXBElement<String> referenceOneValue = new JAXBElement<>(new QName(this.nameSpace, nameType), String.class, "");
		JAXBElement<String> referenceTwoValue = new JAXBElement<>(new QName(this.nameSpace, nameType), String.class, "");
		JAXBElement<String> referenceThrValue = new JAXBElement<>(new QName(this.nameSpace, nameType), String.class, "");
		agrPmtReferencesType.getContent().add(referenceOneValue);
		agrPmtReferencesType.getContent().add(referenceTwoValue);
		agrPmtReferencesType.getContent().add(referenceThrValue);
		return agrPmtReferencesType;
	}
	
	private InvoicePmtType mappingInvoicePmtType() {
		InvoicePmtType invoicePmtType = new InvoicePmtType();
		invoicePmtType.setCategory(null);
		invoicePmtType.setPmtType("2");
		return invoicePmtType;
	}

	private InvoiceSender mappingInvoiceSender(ArchivoFacturacion item) {
		InvoiceSender invoiceSender = new InvoiceSender();
		OrgId orgId = new OrgId();
		Agreement agreement = new Agreement();
		BankInfoType bankInfo = new BankInfoType();
		orgId.setOrgIdNum(item.getConvenioID());
		agreement.setAgrmId(item.getConvenioID());
		bankInfo.setBankId(null);
		invoiceSender.setOrgId(orgId);
		invoiceSender.setAgreement(agreement);
		invoiceSender.setBankInfo(bankInfo);
		return invoiceSender;
	}
	
	private TotalCurAmt mappingTotalCurAmt() {
		TotalCurAmt totalCurAmt = new TotalCurAmt();
		totalCurAmt.setAmt(new BigDecimal(0));
		totalCurAmt.setCurCode("COP");
		return totalCurAmt;
	}
	
	private int obtainAttemps() {
		int valueDefault= 3;
		try {
			return Integer.parseInt(this.attempsCheck);
		}catch(Exception e) {
			return valueDefault;
		}
	}
	
	private XMLGregorianCalendar getDate() {
		try {
			GregorianCalendar gcal = new GregorianCalendar();
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
		} catch (DatatypeConfigurationException e) {
			logger.error(e.getMessage());
		}
		return null;
	}
}
