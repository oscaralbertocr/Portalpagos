package co.com.ath.recaudadores.apirest.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.com.ath.recaudadores.apirest.model.dto.EstadoConvenioDTO;
import co.com.ath.recaudadores.apirest.model.services.IEstadoConvenioService;

/*
 * Clase : EstadoConvenioRestController
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */

@RestController
@RequestMapping("/rest")
public class EstadoConvenioRestController {
	static Logger logger = LoggerFactory.getLogger(EstadoConvenioRestController.class);
	
	@Autowired
	private IEstadoConvenioService estadoConvenioService;
	
	@Autowired
	private MessageSource mensaje;
	
	private Locale locale = LocaleContextHolder.getLocale();
	private Map<String, Object> response = new HashMap<>();
	
	/**
	 * @return
	 */
	@GetMapping("/convenios/estados")
	public ResponseEntity<?> index() {
		List<EstadoConvenioDTO> lst;

		try {
			lst = estadoConvenioService.findAll();
			if (lst.isEmpty() || lst == null) {
				response.put(mensaje.getMessage("msg.titulo", null, locale), mensaje.getMessage("msg.estado.vacio",null, locale));
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
			}
		} catch(Exception ex) {
			response.put(mensaje.getMessage("msg.titulo", null, locale), mensaje.getMessage("msg.estado.error", null, locale));
			
			if (ex.getMessage() != null && ex.getCause() != null) {
				response.put(mensaje.getMessage("msg.titulo.error", null, locale),
						ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			} else {
				response.put(mensaje.getMessage("msg.titulo.error", null, locale),
						mensaje.getMessage("msg.general.error", null, locale));
			}

			logger.error(mensaje.getMessage("msg.estado.error", null, locale), ex.getCause());
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<List<EstadoConvenioDTO>>(lst, HttpStatus.OK); 
	}
		
}
