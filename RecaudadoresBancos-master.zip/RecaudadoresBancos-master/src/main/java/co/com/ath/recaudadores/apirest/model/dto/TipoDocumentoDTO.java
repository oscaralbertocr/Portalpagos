package co.com.ath.recaudadores.apirest.model.dto;

import java.io.Serializable;

public class TipoDocumentoDTO implements Serializable{

	private static final long serialVersionUID = 1L;

	private String tipdocId;

	private String tipdocDescripcion;
	
	private String tipodocCodigo;

	public String getTipdocId() {
		return tipdocId;
	}

	public void setTipdocId(String tipdocId) {
		this.tipdocId = tipdocId;
	}

	public String getTipdocDescripcion() {
		return tipdocDescripcion;
	}

	public void setTipdocDescripcion(String tipdocDescripcion) {
		this.tipdocDescripcion = tipdocDescripcion;
	}

	public String getTipodocCodigo() {
		return tipodocCodigo;
	}

	public void setTipodocCodigo(String tipodocCodigo) {
		this.tipodocCodigo = tipodocCodigo;
	}
	
	
	
}
