package co.com.ath.recaudadores.checkstatus;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.persistence.EntityManagerFactory;

import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.entities.ArchivoFacturacion;

/**
*
* @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
* @version 1.0 12/05/2021
* 
* @sophosSolutions
* <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
* <strong>Numero de Cambios: </strong>0</br>
* 	
*/ 

@Service
@StepScope
public class CheckStatusWriter extends JpaItemWriter<ArchivoFacturacion>{
	
	@Resource
	private EntityManagerFactory entityManagerFactory;
	
	@PostConstruct
	public void init() {
		this.setEntityManagerFactory(entityManagerFactory);
	}

}
