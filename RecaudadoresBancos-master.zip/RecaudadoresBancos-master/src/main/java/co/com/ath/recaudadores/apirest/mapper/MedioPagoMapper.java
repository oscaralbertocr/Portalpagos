package co.com.ath.recaudadores.apirest.mapper;

import java.util.ArrayList;
import java.util.List;

import co.com.ath.recaudadores.apirest.model.dto.MedioPagoDTO;
import co.com.ath.recaudadores.apirest.model.entities.MedioPago;


public class MedioPagoMapper {
	
	private MedioPagoMapper() {}
	
	public static List<MedioPagoDTO> mapListEntityToDto(List<MedioPago> mediosPago) {
		List<MedioPagoDTO> medioPagoDto = new ArrayList<MedioPagoDTO>();
		if (mediosPago != null && !mediosPago.isEmpty()) {
			for (MedioPago medioPago : mediosPago) {
				medioPagoDto.add(mapEntityToDto(medioPago));
			}
		}
		return medioPagoDto;
	}
	
	public static MedioPagoDTO mapEntityToDto(MedioPago medioPago) {
		MedioPagoDTO medioPagoDto = null;
		if(medioPago != null) {
			medioPagoDto = new MedioPagoDTO();
			medioPagoDto.setId(medioPago.getId());
			medioPagoDto.setNombre(medioPago.getNombre());
		}
		return medioPagoDto;
	}
}
