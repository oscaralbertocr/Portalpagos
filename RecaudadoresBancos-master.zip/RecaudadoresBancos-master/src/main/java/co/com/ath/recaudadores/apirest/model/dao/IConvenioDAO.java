package co.com.ath.recaudadores.apirest.model.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.entities.Convenio;

/*
 * Clase : IConvenioDao
 * Date  : 16-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */

@Transactional(value = "prvTransactionManager", readOnly = true)
 public interface IConvenioDAO extends JpaRepository<Convenio, String> {

	@Query(value = "select conv.cnv_id,  \r\n" + 
			"	conv.cnv_nombre, \r\n" + 
			"	emp.sv_razon_social, \r\n" + 
			"	conv.cnv_nit,  \r\n" + 
			"	est.ec_estado,  \r\n" + 
			"	cat.cat_nombre, \r\n" + 
			"	ciu.ciud_nombre, \r\n" + 
			"	emp.sv_telefono_contacto,\r\n" + 
			"	emp.sv_nombre_contacto, \r\n" + 
			"	emp.sv_correo_corporativo,\r\n" + 
			"	modal.mod_tipo,\r\n" + 
			"	bco.bank_name, \r\n" + 
			"	conf.cnv_numero_cuenta_recaudo, \r\n" + 
			"	( select WMSYS.WM_CONCAT(refe.ref_label) from ext_convenio_referencia refe where refe.ref_cnv_id=conv.cnv_id group by conv.cnv_id ) referencia, \r\n" + 
			"   tcta.descripcion, \r\n" +
			"   info.direccion \r\n" +	
			"	from ext_convenios conv \r\n" + 
			"	LEFT OUTER join ext_dueno_convenio due ON due.dc_id = conv.cnv_dueno_id\r\n" + 
			"	LEFT OUTER join ext_estado_convenios est ON est.ec_id = conv.ext_estado_convenios_id\r\n" + 
			"	LEFT OUTER join conv_cat catConv ON catConv.ext_convenios_cnv_id = conv.cnv_id \r\n" + 
			"	LEFT OUTER join ext_categoria cat ON cat.cat_id = catConv.ext_categoria_cat_id\r\n" + 
			"	LEFT OUTER join ext_ciudad_dane ciu ON ciu.ciud_cod = conv.cnv_ciudad \r\n" + 
			"	LEFT OUTER join solicitud_vinculacion emp ON emp.sv_nit = conv.cnv_nit\r\n" + 
			"	LEFT OUTER join ext_cnv_modalidad modal ON modal.mod_id = conv.ext_cnv_modalidad_mod_id\r\n" + 
			"	LEFT OUTER join banco_maestro bco ON bco.bank_id = emp.sv_bank_id \r\n" + 
			"	LEFT OUTER join ext_convenio_conf conf ON conf.cnv_id = conv.cnv_id \r\n" + 
			"   LEFT OUTER join ext_convenios_others info ON info.cnv_id = conv.cnv_id \r\n" +
			"   LEFT OUTER join ext_tipo_cuenta tcta ON tcta.ID = info.id_tipo_cuenta \r\n" +
			"	Where   ( conv.cnv_id = ?1 or ?1 IS NULL) and ( est.ec_id = ?2 or ?2=99 or ?2=0) and  \r\n" + 
			"	        ( catConv.ext_categoria_cat_id = ?3 or ?3=99 or ?3=0) and (conf.cnv_numero_cuenta_recaudo = ?4 or ?4 IS NULL ) \r\n" +
	        "	        and (conv.cnv_dueno_id=1 or conv.cnv_dueno_id=2 ) and conf.cnv_bank_id='00010524' and conv.ext_estado_convenios_id !=3 ORDER BY conv.cnv_nombre", nativeQuery = true)
	public List<Object[]> consultaConvenios(String convenio, Long estado, Long categoria, String ctaRecaudo);
		
	@Query(value="SELECT conv.cnv_id, conv.cnv_nombre, conf.cnv_numero_cuenta_recaudo FROM ext_convenios conv \r\n" + 
			"	LEFT JOIN ext_convenio_conf conf ON conf.cnv_id = conv.cnv_id\r\n" + 
			"   where (conv.cnv_dueno_id=1 or conv.cnv_dueno_id=2 ) and conf.cnv_bank_id='00010524'  \r\n" + 
			"	and conv.ext_estado_convenios_id !=3 ORDER BY conv.cnv_nombre", nativeQuery = true)
	public List<Object[]> fetchAll();
	
	@Query(value="SELECT * FROM ext_convenios WHERE CNV_ID = ?1", nativeQuery = true)
	public Object consultaConvenio(String id);
	
	
}
