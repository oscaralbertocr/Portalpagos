package co.com.ath.recaudadores.apirest.model.dto;

import java.io.Serializable;

/*
 * Clase : ConvenioTo
 * Date  : 16-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */

public class ConvenioDTO  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private String nombre;
	private String cuentaRecaudo;



	
	public ConvenioDTO() {
	}


	public ConvenioDTO(String id, String nombre, String cuentaRecaudo) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.cuentaRecaudo = cuentaRecaudo;
	}


	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCuentaRecaudo() {
		return cuentaRecaudo;
	}

	public void setCuentaRecaudo(String cuentaRecaudo) {
		this.cuentaRecaudo = cuentaRecaudo;
	}

	@Override
	public String toString() {
		return "ConvenioTo [id=" + id + ", nombre=" + nombre + ", cuentaRecaudo=" + cuentaRecaudo + "]";
	}

}
