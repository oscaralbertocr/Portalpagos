package co.com.ath.recaudadores.apirest.model.entities;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
@Entity(name = "ArchivoFacturacion")
@Table(name = "ARCHIVO_FACTURACION")
public class ArchivoFacturacion {
	
	@SequenceGenerator(name="sequence_af_id", sequenceName="SEQ_ARCHIVO_FACTURACION_ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequence_af_id")
	@Column(name = "AF_ID", nullable = false)
	@Id
	private Long id;
	
	@Column(name = "AF_CONVENIO_ID", nullable = true)
	private String convenioID;
	
	@Column(name = "AF_NOMBRE_ORIGINAL", nullable = false)
	private String nombreOriginal;
	
	@Column(name = "AF_NOMBRE_ATH", nullable = false)
	private String nombreATH;
	
	@Column(name = "AF_FECHA_CARGA", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaCarga;
	
	@Column(name = "AF_FECHA_ACTUALIZACION", nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaActualizacion;
	
	@Column(name = "AF_FECHA_NOTIFICACION_EMAIL", nullable = true)
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaNotificacionEmail;
	
	@Column(name = "AF_TAMANO", nullable = false)
	private String tamano;
	
	@Column(name = "AF_USUARIO", nullable = false)
	private String usuario;
	
	@Column(name = "AF_ENVIO_PAYCENTRAL", nullable = false)
	private String envioPaycentral;
	
	@Column(name = "AF_ESTADO_PAYCENTRAL", nullable = true)
	private String estadoPaycentral;
	
	@Column(name = "AF_ACCION", nullable = true)
	private String accion;
	
	@Column(name = "AF_COMENTARIOS", nullable = true)
	private String comentarios;
	
	@Column(name = "AF_CICLO", nullable = true)
	private String ciclo;
	
	@Column(name = "AF_CORREO_USUARIO", nullable = true)
	private String correoUsuario;
	
	@Column(name = "AF_NOMBRE_USUARIO", nullable = true)
	private String nombreUsuario;
	
	@Column(name = "AF_HASH", nullable = true)
	private String hash;
	
	@Column(name = "EMAIL_NOTIFICACION_ENVIADO", nullable = true)
	private int emailNotificacionEnviado;
	
	@Column(name = "REFERENCIA_PRINCIPAL", nullable = true)
	private String referenciaPrincipal;
	
	@Column(name = "INTENTOS_CONSULTA", nullable = true)
	private int intentosConsulta;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getConvenioID() {
		return convenioID;
	}

	public void setConvenioID(String convenioID) {
		this.convenioID = convenioID;
	}

	public String getNombreOriginal() {
		return nombreOriginal;
	}

	public void setNombreOriginal(String nombreOriginal) {
		this.nombreOriginal = nombreOriginal;
	}

	public String getNombreATH() {
		return nombreATH;
	}

	public void setNombreATH(String nombreATH) {
		this.nombreATH = nombreATH;
	}

	public Date getFechaCarga() {
		return fechaCarga;
	}

	public void setFechaCarga(Date fechaCarga) {
		this.fechaCarga = fechaCarga;
	}

	public String getTamano() {
		return tamano;
	}

	public void setTamano(String tamano) {
		this.tamano = tamano;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getEnvioPaycentral() {
		return envioPaycentral;
	}

	public void setEnvioPaycentral(String envioPaycentral) {
		this.envioPaycentral = envioPaycentral;
	}

	public String getEstadoPaycentral() {
		return estadoPaycentral;
	}

	public void setEstadoPaycentral(String estadoPaycentral) {
		this.estadoPaycentral = estadoPaycentral;
	}

	public String getAccion() {
		return accion;
	}

	public void setAccion(String accion) {
		this.accion = accion;
	}

	public String getComentarios() {
		return comentarios;
	}

	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}

	public String getCiclo() {
		return ciclo;
	}

	public void setCiclo(String ciclo) {
		this.ciclo = ciclo;
	}

	public String getCorreoUsuario() {
		return correoUsuario;
	}

	public void setCorreoUsuario(String correoUsuario) {
		this.correoUsuario = correoUsuario;
	}

	public String getNombreUsuario() {
		return nombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public int getEmailNotificacionEnviado() {
		return emailNotificacionEnviado;
	}

	public void setEmailNotificacionEnviado(int emailNotificacionEnviado) {
		this.emailNotificacionEnviado = emailNotificacionEnviado;
	}

	public String getReferenciaPrincipal() {
		return referenciaPrincipal;
	}

	public void setReferenciaPrincipal(String referenciaPrincipal) {
		this.referenciaPrincipal = referenciaPrincipal;
	}

	public int getIntentosConsulta() {
		return intentosConsulta;
	}

	public void setIntentosConsulta(int intentosConsulta) {
		this.intentosConsulta = intentosConsulta;
	}

	public Date getFechaActualizacion() {
		return fechaActualizacion;
	}

	public void setFechaActualizacion(Date fechaActualizacion) {
		this.fechaActualizacion = fechaActualizacion;
	}

	public Date getFechaNotificacionEmail() {
		return fechaNotificacionEmail;
	}

	public void setFechaNotificacionEmail(Date fechaNotificacionEmail) {
		this.fechaNotificacionEmail = fechaNotificacionEmail;
	}
	
}
