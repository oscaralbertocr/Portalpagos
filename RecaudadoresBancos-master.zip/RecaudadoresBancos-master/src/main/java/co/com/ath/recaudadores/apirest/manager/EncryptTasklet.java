package co.com.ath.recaudadores.apirest.manager;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.util.Constants;
import co.com.ath.recaudadores.apirest.util.PGPFileProcessor;

/**
 * 
 * custom Exception.
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 
 * 	
*/

@Service
@StepScope
public class EncryptTasklet implements Tasklet{
	
	@Value("#{jobParameters[pathOutput]}")
	private String pathOutput;

	@Value("#{jobParameters[fileNameOutput]}")
	private String fileNameOutput;
	
	@Value("#{jobParameters[keyPublicPGP]}")
	private String keyPublicPGP;
	
	static Logger logger = LoggerFactory.getLogger(EncryptTasklet.class);

	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
		PGPFileProcessor pgpFileProcessor = new PGPFileProcessor();
			try {
				pgpFileProcessor.setInputFileName( this.pathOutput.concat("\\" + this.fileNameOutput));
				pgpFileProcessor.setOutputFileName(this.pathOutput.concat("\\" + this.fileNameOutput + Constants.extFileCipher));
				pgpFileProcessor.setPublicKeyFileName(this.keyPublicPGP);
				
				if (pgpFileProcessor.encrypt()) {
					logger.info("Se encripto correctamente el archivo :{}",	this.fileNameOutput);
				} else {
					throw new Exception("Encrypt and signature Fail");
				}
			} catch (Exception e) {
				logger.error(e.getMessage());
				logger.error("Error al tratar de encriptar y cifrar el archivo a PGP : {}", this.fileNameOutput);
				logger.error(e.toString());
			}
		return RepeatStatus.FINISHED;
	}
	
}
