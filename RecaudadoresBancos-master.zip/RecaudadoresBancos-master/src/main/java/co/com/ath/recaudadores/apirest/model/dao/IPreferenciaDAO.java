package co.com.ath.recaudadores.apirest.model.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.entities.Preferencia;

/*
 * Clase : ParametriaAO
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Transactional(value = "prvTransactionManager")
public interface IPreferenciaDAO extends CrudRepository<Preferencia, Long> {

	@Query(value = " select cast(pref.PREF_USUARIOS_ID as NUMBER), pref.UID_USUARIO,\r\n" + 
			"	pref.CNV_ID, cast(pref.ID_IDENTIFICADOR as NUMBER), \r\n" + 
			"	cast(param.id_preferencia as NUMBER), cast(pref.ESTADO as NUMBER), param.DESCRIPCION \r\n" + 
			"	from preferencias param\r\n" + 
			"	left join preferencias_usuario pref ON pref.id_preferencia = param.id_preferencia \r\n" + 
			"    where pref.cnv_id=?1 and pref.uid_usuario=?2 ORDER BY param.id_preferencia", nativeQuery = true)
	public List<Object[]> getPreferencias(String convenio, String usuario);

	@Modifying
	@Query(value = "INSERT INTO PREFERENCIAS_USUARIO(PREF_USUARIOS_ID, CNV_ID, UID_USUARIO, ID_PREFERENCIA, ID_IDENTIFICADOR, ESTADO ) VALUES\r\n" + 
			"	 (SEQ_PREF_USUARIOS_ID_PORTAL.nextval, ?1, ?2, ?3, ?4, ?5)", nativeQuery = true)
	public void crear(String convenio, String usuario, Long idParametro, Long identificador, Boolean estado);
	
	@Modifying
	@Query(value = "UPDATE PREFERENCIAS_USUARIO pref SET pref.ESTADO = ?1\r\n" + 
			"WHERE pref.CNV_ID = ?2 and pref.UID_USUARIO = ?3 and pref.ID_PREFERENCIA = ?4", nativeQuery = true)
	public void modificar(Boolean estado, String convenio, String usuario, Long idParametro);

}
