package co.com.ath.recaudadores.apirest.storedprocedures.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.services.IParametroService;
import co.com.ath.recaudadores.apirest.util.Filtro;
import co.com.ath.recaudadores.apirest.util.Utils;

@Service
public class ProcedureServiceImpl {
	
	static Logger logger = LoggerFactory.getLogger(ProcedureServiceImpl.class);
	
	 @Autowired(required = true)
	 Utils util;
	 
	@Autowired
	IParametroService parametroService;
		
	public static final int CURSOR = -10;
	public static final String SP_CONVENIOS= "{ call pkg_convenios.sp_consulta_convenios(?, ?, ?, ?, ?, ?, ?) }";
	
	@Async
	public void generateConsultaConvenios(Filtro filtro) throws SQLException {
		Connection connection = null;
		CallableStatement callableStatement = null;
		ResultSet resultSet = null;
        InitialContext initialContext = null;
        DataSource dataSource = null;
		try {
	        initialContext = new InitialContext();
	        dataSource = (DataSource) initialContext
	                       .lookup("jdbc/PortalPagosDS");	
	        logger.info("::: SE REALIZA LA CONEXION AL DATASOURCE :::");			
			connection = dataSource.getConnection();
			callableStatement = connection.prepareCall(SP_CONVENIOS);
			callableStatement.setString(1, filtro.getNuraConvenio());
			callableStatement.setString(2, String.valueOf(filtro.getIdEstado()));
			callableStatement.setString(3, String.valueOf(filtro.getIdCategoria()));
			callableStatement.setString(4, filtro.getCuentaRecaudo());			
			callableStatement.registerOutParameter(7, Types.VARCHAR);
			callableStatement.registerOutParameter(6, Types.VARCHAR);
			callableStatement.registerOutParameter(5, CURSOR);
			
			logger.info("Se genera el archivo con los siguientes parametros nura: {}, estado: {}, categoria: {}, cuenta recaudo: {}",
					filtro.getNuraConvenio(),filtro.getIdEstado(),filtro.getIdCategoria(),filtro.getCuentaRecaudo());
			
			logger.info("Inicia llamado a procedimiento almacenado");
			callableStatement.execute();
			logger.info("Finaliza llamado a procedimiento almacenado");
			
			resultSet = (ResultSet) callableStatement.getObject(5);
			
			if (callableStatement.getObject(6).equals("error")) {
				logger.error("Error interno del procedimiento {}", callableStatement.getObject(7));
			} else {
				util.generarArchivo(resultSet, filtro.getCorreo());
			}
						
			resultSet.close();			
			callableStatement.close();
			connection.close();
		}catch(Exception e) {
			logger.error("Error llamando procedimiento {}", e);
			util.envioCorreo(filtro.getCorreo(), parametroService.find("ReporteConveniosCuerpoError").getValor(), "");
			
		} finally {
			if (connection != null) {
				connection.close();
			}
			if (callableStatement != null) {
				callableStatement.close();
			}
			if (resultSet != null) {
				resultSet.close();
			}
		}
		
	}

	

}
