package co.com.ath.recaudadores.apirest.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.json.JSONArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.com.ath.recaudadores.apirest.model.dto.TransaccionConsultaDTO;
import co.com.ath.recaudadores.apirest.model.services.ITransaccionService;
import co.com.ath.recaudadores.apirest.util.FilterTransaccion;

@RestController
@RequestMapping("/rest")
public class TransaccionRestController {

	static Logger logger = LoggerFactory.getLogger(TransaccionRestController.class);

	private final ITransaccionService transaccionService;

	private final MessageSource mensaje;

	@Autowired
	public TransaccionRestController(ITransaccionService transaccionService, MessageSource mensaje) {
		this.transaccionService = transaccionService;
		this.mensaje = mensaje;
	}

	/**
	 * @return
	 */
	@PostMapping("/transaccion/getTxByFilter")
	public ResponseEntity<?> getTxByFilter(@RequestBody FilterTransaccion filter) {
		JSONArray resp = null;
		Locale locale = LocaleContextHolder.getLocale();
		Map<String, Object> response = new HashMap<>();
		try {
			resp = transaccionService.getTxByFilters(filter);
			
			if (resp == null || resp.isEmpty()) {
				response.put(mensaje.getMessage("msg.titulo", null, locale),
						mensaje.getMessage("msg.transaccion.vacio", null, locale));
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			response.put(mensaje.getMessage("msg.titulo", null, locale),
					mensaje.getMessage("msg.general.error", null, locale));

			if (ex.getMessage() != null && ex.getCause() != null) {
				response.put(mensaje.getMessage("msg.titulo.error", null, locale),
						ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			} else {
				response.put(mensaje.getMessage("msg.titulo.error", null, locale),
						mensaje.getMessage("msg.general.error", null, locale));
			}

			logger.error(mensaje.getMessage("msg.general.error", null, locale), ex.getCause());
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<List<Object>>(resp.toList(), HttpStatus.OK);
	}
	
	/**
	 * @return
	 */
	@PostMapping("/transaccion/getAllTxByFilter")
	public ResponseEntity<?> getAllTxByFilter(@RequestBody FilterTransaccion filter) {
		List<TransaccionConsultaDTO> resp = new ArrayList<TransaccionConsultaDTO>();
		Locale locale = LocaleContextHolder.getLocale();
		Map<String, Object> response = new HashMap<>();
		try {
			resp = transaccionService.getAllTxByFilter(filter);
			
			if (resp == null || resp.isEmpty()) {
				response.put(mensaje.getMessage("msg.titulo", null, locale),
						mensaje.getMessage("msg.transaccion.vacio", null, locale));
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
			response.put(mensaje.getMessage("msg.titulo", null, locale),
					mensaje.getMessage("msg.general.error", null, locale));

			if (ex.getMessage() != null && ex.getCause() != null) {
				response.put(mensaje.getMessage("msg.titulo.error", null, locale),
						ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			} else {
				response.put(mensaje.getMessage("msg.titulo.error", null, locale),
						mensaje.getMessage("msg.general.error", null, locale));
			}

			logger.error(mensaje.getMessage("msg.general.error", null, locale), ex.getCause());
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<List<TransaccionConsultaDTO>>(resp, HttpStatus.OK);
	}

}
