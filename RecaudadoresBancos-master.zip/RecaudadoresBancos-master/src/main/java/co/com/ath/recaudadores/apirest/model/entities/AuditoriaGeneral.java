package co.com.ath.recaudadores.apirest.model.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity(name = "AuditoriaGeneral")
@Table(name="AUDITORIA_GENERAL")
public class AuditoriaGeneral implements Serializable{

	private static final long serialVersionUID = 1L;

	@SequenceGenerator(name = "sequence_audgnrl", sequenceName = "SEQ_AUDITORIA")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequence_audgnrl")
	@Column(name = "AUD_ID", nullable = false)
	@Id
	private Long id;

	@Column(name = "AUD_IP")
	private String ip;
	
	@Column(name = "AUD_FECHA_OPERACION", nullable = false)
	private String fechaOperacion;
	
	@Column(name = "AUD_ACCION", nullable = false)
	private String accion;
	
	@Column(name = "AUD_PORTAL_ORIGEN")
	private String portalOrigen;
	
	@Column(name = "AUD_INFO_ADICIONAL")
	private String infoAdicional;
	
	@Column(name = "AUD_USUARIO")
	private String usuario;
	
	@Column(name = "AUD_PAGINA")
	private String pagina;
	
	@Column(name = "AUD_PORTLET")
	private String portlet;
	
	@Column(name = "AUD_PMTID")
	private String pmtid;
	
	@Column(name = "AUD_REFERENCIA")
	private String referencia;
	
	@Column(name = "AUD_RQUID")
	private String rquid;
	
	@Column(name = "AUD_ESTADO")
	private String estado;
	
	@Column(name = "AUD_CODIGO_ERROR")
	private String codigoError;
	
	@Column(name = "AUD_COD_SERVICIO_INT")
	private String codServicioInt;
	
	@Column(name = "AUD_TIPO_SERVICIO")
	private String tipoServicio;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getFechaOperacion() {
		return fechaOperacion;
	}

	public void setFechaOperacion(String fechaOperacion) {
		this.fechaOperacion = fechaOperacion;
	}

	public String getAccion() {
		return accion;
	}

	public void setAccion(String accion) {
		this.accion = accion;
	}

	public String getPortalOrigen() {
		return portalOrigen;
	}

	public void setPortalOrigen(String portalOrigen) {
		this.portalOrigen = portalOrigen;
	}

	public String getInfoAdicional() {
		return infoAdicional;
	}

	public void setInfoAdicional(String infoAdicional) {
		this.infoAdicional = infoAdicional;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getPagina() {
		return pagina;
	}

	public void setPagina(String pagina) {
		this.pagina = pagina;
	}

	public String getPortlet() {
		return portlet;
	}

	public void setPortlet(String portlet) {
		this.portlet = portlet;
	}

	public String getPmtid() {
		return pmtid;
	}

	public void setPmtid(String pmtid) {
		this.pmtid = pmtid;
	}

	public String getReferencia() {
		return referencia;
	}

	public void setReferencia(String referencia) {
		this.referencia = referencia;
	}

	public String getRquid() {
		return rquid;
	}

	public void setRquid(String rquid) {
		this.rquid = rquid;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getCodigoError() {
		return codigoError;
	}

	public void setCodigoError(String codigoError) {
		this.codigoError = codigoError;
	}

	public String getCodServicioInt() {
		return codServicioInt;
	}

	public void setCodServicioInt(String codServicioInt) {
		this.codServicioInt = codServicioInt;
	}

	public String getTipoServicio() {
		return tipoServicio;
	}

	public void setTipoServicio(String tipoServicio) {
		this.tipoServicio = tipoServicio;
	}
	
}
