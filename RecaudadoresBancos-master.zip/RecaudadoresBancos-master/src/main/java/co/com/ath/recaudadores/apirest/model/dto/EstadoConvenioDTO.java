package co.com.ath.recaudadores.apirest.model.dto;

import java.io.Serializable;

/*
 * Clase : EstadoConvenioTo
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
public class EstadoConvenioDTO implements Serializable {

	private Long id;
	private String nombre;

	public EstadoConvenioDTO() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "EstadoConvenio [id=" + id + ", nombre=" + nombre + "]";
	}

	private static final long serialVersionUID = 1L;
}
