
package co.com.ath.recaudadores.apirest.util;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 

public class AuditException extends Exception {

	private static final long serialVersionUID = 1L;
	private final Object objeto;

	public AuditException() {
        super();
        this.objeto = null;

    }
	

    public AuditException(String message) {
        super(message);
        this.objeto = null;
    }

    public AuditException(String message, Object objeto) {
        super(message);
        this.objeto = objeto;
    }

	public Object getObjeto() {
		return objeto;
	}
	
	
	private void readObject(ObjectInputStream aInputStream) throws ClassNotFoundException, IOException{// default implementation ignored
    }
 
    private void writeObject(ObjectOutputStream aOutputStream) throws IOException 
    {
        aOutputStream.writeObject(objeto);
    }

	
}
