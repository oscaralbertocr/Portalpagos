package co.com.ath.recaudadores.apirest.mapper;

import java.util.ArrayList;
import java.util.List;

import co.com.ath.recaudadores.apirest.model.dto.EstadoTransaccionDTO;
import co.com.ath.recaudadores.apirest.model.entities.EstadoTransaccion;

public class EstadoTransaccionMapper {
	private EstadoTransaccionMapper() {}
	
	public static List<EstadoTransaccionDTO> mapListEntityToDto(List<EstadoTransaccion> estados) {
		List<EstadoTransaccionDTO> estadoDto = new ArrayList<EstadoTransaccionDTO>();
		if (estados != null && !estados.isEmpty()) {
			for (EstadoTransaccion estado : estados) {
				estadoDto.add(mapEntityToDto(estado));
			}
		}
		return estadoDto;
	}
	
	public static EstadoTransaccionDTO mapEntityToDto(EstadoTransaccion estadoTransaccion) {
		EstadoTransaccionDTO estadoTransaccionDto = null;
		if(estadoTransaccion != null) {
			estadoTransaccionDto = new EstadoTransaccionDTO();
			estadoTransaccionDto.setId(estadoTransaccion.getId());
			estadoTransaccionDto.setNombre(estadoTransaccion.getNombre());
		}
		return estadoTransaccionDto;
	}
}
