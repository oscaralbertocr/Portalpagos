package co.com.ath.recaudadores.apirest.model.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import co.com.ath.recaudadores.apirest.model.dto.EstadoTransaccionDTO;
import co.com.ath.recaudadores.apirest.util.Constants;

/*
 * Clase : EstadoTransaccion
 * Date  : 21-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Entity
@Table(name = "EXT_ESTADO_TX")
public class EstadoTransaccion implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "EST_ID", nullable = false)
	private Long id;

	@Column(name = "EST_NOMBRE", nullable = false)
	private String nombre;

	@Column(name = "EST_FEC_CREACION", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaCreacion;

	@Column(name = "EST_FEC_MODIF")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaModif;

	@Column(name = "EST_USUARIO_CREACION", nullable = false)
	private String userCreacion;

	@Column(name = "EST_USUARIO_MODIF")
	private String userModif;

	public EstadoTransaccion() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public Date getFechaModif() {
		return fechaModif;
	}

	public void setFechaModif(Date fechaModif) {
		this.fechaModif = fechaModif;
	}

	public String getUserCreacion() {
		return userCreacion;
	}

	public void setUserCreacion(String userCreacion) {
		this.userCreacion = userCreacion;
	}

	public String getUserModif() {
		return userModif;
	}

	public void setUserModif(String userModif) {
		this.userModif = userModif;
	}

	@Override
	public String toString() {
		return "EstadoTransaccion [id=" + id + ", nombre=" + nombre + ", fechaCreacion=" + fechaCreacion
				+ ", fechaModif=" + fechaModif + ", userCreacion=" + userCreacion + ", userModif=" + userModif + "]";
	}

	/**
	 * @return
	 */
	public EstadoTransaccionDTO toEstadoTransaccionDTO() {
		EstadoTransaccionDTO estado;

		if (this.id != Constants.ESTADO_TX_DESCARTADO && this.id != Constants.ESTADO_TX_INICIADO) {
			estado = new EstadoTransaccionDTO();
			estado.setId(this.id);
			estado.setNombre(this.nombre);
			return estado;
		}
		return null;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
