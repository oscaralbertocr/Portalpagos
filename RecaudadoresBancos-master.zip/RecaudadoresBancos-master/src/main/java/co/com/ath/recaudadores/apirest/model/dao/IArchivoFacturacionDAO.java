package co.com.ath.recaudadores.apirest.model.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.entities.ArchivoFacturacion;

/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
@Transactional(value = "prvTransactionManager")
public interface IArchivoFacturacionDAO extends CrudRepository<ArchivoFacturacion, Long> {

	@Query(value = "SELECT * FROM portal_depagos.ARCHIVO_FACTURACION WHERE AF_NOMBRE_ATH = ?1", nativeQuery = true)
	public List<ArchivoFacturacion> obtenerRegistrosPorNombreArchivo(String nombreATH);

}
