package co.com.ath.recaudadores.email;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.persistence.EntityManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import co.com.ath.recaudadores.apirest.model.entities.ArchivoFacturacion;

/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
@Service
public class AuditBatch {

	static Logger logger = LoggerFactory.getLogger(AuditBatch.class);
	
	@Resource
	private EntityManagerFactory entityManagerFactory;
	
	private final String jobName = "AUDIT_PROCESS";

	@Autowired
	private AuditItemReader auditReader;

	@Autowired
	private AuditItemProcessor auditProcessor;
	
	@Autowired
	private AuditWriter auditWriter;

	private Job job;

	@Autowired(required=true)
	private JobBuilderFactory jobBuilderFactory;

	@Autowired(required=true)
	private JobLauncher jobLauncher;

	@Autowired(required=true)
	private StepBuilderFactory stepBuilderFactory;

	@PostConstruct
	public void init() {
		this.job = this.generateJob();
	}

	@Scheduled(fixedRateString = "300000")
	@Transactional(value = "transactionManager" , propagation = Propagation.NOT_SUPPORTED)
	public void autoRun() {
		this.execute();
	}

	private JobExecution execute() {
		try {
			logger.info("INICIO DE SONDA DE AUDITORIA");
			JobParametersBuilder jobParams = new JobParametersBuilder();
			jobParams.addLong("time", System.currentTimeMillis());
			return this.jobLauncher.run(job, jobParams.toJobParameters());
		} catch (Exception e) {
			logger.error("ERROR EJECUTANDO EL PROCESO DE AUDITORIA");
			logger.error(e.getMessage());
			return null;
		}
	}

	private Job generateJob() {
		return this.jobBuilderFactory.get(this.jobName)
				.incrementer(new RunIdIncrementer())
				.start(this.generateStep())
				.build();
	}

	private Step generateStep(){
		return this.stepBuilderFactory.get("STEP_POCCESS_AUDIT")
				.<ArchivoFacturacion, ArchivoFacturacion> chunk(10)
				.reader(this.auditReader)
				.processor(this.auditProcessor)
				.writer(this.auditWriter)
				.build();
	}
	

}
