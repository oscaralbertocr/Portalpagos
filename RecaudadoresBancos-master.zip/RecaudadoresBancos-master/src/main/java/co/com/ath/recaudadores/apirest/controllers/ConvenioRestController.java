package co.com.ath.recaudadores.apirest.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import co.com.ath.recaudadores.apirest.model.dto.ConsultaConvenioDTO;
import co.com.ath.recaudadores.apirest.model.dto.ConvenioDTO;
import co.com.ath.recaudadores.apirest.model.dto.MailServiceInDTO;
import co.com.ath.recaudadores.apirest.model.services.IConvenioService;
import co.com.ath.recaudadores.apirest.storedprocedures.impl.ProcedureServiceImpl;
import co.com.ath.recaudadores.apirest.util.Filtro;
/*
 * Clase : ConvenioRestController
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
import co.com.ath.recaudadores.apirest.util.MailService;

@RestController
@RequestMapping("/rest")
public class ConvenioRestController {
	static Logger logger = LoggerFactory.getLogger(ConvenioRestController.class);

	@Autowired
	private IConvenioService convenioService;

	@Autowired
	private MessageSource mensaje;
	
	@Autowired
	ProcedureServiceImpl service;
	
	private Locale locale = LocaleContextHolder.getLocale();
	private Map<String, Object> response = new HashMap<>();

	/**
	 * @return
	 */
	@GetMapping("/convenios/catalogo")
	public ResponseEntity<?> catalogo() {
		List<ConvenioDTO> lst;

		try {
			lst = convenioService.findAll(1);

			if (lst.isEmpty() || lst == null) {
				response.put(mensaje.getMessage("msg.titulo", null, locale),
						mensaje.getMessage("msg.convenio.vacio", null, locale));
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
			}
		} catch (Exception ex) {
			response.put(mensaje.getMessage("msg.titulo", null, locale),
					mensaje.getMessage("msg.convenio.error", null, locale));
			
			if (ex.getMessage() != null && ex.getCause() != null) {
				response.put(mensaje.getMessage("msg.titulo.error", null, locale),
						ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			} else {
				response.put(mensaje.getMessage("msg.titulo.error", null, locale),
						mensaje.getMessage("msg.general.error", null, locale));
			}
			
			logger.error(mensaje.getMessage("msg.convenio.error", null, locale), ex.getCause());
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return new ResponseEntity<List<ConvenioDTO>>(lst, HttpStatus.OK);
	}

	
	
	/**
	 * @param filtro
	 * @return
	 */
	@PostMapping("/convenios")
	public ResponseEntity<?> consultaConvenios(@RequestBody Filtro filtro, @RequestParam(defaultValue = "0") int pagina,
			@RequestParam(defaultValue = "10") int registros ) {

		List<ConsultaConvenioDTO> lst;
		pagina = (pagina < 0) ? 0 : pagina;
		registros = (registros < 1) ? 10 : registros;
		Pageable pageable = new PageRequest(pagina, registros);
		
		try {

			// validacion del filtro

			if (filtro == null) {
				response.put(mensaje.getMessage("msg.titulo", null, locale), mensaje.getMessage("msg.filtro.null", null, locale));
				logger.error(mensaje.getMessage("msg.filtro.null", null, locale));
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
			}

			if (( filtro.getIdCategoria() == null  || filtro.getIdCategoria() == 0) && 
					(filtro.getNuraConvenio() == null || filtro.getNuraConvenio().isEmpty()) && 
					(filtro.getIdEstado() ==null || filtro.getIdEstado() == 0) &&
			        (filtro.getCuentaRecaudo() == null || filtro.getCuentaRecaudo().isEmpty() )) {
				response.put(mensaje.getMessage("msg.titulo", null, locale), mensaje.getMessage("msg.filtro.vacio", null, locale));
				logger.debug(mensaje.getMessage("msg.filtro.vacio", null, locale));
				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
			}
			
			// realiza la consulta			
			this.service.generateConsultaConvenios(filtro);	
			
		} catch (Exception ex) {
			response.put(mensaje.getMessage("msg.titulo", null, locale),
					mensaje.getMessage("msg.consulta.error", null, locale));
			if (ex.getMessage() != null && ex.getCause() != null) {
				response.put(mensaje.getMessage("msg.titulo.error", null, locale),
						ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
			} else {
				response.put(mensaje.getMessage("msg.titulo.error", null, locale),
						mensaje.getMessage("msg.general.error", null, locale));
			}
			logger.error(mensaje.getMessage("msg.consulta.error", null, locale), ex.getCause());
			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	
//	@PostMapping("/convenios")
//	public ResponseEntity<?> consultaConvenios_old(@RequestBody Filtro filtro, @RequestParam(defaultValue = "0") int pagina,
//			@RequestParam(defaultValue = "10") int registros ) {
//
//		List<ConsultaConvenioDTO> lst;
//		pagina = (pagina < 0) ? 0 : pagina;
//		registros = (registros < 1) ? 10 : registros;
//		Pageable pageable = new PageRequest(pagina, registros);
//		
//		try {
//
//			// validacion del filtro
//
//			if (filtro == null) {
//				response.put(mensaje.getMessage("msg.titulo", null, locale), mensaje.getMessage("msg.filtro.null", null, locale));
//				logger.error(mensaje.getMessage("msg.filtro.null", null, locale));
//				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
//			}
//
//			if (( filtro.getIdCategoria() == null  || filtro.getIdCategoria() == 0) && 
//					(filtro.getNuraConvenio() == null || filtro.getNuraConvenio().isEmpty()) && 
//					(filtro.getIdEstado() ==null || filtro.getIdEstado() == 0) &&
//			        (filtro.getCuentaRecaudo() == null || filtro.getCuentaRecaudo().isEmpty() )) {
//				response.put(mensaje.getMessage("msg.titulo", null, locale), mensaje.getMessage("msg.filtro.vacio", null, locale));
//				logger.debug(mensaje.getMessage("msg.filtro.vacio", null, locale));
//				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
//			}
//			
//			// realiza la consulta
//			lst = convenioService.consultaConvenios(filtro, pageable);
//			
//			if (lst == null || lst.size() == 0) {	
//				response.put(mensaje.getMessage("msg.titulo", null, locale),
//						mensaje.getMessage("msg.consulta.vacio", null, locale));
//				return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
//			}
//		} catch (Exception ex) {
//			response.put(mensaje.getMessage("msg.titulo", null, locale),
//					mensaje.getMessage("msg.consulta.error", null, locale));
//			if (ex.getMessage() != null && ex.getCause() != null) {
//				response.put(mensaje.getMessage("msg.titulo.error", null, locale),
//						ex.getMessage().concat(": ").concat(ex.getCause().getMessage()));
//			} else {
//				response.put(mensaje.getMessage("msg.titulo.error", null, locale),
//						mensaje.getMessage("msg.general.error", null, locale));
//			}
//			logger.error(mensaje.getMessage("msg.consulta.error", null, locale), ex.getCause());
//			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.INTERNAL_SERVER_ERROR);
//		}
//
//		return new ResponseEntity<List<ConsultaConvenioDTO>>(lst, HttpStatus.OK);
//	}
}
