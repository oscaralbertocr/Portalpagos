package co.com.ath.recaudadores.apirest.model.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Entity class for BancoPago to build the Transaccion entity
 * @author javier.florez
 * 24-oct-2020
 */
@Entity
@Table(name="EXT_BANCO_PAGO")
public class BancoPago implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="BNC_ID")
	private String bncId;

	@Column(name="BNC_NOMBRE")
	private String bncNombre;

	//bi-directional many-to-one association to ExtTransaccion
	@OneToMany(mappedBy="bancoPago")
	private List<Transaccion> transaccions;

	public String getBncId() {
		return bncId;
	}

	public void setBncId(String bncId) {
		this.bncId = bncId;
	}

	public String getBncNombre() {
		return bncNombre;
	}

	public void setBncNombre(String bncNombre) {
		this.bncNombre = bncNombre;
	}

	public List<Transaccion> getTransaccions() {
		return transaccions;
	}

	public void setTransaccions(List<Transaccion> transaccions) {
		this.transaccions = transaccions;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
