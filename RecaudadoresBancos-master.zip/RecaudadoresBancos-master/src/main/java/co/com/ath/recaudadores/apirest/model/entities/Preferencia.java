package co.com.ath.recaudadores.apirest.model.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/*
 * Clase : Parametrias
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Entity
@Table(name = "PREFERENCIAS")
public class Preferencia {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID_PREFERENCIA", nullable = false)
	private Long id;
	
	@Column(name = "IDENTIFICADOR", nullable = false)
	private Long identificador;
	
	@Column(name = "NOMBRE", nullable = false)
	private String nombre;
	
	@Column(name = "DESCRIPCION", nullable = false)
	private String descripcion;
	
	@Column(name = "CAMPOS_TABLA", nullable = false)
	private String camposTabla;
	
//	@Column(name = "ESTADO", nullable = false)
//	private boolean estado;

	public Preferencia() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getIdentificador() {
		return identificador;
	}

	public void setIdentificador(Long identificador) {
		this.identificador = identificador;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getCamposTabla() {
		return camposTabla;
	}

	public void setCamposTabla(String camposTabla) {
		this.camposTabla = camposTabla;
	}
	
//	public Boolean getEstado() {
//		return estado;
//	}
//
//	public void setEstado(Boolean estado) {
//		this.estado = estado;
//	}

	@Override
	public String toString() {
		return "Parametrias [id=" + id + ", identificador=" + identificador + ", nombre=" + nombre + ", descripcion="
				+ descripcion + ", camposTabla=" + camposTabla + "]";
	}
	
	

}
