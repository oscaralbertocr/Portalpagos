package co.com.ath.recaudadores.apirest.util;

import java.io.Serializable;

import org.springframework.stereotype.Component;

/*
 * Clase : FiltroTo
 * Date  : 16-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Component
public class Filtro implements Serializable {

	private String nuraConvenio;
	private Long idEstado;
	private Long idCategoria;
	private String cuentaRecaudo;
	private int banco;
	private String correo;
	private String correoConfirmacion;	

	public Filtro() {

	}

	public String getNuraConvenio() {
		return nuraConvenio;
	}

	public void setNuraConvenio(String nuraConvenio) {
		this.nuraConvenio = nuraConvenio;
	}

	public Long getIdEstado() {
		return idEstado;
	}

	public void setIdEstado(Long idEstado) {
		this.idEstado = idEstado;
	}

	public Long getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoria(Long idCategoria) {
		this.idCategoria = idCategoria;
	}

	public String getCuentaRecaudo() {
		return cuentaRecaudo;
	}

	public void setCuentaRecaudo(String cuentaRecaudo) {
		this.cuentaRecaudo = cuentaRecaudo;
	}

	public int getBanco() {
		return banco;
	}

	public void setBanco(int banco) {
		this.banco = banco;
	}
	
	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getCorreoConfirmacion() {
		return correoConfirmacion;
	}

	public void setCorreoConfirmacion(String correoConfirmacion) {
		this.correoConfirmacion = correoConfirmacion;
	}

	@Override
	public String toString() {
		return "FiltroTo [nuraConvenio=" + nuraConvenio + ", idEstado=" + idEstado + ", idCategoria=" + idCategoria
				+ ", cuenta=" + cuentaRecaudo + "]";
	}

	private static final long serialVersionUID = 1L;
}
