package co.com.ath.recaudadores.apirest.model.services;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.dto.EstadoTransaccionDTO;

/*
 * Clase : IEstadoTransaccionService
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Transactional(value = "prvTransactionManager")
public interface IEstadoTransaccionService {
	public List<EstadoTransaccionDTO> findAll();
}
