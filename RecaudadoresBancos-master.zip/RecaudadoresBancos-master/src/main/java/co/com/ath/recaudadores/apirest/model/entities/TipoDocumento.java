package co.com.ath.recaudadores.apirest.model.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entity class for EXT_TIPO_DOCUMENTO table
 * @author javier.florez
 * 25-oct-2020
 */
@Entity
@Table(name="EXT_TIPO_DOCUMENTO")
public class TipoDocumento implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="TIPDOC_ID")
	private String tipdocId;

	@Column(name="TIPDOC_DESCRIPCION")
	private String tipdocDescripcion;
	
	@Column(name="TIPODOC_CODIGO")
	private String tipodocCodigo;

	public String getTipdocId() {
		return tipdocId;
	}

	public void setTipdocId(String tipdocId) {
		this.tipdocId = tipdocId;
	}

	public String getTipdocDescripcion() {
		return tipdocDescripcion;
	}

	public void setTipdocDescripcion(String tipdocDescripcion) {
		this.tipdocDescripcion = tipdocDescripcion;
	}

	public String getTipodocCodigo() {
		return tipodocCodigo;
	}

	public void setTipodocCodigo(String tipodocCodigo) {
		this.tipodocCodigo = tipodocCodigo;
	}

	
}
