package co.com.ath.recaudadores.apirest.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dto.MailServiceInDTO;
/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
 */ 
@Service
public class AbortUtil implements JobExecutionListener {

	static Logger logger = LoggerFactory.getLogger(AbortUtil.class);


	@Autowired
	MailService mailService;

	@Override
	public void beforeJob(JobExecution jobExecution) {
		// no used		
	}

	@Override
	public void afterJob(JobExecution jobExecution) {
		for(Throwable t : jobExecution.getAllFailureExceptions()) {
			try {
				String pathInput = jobExecution.getJobParameters().getString("pathInput");
				String nameFileInput = jobExecution.getJobParameters().getString("fileNameInput");
				String nameOriginalFile = jobExecution.getJobParameters().getString("fileOriginalName");
				String pathOutput = jobExecution.getJobParameters().getString("pathOutput");
				String urlFileStructure = jobExecution.getJobParameters().getString("urlFileStructure");
				String nameFileOutput = jobExecution.getJobParameters().getString("fileNameOutput");
				String messageTo = jobExecution.getJobParameters().getString("messageTo");
				String messageContentError = jobExecution.getJobParameters().getString("messageContentError");
				if((t instanceof FlatFileParseException) || (t instanceof CustomException)) {

					this.deleteFileOriginal(pathInput, nameFileInput);
					if(!t.getMessage().equals(Constants.FTP_ERROR)) {
						this.deleteFileConvert(pathOutput, nameFileOutput);
						this.deleteFileCipher(pathOutput, nameFileOutput);
					}

					MailServiceInDTO mail = new MailServiceInDTO();
					mail.setTo(messageTo);
					mail.setText(messageContentError.replace("#fileName", nameOriginalFile));
					mail.setText(messageContentError.replace("#url", urlFileStructure));
					mailService.sendMail(mail);
				}
			} catch (CustomException e) {
				logger.error("Error al Enviar el Mail de ERROR");
				logger.error(e.getMessage());
			} catch (Exception e) {
				logger.error(e.getMessage());
			}
		}
	}

	private void deleteFileOriginal(String pathInput, String nameFileInput) {
		deleteFile(new File(pathInput, nameFileInput));
		
	}

	private void deleteFileConvert(String pathOutput, String nameFileOutput) {
		deleteFile(new File(pathOutput, nameFileOutput));
	}
	
	private void deleteFileCipher(String pathOutput, String nameFileOutput) {
		deleteFile(new File(pathOutput, nameFileOutput.concat(Constants.extFileCipher)));
	}
	
	private void deleteFile(File file) {
		try {
		Path p = file.toPath();
			Files.delete(p);
		} catch (IOException e) {
			logger.error("Error al borrar los archivos temporales");
			logger.error(e.getMessage());
		}
	}

}
