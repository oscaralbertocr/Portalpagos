package co.com.ath.recaudadores.apirest.model.dto;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

import co.com.ath.recaudadores.apirest.util.XMLUtil;


public class RequestDownloadFile implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("Date")
	private String date;
	
	@JsonProperty("PaymentWay")
	private String paymentWay;
	
	@JsonProperty("IDConv")
	private String idConv;
	
	@JsonProperty("Structure")
	private String structure;
	
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getPaymentWay() {
		return paymentWay;
	}

	public void setPaymentWay(String paymentWay) {
		this.paymentWay = paymentWay;
	}

	public String getIdConv() {
		return idConv;
	}

	public void setIdConv(String idConv) {
		this.idConv = idConv;
	}

	public String getStructure() {
		return structure;
	}

	public void setStructure(String structure) {
		this.structure = structure;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		XMLUtil<RequestDownloadFile> util = new XMLUtil<RequestDownloadFile>();
		return util.convertObjectToJson(this);
	}
}
