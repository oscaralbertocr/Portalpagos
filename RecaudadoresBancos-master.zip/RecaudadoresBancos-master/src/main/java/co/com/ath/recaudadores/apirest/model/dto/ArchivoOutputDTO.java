package co.com.ath.recaudadores.apirest.model.dto;

import java.io.Serializable;

/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
public class ArchivoOutputDTO implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private String idenType;

	private String idenNumber;
	
	private String description;
	
	private String idenBusiness;
	
	private String invoiceNumber;
	
	private String valueOne;
	
	private String taxOne;
	
	private String additionalFieldOne;
	
	private String additionalFieldTwo;
	
	private String additionalFieldThree;
	
	private String additionalFieldFour;
	
	private String additionalFieldFive;
	
	private String additionalFieldSix;
	
	private String additionalFieldSeven;
	
	private String additionalFieldEight;
	
	private String additionalFieldNine;
	
	private String expirationDateOne;
	
	private String valueTwo;
	
	private String taxTwo;
	
	private String expirationDateTwo;
	
	private String valueThree;
	
	private String taxThree;
	
	private String expirationDateThree;
	
	private String valueFour;
	
	private String taxFour;
	
	private String expirationDateFour;
	
	public String getIdenType() {
		return idenType;
	}

	public void setIdenType(String idenType) {
		this.idenType = idenType;
	}

	public String getIdenNumber() {
		return idenNumber;
	}

	public void setIdenNumber(String idenNumber) {
		this.idenNumber = idenNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getIdenBusiness() {
		return idenBusiness;
	}

	public void setIdenBusiness(String idenBusiness) {
		this.idenBusiness = idenBusiness;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getValueOne() {
		return valueOne;
	}

	public void setValueOne(String valueOne) {
		this.valueOne = valueOne;
	}

	public String getTaxOne() {
		return taxOne;
	}

	public void setTaxOne(String taxOne) {
		this.taxOne = taxOne;
	}

	public String getAdditionalFieldOne() {
		return additionalFieldOne;
	}

	public void setAdditionalFieldOne(String additionalFieldOne) {
		this.additionalFieldOne = additionalFieldOne;
	}

	public String getAdditionalFieldTwo() {
		return additionalFieldTwo;
	}

	public void setAdditionalFieldTwo(String additionalFieldTwo) {
		this.additionalFieldTwo = additionalFieldTwo;
	}

	public String getAdditionalFieldThree() {
		return additionalFieldThree;
	}

	public void setAdditionalFieldThree(String additionalFieldThree) {
		this.additionalFieldThree = additionalFieldThree;
	}

	public String getAdditionalFieldFour() {
		return additionalFieldFour;
	}

	public void setAdditionalFieldFour(String additionalFieldFour) {
		this.additionalFieldFour = additionalFieldFour;
	}

	public String getAdditionalFieldFive() {
		return additionalFieldFive;
	}

	public void setAdditionalFieldFive(String additionalFieldFive) {
		this.additionalFieldFive = additionalFieldFive;
	}

	public String getAdditionalFieldSix() {
		return additionalFieldSix;
	}

	public void setAdditionalFieldSix(String additionalFieldSix) {
		this.additionalFieldSix = additionalFieldSix;
	}

	public String getAdditionalFieldSeven() {
		return additionalFieldSeven;
	}

	public void setAdditionalFieldSeven(String additionalFieldSeven) {
		this.additionalFieldSeven = additionalFieldSeven;
	}

	public String getAdditionalFieldEight() {
		return additionalFieldEight;
	}

	public void setAdditionalFieldEight(String additionalFieldEight) {
		this.additionalFieldEight = additionalFieldEight;
	}

	public String getAdditionalFieldNine() {
		return additionalFieldNine;
	}

	public void setAdditionalFieldNine(String additionalFieldNine) {
		this.additionalFieldNine = additionalFieldNine;
	}

	public String getExpirationDateOne() {
		return expirationDateOne;
	}

	public void setExpirationDateOne(String expirationDateOne) {
		this.expirationDateOne = expirationDateOne;
	}

	public String getValueTwo() {
		return valueTwo;
	}

	public void setValueTwo(String valueTwo) {
		this.valueTwo = valueTwo;
	}

	public String getTaxTwo() {
		return taxTwo;
	}

	public void setTaxTwo(String taxTwo) {
		this.taxTwo = taxTwo;
	}

	public String getExpirationDateTwo() {
		return expirationDateTwo;
	}

	public void setExpirationDateTwo(String expirationDateTwo) {
		this.expirationDateTwo = expirationDateTwo;
	}

	public String getValueThree() {
		return valueThree;
	}

	public void setValueThree(String valueThree) {
		this.valueThree = valueThree;
	}

	public String getTaxThree() {
		return taxThree;
	}

	public void setTaxThree(String taxThree) {
		this.taxThree = taxThree;
	}

	public String getExpirationDateThree() {
		return expirationDateThree;
	}

	public void setExpirationDateThree(String expirationDateThree) {
		this.expirationDateThree = expirationDateThree;
	}

	public String getValueFour() {
		return valueFour;
	}

	public void setValueFour(String valueFour) {
		this.valueFour = valueFour;
	}

	public String getTaxFour() {
		return taxFour;
	}

	public void setTaxFour(String taxFour) {
		this.taxFour = taxFour;
	}

	public String getExpirationDateFour() {
		return expirationDateFour;
	}

	public void setExpirationDateFour(String expirationDateFour) {
		this.expirationDateFour = expirationDateFour;
	}

	@Override
	public String toString() {
		return  idenType + ";" + idenNumber + ";" + description + ";" + idenBusiness + ";" + invoiceNumber + ";" + valueOne + ";"
				+ taxOne + ";" + additionalFieldOne + ";" + additionalFieldTwo + ";" + additionalFieldThree + ";" + additionalFieldFour + ";" 
				+ additionalFieldFive + ";" + additionalFieldSix + ";" + additionalFieldSeven + ";" + additionalFieldEight + ";" + additionalFieldNine + ";"
				+ expirationDateOne + ";" + valueTwo + ";" + taxTwo + ";" + expirationDateTwo + ";" + valueThree + ";" + taxThree + ";" + expirationDateThree + ";"
				+ valueFour + ";" + taxFour + ";" + expirationDateFour + ";";
	}
	
}
