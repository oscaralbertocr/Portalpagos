package co.com.ath.recaudadores.apirest.model.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dao.IMedioPagoDAO;
import co.com.ath.recaudadores.apirest.model.dto.MedioPagoDTO;
import co.com.ath.recaudadores.apirest.model.entities.MedioPago;
import co.com.ath.recaudadores.apirest.model.services.IMedioPagoService;
import co.com.ath.recaudadores.apirest.util.Constants;

@Service
public class MedioPagoServiceImpl implements IMedioPagoService {
	static Logger logger = LoggerFactory.getLogger(MedioPagoServiceImpl.class);

	@Autowired
	private IMedioPagoDAO medioPagoDao;

	@Override
	public List<MedioPagoDTO> findAll() {
		List<MedioPago> lst = (List<MedioPago>) medioPagoDao.findAll();
		List<MedioPagoDTO> listaMedioPago = new ArrayList<>();
		if (lst.size() > 0) {
			MedioPagoDTO medioPagoDTO = new MedioPagoDTO();
			for (MedioPago m : lst) {
				listaMedioPago.add(m.toMedioPagoDTO());
			}
			// sin medios de pago
			medioPagoDTO = new MedioPagoDTO();
			medioPagoDTO.setId(Constants.ID_SIN_MEDIO_PAGO);
			medioPagoDTO.setNombre(Constants.SIN_MEDIO_PAGO_TXT);
			listaMedioPago.add(medioPagoDTO);
			
			// Todos
			medioPagoDTO = new MedioPagoDTO();
			medioPagoDTO.setId(Constants.TODOS_ID);
			medioPagoDTO.setNombre(Constants.MEDIOS_PAGO_TODOS_TXT);
			listaMedioPago.add(medioPagoDTO);
		}
		return listaMedioPago;
	}

}
