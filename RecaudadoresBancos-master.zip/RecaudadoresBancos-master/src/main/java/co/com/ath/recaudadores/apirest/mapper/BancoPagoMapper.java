package co.com.ath.recaudadores.apirest.mapper;

import java.util.ArrayList;
import java.util.List;

import co.com.ath.recaudadores.apirest.model.dto.BancoPagoDTO;
import co.com.ath.recaudadores.apirest.model.entities.BancoPago;

public class BancoPagoMapper {
	
	private BancoPagoMapper() {}
	
	public static List<BancoPagoDTO> mapListEntityToDto(List<BancoPago> bancos) {
		List<BancoPagoDTO> bancosDto = new ArrayList<BancoPagoDTO>();
		if (bancos != null && !bancos.isEmpty()) {
			for (BancoPago banco : bancos) {
				bancosDto.add(mapEntityToDto(banco));
			}
		}
		return bancosDto;
	}
	
	public static BancoPagoDTO mapEntityToDto(BancoPago banco) {
		BancoPagoDTO bancoPagoDto = null;
		if(banco != null) {
			bancoPagoDto = new BancoPagoDTO();
			bancoPagoDto.setBncId(banco.getBncId());
			bancoPagoDto.setBncNombre(banco.getBncNombre());
		}
		return bancoPagoDto;
	}
	
}
