package co.com.ath.recaudadores.apirest.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Service;

@Service
public class StringsUtil {
	
	public String deleteFilled(String field) {
		field = field.trim();
		StringBuilder result = new StringBuilder("");
		boolean flag = false;
		for(char c : field.toCharArray()) {
			if(c != '0' || flag) {
				result = result.append(c);
				flag = true;
			}
		}
		return result.toString();
	}
	
	/**
	 * Second sign for method to not change the actual references
	 * @param campo value being validated
	 * @param caracteres length that campo must have
	 * @return
	 * @throws CustomException
	 */
	public String obtain(String campo, int caracteres) throws CustomException {
		return obtain(campo, caracteres, false);
	}	
	
	/**
	 * 
	 * @param campo campo value being validated
	 * @param caracteres length that campo must have
	 * @param valuesNoDecimal Indicates if the method should allow a difference in two characters for values that have decimals 
	 * @return
	 * @throws CustomException
	 */
	public String obtain(String campo, int caracteres, boolean valuesNoDecimal) throws CustomException{
		int a = campo.length()-caracteres;
		if((a>0) && (valuesNoDecimal && a>2)) {
			throw new CustomException(Constants.LENGHT_INVALID);
		}else {
			if (valuesNoDecimal) {
				return campo.substring(0, caracteres);
			}
			return campo;
		}
	}
	
	public String fillC(String campo, int cantidad, String ch) {
		int a;
		if(campo != null) {
			a = cantidad - campo.length();
		}else {
			campo = "";
			a = cantidad;
		}
		StringBuilder line = new StringBuilder();
		for (int i = 0; i < a; i++) {
			line.append(ch);
		}
		line.append(campo);
		return line.toString();
	}
	
	public String getDate() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		return sdf.format(new Date());
	}

	public String getHour() {
		SimpleDateFormat sdf = new SimpleDateFormat("HHmm");
		return sdf.format(new Date());
	}
	
}
