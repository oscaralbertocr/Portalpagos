package co.com.ath.recaudadores.apirest.util;

import java.io.Serializable;

public class ConsultaFacturacionFiltro implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nuraConvenio;
	private String fechaDesde;
	private String fechaHasta;

	public ConsultaFacturacionFiltro() {
	}

	public String getNuraConvenio() {
		return nuraConvenio;
	}

	public void setNuraConvenio(String nuraConvenio) {
		this.nuraConvenio = nuraConvenio;
	}

	public String getFechaDesde() {
		return fechaDesde;
	}

	public void setFechaDesde(String fechaDesde) {
		this.fechaDesde = fechaDesde;
	}

	public String getFechaHasta() {
		return fechaHasta;
	}

	public void setFechaHasta(String fechaHasta) {
		this.fechaHasta = fechaHasta;
	}

}
