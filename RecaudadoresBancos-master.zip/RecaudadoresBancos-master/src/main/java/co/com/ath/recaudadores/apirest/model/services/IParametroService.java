package co.com.ath.recaudadores.apirest.model.services;

import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.dto.ParametroDTO;

/*
 * Clase : IParametroService
 * Date  : 18-Nov-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Transactional(value = "prvTransactionManager")
public interface IParametroService {
	
	public ParametroDTO save(ParametroDTO parametroDTO);
	
	public ParametroDTO find(String clave);

}
