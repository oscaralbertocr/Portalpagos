package co.com.ath.recaudadores.apirest.manager;

import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.dto.ArchivoInputDTO;
import co.com.ath.recaudadores.apirest.model.dto.ArchivoOutputDTO;
import co.com.ath.recaudadores.apirest.util.AbortUtil;

/**
 * Proceso para la gestion de los archivos cargados
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 07/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 

@Service
public class FileManager {

	static Logger logger = LoggerFactory.getLogger(FileManager.class);
	
	private final String jobName = "UploadFile";

	private final String stepName = "ConvertUploadFile";

	private final String stepEncrypt = "CipherUploadFile";
	
	private final String stepDelete = "DeleteUploadFile";
	
	private final String stepAudit = "AuditResult";

	private Job job;
	
	@Autowired(required=true)
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired(required=true)
	private JobLauncher jobLauncher;
	
	@Autowired(required=true)
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired(required=true)
	private FileInput fileInput;
	
	@Autowired(required=true)
	private FileValidate fileValidate;
	
	@Autowired(required=true)
	private FileOutput fileOutput;
	
	@Autowired(required=true)
	private EncryptTasklet encryptTasklet;
	
	@Autowired(required=true)
	private DeleteFileTasklet deleteFileTasklet;
	
	@Autowired(required=true)
	private AbortUtil abortUtil;
	
	@Autowired(required=true)
	private AuditTask auditTask;
	
	@Transactional(value = "transactionManager" , propagation = Propagation.NOT_SUPPORTED)
	public void run(Map<String, String> parameters) {
		JobParametersBuilder jobParametersBuilder = this.getParameters(parameters);
		this.execute(jobParametersBuilder);
	}
	
	@PostConstruct
	public void init() {
		this.job = this.createJob();
	}
	
	private Job createJob() {
		return this.jobBuilderFactory.get(this.jobName)
				.listener(abortUtil)
				.flow(this.createStep())
				.next(this.cipherTask())
				.next(this.deleteFileTask())
				.next(this.auditResultTask())
				.end()
				.build();
	}
	
	private Step createStep() {
		return this.stepBuilderFactory.get(this.stepName)
				.<ArchivoInputDTO, ArchivoOutputDTO> chunk(100)
				.reader(fileInput)
				.processor(fileValidate)
				.writer(fileOutput)
				.build();
	}
	
	private Step cipherTask() {
		return this.stepBuilderFactory.get(this.stepEncrypt)
				.tasklet(this.encryptTasklet)
				.build();
	}
	
	private Step deleteFileTask() {
		return this.stepBuilderFactory.get(this.stepDelete)
				.tasklet(this.deleteFileTasklet)
				.build();
	}
	
	private Step auditResultTask() {
		return this.stepBuilderFactory.get(this.stepAudit)
				.tasklet(this.auditTask)
				.build();
	}
	
	private JobExecution execute(JobParametersBuilder parameters) {
		try {
			return this.jobLauncher.run(this.job, parameters.toJobParameters());
		}catch (Exception e) {
			logger.error(e.getMessage());
			return null;
		}
	}
	
	private JobParametersBuilder getParameters(Map<String, String> hashMap) {
		JobParametersBuilder jpb = new JobParametersBuilder();
		jpb.addLong("time", System.currentTimeMillis());
		jpb.addString("pathInput",hashMap.get("pathInput"));
		jpb.addString("fileNameInput",hashMap.get("fileNameInput"));
		jpb.addString("fileOriginalName",hashMap.get("fileOriginalName"));
		jpb.addString("pathOutput",hashMap.get("pathOutput"));
		jpb.addString("fileNameOutput",hashMap.get("fileNameOutput"));
		jpb.addString("keyPublicPGP",hashMap.get("keyPublicPGP"));
		jpb.addString("messageTo",hashMap.get("messageTo"));
		jpb.addString("urlFileStructure",hashMap.get("urlFileStructure"));
		jpb.addString("messageContentSuccess",hashMap.get("messageContentSuccess"));
		jpb.addString("messageContentError",hashMap.get("messageContentError"));
		jpb.addString("idConvenio",hashMap.get("idConvenio"));
		jpb.addString("nit", hashMap.get("nit").trim());
		jpb.addString("ean", hashMap.get("ean"));
		jpb.addString("fileSize",hashMap.get("fileSize"));
		jpb.addString("userNickName",hashMap.get("userNickName"));
		jpb.addString("ciclo",hashMap.get("ciclo"));
		jpb.addString("userFullName",hashMap.get("userFullName"));
		return jpb;
	}
	
}
