package co.com.ath.recaudadores.apirest.util;

import java.io.InputStream;
import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
/**
 * Permite la conexion a un recurso FTP, SSH,
 *
 *
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 16/15/2019
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
 */ 
public class FTPconnection {

	static Logger LOGGER = LoggerFactory.getLogger(FTPconnection.class);	

	private ChannelSftp connSSH = null;

	@SuppressWarnings("unused")
	private String directory = null;

	private Integer port = (Integer) null;

	private String server;

	private String userName;

	private String password;


	/**
	 * inicializa los parametros para la conexion al recurso.
	 * @param server
	 * 			Servidor al que se desea conectar
	 * @param username
	 * 			usuario registrado para la conexion
	 * @param conexion
	 * 			contraseña para establecer la conexion
	 * @param directory
	 * 			ruta dentro del servidor FTP desde donde se desea descargar los archivos
	 * @param port
	 * 			puerto requerido para establecer la conexion
	 * @param mode
	 * 			tipo de conexion a establecer, 0: SFTP, FTP; 1: SSH
	 */
	public FTPconnection(String server,String username,String password,String directory,String port) throws Exception {
		this.server = server;
		this.userName = username;
		this.password = password;
		this.directory = directory;
		this.port = Integer.parseInt(port);
		try {
			this.connectOnSSH();
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}
	}


	/**
	 * Realiza la conexión a un recurso SSH.
	 */
	private void connectOnSSH() throws Exception {
		Channel channel = null;
		try {
			JSch jsch = new JSch();
			Session session = jsch.getSession( this.userName, this.server, this.port );
			//			
			session.setPassword(password);

			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);

			session.connect();

			channel = session.openChannel("sftp");
			channel.connect();

			LOGGER.info("Conectado al SFTP ");
			connSSH = (ChannelSftp) channel;

			SftpATTRS attrs = null;
			try {
				attrs = connSSH.stat(this.directory);
			} catch (Exception e) {
				LOGGER.info("basePath" + " not found");
			}

			if (attrs != null) {
				LOGGER.info("Directory exists IsDir=" + attrs.isDir());
			} 

			connSSH.cd(this.directory);

		} catch (Exception e) {
			LOGGER.error("Error al tratar de conectar con el servidor SSH: "+ e.getMessage());
			//			throw new Exception("Error al tratar de conectar con el servidor SSH: "+ e.getMessage());
		}
	}

	/**
	 * Lista los archivos destro de la carpeta actual del FTP.
	 */
	public ArrayList<LsEntry> listFiles(String chain){
		try {
			LOGGER.info("Directory is " + this.connSSH.pwd());
			ArrayList<?> filelist = new ArrayList<>(this.connSSH.ls(chain));
			ArrayList<LsEntry> vector = new ArrayList<>();
			for(int i=0; i<filelist.size();i++){
				LsEntry entry = (LsEntry) filelist.get(i);
				vector.add(entry);
			}
			return vector;
		} catch (Exception e) {
			LOGGER.error(e.toString());
		}
		return null;
	}


	/**
	 * Descarga un archivo de la conexion actual, y lo ubica en una ruta especifica.
	 * 
	 * @param
	 * 		destination
	 * 				carpeta de destino donde se colocara el archivo descargado
	 * 		fileToDownload
	 * 				Nombre del archivo que se debe descargar
	 * @throws CustomException 
	 */
	public InputStream downloadFile(String fileToDownload) throws CustomException{
		try {
			LOGGER.info("Se descargara desde la carpeta: " + this.connSSH.pwd());
			LOGGER.info("El archivo: " + fileToDownload);
			LOGGER.info(this.connSSH.pwd() + fileToDownload);
			return this.connSSH.get(fileToDownload);
		} catch (SftpException | NullPointerException e) {
			LOGGER.info("Error en la Carga");
			LOGGER.error(e.getMessage());
			LOGGER.error(e.getLocalizedMessage());
			throw new CustomException(Constants.FTP_ERROR);
		}
	}

	/**
	 * Descarga un archivo de la conexion actual, y lo ubica en una ruta especifica.
	 * 
	 * @param
	 * 		destination
	 * 				carpeta de destino donde se colocara el archivo descargado
	 * 		fileToDownload
	 * 				Nombre del archivo que se debe descargar
	 * @throws CustomException 
	 */
	public void uploadFile(String file, String dirFTP) throws CustomException{
		try {
			LOGGER.info("Se cargara a la carpeta: " + this.connSSH.pwd());
			LOGGER.info("El archivo: " + file);
			LOGGER.info("La carpeta: " + dirFTP);
			LOGGER.info(this.connSSH.pwd() + file);
			this.connSSH.put(file,dirFTP);
		} catch (SftpException | NullPointerException e) {
			LOGGER.info("Error en la Carga");
			LOGGER.error(e.getMessage());
			LOGGER.error(e.getLocalizedMessage());
			throw new CustomException(Constants.FTP_ERROR);
		}
	}
	
	public void uploadFile(String file, String dirFTP, String directoryDate) throws CustomException{
		try {
			LOGGER.info("SobreCarga");
			if(directoryDate != null) {
				try {
					this.connSSH.cd(directoryDate); 
					LOGGER.info(directoryDate + " --> Carpeta Encontrada");
				} catch (SftpException e) {
					LOGGER.info(directoryDate + " --> Carpeta NO Encontrada");
					LOGGER.info("Creando la carpeta -->" + directoryDate);
					this.connSSH.mkdir(directoryDate); 
					LOGGER.info("Cambiando directorio: " + this.connSSH.pwd() + "--->" + directoryDate);
					this.connSSH.cd(directoryDate); 
				}
			}
			LOGGER.info("Se cargara a la carpeta: " + this.connSSH.pwd());
			LOGGER.info("El archivo: " + file);
			LOGGER.info(this.connSSH.pwd() + " <----> " + file);
			this.connSSH.put(file, this.connSSH.pwd());
			this.connSSH.cd(".."); 
		} catch (SftpException | NullPointerException e) {
			LOGGER.info("Error en la Carga");
			LOGGER.error(e.getMessage());
			LOGGER.error(e.getLocalizedMessage());
			e.printStackTrace();
			throw new CustomException(Constants.FTP_ERROR);
		}
	}

	/**
	 * Cierra la conexion.
	 */
	public void close() {
		try {
			this.connSSH.disconnect();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Verifica si existe un archivo en el servidor
	 */
	public boolean existsFile(String fileToDownload) {
		boolean existe = false;
		try {
			SftpATTRS fileList = this.connSSH.stat(fileToDownload);
			if (fileList != null) {
				existe = true;
			}
			return existe;
		} catch (Exception e) {
			LOGGER.error(e.toString());
			return false;
		}
	}

}