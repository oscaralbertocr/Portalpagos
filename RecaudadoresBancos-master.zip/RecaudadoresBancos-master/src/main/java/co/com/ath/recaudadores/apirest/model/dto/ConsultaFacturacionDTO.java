package co.com.ath.recaudadores.apirest.model.dto;

import java.io.Serializable;

public class ConsultaFacturacionDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nuraConvenio;
	private String nombreOriginal;
	private String ciclo;
	private String fechaCarga;
	private String tamano;
	private String estado;

	public ConsultaFacturacionDTO() {

	}

	public String getNuraConvenio() {
		return nuraConvenio;
	}

	public void setNuraConvenio(String nuraConvenio) {
		this.nuraConvenio = nuraConvenio;
	}

	public String getNombreOriginal() {
		return nombreOriginal;
	}

	public void setNombreOriginal(String nombreOriginal) {
		this.nombreOriginal = nombreOriginal;
	}

	public String getCiclo() {
		return ciclo;
	}

	public void setCiclo(String ciclo) {
		this.ciclo = ciclo;
	}

	public String getFechaCarga() {
		return fechaCarga;
	}

	public void setFechaCarga(String fechaCarga) {
		this.fechaCarga = fechaCarga;
	}

	public String getTamano() {
		return tamano;
	}

	public void setTamano(String tamano) {
		this.tamano = tamano;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	@Override
	public String toString() {
		return "ConsultaFacturacionDTO [nuraConvenio=" + nuraConvenio + ", nombreOriginal=" + nombreOriginal
				+ ", ciclo=" + ciclo + ", fechaCarga=" + fechaCarga + ", tamano=" + tamano + ", estado=" + estado + "]";
	}

}
