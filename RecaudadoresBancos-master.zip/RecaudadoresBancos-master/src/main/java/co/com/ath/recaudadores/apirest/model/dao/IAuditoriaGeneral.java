package co.com.ath.recaudadores.apirest.model.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.entities.AuditoriaGeneral;


@Transactional(value = "prvTransactionManager", readOnly = true)
public interface IAuditoriaGeneral extends JpaRepository<AuditoriaGeneral, String> {

}
