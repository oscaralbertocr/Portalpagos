package co.com.ath.recaudadores.apirest.model.entities;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import co.com.ath.recaudadores.apirest.model.dto.ConsultaFacturacionDTO;

@Entity
@Table(name = "ARCHIVO_FACTURACION")
public class Facturacion implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "AF_ID", nullable = false)
	private Long id;

	@Column(name = "AF_CONVENIO_ID")
	private String convenio;

	@Column(name = "AF_NOMBRE_ORIGINAL", nullable = false)
	private String nombreOriginal;

	@Column(name = "AF_NOMBRE_ATH", nullable = false)
	private String nombreAth;

	@Column(name = "AF_FECHA_CARGA", nullable = false)
	private Date fechaCarga;

	@Column(name = "AF_TAMANO", nullable = false)
	private String tamano;

	@Column(name = "AF_USUARIO", nullable = false)
	private String usuario;

	@Column(name = "AF_ENVIO_PAYCENTRAL", nullable = false)
	private char envioPaycentral;

	@Column(name = "AF_ESTADO_PAYCENTRAL")
	private String estado;

	@Column(name = "AF_ACCION")
	private String accion;

	@Column(name = "AF_COMENTARIOS")
	private String comentarios;

	@Column(name = "AF_CICLO")
	private String ciclo;

	@Column(name = "AF_CORREO_USUARIO")
	private String correo;

	@Column(name = "AF_NOMBRE_USUARIO")
	private String nombreUsuario;

	@Column(name = "AF_HASH")
	private String hash;

	public Facturacion() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getConvenio() {
		return convenio;
	}

	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}

	public String getNombreOriginal() {
		return nombreOriginal;
	}

	public void setNombreOriginal(String nombreOriginal) {
		this.nombreOriginal = nombreOriginal;
	}

	public String getNombreAth() {
		return nombreAth;
	}

	public void setNombreAth(String nombreAth) {
		this.nombreAth = nombreAth;
	}

	public Date getFechaCarga() {
		return fechaCarga;
	}

	public void setFechaCarga(Date fechaCarga) {
		this.fechaCarga = fechaCarga;
	}

	public String getTamano() {
		return tamano;
	}

	public void setTamano(String tamano) {
		this.tamano = tamano;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public char getEnvioPaycentral() {
		return envioPaycentral;
	}

	public void setEnvioPaycentral(char envioPaycentral) {
		this.envioPaycentral = envioPaycentral;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getAccion() {
		return accion;
	}

	public void setAccion(String accion) {
		this.accion = accion;
	}

	public String getComentarios() {
		return comentarios;
	}

	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}

	public String getCiclo() {
		return ciclo;
	}

	public void setCiclo(String ciclo) {
		this.ciclo = ciclo;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getNombreUsuario() {
		return nombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	@Override
	public String toString() {
		return "Facturacion [id=" + id + ", convenio=" + convenio + ", nombreOriginal=" + nombreOriginal
				+ ", nombreAth=" + nombreAth + ", fechaCarga=" + fechaCarga + ", tamano=" + tamano + ", usuario="
				+ usuario + ", envioPaycentral=" + envioPaycentral + ", estado=" + estado + ", accion=" + accion
				+ ", comentarios=" + comentarios + ", ciclo=" + ciclo + ", correo=" + correo + ", nombreUsuario="
				+ nombreUsuario + ", hash=" + hash + "]";
	}

	/**
	 * @return
	 */
	public ConsultaFacturacionDTO toConsultaConvenioDTO() {
		ConsultaFacturacionDTO consulta = new ConsultaFacturacionDTO();
		SimpleDateFormat formatoFecha = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss aa");

		String fechaString = formatoFecha.format(fechaCarga);
		consulta.setNuraConvenio(convenio);
		consulta.setNombreOriginal(nombreOriginal);
		consulta.setFechaCarga(fechaString);
		consulta.setEstado(estado);
		consulta.setCiclo(ciclo);
		consulta.setTamano(tamano);
		return consulta;

	}

}
