package co.com.ath.recaudadores.apirest.model.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import co.com.ath.recaudadores.apirest.model.dto.MedioPagoDTO;

/*
 * Clase : MedioPago
 * Date  : 21-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Entity
@Table(name = "MEDIO_PAGO")
public class MedioPago implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "MP_ID", nullable = false)
	private Long id;

	@Column(name = "MP_MEDIO_PAGO", nullable = false)
	private String nombre;

	public MedioPago() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "MedioPago [id=" + id + ", nombre=" + nombre + "]";
	}

	/**
	 * @return
	 */
	public MedioPagoDTO toMedioPagoDTO() {
		MedioPagoDTO medio = new MedioPagoDTO();
		medio.setId(this.id);
		medio.setNombre(this.nombre);
		return medio;
	}

	private static final long serialVersionUID = 1L;
}
