package co.com.ath.recaudadores.apirest.controllers;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import co.com.ath.recaudadores.apirest.util.UserRequest;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@RestController
@RequestMapping("/usuarios")
public class UsuariosRestController {

	@PostMapping("/user")
	public String login(@RequestBody UserRequest username) {
		return getJWTToken(username.getUser());
	}

	private String getJWTToken(String username) {
		String secretKey = "mySecretKey";
		List<GrantedAuthority> grantedAuthorities = AuthorityUtils.commaSeparatedStringToAuthorityList("ROLE_USER");

		String token = Jwts.builder().setId("softtekJWT").setSubject(username)
				.claim("authorities", getAuthorities(grantedAuthorities))
				.setIssuedAt(new Date(System.currentTimeMillis()))
				.setExpiration(new Date(System.currentTimeMillis() + 86400000))
				.signWith(SignatureAlgorithm.HS512, secretKey.getBytes()).compact();

		return "Bearer " + token;
	}

	private List<String> getAuthorities(List<GrantedAuthority> grantedAuthorities) {
		List<String> authorities = new ArrayList<String>();
		if (grantedAuthorities != null) {
			for (GrantedAuthority grant : grantedAuthorities) {
				authorities.add(grant.getAuthority());
			}
		}
		return authorities;
	}

}
