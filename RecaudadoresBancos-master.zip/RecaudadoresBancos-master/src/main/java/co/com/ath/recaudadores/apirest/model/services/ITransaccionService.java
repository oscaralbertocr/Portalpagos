package co.com.ath.recaudadores.apirest.model.services;

import java.util.List;

import org.json.JSONArray;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.dto.TransaccionConsultaDTO;
import co.com.ath.recaudadores.apirest.util.FilterTransaccion;

@Transactional(value = "prvTransactionManager")
public interface ITransaccionService {
	
	public JSONArray getTxByFilters(FilterTransaccion filter) throws Exception;
	
	public List<TransaccionConsultaDTO> getAllTxByFilter(FilterTransaccion filter) throws Exception;

}
