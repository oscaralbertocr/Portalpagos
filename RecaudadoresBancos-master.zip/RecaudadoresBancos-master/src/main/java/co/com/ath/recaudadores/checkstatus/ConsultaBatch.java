package co.com.ath.recaudadores.checkstatus;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.entities.ArchivoFacturacion;
import co.com.ath.recaudadores.apirest.model.services.IParametroService;

/**
*
* @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
* @version 1.0 12/05/2021
* 
* @sophosSolutions
* <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
* <strong>Numero de Cambios: </strong>0</br>
* 	
*/ 

@Service
public class ConsultaBatch {
	
	static Logger logger = LoggerFactory.getLogger(ConsultaBatch.class);
	
	private final String jobName = "CONSULTA_PAYBILL_PROCESS";

	private Job job;
	
	@Autowired(required=true)
	private JobBuilderFactory jobBuilderFactory;

	@Autowired(required=true)
	private JobLauncher jobLauncher;

	@Autowired(required=true)
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private CheckStatusItemReader checkStatusReader;

	@Autowired
	private CheckStatusItemProcessor checkStatusProcessor;
	
	@Autowired
	private CheckStatusWriter checkStatusWriter;
	
	@Autowired
	private IParametroService parametroService;
	
	private String attempsCheck;
	
	private String gatewayPaymentInvoiceEndPoint;
	
	private String gatewayPaymentInvoiceConnectionTimeout;
	
	private String gatewayPaymentInvoiceRequestTimeout;
	
	@Transactional(value = "transactionManager" , propagation = Propagation.NOT_SUPPORTED)
	@Scheduled(cron="#{@getCronValue}")
	public void autoRun() {
		logger.info("Inicio de Cron ConsultaBatch");
		this.execute();
	}
	
	@PostConstruct
	public void init() {
		this.attempsCheck = parametroService.find("NumberOfQueriesFileStatusInBillPay").getValor();
		this.gatewayPaymentInvoiceEndPoint = parametroService.find("GatewayPaymentInvoiceEndPoint").getValor();
		this.gatewayPaymentInvoiceConnectionTimeout = parametroService.find("GatewayPaymentInvoiceConnectionTimeout").getValor();
		this.gatewayPaymentInvoiceRequestTimeout = parametroService.find("GatewayPaymentInvoiceRequestTimeout").getValor();
		this.job = this.generateJob();
	}
	
	private JobExecution execute() {
		try {
			logger.info("INICIO DE SONDA DE CONSULTA DE ESTADO EN BILLPAY");
			JobParametersBuilder jobParams = new JobParametersBuilder();
			jobParams.addLong("time", System.currentTimeMillis());
			jobParams.addString("attempsCheck", this.attempsCheck);
			jobParams.addString("gatewayPaymentInvoiceEndPoint", this.gatewayPaymentInvoiceEndPoint);
			jobParams.addString("gatewayPaymentInvoiceConnectionTimeout", this.gatewayPaymentInvoiceConnectionTimeout);
			jobParams.addString("gatewayPaymentInvoiceRequestTimeout", this.gatewayPaymentInvoiceRequestTimeout);
			return this.jobLauncher.run(job, jobParams.toJobParameters());
		} catch (Exception e) {
			logger.error("ERROR EJECUTANDO EL PROCESO DE CONSULTA DE ESTADO EN BILLPAY");
			logger.error(e.getMessage());
			return null;
		}
	}
	
	private Job generateJob() {
		return this.jobBuilderFactory.get(this.jobName)
				.incrementer(new RunIdIncrementer())
				.start(this.generateStep())
				.build();
	}

	private Step generateStep(){
		return this.stepBuilderFactory.get("STEP_POCCESS_CHECKSTATUS")
				.<ArchivoFacturacion, ArchivoFacturacion> chunk(100)
				.reader(this.checkStatusReader)
				.processor(this.checkStatusProcessor)
				.writer(this.checkStatusWriter)
				.faultTolerant()
				.build();
	}
	
}
