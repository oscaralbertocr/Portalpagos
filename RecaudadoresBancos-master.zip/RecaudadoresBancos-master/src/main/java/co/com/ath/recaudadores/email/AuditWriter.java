package co.com.ath.recaudadores.email;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.persistence.EntityManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.database.JpaItemWriter;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.entities.ArchivoFacturacion;

/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 

@Service
@StepScope
public class AuditWriter extends JpaItemWriter<ArchivoFacturacion>{
	
	static Logger logger = LoggerFactory.getLogger(AuditWriter.class);
	
	@Resource
	private EntityManagerFactory entityManagerFactory;
	
	@PostConstruct
	public void init() {
		this.setEntityManagerFactory(entityManagerFactory);
	}

}
