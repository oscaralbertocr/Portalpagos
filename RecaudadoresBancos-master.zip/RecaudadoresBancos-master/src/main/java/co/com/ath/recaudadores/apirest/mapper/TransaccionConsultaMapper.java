package co.com.ath.recaudadores.apirest.mapper;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import co.com.ath.recaudadores.apirest.model.dto.TransaccionConsultaDTO;
import co.com.ath.recaudadores.apirest.model.entities.Transaccion;

public class TransaccionConsultaMapper {
	
	private TransaccionConsultaMapper() {}
	
	public static List<TransaccionConsultaDTO> mapListEntityToDto(List<Transaccion> transacciones) {
		List<TransaccionConsultaDTO> transaccionesDto = new ArrayList<TransaccionConsultaDTO>();
		if (transacciones != null && !transacciones.isEmpty()) {
			for (Transaccion transaccion : transacciones) {
				transaccionesDto.add(mapEntityToDto(transaccion));
			}
		}
		return transaccionesDto;
	}
	
	public static TransaccionConsultaDTO mapEntityToDto(Transaccion transaccion) {
		TransaccionConsultaDTO transaccionDto = null;
		if (transaccion != null) {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			
			transaccionDto = new TransaccionConsultaDTO();
			transaccionDto.setNombreConvenio(ConvenioMapper.mapEntityToDto(transaccion.getConvenio()).getNombre());
			transaccionDto.setReferencias(ReferenciaTxMapper.mapListEntityToDto(transaccion.getReferenciaTxs()));
			transaccionDto.setValor(transaccion.getValor());
			transaccionDto.setBancoAutorizacion(transaccion.getBankName());
			transaccionDto.setNumAutorizacion(transaccion.getNumAuth());
			transaccionDto.setCorreo(transaccion.getEmailCliente());
			transaccionDto.setNombre(transaccion.getNombreCliente() + " " + transaccion.getApellidoCliente());
			transaccionDto.setIp(transaccion.getIpCliente());
			transaccionDto.setFechaPago(format.format(transaccion.getFechaInicioPago()) + " 00:00");
			transaccionDto.setEstado(EstadoTransaccionMapper.mapEntityToDto(transaccion.getEstadoTx()).getNombre());
			transaccionDto.setTipoPago(MedioPagoMapper.mapEntityToDto(transaccion.getMedioPago()) != null ? 
					MedioPagoMapper.mapEntityToDto(transaccion.getMedioPago()).getNombre() : "");
			transaccionDto.setCiclo(transaccion.getCicloAch());
			transaccionDto.setObservaciones(transaccion.getComentario());
			transaccionDto.setConcepto(transaccion.getConceptoPago());
			transaccionDto.setIncocredito(transaccion.getConvenio().getConvenioInfo() != null ?
	    			transaccion.getConvenio().getConvenioInfo().getIncocredito(): "");

		}
		return transaccionDto;
	}

}
