package co.com.ath.recaudadores.apirest.model.services;

import java.util.List;

import co.com.ath.recaudadores.apirest.model.dto.AlertRecaudadorDTO;


public interface IAlertRecaudadorService {

	public AlertRecaudadorDTO save(AlertRecaudadorDTO alertRecaudadorDTO );

	public List<AlertRecaudadorDTO> findAll();
	
	public AlertRecaudadorDTO update(AlertRecaudadorDTO alertRecaudadorDTO);

	public AlertRecaudadorDTO find(String id);

	public void delete(AlertRecaudadorDTO alertRecaudadorDTO);

}
