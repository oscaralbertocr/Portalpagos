package co.com.ath.recaudadores.apirest.mapper;

import java.util.ArrayList;
import java.util.List;

import co.com.ath.recaudadores.apirest.model.dto.TransaccionDTO;
import co.com.ath.recaudadores.apirest.model.entities.Transaccion;

public class TransaccionMapper {
	
	private TransaccionMapper() {}
	
	public static List<TransaccionDTO> mapListEntityToDto(List<Transaccion> transacciones) {
		List<TransaccionDTO> transaccionesDto = new ArrayList<TransaccionDTO>();
		if (transacciones != null && !transacciones.isEmpty()) {
			for (Transaccion transaccion : transacciones) {
				transaccionesDto.add(mapEntityToDto(transaccion));
			}
		}
		return transaccionesDto;
	}
	
	public static TransaccionDTO mapEntityToDto(Transaccion transaccion) {
		TransaccionDTO transaccionDto = null;
		if (transaccion != null) {
			transaccionDto = new TransaccionDTO();
			transaccionDto.setId(transaccion.getId());
			transaccionDto.setBancoPortal(transaccion.getBancoPortal());
			transaccionDto.setFqrId(transaccion.getFqrId());
			transaccionDto.setMedioPago(MedioPagoMapper.mapEntityToDto(transaccion.getMedioPago()));
			transaccionDto.setNumDocumento(transaccion.getNumDocumento());
			transaccionDto.setApellidoCliente(transaccion.getApellidoCliente());
			transaccionDto.setAprobacionId(transaccion.getAprobacionId());
			transaccionDto.setAsociadaPorCorreo(transaccion.isAsociadaPorCorreo());
			transaccionDto.setBancoAch(transaccion.getBancoAch());
			transaccionDto.setBancoId(transaccion.getBancoId());
			transaccionDto.setBankName(transaccion.getBankName());
			transaccionDto.setComentario(transaccion.getComentario());
			transaccionDto.setCurCode(transaccion.getCurCode());
			transaccionDto.setEmailCliente(transaccion.getEmailCliente());
			transaccionDto.setFechaInicioPago(transaccion.getFechaInicioPago());
			transaccionDto.setFechaModifPago(transaccion.getFechaModifPago());
			transaccionDto.setFechaActualizacion(transaccion.getFechaActualizacion());
			transaccionDto.setIpCliente(transaccion.getIpCliente());
			transaccionDto.setNitCliente(transaccion.getNitCliente());
			transaccionDto.setNombreCliente(transaccion.getNombreCliente());
			transaccionDto.setNombrePagador(transaccion.getNombrePagador());
			transaccionDto.setNumAuth(transaccion.getNumAuth());
			transaccionDto.setNumTarjeta(transaccion.getNumTarjeta());
			transaccionDto.setPagoId(transaccion.getPagoId());
			transaccionDto.setRquId(transaccion.getRquId());
			transaccionDto.setTipoAporte(transaccion.getTipoAporte());
			transaccionDto.setTipoMoneda(transaccion.getTipoMoneda());
			transaccionDto.setToken(transaccion.getToken());
			transaccionDto.setPendienteMarcacion(transaccion.getPendienteMarcacion());
			transaccionDto.setValor(transaccion.getValor());
			transaccionDto.setUid(transaccion.getUid());
			transaccionDto.setUuidCpv(transaccion.getUuidCpv());
			transaccionDto.setDesErrorMarcacion(transaccion.getDesErrorMarcacion());
			transaccionDto.setBancoPago(BancoPagoMapper.mapEntityToDto(transaccion.getBancoPago()));
			transaccionDto.setConvenio(ConvenioMapper.mapEntityToDto(transaccion.getConvenio()));
			transaccionDto.setEstadoTx(EstadoTransaccionMapper.mapEntityToDto(transaccion.getEstadoTx()));
			transaccionDto.setIntencionPago(transaccion.getIntencionPago());
			transaccionDto.setTipoDocumento(TipoDocumentoMapper.mapEntityToDto(transaccion.getTipoDocumento()));
			transaccionDto.setConsultaComprobante(transaccion.isConsultaComprobante());
			transaccionDto.setCicloAch(transaccion.getCicloAch());
			transaccionDto.setIdCpv(transaccion.getIdCpv());
			transaccionDto.setTasaCambio(transaccion.getTasaCambio());
			transaccionDto.setTaquilla(transaccion.isTaquilla());
			transaccionDto.setErrorMarcacion(transaccion.getErrorMarcacion());
			transaccionDto.setReintentosMarcacion(transaccion.getReintentosMarcacion());
			transaccionDto.setFechaNextDay(transaccion.getFechaNextDay());
			transaccionDto.setConceptoPago(transaccion.getConceptoPago());
			transaccionDto.setUrlRespuestaCpv(transaccion.getUrlRespuestaCpv());
			transaccionDto.setReferenciaTxs(ReferenciaTxMapper.mapListEntityToDto(transaccion.getReferenciaTxs()));
		}
		return transaccionDto;
	}
	
	
}
