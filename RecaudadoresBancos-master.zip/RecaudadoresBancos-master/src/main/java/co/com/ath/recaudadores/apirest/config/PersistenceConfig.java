package co.com.ath.recaudadores.apirest.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Configuracion persistencia para el api
 * @author SophosSolutions
 * @version 1.0
 */
@Configuration
@ComponentScan(basePackages = {"co.com.ath.recaudadores.apirest.model.dao",
		"co.com.ath.recaudadores.apirest.model.entities",
		"co.com.ath.recaudadores.checkstatus",
		"co.com.ath.recaudadores.email"})
public class PersistenceConfig {


}
