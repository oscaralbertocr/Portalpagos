package co.com.ath.recaudadores.apirest.model.services.impl;

import java.sql.Clob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dao.IConvenioDAO;
import co.com.ath.recaudadores.apirest.model.dto.ConsultaConvenioDTO;
import co.com.ath.recaudadores.apirest.model.dto.ConvenioDTO;
import co.com.ath.recaudadores.apirest.model.services.IConvenioService;
import co.com.ath.recaudadores.apirest.util.Filtro;

/*
 * Clase : CategoriaServiceImpl
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Service
public class ConvenioServiceImpl implements IConvenioService {
	static Logger logger = LoggerFactory.getLogger(ConvenioServiceImpl.class);

	@Autowired
	private IConvenioDAO convenioDao;

	@Override
	public List<ConvenioDTO> findAll(int banco) {
		List<Object[]> lst = convenioDao.fetchAll();
		List<ConvenioDTO> lista = new ArrayList<>();
		ConvenioDTO convenioDTO;

		for (Object[] object : lst) {
			convenioDTO = new ConvenioDTO();
			convenioDTO.setId((String) object[0]);
			convenioDTO.setNombre((String) object[1]);
			convenioDTO.setCuentaRecaudo((String) object[2]);
			lista.add(convenioDTO);
		}

		return lista;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see co.com.ath.recaudadores.apirest.model.services.IConvenioService#
	 * consultaConvenios(co.com.ath.recaudadores.apirest.util.Filtro,
	 * org.springframework.data.domain.Pageable)
	 */
	@Override
	public List<ConsultaConvenioDTO> consultaConvenios(Filtro filtro, Pageable pageable) {
		String referencia;
		List<ConsultaConvenioDTO> lst = new ArrayList<>();

		filtro.setBanco(1);
		List<Object[]> page = convenioDao.consultaConvenios(filtro.getNuraConvenio(), filtro.getIdEstado(),
				filtro.getIdCategoria(), filtro.getCuentaRecaudo());

		for (Object[] o : page) {
			Clob clobValue = (Clob) o[13]; // lista de referencias
			try {
				referencia = "";
				if (clobValue != null) {
					referencia = clobValue.getSubString(1, (int) clobValue.length()).toString();
				}
				lst.add(new ConsultaConvenioDTO((String) o[0], (String) o[1], (String) o[2], (String) o[3],
						(String) o[4], (String) o[5], (String) o[6], (String) o[7], (String) o[8], (String) o[9],
						(String) o[10], (String) o[11], (String) o[12], referencia, (String) o[14], (String) o[15]));

			} catch (SQLException e) {
				logger.error(
						"Error al procesar, el resultado del @Query de [convenioDao.consultaConvenios] en [ConvenioServiceImpl.class]");
			}
		}
		return lst;
	}
}
