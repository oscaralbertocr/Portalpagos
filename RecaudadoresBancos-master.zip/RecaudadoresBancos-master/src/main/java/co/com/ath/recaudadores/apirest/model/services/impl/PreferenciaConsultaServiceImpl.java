package co.com.ath.recaudadores.apirest.model.services.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dao.IPreferenciaDAO;
import co.com.ath.recaudadores.apirest.model.dto.PreferenciaConsultaDTO;
import co.com.ath.recaudadores.apirest.model.entities.Preferencia;
import co.com.ath.recaudadores.apirest.model.services.IPreferenciaConsultaService;

/*
 * Clase : ParametriasConsultaServiceImpl
 * Date  : 24-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Service
public class PreferenciaConsultaServiceImpl implements IPreferenciaConsultaService {
	static Logger logger = LoggerFactory.getLogger(CategoriaServiceImpl.class);

	@Autowired
	private IPreferenciaDAO parametriaDAO;

	@Override
	public List<PreferenciaConsultaDTO> findAll(String convenio, String usuario) {

		List<PreferenciaConsultaDTO> lst = new ArrayList<>();

		// carga las parametrias
		List<Preferencia> lstParametrias = (List<Preferencia>) parametriaDAO.findAll();
		for (Preferencia p : lstParametrias) {
			PreferenciaConsultaDTO paramConsultaDTO = new PreferenciaConsultaDTO();
			paramConsultaDTO.setConvenio(convenio);
			paramConsultaDTO.setUsuario(usuario);
			paramConsultaDTO.setIdParametro(p.getId());
			paramConsultaDTO.setIdIdentificador(p.getIdentificador());
			paramConsultaDTO.setNombreParametro(p.getDescripcion());
			paramConsultaDTO.setEstado(0.0D);
			paramConsultaDTO.setActivo(p.getIdentificador()==1?true:false);
			lst.add(paramConsultaDTO);
		}

		// valida si el cliente tiene parametrias
		List<Object[]> lstObject = parametriaDAO.getPreferencias(convenio, usuario);
		if (lstObject != null && !lstObject.isEmpty()) {
			PreferenciaConsultaDTO paramConsultaDTO;
			List<PreferenciaConsultaDTO> lstTmp = new ArrayList<>();

			for (PreferenciaConsultaDTO p : lst) {
				p.setActivo(false);
				for (Object[] o : lstObject) {
					 paramConsultaDTO = new PreferenciaConsultaDTO((BigDecimal) o[0],
							(String) o[1], (String) o[2], (BigDecimal) o[3], (BigDecimal) o[4], (BigDecimal) o[5],
							(String) o[6]);
					if(p.getIdParametro().compareTo(paramConsultaDTO.getIdParametro()) == 0 ) {
						p = paramConsultaDTO;
						break;
					}
				}
				lstTmp.add(p);
			}
			lst = lstTmp;
		}
	
	return lst;

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * co.com.ath.recaudadores.apirest.model.services.IParametriasConsultaService#
	 * guardar(java.util.List)
	 */
	@Override
	public List<PreferenciaConsultaDTO> guardar(List<PreferenciaConsultaDTO> lst) {
		String convenio = "";
		String usuario = "";

		for (PreferenciaConsultaDTO p : lst) {
			convenio = p.getConvenio();
			usuario = p.getUsuario();

			if (p.getId() == null) {
				parametriaDAO.crear(p.getConvenio(), p.getUsuario(), p.getIdParametro(), p.getIdIdentificador(),
						p.isActivo());
			} else {
				parametriaDAO.modificar(p.isActivo(), p.getConvenio(), p.getUsuario(), p.getIdParametro());
			}
		}
		return findAll(convenio, usuario);
	}

}
