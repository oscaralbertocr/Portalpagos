package co.com.ath.recaudadores.apirest.util;

import java.io.File;
import java.io.FileInputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SignatureService {

	public static void main(String[] args) {
//		try {
//			PGPFileProcessor p = new PGPFileProcessor();
//			p.setInputFileName("D:\\Temp\\0000001720201111103626.dat.PGP");
//			p.setOutputFileName("D:\\Temp\\0000001720201111103626.dat.PGP.firmado");
//			p.setSecretKeyFileName("C:\\Users\\jesus.avendano\\Downloads\\BTXAVAL_PT_Firma_priv.asc");
//			p.setPublicKeyFileName("C:\\Users\\jesus.avendano\\Downloads\\BTXAVAL_PT_Firma_pub.asc");
//			p.setRing("BK_PT_2020_Firma");
//			
//			p.signEncrypt();
//			
//			boolean a = p.verify(new FileInputStream(new File("D:\\Temp\\0000001720201111103626.dat.PGP.firmado")), 
//					new FileInputStream(new File("C:\\Users\\jesus.avendano\\Downloads\\BTXAVAL_PT_Firma_pub.asc")));
//				
//			System.out.println(a);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
		System.out.println("resultado: "+ convertDate("2015-09-21 18:26:12.127"));
	}
	
	public static String convertDate(String date) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss a");
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.sss");
		try {
			Date newDate = sdf1.parse(date);
			return sdf.format(newDate);
		} catch (ParseException e) {
			e.printStackTrace();
			return null;
		}
	}
}
