package co.com.ath.recaudadores.apirest.model.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import co.com.ath.recaudadores.apirest.model.dto.AlertRecaudadorDTO;

/*
 * Clase : AlertRecaudador
 * Date  : 07-Ene-2021
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Entity
@Table(name = "EXT_ALERT_RECAUDADOR_BANCO")
public class AlertRecaudador implements Serializable {

	@Id
	@Column(name = "ID_MENSAJE", nullable = false)
	private String id;

	@Column(name = "TXT_MENSAJE", nullable = false)
	private String mensaje;

	@Column(name = "TIPO_MESAJE", nullable = false)
	private String tipo;

	@Column(name = "ESTADO")
	private boolean estado;

	public AlertRecaudador() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}
	
	
	/**
	 * @return
	 */
	public AlertRecaudadorDTO toAlertRecaudadorDTO(){
		AlertRecaudadorDTO  alert = new AlertRecaudadorDTO();
		alert.setId(this.id);
		alert.setMensaje(this.mensaje);
		alert.setTipo(this.tipo);
		alert.setEstado(this.estado);
		return alert;
	}

	
	/**
	 * 
	 */
	public void toAlertRecaudador(AlertRecaudadorDTO alert) {
		this.id = alert.getId() ;
		this.mensaje = alert.getMensaje();
		this.tipo = alert.getTipo();
		this.estado = alert.isEstado();	
	}
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
