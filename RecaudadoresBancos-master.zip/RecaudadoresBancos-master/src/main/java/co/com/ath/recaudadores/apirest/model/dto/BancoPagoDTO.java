package co.com.ath.recaudadores.apirest.model.dto;

import java.io.Serializable;
import java.util.List;

import co.com.ath.recaudadores.apirest.model.entities.Transaccion;

public class BancoPagoDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private String bncId;

	private String bncNombre;
	
	private List<Transaccion> transaccions;

	public String getBncId() {
		return bncId;
	}

	public void setBncId(String bncId) {
		this.bncId = bncId;
	}

	public String getBncNombre() {
		return bncNombre;
	}

	public void setBncNombre(String bncNombre) {
		this.bncNombre = bncNombre;
	}

	public List<Transaccion> getTransaccions() {
		return transaccions;
	}

	public void setTransaccions(List<Transaccion> transaccions) {
		this.transaccions = transaccions;
	}
	
	
}
