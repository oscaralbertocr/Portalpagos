package co.com.ath.recaudadores.apirest.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dto.MailServiceInDTO;
import co.com.ath.recaudadores.apirest.model.services.IParametroService;

@Service
public class Utils {
	
	private static final Logger logger = LoggerFactory.getLogger(Utils.class);
	
	@Autowired
	MailService mailService;
	
	@Autowired
	IParametroService parametroService;

	public static final String DATE_FORMAT = "mm/dd/yyyy hh:mm:ss";
    
       
    /**
     * Metodo que crea el archivo
     * @param resultSet
     * @param fileName
     * @param resultFooter 
     * @throws IOException
     */
    public void generarArchivo (ResultSet resultSet, String correo) throws IOException {
    	
    	logger.info("Inicia instancia del WorkBook Excel: {}",System.currentTimeMillis());
		try (XSSFWorkbook workbook = new XSSFWorkbook()){
				Sheet sheet = workbook.createSheet("Convenios");
				Row row = sheet.createRow(0);

				CellStyle cellStyle = workbook.createCellStyle();
				
				CreationHelper createHelper = workbook.getCreationHelper();
				cellStyle.setDataFormat(createHelper.createDataFormat().getFormat(DATE_FORMAT));
				
				/*
				 * formato para encabezado de columnas
				 */
				CellStyle cellStyle1 = workbook.createCellStyle();
				cellStyle1.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
				cellStyle1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
				cellStyle1.setBorderBottom(BorderStyle.THIN);
				cellStyle1.setBorderLeft(BorderStyle.THIN);
				cellStyle1.setBorderRight(BorderStyle.THIN);
				cellStyle1.setBorderTop(BorderStyle.THIN);
				
				String tituloArchivo = parametroService.find("ReporteConveniosTitulo").getValor();
				
				String[] columns = tituloArchivo.split(",");
				
				// aqui colocamos el nombre de las columnas
				for (int i = 0; i < columns.length; i++) {
					Cell cell = row.createCell(i);
					cell.setCellValue(columns[i]);
					cell.setCellStyle(cellStyle1);
					
					sheet.autoSizeColumn(i);
				}

				String result[] = null;
				int initRow = 1;
				int rowCount = 0;
				
				logger.info("Inicia el llenado de las filas: "+System.currentTimeMillis());
		       	 while(resultSet.next()) {
			       	 if (!resultSet.getString(1).isEmpty()) {
			       		result = resultSet.getString(1).split(";");
			       							
						row = sheet.createRow(initRow);					
						row.createCell(0).setCellValue(result[0]);
						row.createCell(1).setCellValue(result[1]);
						
						row.createCell(2).setCellValue(result[2]);
						row.createCell(3).setCellValue(result[3]);
				
						row.createCell(4).setCellValue(result[4]);
						row.createCell(5).setCellValue(result[5]);
						
						row.createCell(6).setCellValue(result[6]);
						row.createCell(7).setCellValue(result[7]);
						
						row.createCell(8).setCellValue(result[8]);
						row.createCell(9).setCellValue(result[9]);
						
						row.createCell(10).setCellValue(result[10]);
						row.createCell(11).setCellValue(result[11]);
				
						row.createCell(12).setCellValue(result[12]);
						row.createCell(13).setCellValue(result[13]);
						
						row.createCell(14).setCellValue(result[14]);					
						
						initRow++;
						rowCount++;
			       		
			       	 } else {
			       		 
						logger.info("El archivo no se genera, no hay datos para mostrar");		
						envioCorreo(correo, parametroService.find("ReporteConveniosCuerpoSinResultados").getValor(), "");
						break;
					 }	       	 
		        }
		       	 
				if (rowCount == 0) {
					logger.info("El archivo no se genera, no hay datos para mostrar");		
					envioCorreo(correo, parametroService.find("ReporteConveniosCuerpoSinResultados").getValor(), "");
					
				}else {
			       	logger.info("Finaliza el llenado de las filas: {}",System.currentTimeMillis());
			       	logger.info("Total registros: {}",rowCount);

			       	logger.info("Inicia creación del nombre: {}",System.currentTimeMillis());
			       	String name=obtenerNombreArchivo(parametroService.find("ReporteConveniosName").getValor());
			       	logger.info("finaliza la creación del nombre: "+name+" : "+System.currentTimeMillis());
			       	
			       	
			       	String rutaArchivo = parametroService.find("ReporteConveniosRuta").getValor() + name;
			       	logger.info("Inicia generación del archivo en la ruta: {}",rutaArchivo);
					// Se genera archivo
					FileOutputStream out = new FileOutputStream(
							new File( rutaArchivo ));
					workbook.write(out);
					out.flush();
					out.close();
					logger.info("El archivo "+name+" se genera con exito"+System.currentTimeMillis());
							
					//Envio de correo
					logger.info("Inicia el envío de correo del archivo "+name+" : "+System.currentTimeMillis());
					envioCorreo(correo, parametroService.find("ReporteConveniosCuerpoOk").getValor(), name);
					logger.info("Finaliza el envío de correo del archivo "+name+" : "+System.currentTimeMillis());
				} 			
		} catch (Exception e) {
			logger.error(String.format("Se presenta un error al generar el archivo: %s", e.toString()));
			envioCorreo(correo, parametroService.find("ReporteConveniosCuerpoError").getValor(), "");
		}  
	}
    
    private String obtenerNombreArchivo(String nombreArchivo) {
    	Calendar calendario = new GregorianCalendar();
    	nombreArchivo = nombreArchivo.replace("yyyy", String.valueOf(calendario.get(Calendar.YEAR)));
    	nombreArchivo = nombreArchivo.replace("MM", String.valueOf(calendario.get(Calendar.MONTH)+1).length()>1?String.valueOf(calendario.get(Calendar.MONTH)+1):"0".concat(String.valueOf(calendario.get(Calendar.MONTH)+1)));
    	nombreArchivo = nombreArchivo.replace("dd", String.valueOf(calendario.get(Calendar.DAY_OF_MONTH)).length()>1?String.valueOf(calendario.get(Calendar.DAY_OF_MONTH)):"0".concat(String.valueOf(calendario.get(Calendar.DAY_OF_MONTH))));
    	nombreArchivo = nombreArchivo.replace("hh", String.valueOf(calendario.get(Calendar.HOUR_OF_DAY)).length()>1?String.valueOf(calendario.get(Calendar.HOUR_OF_DAY)):"0".concat(String.valueOf(calendario.get(Calendar.HOUR_OF_DAY))));
    	nombreArchivo = nombreArchivo.replace("mm", String.valueOf(calendario.get(Calendar.MINUTE)).length()>1?String.valueOf(calendario.get(Calendar.MINUTE)):"0".concat(String.valueOf(calendario.get(Calendar.MINUTE))));
    	nombreArchivo = nombreArchivo.replace("ss", String.valueOf(calendario.get(Calendar.SECOND)).length()>1?String.valueOf(calendario.get(Calendar.SECOND)):"0".concat(String.valueOf(calendario.get(Calendar.SECOND))));
    	return nombreArchivo;
    }
    
    public void envioCorreo(String correo, String cuerpo, String name) {
		try {
			MailServiceInDTO mail = new MailServiceInDTO();
			
			mail.setTo(correo);
			mail.setSubject(parametroService.find("ReporteConveniosAsunto").getValor());
			mail.setText(cuerpo);			
			mailService.sendMailWithFile(mail, parametroService.find("ReporteConveniosRuta").getValor()+name, name);
			
		} catch (Exception e) {
			logger.error("Error enviando parametros de envio correo. {}",e);
		}
	}
    	
}