package co.com.ath.recaudadores.apirest.util;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import co.com.ath.recaudadores.apirest.model.dto.PreferenciaConsultaDTO;

/**
 * DTO class for receive body parameters for query
 * @author javier.florez
 * 23-oct-2020
 */
public class FilterTransaccion implements Serializable{

	private static final long serialVersionUID = 1L;

	private Date fechaInicio;
	
	private Date fechaFin;
	
	private Long medioPago;
	
	private long estadoTx;
	
	private String convenio;
	
	private String numRef;
	
	private double valorPago;
	
	private long idTx;
	
	private String cus;
	
	private List<PreferenciaConsultaDTO> parametrias; 
	
	public Date getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public Date getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}

	public Long getMedioPago() {
		return medioPago;
	}

	public void setMedioPago(Long medioPago) {
		this.medioPago = medioPago;
	}

	public String getConvenio() {
		return convenio;
	}

	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}

	public long getEstadoTx() {
		return estadoTx;
	}

	public void setEstadoTx(long estadoTx) {
		this.estadoTx = estadoTx;
	}

	public String getNumRef() {
		return numRef;
	}

	public void setNumRef(String numRef) {
		this.numRef = numRef;
	}

	public double getValorPago() {
		return valorPago;
	}

	public void setValorPago(double valorPago) {
		this.valorPago = valorPago;
	}

	public long getIdTx() {
		return idTx;
	}

	public void setIdTx(long idTx) {
		this.idTx = idTx;
	}

	public String getCus() {
		return cus;
	}

	public void setCus(String cus) {
		this.cus = cus;
	}

	public List<PreferenciaConsultaDTO> getParametrias() {
		return parametrias;
	}

	public void setParametrias(List<PreferenciaConsultaDTO> parametrias) {
		this.parametrias = parametrias;
	}
	
}
