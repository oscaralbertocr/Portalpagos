package co.com.ath.recaudadores.apirest.manager;

import java.util.Calendar;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.util.FTPconnection;
/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
@Service
@StepScope
public class UploadFileTasklet implements Tasklet{

	static Logger logger = LoggerFactory.getLogger(UploadFileTasklet.class);
	
	@Value("#{jobParameters[pathOutput]}")
	private String pathOutput;

	@Value("#{jobParameters[fileNameOutput]}")
	private String fileNameOutput;
	
	@Value("#{jobParameters[hostFtp]}")
	private String hostFtp;

	@Value("#{jobParameters[userFtp]}")
	private String userFtp;
	
	@Value("#{jobParameters[passFtp]}")
	private String passFtp;

	@Value("#{jobParameters[baseFtp]}")
	private String baseFtp;
	
	@Value("#{jobParameters[whitDateFTP]}")
	private String whitDateFTP;
	
	@Value("#{jobParameters[portFtp]}")
	private String portFtp;
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		logger.info("Iniciando conexion al SFTP");
		FTPconnection conection = new FTPconnection(this.hostFtp, this.userFtp, this.passFtp, this.baseFtp, this.portFtp);
		if(whitDateFTP.equalsIgnoreCase("0")) {
			conection.uploadFile(pathOutput+"\\"+fileNameOutput,this.baseFtp.concat("/"+fileNameOutput));
			conection.uploadFile(pathOutput+"\\"+fileNameOutput.concat(".PGP"),this.baseFtp.concat("/"+fileNameOutput.concat(".PGP")));
		}else if(whitDateFTP.equalsIgnoreCase("1")) {
			conection.uploadFile(pathOutput+"\\"+fileNameOutput,this.baseFtp.concat("/"+fileNameOutput), this.generateDate());
			conection.uploadFile(pathOutput+"\\"+fileNameOutput.concat(".PGP"),this.baseFtp.concat("/"+fileNameOutput.concat(".PGP")), this.generateDate());
		}
		logger.info("Finalizando conexion al SFTP");
		conection.close();
		return RepeatStatus.FINISHED;
	}

	private String generateDate() {
		Calendar calendar = Calendar.getInstance();
		String day = String.valueOf(calendar.get(Calendar.DATE));
		String month = String.valueOf(calendar.get(Calendar.MONTH)+1);
		if((calendar.get(Calendar.MONTH)+1) < 10) {
			month = "0".concat(month);
		}
		if(calendar.get(Calendar.DATE) < 10) {
			day = "0".concat(day);
		}
		String year = String.valueOf(calendar.get(Calendar.YEAR));
		return (year).concat(month).concat(day);
	}
	
}
