package co.com.ath.recaudadores.apirest.model.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
/*
 * Clase : Convenio
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/*
 * Clase : Convenio
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */

@Entity
@Table(name = "EXT_CONVENIOS")
public class Convenio implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CNV_ID", nullable = false)
	private String id;

	@Column(name = "CNV_NOMBRE", nullable = false)
	private String nombre;

	@Column(name = "CNV_SIGLA")
	private String sigla;

	@Column(name = "CNV_CIUDAD")
	private String ciudad;

	@Column(name = "CNV_NOMBRE_IMG_CAPTURA_REF")
	private String nombImagenCaptura;

	@Column(name = "CNV_USUARIO_CREACION", nullable = false)
	private String userCreacion;

	@Column(name = "CNV_USUARIO_MODIF")
	private String userModificacion;

	@Column(name = "CNV_NIT")
	private String nit;

	@Column(name = "CNV_COD_EAN")
	private String codEan;

	@Column(name = "CNV_PALABRAS_CLAVES ")
	private String palabrasClave;

	@Column(name = "EXT_CNV_MODALIDAD_MOD_ID", nullable = false)
	private Long modalidad;

	@Column(name = "EXT_ESTADO_CONVENIOS_ID")
	private Long estadoConvenio;

	@Column(name = "EXT_CNV_INSCRIPCION")
	private Long inscripcion;

	@Column(name = "CNV_DUENO_ID")
	private Long duenoCovenio;

	@Column(name = "CNV_FEC_CREACION", nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaCreacion;

	@Column(name = "CNV_FEC_MODIF")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaModificacion;

	@Column(name = "EXT_VISIBLE_BUSCADOR", nullable = true, length = 16, columnDefinition = "CHAR")
	private String visibleBuscador;

	@Column(name = "EXT_ENMASCARAR", nullable = true, length = 16, columnDefinition = "CHAR")
	private String enmascarar;

	@OneToOne(mappedBy = "convenio")
	private ConvenioOther convenioInfo;
	
	/*-------------------------- */
	@OneToOne(mappedBy = "convenio")
	private ConvenioConf conf;
	/*-------------------------- */

	public Convenio() {
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getSigla() {
		return sigla;
	}

	public void setSigla(String sigla) {
		this.sigla = sigla;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public String getNombImagenCaptura() {
		return nombImagenCaptura;
	}

	public void setNombImagenCaptura(String nombImagenCaptura) {
		this.nombImagenCaptura = nombImagenCaptura;
	}

	public String getUserCreacion() {
		return userCreacion;
	}

	public void setUserCreacion(String userCreacion) {
		this.userCreacion = userCreacion;
	}

	public String getUserModificacion() {
		return userModificacion;
	}

	public void setUserModificacion(String userModificacion) {
		this.userModificacion = userModificacion;
	}

	public String getNit() {
		return nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getCodEan() {
		return codEan;
	}

	public void setCodEan(String codEan) {
		this.codEan = codEan;
	}

	public String getPalabrasClave() {
		return palabrasClave;
	}

	public void setPalabrasClave(String palabrasClave) {
		this.palabrasClave = palabrasClave;
	}

	public Long getModalidad() {
		return modalidad;
	}

	public void setModalidad(Long modalidad) {
		this.modalidad = modalidad;
	}

	public Long getEstadoConvenio() {
		return estadoConvenio;
	}

	public void setEstadoConvenio(Long estadoConvenio) {
		this.estadoConvenio = estadoConvenio;
	}

	public Long getInscripcion() {
		return inscripcion;
	}

	public void setInscripcion(Long inscripcion) {
		this.inscripcion = inscripcion;
	}

	public Long getDuenoCovenio() {
		return duenoCovenio;
	}

	public void setDuenoCovenio(Long duenoCovenio) {
		this.duenoCovenio = duenoCovenio;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public String getVisibleBuscador() {
		return visibleBuscador;
	}

	public void setVisibleBuscador(String visibleBuscador) {
		this.visibleBuscador = visibleBuscador;
	}

	public String getEnmascarar() {
		return enmascarar;
	}

	public void setEnmascarar(String enmascarar) {
		this.enmascarar = enmascarar;
	}

	public ConvenioOther getConvenioInfo() {
		return convenioInfo;
	}

	public void setConvenioInfo(ConvenioOther convenioInfo) {
		this.convenioInfo = convenioInfo;
	}

	public ConvenioConf getConf() {
		return conf;
	}

	public void setConf(ConvenioConf conf) {
		this.conf = conf;
	}

	@Override
	public String toString() {
		return "Convenio [id=" + id + ", nombre=" + nombre + ", sigla=" + sigla + ", ciudad=" + ciudad + "]";
	}

	private static final long serialVersionUID = 1L;

}
