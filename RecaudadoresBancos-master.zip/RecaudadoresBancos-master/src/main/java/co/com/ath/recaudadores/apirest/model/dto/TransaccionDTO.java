package co.com.ath.recaudadores.apirest.model.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

public class TransaccionDTO {

	private long id;

	private String bancoPortal;

	private String fqrId;

	private MedioPagoDTO medioPago;
	
	private String numDocumento;

	private String apellidoCliente;
	
	private String aprobacionId;

	private boolean asociadaPorCorreo;

	private String bancoAch;

	private String bancoId;

	private String bankName;

	private String comentario;

	private String curCode;

	private String emailCliente;

	private Date fechaInicioPago;

	private Date fechaModifPago;

	private Date fechaActualizacion;

	private String ipCliente;

	private String nitCliente;

	private String nombreCliente;

	private String nombrePagador;

	private String numAuth;

	private String numTarjeta;

	private String pagoId;

	private String rquId;

	private BigDecimal tipoAporte;

	private String tipoMoneda;

	private String token;

	private String pendienteMarcacion;

	private BigDecimal valor;

	private String uid;

	private String uuidCpv;
	
	private String desErrorMarcacion;

	private BancoPagoDTO bancoPago;

	private ConvenioDTO convenio;

	private EstadoTransaccionDTO estadoTx;

	private Integer intencionPago;

	private TipoDocumentoDTO tipoDocumento;

	private boolean consultaComprobante;

	private String cicloAch;

	private String idCpv;

	private String tasaCambio;

	private Boolean taquilla;
	
	private String errorMarcacion;

	private BigDecimal reintentosMarcacion;

	private Date fechaNextDay;

	private String conceptoPago;
	
	private String urlRespuestaCpv;
	
	private List<ReferenciaTxDTO> referenciaTxs;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getBancoPortal() {
		return bancoPortal;
	}

	public void setBancoPortal(String bancoPortal) {
		this.bancoPortal = bancoPortal;
	}

	public String getFqrId() {
		return fqrId;
	}

	public void setFqrId(String fqrId) {
		this.fqrId = fqrId;
	}

	public MedioPagoDTO getMedioPago() {
		return medioPago;
	}

	public void setMedioPago(MedioPagoDTO medioPago) {
		this.medioPago = medioPago;
	}

	public String getNumDocumento() {
		return numDocumento;
	}

	public void setNumDocumento(String numDocumento) {
		this.numDocumento = numDocumento;
	}

	public String getApellidoCliente() {
		return apellidoCliente;
	}

	public void setApellidoCliente(String apellidoCliente) {
		this.apellidoCliente = apellidoCliente;
	}

	public String getAprobacionId() {
		return aprobacionId;
	}

	public void setAprobacionId(String aprobacionId) {
		this.aprobacionId = aprobacionId;
	}

	public boolean isAsociadaPorCorreo() {
		return asociadaPorCorreo;
	}

	public void setAsociadaPorCorreo(boolean asociadaPorCorreo) {
		this.asociadaPorCorreo = asociadaPorCorreo;
	}

	public String getBancoAch() {
		return bancoAch;
	}

	public void setBancoAch(String bancoAch) {
		this.bancoAch = bancoAch;
	}

	public String getBancoId() {
		return bancoId;
	}

	public void setBancoId(String bancoId) {
		this.bancoId = bancoId;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	public String getCurCode() {
		return curCode;
	}

	public void setCurCode(String curCode) {
		this.curCode = curCode;
	}

	public String getEmailCliente() {
		return emailCliente;
	}

	public void setEmailCliente(String emailCliente) {
		this.emailCliente = emailCliente;
	}

	public Date getFechaInicioPago() {
		return fechaInicioPago;
	}

	public void setFechaInicioPago(Date fechaInicioPago) {
		this.fechaInicioPago = fechaInicioPago;
	}

	public Date getFechaModifPago() {
		return fechaModifPago;
	}

	public void setFechaModifPago(Date fechaModifPago) {
		this.fechaModifPago = fechaModifPago;
	}

	public Date getFechaActualizacion() {
		return fechaActualizacion;
	}

	public void setFechaActualizacion(Date fechaActualizacion) {
		this.fechaActualizacion = fechaActualizacion;
	}

	public String getIpCliente() {
		return ipCliente;
	}

	public void setIpCliente(String ipCliente) {
		this.ipCliente = ipCliente;
	}

	public String getNitCliente() {
		return nitCliente;
	}

	public void setNitCliente(String nitCliente) {
		this.nitCliente = nitCliente;
	}

	public String getNombreCliente() {
		return nombreCliente;
	}

	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}

	public String getNombrePagador() {
		return nombrePagador;
	}

	public void setNombrePagador(String nombrePagador) {
		this.nombrePagador = nombrePagador;
	}

	public String getNumAuth() {
		return numAuth;
	}

	public void setNumAuth(String numAuth) {
		this.numAuth = numAuth;
	}

	public String getNumTarjeta() {
		return numTarjeta;
	}

	public void setNumTarjeta(String numTarjeta) {
		this.numTarjeta = numTarjeta;
	}

	public String getPagoId() {
		return pagoId;
	}

	public void setPagoId(String pagoId) {
		this.pagoId = pagoId;
	}

	public String getRquId() {
		return rquId;
	}

	public void setRquId(String rquId) {
		this.rquId = rquId;
	}

	public BigDecimal getTipoAporte() {
		return tipoAporte;
	}

	public void setTipoAporte(BigDecimal tipoAporte) {
		this.tipoAporte = tipoAporte;
	}

	public String getTipoMoneda() {
		return tipoMoneda;
	}

	public void setTipoMoneda(String tipoMoneda) {
		this.tipoMoneda = tipoMoneda;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getPendienteMarcacion() {
		return pendienteMarcacion;
	}

	public void setPendienteMarcacion(String pendienteMarcacion) {
		this.pendienteMarcacion = pendienteMarcacion;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getUuidCpv() {
		return uuidCpv;
	}

	public void setUuidCpv(String uuidCpv) {
		this.uuidCpv = uuidCpv;
	}

	public String getDesErrorMarcacion() {
		return desErrorMarcacion;
	}

	public void setDesErrorMarcacion(String desErrorMarcacion) {
		this.desErrorMarcacion = desErrorMarcacion;
	}

	public BancoPagoDTO getBancoPago() {
		return bancoPago;
	}

	public void setBancoPago(BancoPagoDTO bancoPago) {
		this.bancoPago = bancoPago;
	}

	public ConvenioDTO getConvenio() {
		return convenio;
	}

	public void setConvenio(ConvenioDTO convenio) {
		this.convenio = convenio;
	}

	public EstadoTransaccionDTO getEstadoTx() {
		return estadoTx;
	}

	public void setEstadoTx(EstadoTransaccionDTO estadoTx) {
		this.estadoTx = estadoTx;
	}

	public Integer getIntencionPago() {
		return intencionPago;
	}

	public void setIntencionPago(Integer intencionPago) {
		this.intencionPago = intencionPago;
	}

	public TipoDocumentoDTO getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(TipoDocumentoDTO tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public boolean isConsultaComprobante() {
		return consultaComprobante;
	}

	public void setConsultaComprobante(boolean consultaComprobante) {
		this.consultaComprobante = consultaComprobante;
	}

	public String getCicloAch() {
		return cicloAch;
	}

	public void setCicloAch(String cicloAch) {
		this.cicloAch = cicloAch;
	}

	public String getIdCpv() {
		return idCpv;
	}

	public void setIdCpv(String idCpv) {
		this.idCpv = idCpv;
	}

	public String getTasaCambio() {
		return tasaCambio;
	}

	public void setTasaCambio(String tasaCambio) {
		this.tasaCambio = tasaCambio;
	}

	public Boolean isTaquilla() {
		return taquilla;
	}

	public void setTaquilla(Boolean taquilla) {
		this.taquilla = taquilla;
	}

	public String getErrorMarcacion() {
		return errorMarcacion;
	}

	public void setErrorMarcacion(String errorMarcacion) {
		this.errorMarcacion = errorMarcacion;
	}

	public BigDecimal getReintentosMarcacion() {
		return reintentosMarcacion;
	}

	public void setReintentosMarcacion(BigDecimal reintentosMarcacion) {
		this.reintentosMarcacion = reintentosMarcacion;
	}

	public Date getFechaNextDay() {
		return fechaNextDay;
	}

	public void setFechaNextDay(Date fechaNextDay) {
		this.fechaNextDay = fechaNextDay;
	}

	public String getConceptoPago() {
		return conceptoPago;
	}

	public void setConceptoPago(String conceptoPago) {
		this.conceptoPago = conceptoPago;
	}

	public String getUrlRespuestaCpv() {
		return urlRespuestaCpv;
	}

	public void setUrlRespuestaCpv(String urlRespuestaCpv) {
		this.urlRespuestaCpv = urlRespuestaCpv;
	}

	public List<ReferenciaTxDTO> getReferenciaTxs() {
		return referenciaTxs;
	}

	public void setReferenciaTxs(List<ReferenciaTxDTO> referenciaTxs) {
		this.referenciaTxs = referenciaTxs;
	}
	
	
	
}
