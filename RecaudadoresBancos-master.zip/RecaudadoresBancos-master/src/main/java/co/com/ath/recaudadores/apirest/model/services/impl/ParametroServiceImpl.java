package co.com.ath.recaudadores.apirest.model.services.impl;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dao.IParametroDAO;
import co.com.ath.recaudadores.apirest.model.dto.ParametroDTO;
import co.com.ath.recaudadores.apirest.model.entities.Parametro;
import co.com.ath.recaudadores.apirest.model.services.IParametroService;

/*
 * Clase : ParametroServiceImpl
 * Date  : 18-Nov-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Service
public class ParametroServiceImpl implements IParametroService {

	@Autowired
	private IParametroDAO parametroDAO;

	/* (non-Javadoc)
	 * @see co.com.ath.recaudadores.apirest.model.services.IParametroService#save(co.com.ath.recaudadores.apirest.model.dto.ParametroDTO)
	 */
	@Override
	public ParametroDTO save(ParametroDTO parametroDTO) {
		Parametro parametro = new Parametro();

		if (parametroDTO != null && parametroDTO.getClave() != null && !parametroDTO.getClave().isEmpty()) {
			parametro = parametroDAO.findById(parametroDTO.getClave());
			if (parametro != null) {
				parametroDTO.setFechaCreacion(parametro.getFechaCreacion());
				parametroDTO.setFechaModificacion(parametro.getFechaModificacion());
				if (!parametro.getValor().equals(parametroDTO.getValor())
						|| !parametro.getDescripcion().equals(parametroDTO.getDescripcion())
						|| !parametro.getEstado().equals(parametroDTO.getEstado())
						|| !parametro.getTipo().equals(parametroDTO.getTipo())) {
					parametroDTO.setFechaModificacion(new Date());
				}
			} else {
				parametro = new Parametro();
				parametroDTO.setFechaCreacion(new Date());
				parametroDTO.setFechaModificacion(new Date());
				parametroDTO.setEstado("A");
			}
			parametro.toParametro(parametroDTO);
			return parametroDAO.save(parametro).toParametroDAO();
		}
		return null;

	}

	/* (non-Javadoc)
	 * @see co.com.ath.recaudadores.apirest.model.services.IParametroService#find(java.lang.String)
	 */
	@Override
	public ParametroDTO find(String clave) {
		if (clave != null) {
			Parametro parametro = parametroDAO.findById(clave);
			if (parametro != null) {
				return parametro.toParametroDAO();
			}
		}
		return null;
	}
}
