package co.com.ath.recaudadores.apirest.util;

public class UserRequest {

	private String User;

	public String getUser() {
		return User;
	}

	public void setUser(String user) {
		User = user;
	}
	
	
	
}
