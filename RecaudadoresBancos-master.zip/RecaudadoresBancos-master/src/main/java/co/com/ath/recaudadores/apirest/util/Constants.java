package co.com.ath.recaudadores.apirest.util;

public class Constants {

	private Constants() {
		throw new IllegalStateException("Utility class");
	}

	/** Parámetros validación SpringSecurity **/ 
	public static final String ACTUATOR = "/actuator/health";
	public static final String HEADER_AUTHORIZACION_KEY = "Authorization";
	public static final String TOKEN_BEARER_PREFIX = "Bearer ";

	/** Clave para cifrado del Token **/
	public static final String SECRET = "b7c6fd81d2ff8a8ea0cc73216238b5a8c8e53de2f73719e85651e916888a5dd4bb0c8fab4c30c2ca898e6dc44acfba4b9c0c011f3457e958b8f8478976657bce4a0a35793a0e6d2f176416ca726fbb1e93a2b8d0ad0a140902dffb00a4bdc7fba9deec121d9455d0f1f21ce9d4ad5eecce17a7c01b6a64ea366fb881c9eead5";

	public static final String HEADER_LOG = "*******************************************************************";
	
	/**  registros  **/
	public static final Long ESTADO_ELIMINADO = 3L;
	public static final Long  TODOS_ID = 99L;
	public static final Long ID_SIN_MEDIO_PAGO = 98L;
	public static final Long ESTADO_TX_INICIADO = 0L;
	public static final Long ESTADO_TX_DESCARTADO = 7L;
	public static final String ESTADO_TODOS_TXT = "TODOS";
	public static final String CATEGORIA_TODOS_TXT = "TODAS LAS CATEGORIAS";
	public static final String MEDIOS_PAGO_TODOS_TXT = "TODOS";
	public static final String ESTADOS_TX_TODOS_TXT = "TODOS";
	public static final String SIN_MEDIO_PAGO_TXT = "SIN MEDIO DE PAGO";
	public static final String ID_TRANSACCION = "ID transacción";
	public static final String NOMBRE_CONVENIO = "Nombre del convenio";
	public static final String REFERENCIAS_TX = "Referencias";
	public static final String VALOR_TRANSACCION = "Valor de la transacción";
	public static final String BANCO_AUTORIZADOR = "Banco Autorizador";
	public static final String NUMERO_AUTORIZACION = "N° Autorización";
	public static final String CORREO_ELECTRONICO =	"Correo electrónico";
	public static final String NOMBRE_CLIENTE ="Nombre";
	public static final String IP_TRANSACCION = "IP";
	public static final String FECHA_PAGO =	"Fecha de Pago";
	public static final String ESTADO_TRANSACCION =	"Estado de la Transacción";
	public static final String TIPO_PAGO = "Tipo de pago";
	public static final String CICLO_PAGO =	"Ciclo";
	public static final String OBSERVACIONES_TRANSACCION = "Observaciones";
	public static final String CONCEPTO_TRANSACCION = "Concepto";
	public static final String INCOCREDITO_TX = "Código Incocredito";
	public static final String FECHA_CONVENIO_TX = "Fecha creación del convenio";
	public static final String CUENTA_RECAUDO_TX = "Número cuenta de recaudo";
	public static final String PSEUDO_CUENTA_TX = "PSeudocuenta";
	public static final String CUS_TX = "CUS";

	// Parametros

	public static final String ERR_PARAMETRO_TXT = "Error";
	public static final String ERR_PARAMETRO_01 = "PAR/Err001-Error al acceder la base de datos";


	// Servicio de desarga de archivo

	public static final String PSEname = "PSE";
	public static final String TCname = "TC";
	public static final String AVALname = "AVAL";
	public static final String extFile = ".zip";
	public static final String spaFile = "\\s";
	public static final String sepaFile = "_";
	public static final String expFile = "*";

	public static final String dispositionFile = "attachment;";
	public static final String typeFile = "application/zip;";

	/* Mensajes informativos */
	public static final String MSG_PARAMETRO_TXT = "Mensaje";
	public static final String INF_PARAMETRO_01 = "PAR/Inf001-No se encontró información de ese parámetro";
	public static final String INF_PARAMETRO_02 = "PAR/Inf002-El parámetro no pudo guardarse";
	public static final String INF_PARAMETRO_03 = "PAR/Inf003-El parámetro que se va actualizar no existe";
	public static final String INF_PARAMETRO_04 = "PAR/Inf004-Los tipo de datos reconocidos son: Alfanumérico, Numérico, Fecha, Booleano o Bloque";	
	public static final String INF_PARAMETRO_05 = "PAR/Inf005-El parámetro no pudo actualizarse";
	public static final String INF_PARAMETRO_06 = "PAR/Inf006-Hay campos vacíos en la solicitud que deben diligenciarse";
	public static final String INF_PARAMETRO_07 = "PAR/Inf007-No hay información para guardar";
	
	/** Util */
	public static final String SEPARATOR = System.getProperty("line.separator");
	

	public static final String firsStateFile = "En Proceso";
	public static final String extFileCipher = ".PGP";
	
	/** Mensajes de error */
	public static final String AGREEMENT_TYPE_INVALID = "AGREEMENT_TYPE_INVALID";
	public static final String LENGHT_INVALID = "LENGHT_OF_FIELD_INVALID";
	public static final String ACOUNT_NUMBER_INVALID = "ACOUNT_NUMBER_INVALID";
	public static final String REFERENCE_ONE_INVALID = "REFERENCE_ONE_INVALID";
	public static final String DATE_ONE_INVALID = "DATE_ONE_INVALID";
	public static final String VALUE_ONE_INVALID = "VALUE_ONE_INVALID";
	public static final String DATE_TWO_INVALID = "DATE_TWO_INVALID";
	public static final String VALUE_TWO_INVALID = "VALUE_TWO_INVALID";
	public static final String DATE_THREE_INVALID = "DATE_THREE_INVALID";
	public static final String VALUE_THREE_INVALID = "VALUE_THREE_INVALID";
	public static final String DATE_FOUR_INVALID = "DATE_FOUR_INVALID";
	public static final String VALUE_FOUR_INVALID = "VALUE_FOUR_INVALID";
	public static final String REFERENCE_TWO_INVALID = "REFERENCE_TWO_INVALID";
	public static final String REFERENCE_THREE_INVALID = "REFERENCE_THREE_INVALID";
	public static final String REFERENCE_FOUR_INVALID = "REFERENCE_FOUR_INVALID";
	public static final String BILLING_CYCLE_INVALID = "BILLING_CYCLE_INVALID";
	public static final String CYCLE_EFFECTIVE_DATE_INVALID = "CYCLE_EFFECTIVE_DATE_INVALID";
	public static final String FILLER_INVALID = "FILLER_INVALID";
	public static final String FTP_ERROR = "SFTP_ERROR";
	public static final String AUDIT_ERROR = "AUDIT_ERROR";
	public static final String MAIL_ERROR = "FPT_ERROR";
	
	/** Estados auditoria */
	public static final String validado = "Validado";
	public static final String aplicado = "Aplicado";
	public static final String rechazado = "Rechazado";
	public static final String reversado = "Reversado";
	public static final String retirado = "Retirado";
	public static final String conObservaciones = "Con Observaciones";
	
	/* Mensajes informativos servicio txtAlert*/
	public static final String ERR_ALERT_TXT = "Error";
	public static final String ERR_ALERT_01 = "ALERT/Err001-Error al acceder la base de datos";
	public static final String MSG_ALERT_TXT = "Mensaje";
	public static final String INF_ALERT_01 = "ALERT/Inf001-No se encontró texto para esa alerta";
	public static final String INF_ALERT_02 = "ALERT/Inf002-El texto de la alerta no pudo guardarse";
	public static final String INF_ALERT_03 = "ALERT/Inf003-El texto de la alerta que se va actualizar no existe";
	public static final String INF_ALERT_05 = "ALERT/Inf005-El texto de la alerta no pudo actualizarse";
	public static final String INF_ALERT_06 = "ALERT/Inf006-Hay texto de la alerta que deben diligenciarse";
	public static final String INF_ALERT_07 = "ALERT/Inf007-No hay información para guardar";
	public static final String CHANNEL_INVOICES_INQ_RQ = "PPA";
	public static final String CODE_INVOICES_INQ_RQ = "2";
	public static final String BANKID_INVOICES_INQ_RQ = "00089898";
	
}
