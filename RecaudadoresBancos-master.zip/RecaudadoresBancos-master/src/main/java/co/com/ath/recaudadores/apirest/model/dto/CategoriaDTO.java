package co.com.ath.recaudadores.apirest.model.dto;

import java.io.Serializable;

/*
 * Clase : CategoriaTo
 * Date  : 15-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */

public class CategoriaDTO implements Serializable {

	private Long id;
	private String nombre;

	public CategoriaDTO() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public String toString() {
		return "CategoriaTO [id=" + id + ", nombre=" + nombre + "]";
	}

	private static final long serialVersionUID = 1L;

}
