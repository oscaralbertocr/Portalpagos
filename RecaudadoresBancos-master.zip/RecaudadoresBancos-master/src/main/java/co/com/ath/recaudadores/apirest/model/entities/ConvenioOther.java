package co.com.ath.recaudadores.apirest.model.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "EXT_CONVENIOS_OTHERS")
public class ConvenioOther implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "DIRECCION")
	private String direccion;
	
	@Column(name = "ID_TIPO_CUENTA")
	private Long idTipoCuenta;
	
	@Column(name = "INCOCREDITO")
	private String incocredito;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "CNV_ID")
	private Convenio convenio;

	public ConvenioOther() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public Long getIdTipoCuenta() {
		return idTipoCuenta;
	}

	public void setIdTipoCuenta(Long idTipoCuenta) {
		this.idTipoCuenta = idTipoCuenta;
	}

	public String getIncocredito() {
		return incocredito;
	}

	public void setIncocredito(String incocredito) {
		this.incocredito = incocredito;
	}

	public Convenio getConvenio() {
		return convenio;
	}

	public void setConvenio(Convenio convenio) {
		this.convenio = convenio;
	}

	@Override
	public String toString() {
		return "ConvenioOther [id=" + id + ", direccion=" + direccion + ", idTipoCuenta=" + idTipoCuenta
				+ ", incocredito=" + incocredito + ", convenio=" + convenio + "]";
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
