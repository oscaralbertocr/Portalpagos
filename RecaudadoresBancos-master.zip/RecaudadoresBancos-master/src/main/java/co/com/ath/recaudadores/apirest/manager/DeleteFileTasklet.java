package co.com.ath.recaudadores.apirest.manager;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;

import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
@Service
@StepScope
public class DeleteFileTasklet implements Tasklet{

	@Value("#{jobParameters[pathInput]}")
	private String pathInput;

	@Value("#{jobParameters[fileNameInput]}")
	private String fileNameInput;
	
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		File f = new File(this.pathInput, this.fileNameInput);
		Path p = f.toPath();
		Files.delete(p);
		return RepeatStatus.FINISHED;
	}

}
