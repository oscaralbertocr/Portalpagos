package co.com.ath.recaudadores.apirest.model.dto;

import java.io.Serializable;

public class ConsultaConvenioDTO implements Serializable {

	private String nura;
	private String convenio;
	private String empresa;
	private String nit;
	private String estado;
	private String categoria;
	private String municipio;
	private String telefono;
	private String contacto;
	private String correo;
	private String tipoConvenio;
	private String banco;
	private String cuentaRecaudo;
	private String referencia;
	private String tipoCuenta;
	private String direccion;

	public ConsultaConvenioDTO() {

	}

	public ConsultaConvenioDTO(Object nura, Object convenio, Object empresa, Object nit, Object estado,
			Object categoria, Object municipio, Object telefono, Object contacto, Object correo, Object tipoConvenio,
			Object banco, Object cuentaRecaudo, Object referencia, Object tipoCuenta, Object direccion) {
		try {
			this.nura = (String) nura;
		} catch (Exception e) {};
		try {
			this.convenio = (String) convenio;
		} catch (Exception e) {};
		try {
			this.empresa = (String) empresa;
		} catch (Exception e) {};
		try {
			this.nit = (String) nit;
		} catch (Exception e) {};
		try {
			this.estado = (String) estado;
		} catch (Exception e) {};
		try {
			this.categoria = (String) categoria;
		} catch (Exception e) {};
		try {
			this.municipio = (String) municipio;
		} catch (Exception e) {};
		try {
			this.telefono = (String) telefono;
		} catch (Exception e) {};
		try {
			this.contacto = (String) contacto;
		} catch (Exception e) {};
		try {
			this.correo = (String) correo;
		} catch (Exception e) {};
		try {
			this.tipoConvenio = (String) tipoConvenio;
		} catch (Exception e) {};
		try {
			this.banco = (String) banco;
		} catch (Exception e) {};
		try {
			this.cuentaRecaudo = (String) cuentaRecaudo;
		} catch (Exception e) {};
		try {
			this.referencia = (String) referencia;
		} catch (Exception e) {};
		try {
			this.tipoCuenta = (String) tipoCuenta;
		} catch (Exception e) {};
		try {
			this.direccion = (String) direccion;
		} catch (Exception e) {};
	}

	public String getNura() {
		return nura;
	}

	public void setNura(String nura) {
		this.nura = nura;
	}

	public String getConvenio() {
		return convenio;
	}

	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}

	public String getEmpresa() {
		return empresa;
	}

	public void setEmpresa(String empresa) {
		this.empresa = empresa;
	}

	public String getNit() {
		return nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getCategoria() {
		return categoria;
	}

	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	public String getMunicipio() {
		return municipio;
	}

	public void setMunicipio(String municipio) {
		this.municipio = municipio;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getContacto() {
		return contacto;
	}

	public void setContacto(String contacto) {
		this.contacto = contacto;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getTipoConvenio() {
		return tipoConvenio;
	}

	public void setTipoConvenio(String tipoConvenio) {
		this.tipoConvenio = tipoConvenio;
	}

	public String getBanco() {
		return banco;
	}

	public void setBanco(String banco) {
		this.banco = banco;
	}

	public String getCuentaRecaudo() {
		return cuentaRecaudo;
	}

	public void setCuentaRecaudo(String cuentaRecaudo) {
		this.cuentaRecaudo = cuentaRecaudo;
	}

	public String getReferencias() {
		return referencia;
	}

	public void setReferencias(String referencia) {
		this.referencia = referencia;
	}

	public String getTipoCuenta() {
		return tipoCuenta;
	}

	public void setTipoCuenta(String tipoCuenta) {
		this.tipoCuenta = tipoCuenta;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	@Override
	public String toString() {
		return "ConsultaConvenioTo [nura=" + nura + ", convenio=" + convenio + ", empresa=" + empresa + ", nit=" + nit
				+ ", estado=" + estado + ", categoria=" + categoria + ", municipio=" + municipio + ", telefono="
				+ telefono + ", contacto=" + contacto + ", correo=" + correo + ", tipoConvenio=" + tipoConvenio
				+ ", banco=" + banco + ", cuentaRecaudo=" + cuentaRecaudo + "]";
	}

	private static final long serialVersionUID = 1L;
}
