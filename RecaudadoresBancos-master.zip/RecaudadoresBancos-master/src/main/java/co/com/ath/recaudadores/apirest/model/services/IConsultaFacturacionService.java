package co.com.ath.recaudadores.apirest.model.services;

import java.util.List;

import co.com.ath.recaudadores.apirest.model.dto.ConsultaFacturacionDTO;
import co.com.ath.recaudadores.apirest.util.ConsultaFacturacionFiltro;

public interface IConsultaFacturacionService {
	public List<ConsultaFacturacionDTO> consultarFacturacion(ConsultaFacturacionFiltro filtro);
}
