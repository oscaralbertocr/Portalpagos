package co.com.ath.recaudadores.apirest.model.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Class Transaction for EXT_TRANSACCION 
 * @author javier.florez
 * 22-Oct-2020
 */
@Entity
@Table(name = "EXT_TRANSACCION")
public class Transaccion implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "TX_ID")
	private long id;

	@Column(name = "EXT_BANCO_PORTAL")
	private String bancoPortal;

	@Column(name = "EXT_FRANQUICIA_FRQ_ID")
	private String fqrId;

	// bi-directional many-to-one association to MedioPago
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "EXT_MEDIO_PAGO_MP_ID")
	private MedioPago medioPago;

	@Column(name = "NUM_DOC_DO")
	private String numDocumento;

	@Column(name = "TX_APELLIDO_CLIENTE")
	private String apellidoCliente;

	@Column(name = "TX_APROBACION_ID")
	private String aprobacionId;

	@Column(name = "TX_ASOCIADA_POR_CORREO", columnDefinition = "char")
	private boolean asociadaPorCorreo;

	@Column(name = "TX_BANCO_ACH")
	private String bancoAch;

	@Column(name = "TX_BANCO_ID")
	private String bancoId;

	@Column(name = "TX_BANK_NAME")
	private String bankName;

	@Column(name = "TX_COMENTARIO")
	private String comentario;

	@Column(name = "TX_CUR_CODE")
	private String curCode;

	@Column(name = "TX_EMAIL_CLIENTE")
	private String emailCliente;

	@Column(name = "TX_FEC_INICIO_PAGO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaInicioPago;

	@Column(name = "TX_FEC_MODIF_PAGO")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaModifPago;

	@Column(name = "TX_FECHA_ACTUALIZACION")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaActualizacion;

	@Column(name = "TX_IP_CLIENTE")
	private String ipCliente;

	@Column(name = "TX_NIT_CLIENTE")
	private String nitCliente;

	@Column(name = "TX_NOMBRE_CLIENTE")
	private String nombreCliente;

	@Column(name = "TX_NOMBRE_PAGADOR")
	private String nombrePagador;

	@Column(name = "TX_NUM_AUTH")
	private String numAuth;

	@Column(name = "TX_NUM_TARJE")
	private String numTarjeta;

	@Column(name = "TX_PAGO_ID")
	private String pagoId;

	@Column(name = "TX_RQUID")
	private String rquId;

	@Column(name = "TX_TIPO_APORTE")
	private BigDecimal tipoAporte;

	@Column(name = "TX_TIPO_MONEDA")
	private String tipoMoneda;

	@Column(name = "TX_TOKEN")
	private String token;

	@Column(name = "TX_PENDIENTE_MARCACION")
	private String pendienteMarcacion;

	@Column(name = "TX_VALOR")
	private BigDecimal valor;

	@Column(name = "UID")
	private String uid;

	@Column(name = "UUID_CPV")
	private String uuidCpv;
	
	@Column(name = "DESC_ERROR_MARCACION")
	private String desErrorMarcacion;

	@ManyToOne
	@JoinColumn(name="EXT_BANCO_PAGO_BNC_ID")
	private BancoPago bancoPago;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "EXT_CONVENIOS_CNV_ID")
	private Convenio convenio;

	@ManyToOne
	@JoinColumn(name = "EXT_ESTADO_TX_EST_ID")
	private EstadoTransaccion estadoTx;

	@Column(name = "INTENCION_PAGO")
	private Integer intencionPago;

	@ManyToOne
	@JoinColumn(name="TIPO_DOC_DO")
	private TipoDocumento tipoDocumento;

	@Column(name = "TX_CONSULTA_COMPROBANTE", columnDefinition = "char")
	private boolean consultaComprobante;

	@Column(name = "CICLO_ACH")
	private String cicloAch;

	@Column(name = "TX_ID_CPV")
	private String idCpv;

	@Column(name = "TX_TASA_CAMBIO")
	private String tasaCambio;

	@Column(name = "TX_TAQUILLA", columnDefinition = "char")
	private Boolean taquilla;

	@Column(name = "TX_ERROR_MARCACION")
	private String errorMarcacion;

	@Column(name = "TX_REINTENTOS_MARCACION")
	private BigDecimal reintentosMarcacion;

	@Column(name = "TX_NEXT_DAY")
	@Temporal(TemporalType.TIMESTAMP)
	private Date fechaNextDay;

	@Column(name = "CONCEPTO_PAGO", columnDefinition = "char")
	private String conceptoPago;

	@Column(name = "TX_URL_RESPUESTA")
	private String urlRespuestaCpv;
	
	@OneToMany()
	@JoinColumn(name = "TX_ID")
	private List<ReferenciaTx> referenciaTxs;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getBancoPortal() {
		return bancoPortal;
	}

	public void setBancoPortal(String bancoPortal) {
		this.bancoPortal = bancoPortal;
	}

	public String getFqrId() {
		return fqrId;
	}

	public void setFqrId(String fqrId) {
		this.fqrId = fqrId;
	}

	public MedioPago getMedioPago() {
		return medioPago;
	}

	public void setMedioPago(MedioPago medioPago) {
		this.medioPago = medioPago;
	}

	public String getNumDocumento() {
		return numDocumento;
	}

	public void setNumDocumento(String numDocumento) {
		this.numDocumento = numDocumento;
	}

	public String getApellidoCliente() {
		return apellidoCliente;
	}

	public void setApellidoCliente(String apellidoCliente) {
		this.apellidoCliente = apellidoCliente;
	}

	public String getAprobacionId() {
		return aprobacionId;
	}

	public void setAprobacionId(String aprobacionId) {
		this.aprobacionId = aprobacionId;
	}

	public boolean isAsociadaPorCorreo() {
		return asociadaPorCorreo;
	}

	public void setAsociadaPorCorreo(boolean asociadaPorCorreo) {
		this.asociadaPorCorreo = asociadaPorCorreo;
	}

	public String getBancoAch() {
		return bancoAch;
	}

	public void setBancoAch(String bancoAch) {
		this.bancoAch = bancoAch;
	}

	public String getBancoId() {
		return bancoId;
	}

	public void setBancoId(String bancoId) {
		this.bancoId = bancoId;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	public String getCurCode() {
		return curCode;
	}

	public void setCurCode(String curCode) {
		this.curCode = curCode;
	}

	public String getEmailCliente() {
		return emailCliente;
	}

	public void setEmailCliente(String emailCliente) {
		this.emailCliente = emailCliente;
	}

	public Date getFechaInicioPago() {
		return fechaInicioPago;
	}

	public void setFechaInicioPago(Date fechaInicioPago) {
		this.fechaInicioPago = fechaInicioPago;
	}

	public Date getFechaModifPago() {
		return fechaModifPago;
	}

	public void setFechaModifPago(Date fechaModifPago) {
		this.fechaModifPago = fechaModifPago;
	}

	public Date getFechaActualizacion() {
		return fechaActualizacion;
	}

	public void setFechaActualizacion(Date fechaActualizacion) {
		this.fechaActualizacion = fechaActualizacion;
	}

	public String getIpCliente() {
		return ipCliente;
	}

	public void setIpCliente(String ipCliente) {
		this.ipCliente = ipCliente;
	}

	public String getNitCliente() {
		return nitCliente;
	}

	public void setNitCliente(String nitCliente) {
		this.nitCliente = nitCliente;
	}

	public String getNombreCliente() {
		return nombreCliente;
	}

	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}

	public String getNombrePagador() {
		return nombrePagador;
	}

	public void setNombrePagador(String nombrePagador) {
		this.nombrePagador = nombrePagador;
	}

	public String getNumAuth() {
		return numAuth;
	}

	public void setNumAuth(String numAuth) {
		this.numAuth = numAuth;
	}

	public String getNumTarjeta() {
		return numTarjeta;
	}

	public void setNumTarjeta(String numTarjeta) {
		this.numTarjeta = numTarjeta;
	}

	public String getPagoId() {
		return pagoId;
	}

	public void setPagoId(String pagoId) {
		this.pagoId = pagoId;
	}

	public String getRquId() {
		return rquId;
	}

	public void setRquId(String rquId) {
		this.rquId = rquId;
	}

	public BigDecimal getTipoAporte() {
		return tipoAporte;
	}

	public void setTipoAporte(BigDecimal tipoAporte) {
		this.tipoAporte = tipoAporte;
	}

	public String getTipoMoneda() {
		return tipoMoneda;
	}

	public void setTipoMoneda(String tipoMoneda) {
		this.tipoMoneda = tipoMoneda;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getPendienteMarcacion() {
		return pendienteMarcacion;
	}

	public void setPendienteMarcacion(String pendienteMarcacion) {
		this.pendienteMarcacion = pendienteMarcacion;
	}

	public BigDecimal getValor() {
		return valor;
	}

	public void setValor(BigDecimal valor) {
		this.valor = valor;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getUuidCpv() {
		return uuidCpv;
	}

	public void setUuidCpv(String uuidCpv) {
		this.uuidCpv = uuidCpv;
	}

	public String getDesErrorMarcacion() {
		return desErrorMarcacion;
	}

	public void setDesErrorMarcacion(String desErrorMarcacion) {
		this.desErrorMarcacion = desErrorMarcacion;
	}

	public BancoPago getBancoPago() {
		return bancoPago;
	}

	public void setBancoPago(BancoPago bancoPago) {
		this.bancoPago = bancoPago;
	}

	public Convenio getConvenio() {
		return convenio;
	}

	public void setConvenio(Convenio convenio) {
		this.convenio = convenio;
	}

	public EstadoTransaccion getEstadoTx() {
		return estadoTx;
	}

	public void setEstadoTx(EstadoTransaccion estadoTx) {
		this.estadoTx = estadoTx;
	}

	public Integer getIntencionPago() {
		return intencionPago;
	}

	public void setIntencionPago(Integer intencionPago) {
		this.intencionPago = intencionPago;
	}

	public TipoDocumento getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(TipoDocumento tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public boolean isConsultaComprobante() {
		return consultaComprobante;
	}

	public void setConsultaComprobante(boolean consultaComprobante) {
		this.consultaComprobante = consultaComprobante;
	}

	public String getCicloAch() {
		return cicloAch;
	}

	public void setCicloAch(String cicloAch) {
		this.cicloAch = cicloAch;
	}

	public String getIdCpv() {
		return idCpv;
	}

	public void setIdCpv(String idCpv) {
		this.idCpv = idCpv;
	}

	public String getTasaCambio() {
		return tasaCambio;
	}

	public void setTasaCambio(String tasaCambio) {
		this.tasaCambio = tasaCambio;
	}

	public Boolean isTaquilla() {
		return taquilla;
	}

	public void setTaquilla(Boolean taquilla) {
		this.taquilla = taquilla;
	}

	public String getErrorMarcacion() {
		return errorMarcacion;
	}

	public void setErrorMarcacion(String errorMarcacion) {
		this.errorMarcacion = errorMarcacion;
	}

	public BigDecimal getReintentosMarcacion() {
		return reintentosMarcacion;
	}

	public void setReintentosMarcacion(BigDecimal reintentosMarcacion) {
		this.reintentosMarcacion = reintentosMarcacion;
	}

	public Date getFechaNextDay() {
		return fechaNextDay;
	}

	public void setFechaNextDay(Date fechaNextDay) {
		this.fechaNextDay = fechaNextDay;
	}

	public String getConceptoPago() {
		return conceptoPago;
	}

	public void setConceptoPago(String conceptoPago) {
		this.conceptoPago = conceptoPago;
	}

	public String getUrlRespuestaCpv() {
		return urlRespuestaCpv;
	}

	public void setUrlRespuestaCpv(String urlRespuestaCpv) {
		this.urlRespuestaCpv = urlRespuestaCpv;
	}

	public List<ReferenciaTx> getReferenciaTxs() {
		return referenciaTxs;
	}

	public void setReferenciaTxs(List<ReferenciaTx> referenciaTxs) {
		this.referenciaTxs = referenciaTxs;
	}
	
	
}
