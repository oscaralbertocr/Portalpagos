package co.com.ath.recaudadores.email;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.persistence.EntityManagerFactory;

import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.database.JpaPagingItemReader;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.entities.ArchivoFacturacion;
import co.com.ath.recaudadores.apirest.util.Constants;

/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 

@Service
@StepScope
public class AuditItemReader extends JpaPagingItemReader<ArchivoFacturacion>{

	@Resource
	private EntityManagerFactory entityManagerFactory;
	
	@PostConstruct
	private void init() {
		this.setEntityManagerFactory(entityManagerFactory);
		this.setQueryString(this.generateString());
		this.setParameterValues(this.generateParameters());
	}

	private String generateString() {
		StringBuilder jpql = new StringBuilder();
		jpql.append("SELECT AF FROM ArchivoFacturacion AF ");
		jpql.append("WHERE AF.estadoPaycentral ");
		jpql.append("IN (:aplicado, :rechazado) ");
		jpql.append("AND AF.emailNotificacionEnviado = 0");
		return jpql.toString();
	}
	
	private Map<String, Object>  generateParameters() {
		Map<String, Object> params = new HashMap<>();
		params.put("aplicado", Constants.aplicado);
		params.put("rechazado", Constants.rechazado);
		return params;
	}
}