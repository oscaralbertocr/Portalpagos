package co.com.ath.recaudadores.apirest.model.dto;

import java.io.Serializable;

/*
 * Clase : AlertRecaudadorDTO
 * Date  : 07-Ene-2021
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
public class AlertRecaudadorDTO implements Serializable {
	private String id;
	private String mensaje;
	private String tipo;
	private boolean estado;

	public AlertRecaudadorDTO() {
		
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public boolean isEstado() {
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
}
