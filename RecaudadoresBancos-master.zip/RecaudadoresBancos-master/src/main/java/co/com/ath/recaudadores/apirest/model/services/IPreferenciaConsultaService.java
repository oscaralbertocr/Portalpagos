package co.com.ath.recaudadores.apirest.model.services;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.dto.PreferenciaConsultaDTO;
/*
 * Clase : ParametriasConsultaService
 * Date  : 24-Oct-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Transactional(value = "prvTransactionManager")
public interface IPreferenciaConsultaService {
	
 public List<PreferenciaConsultaDTO> findAll(String convenio, String usuario);

 public List<PreferenciaConsultaDTO> guardar(List<PreferenciaConsultaDTO> lst);

 
}
