package co.com.ath.recaudadores.apirest.model.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.entities.Facturacion;

/*
 * Clase : ICategoriaDao
 * Date  : 21-Dic-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Transactional(value = "prvTransactionManager", readOnly = true)
public interface IConsultaFacturacionDAO extends CrudRepository<Facturacion, Long> {

		@Query(value = "select * from archivo_facturacion fact \r\n"
			+ "inner join ext_convenios     conv ON fact.af_convenio_id = conv.cnv_id \r\n"
			+ "inner join ext_convenio_conf conf ON conv.cnv_id = conf.cnv_id \r\n"
			+ "where (fact.af_fecha_carga between to_timestamp(?1, 'yyyy-mm-dd hh24:mi') \r\n"
			+ "and to_timestamp(?2, 'yyyy-mm-dd hh24:mi')) and conv.cnv_id = ?3 and\r\n"
			+ "(conv.cnv_dueno_id=1 or conv.cnv_dueno_id=2 )  and conv.ext_estado_convenios_id !=3 \r\n"
			+ "and conf.cnv_bank_id='00010524' order by fact.af_fecha_carga", nativeQuery = true)
	public List<Facturacion> consultaFacturacion(String desde, String hasta, String idConvenio);

}
