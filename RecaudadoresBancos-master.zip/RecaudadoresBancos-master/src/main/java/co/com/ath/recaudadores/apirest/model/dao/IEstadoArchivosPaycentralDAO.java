package co.com.ath.recaudadores.apirest.model.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import co.com.ath.recaudadores.apirest.model.entities.EstadoArchivosPaycentral;

/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
@Transactional(value = "prvTransactionManager")
public interface IEstadoArchivosPaycentralDAO extends CrudRepository<EstadoArchivosPaycentral, Long> {

	@Query(value = "UPDATE portal_depagos.EXT_ESTADO_ARCHIVOS_PAYCENTRAL SET FLAG_CORREO = 1 WHERE ARCH_ID = ?1",  nativeQuery = true)
	public List<EstadoArchivosPaycentral> actualizarBanderaCorreo(Long id);
	
	@Query(value = "SELECT * FROM portal_depagos.EXT_ESTADO_ARCHIVOS_PAYCENTRAL WHERE FLAG_CORREO IS NULL AND ROWNUM < 10",  nativeQuery = true)
	public List<EstadoArchivosPaycentral> buscarSinEnvioCorreo();
	
}
