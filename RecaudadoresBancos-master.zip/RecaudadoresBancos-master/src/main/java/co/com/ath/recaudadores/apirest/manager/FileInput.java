package co.com.ath.recaudadores.apirest.manager;

import java.io.File;

import javax.annotation.PostConstruct;

import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.FixedLengthTokenizer;
import org.springframework.batch.item.file.transform.Range;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dto.ArchivoInputDTO;
/**
 * @author Jesus Octavio Avendaño Sierra <jesus.avendano@sophossolutions.com> 
 * @version 1.0 10/12/2020
 * 
 * @sophosSolutions
 * <strong>Autor: </strong>Jesus Octavio Avendaño Sierra</br>
 * <strong>Numero de Cambios: </strong>0</br>
 * 	
*/ 
@Service
@StepScope
public class FileInput extends FlatFileItemReader<ArchivoInputDTO>{

	@Value("#{jobParameters[pathInput]}")
	private String pathInput;
	
	@Value("#{jobParameters[fileNameInput]}")
	private String fileNameInput;
	
	@PostConstruct
	public void init() { 
		this.setResource(new FileSystemResource(new File(this.pathInput, this.fileNameInput)));
		this.setName("UploadFileReader");
		this.setEncoding("utf8");
		this.setLineMapper(this.lineMapper());
	}
	
	private DefaultLineMapper<ArchivoInputDTO> lineMapper(){
		DefaultLineMapper<ArchivoInputDTO> defaultLineMapper = new DefaultLineMapper<ArchivoInputDTO>();
		defaultLineMapper.setFieldSetMapper(new FileMapper());
		defaultLineMapper.setLineTokenizer(this.tokenizerBaloto());
		return defaultLineMapper;
	}
		
	private FixedLengthTokenizer tokenizerBaloto() {
		FixedLengthTokenizer fixedLengthTokenizer = new FixedLengthTokenizer();
		String[] names = {
				"type",
				"acountNumber",
				"referenceOne",
				"dateOne",
				"valueOne",
				"dateTwo",
				"valueTwo",
				"dateThree",
				"valueThree",
				"dateFour",
				"valueFour",
				"referenceTwo",
				"referenceThree",
				"referenceFour",
				"billingCycle",
				"cycleEffectiveDate",
				"filler"
		};

		Range[] ranges = {
				new Range(1,1),
				new Range(2,17),
				new Range(18,33),
				new Range(34,41),
				new Range(42,59),
				new Range(60,67),
				new Range(68,85),
				new Range(86,93),
				new Range(94,111),
				new Range(112,119),
				new Range(120,137),
				new Range(138,153),
				new Range(154,169),
				new Range(170,185),
				new Range(186,188),
				new Range(189,196),
				new Range(197,266)
		};

		fixedLengthTokenizer.setNames(names);
		fixedLengthTokenizer.setColumns(ranges);
		return fixedLengthTokenizer;
	}
}
