package co.com.ath.recaudadores.apirest.model.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import co.com.ath.recaudadores.apirest.model.dao.IAlertRecaudadorDAO;
import co.com.ath.recaudadores.apirest.model.dto.AlertRecaudadorDTO;
import co.com.ath.recaudadores.apirest.model.entities.AlertRecaudador;
import co.com.ath.recaudadores.apirest.model.services.IAlertRecaudadorService;

@Service
public class AlertRecaudadorServiceImpl implements IAlertRecaudadorService {

	@Autowired
	private IAlertRecaudadorDAO alertRecaudadorDAO;

	@Autowired
	private CacheManager cacheManager;

	/* (non-Javadoc)
	 * @see co.com.ath.recaudadores.apirest.model.services.IAlertRecaudadorService#save(co.com.ath.recaudadores.apirest.model.dto.AlertRecaudadorDTO)
	 */
	@Override
	public AlertRecaudadorDTO save(AlertRecaudadorDTO alertRecaudadorDTO) {
		AlertRecaudador alertRecaudador = new AlertRecaudador();
		alertRecaudador.toAlertRecaudador(alertRecaudadorDTO);
		alertRecaudador = alertRecaudadorDAO.save(alertRecaudador);
		cacheManager.getCache("cache").put(alertRecaudador.getId(), alertRecaudador.toAlertRecaudadorDTO());
		return alertRecaudador.toAlertRecaudadorDTO();
	}

	/* (non-Javadoc)
	 * @see co.com.ath.recaudadores.apirest.model.services.IAlertRecaudadorService#findAll()
	 */
	@Override
	public List<AlertRecaudadorDTO> findAll() {
		List<AlertRecaudador> lstAlert;
		List<AlertRecaudadorDTO> lst = new ArrayList<>();
		
		cacheManager.getCache("cache").clear();
		lstAlert = (List<AlertRecaudador>) alertRecaudadorDAO.findAll();
		for (AlertRecaudador a : lstAlert) {
			cacheManager.getCache("cache").put(a.getId(), a.toAlertRecaudadorDTO());
			lst.add(a.toAlertRecaudadorDTO());
		}
		return lst;
	}

	/* (non-Javadoc)
	 * @see co.com.ath.recaudadores.apirest.model.services.IAlertRecaudadorService#update(co.com.ath.recaudadores.apirest.model.dto.AlertRecaudadorDTO)
	 */
	@Override
	@CachePut(value = "cache", key = "#alertRecaudadorDTO.id")
	public AlertRecaudadorDTO update(AlertRecaudadorDTO alertRecaudadorDTO) {

		if (alertRecaudadorDAO.exists(alertRecaudadorDTO.getId())) {
			AlertRecaudador alertRecaudador = alertRecaudadorDAO.findOne(alertRecaudadorDTO.getId());
			alertRecaudador.toAlertRecaudador(alertRecaudadorDTO);

			return alertRecaudadorDAO.save(alertRecaudador).toAlertRecaudadorDTO();
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see co.com.ath.recaudadores.apirest.model.services.IAlertRecaudadorService#find(java.lang.String)
	 */
	@Override
	@Cacheable(value = "cache")
	public AlertRecaudadorDTO find(String id) {
		if (alertRecaudadorDAO.exists(id)) {
			AlertRecaudador alertRecaudador = alertRecaudadorDAO.findOne(id);
			return alertRecaudador.toAlertRecaudadorDTO();
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see co.com.ath.recaudadores.apirest.model.services.IAlertRecaudadorService#delete(co.com.ath.recaudadores.apirest.model.dto.AlertRecaudadorDTO)
	 */
	@Override
	@CacheEvict(value = "cache", key = "#alertRecaudadorDTO")
	public void delete(AlertRecaudadorDTO alertRecaudadorDTO) {
		AlertRecaudador alertRecaudador = alertRecaudadorDAO.findOne(alertRecaudadorDTO.getId());
		if (alertRecaudador != null) {
			alertRecaudadorDAO.delete(alertRecaudador.getId());
		}
	}

}
