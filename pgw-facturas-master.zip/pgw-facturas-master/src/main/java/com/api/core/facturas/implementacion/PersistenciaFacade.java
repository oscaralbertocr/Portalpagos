package com.api.core.facturas.implementacion;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public abstract class PersistenciaFacade<T> {

	private Class<T> entityClass;

	@PersistenceContext()
	private EntityManager entityManager;

	public PersistenciaFacade(Class<T> entityClass) {
		this.entityClass = entityClass;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	protected void crear(T entity) {
		this.entityManager.persist(entity);
	}

	protected void editar(T entity) {
		this.entityManager.merge(entity);
	}

	protected void borrar(T entity) {
		this.entityManager.remove(this.entityManager.merge(entity));
	}

	protected T buscar(Object id) {
		return this.entityManager.find(entityClass, id);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected List<T> consultar() {
		javax.persistence.criteria.CriteriaQuery cq = this.entityManager.getCriteriaBuilder().createQuery();
		cq.select(cq.from(entityClass));
		return this.entityManager.createQuery(cq).getResultList();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected List<T> consultarRango(int[] range) {
		javax.persistence.criteria.CriteriaQuery cq = this.entityManager.getCriteriaBuilder().createQuery();
		cq.select(cq.from(entityClass));
		javax.persistence.Query q = this.entityManager.createQuery(cq);
		q.setMaxResults(range[1] - range[0] + 1);
		q.setFirstResult(range[0]);
		return q.getResultList();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected int contar() {
		javax.persistence.criteria.CriteriaQuery cq = this.entityManager.getCriteriaBuilder().createQuery();
		javax.persistence.criteria.Root<T> rt = cq.from(entityClass);
		cq.select(this.entityManager.getCriteriaBuilder().count(rt));
		javax.persistence.Query q = this.entityManager.createQuery(cq);
		return ((Long) q.getSingleResult()).intValue();
	}
}
