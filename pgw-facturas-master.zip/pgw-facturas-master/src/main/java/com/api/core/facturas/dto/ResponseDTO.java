package com.api.core.facturas.dto;

import java.io.Serializable;

public class ResponseDTO implements Serializable{
	
	private int RqUID;
	private int ApprovalId;
	private int respuesta;
	
	public int getRqUID() {
		return RqUID;
	}
	public void setRqUID(int rqUID) {
		RqUID = rqUID;
	}
	public int getApprovalId() {
		return ApprovalId;
	}
	public void setApprovalId(int approvalId) {
		ApprovalId = approvalId;
	}
	public int getRespuesta() {
		return respuesta;
	}
	public void setRespuesta(int respuesta) {
		this.respuesta = respuesta;
	}
	
	
	
	
}
