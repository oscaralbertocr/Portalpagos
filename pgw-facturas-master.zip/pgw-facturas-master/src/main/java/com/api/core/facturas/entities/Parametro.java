package com.api.core.facturas.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.api.core.facturas.dto.ParametroDTO;

/*
 * Clase : Parametro
 * Date  : 18-Nov-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */

@Entity
@Table(name = "EXT_PARAM_RECAUDADOR_BANCO")
public class Parametro implements Serializable {

	@Id
	@Column(name = "CLAVE", nullable = false)
	private String clave;

	@Column(name = "VALOR", nullable = false)
	private String valor;

	@Column(name = "ESTADO", nullable = false)
	private String estado;

	@Column(name = "TIPO", nullable = false)
	private String tipo;
	
	@Column(name = "DESCRIPCION", nullable = false)
	private String descripcion;

	@Column(name = "FECHA_CREACION", nullable = false)
	private Date fechaCreacion;

	@Column(name = "FECHA_MODIFICACION")
	private Date fechaModificacion;

	public Parametro() {

	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	@Override
	public String toString() {
		return "Parametro [clave=" + clave + ", valor=" + valor + ", estado=" + estado + ", tipo=" + tipo
				+ ", descripcion=" + descripcion + ", fechaCreacion=" + fechaCreacion + ", fechaModificacion="
				+ fechaModificacion + "]";
	}

	/**
	 * @return
	 */
	public ParametroDTO toParametroDAO() {
		ParametroDTO parametroDTO = new ParametroDTO();

		parametroDTO.setClave(this.clave);
		parametroDTO.setValor(this.valor);		
		parametroDTO.setEstado(this.estado);
		parametroDTO.setTipo(this.tipo);
		parametroDTO.setDescripcion(this.descripcion);
		return parametroDTO;
	}

	/**
	 * 
	 */
	public void toParametro(ParametroDTO parametroDTO) {
		this.clave = parametroDTO.getClave();
		this.valor = parametroDTO.getValor();
		this.estado = parametroDTO.getEstado();
		this.tipo = parametroDTO.getTipo();
		this.descripcion = parametroDTO.getDescripcion();
		this.fechaCreacion = parametroDTO.getFechaCreacion();
		this.fechaModificacion = parametroDTO.getFechaModificacion();
	}
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
