package com.api.core.facturas.servicio;

import org.springframework.transaction.annotation.Transactional;

import com.api.core.facturas.dto.ParametroDTO;
/*
 * Clase : IParametroService
 * Date  : 18-Nov-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */

public interface IParametroService {
	
	public ParametroDTO save(ParametroDTO parametroDTO);
	
	public ParametroDTO find(String clave);

}
