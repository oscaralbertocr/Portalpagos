package com.api.core.facturas.dto;

import java.io.Serializable;
import java.util.Date;

/*
 * Clase : ParametroDTO
 * Date  : 18-Nov-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
public class ParametroDTO implements Serializable {

	private String clave;
	private String valor;
	private String estado;
	private String tipo;
	private String descripcion;
	private Date fechaCreacion;
	private Date fechaModificacion;

	public ParametroDTO() {
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ParametroDTO [clave=" + clave + ", valor=" + valor + ", estado=" + estado + ", tipoValor=" + tipo
				+ ", descripcion=" + descripcion + ", fechaCreacion=" + fechaCreacion + ", fechaModificacion="
				+ fechaModificacion + "]";
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
