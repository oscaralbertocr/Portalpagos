package com.api.core.facturas.dto;

import java.io.Serializable;
import java.sql.Date;
import java.text.SimpleDateFormat;


public class FacturasDTO implements Serializable{
	
	private String nameFile;
	private Date dateFile;
	private String rejection;
	private String codeNura;
	private String state;
	private int percentage;
	 
	
	public FacturasDTO() {
		
	}


	public String getNameFile() {
		return nameFile;
	}


	public void setNameFile(String nameFile) {
		this.nameFile = nameFile;
	}


	public Date getDateFile() {
		return dateFile;
	}


	public void setDateFile(Date dateFile) {
		this.dateFile = dateFile;
	}


	public String getRejection() {
		return rejection;
	}


	public void setRejection(String rejection) {
		this.rejection = rejection;
	}


	public String getCodeNura() {
		return codeNura;
	}


	public void setCodeNura(String codeNura) {
		this.codeNura = codeNura;
	}


	public String getState() {
		return state;
	}


	public void setState(String state) {
		this.state = state;
	}


	public int getPercentage() {
		return percentage;
	}


	public void setPercentage(int percentaje) {
		this.percentage = percentaje;
	}
	
	
	
}
