package com.api.core.facturas.servicio;

import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Local;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.api.core.facturas.dto.MailServiceInDTO;
import com.api.core.facturas.utilidades.CustomException;

@Service
@Local
public class MailService {
	
	static Logger logger = LoggerFactory.getLogger(MailService.class);

	JavaMailSenderImpl mailSenderImpl;

	@Autowired
	private IParametroService parametroService;
	
	private JavaMailSender javaMailSender;
	
	@PostConstruct
	public void init() {
		logger.info(parametroService.find("SMTPHost").getValor());
		
		mailSenderImpl = new JavaMailSenderImpl();
	
		mailSenderImpl.setHost(parametroService.find("SMTPHost").getValor());
		mailSenderImpl.setPort(Integer.parseInt(parametroService.find("SMTPPort").getValor()));
		if(parametroService.find("SMTPUser") != null && !parametroService.find("SMTPUser").getValor().isEmpty()) {
			mailSenderImpl.setUsername(parametroService.find("SMTPUser").getValor());
		}
		if(parametroService.find("SMTPPass") != null && !parametroService.find("SMTPPass").getValor().isEmpty()) {
			mailSenderImpl.setUsername(parametroService.find("SMTPPass").getValor());
		}
		mailSenderImpl.setProtocol(parametroService.find("SMTPProtocol").getValor());
		mailSenderImpl.setJavaMailProperties(this.getMailProperties());
		javaMailSender = mailSenderImpl;
	}
	
	@Async
	public void sendMail(MailServiceInDTO inDTO) throws CustomException{
		logger.info("Inicio envio de mensaje");
		MimeMessage message = javaMailSender.createMimeMessage();
		MimeMessageHelper mime;
		try {
			String fromEmail = parametroService.find("SMTPFrom").getValor();
			String subjectEmail = parametroService.find("SMTPSubject").getValor();
			mime = new MimeMessageHelper(message, true, "UTF-8");
			mime.setFrom(fromEmail);
			mime.setSubject((inDTO.getSubject()==null)?subjectEmail:inDTO.getSubject());
			mime.setTo(inDTO.getTo());
			if(inDTO.getCc() != null){
				mime.setCc(inDTO.getCc());
			}
			if(inDTO.getBcc() != null){
				mime.setBcc(inDTO.getBcc());
			}
			mime.setText(inDTO.getText(),true);
			logger.info("Se enviara el mensaje: {}, al destinatario: {}",inDTO.getText(), inDTO.getTo());
			mailSenderImpl.send(message);
		} catch (MessagingException e) {
			logger.info("Error Enviando Correo");
			logger.error(e.getMessage());
			logger.error(e.getLocalizedMessage());
			throw new CustomException();
		}
		logger.info("Fin envio de mensaje. Envio Exitoso");
	}
	
	private Properties getMailProperties() {
		Properties mailProperties = new Properties();
		mailProperties.put("mail.smtp.auth",  parametroService.find("SMTPAuth").getValor());
		mailProperties.put("mail.smtp.starttls.enable",  parametroService.find("SMTPStartTLS").getValor());
		mailProperties.put("mail.smtp.ssl.trust",  parametroService.find("SMTPSSLTrust").getValor());
		
		return mailProperties;
	}

}
