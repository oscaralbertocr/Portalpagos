package com.api.core.facturas.entities;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.transaction.Transactional;



@Entity
@Table(
		name = "ARCHIVO_FACTURACION",
		schema = "PORTAL_PAGOS"
)
@NamedQueries({
	@NamedQuery(name = "Factura.consultar", 
	query = "SELECT f FROM FacturasEntity f"
			+ " WHERE f.nombreArchivo = :nombreArchivo and f.codigoNura = :codigoNura")


})

public class FacturasEntity implements Serializable{

	private long id;
	
	private String codigoNura;
	
	private Date fechaCarga;
	
	private String nombreArchivo;
	
	private String estado;

	private String causalRechazo;

	private String correoUsuario;
	
	private Integer porcentaje;
	
	public FacturasEntity(String codigoNura, Date fechaCarga, String nombreArchivo, String estado) {
	
		this.codigoNura = codigoNura;
		this.fechaCarga = fechaCarga;
		this.nombreArchivo = nombreArchivo;
		this.estado = estado;
	}
	public FacturasEntity() {
		
	}
	
	@Id
	@Column(name="AF_ID")
	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	@Column(name="AF_NOMBRE_ATH")
	public String getNombreArchivo() {
		return nombreArchivo;
	}

	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}

	@Column(name="AF_CONVENIO_ID")
	public String getCodigoNura() {
		return codigoNura;
	}

	public void setCodigoNura(String codigoNura) {
		this.codigoNura = codigoNura;
	}
	@Column(name="AF_FECHA_CARGA")
	public Date getFechaCarga() {
		return fechaCarga;
	}

	public void setFechaCarga(Date fechaCarga) {
		this.fechaCarga = fechaCarga;
	}

	@Column(name="AF_ESTADO_PAYCENTRAL")
	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
		
	@Column(name="AF_CAUSAL_RECHAZO")
	public String getCausalRechazo() {
		return causalRechazo;
	}
	public void setCausalRechazo(String causalRechazo) {
		this.causalRechazo = causalRechazo;
	}
	
	
	@Column(name = "AF_CORREO_USUARIO")
	public String getCorreoUsuario() {
		return correoUsuario;
	}
	public void setCorreoUsuario(String correoUsuario) {
		this.correoUsuario = correoUsuario;
	}
	
	@Column(name = "AF_PORCENTAJE")
	public Integer getPorcentaje() {
		return porcentaje;
	}
	public void setPorcentaje(Integer porcentaje) {
		this.porcentaje = porcentaje;
	}
	
	@Override
	public String toString() {
		return "FacturasEntity [id=" + id + ", codigoNura=" + codigoNura + ", fechaCarga=" + fechaCarga
				+ ", nombreArchivo=" + nombreArchivo + ", estado=" + estado + ", causalRechazo=" + causalRechazo
				+ ", correoUsuario=" + correoUsuario + ", porcentaje=" + porcentaje + "]";
	}
	

	
	
}
//select campo1, campo2 from MiTabla order by campo2 offset 10 rows  fetch next 10 rows only;



