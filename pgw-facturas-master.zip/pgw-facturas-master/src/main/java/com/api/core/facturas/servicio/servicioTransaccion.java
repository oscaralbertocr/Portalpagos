package com.api.core.facturas.servicio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

import javax.ejb.EJB;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.api.core.facturas.Facturas;
import com.api.core.facturas.dto.*;
import com.api.core.facturas.entities.FacturasEntity;

import com.api.core.facturas.implementacion.AppFacturaImplementacion;
import com.api.core.facturas.utilidades.Validacion;
import com.fasterxml.jackson.databind.node.ObjectNode;

import ch.qos.logback.classic.Logger;

@RestController
@RequestMapping(value ="/facturas" , produces = MediaType.APPLICATION_JSON_VALUE)
public class servicioTransaccion {

	static Logger logger = (Logger) LoggerFactory.getLogger(servicioTransaccion.class);
	
	@Autowired
	private Facturas appFactura;

	private Validacion validaciones;

	@PostMapping("/actualizar")
	public ResponseEntity<String> cambioEstadoFacturas(@RequestHeader MultiValueMap<String, String> headers,@RequestBody List<FacturasDTO> facturas) {
		
		logger.info(headers.toString());
	
		    
		
		    HttpHeaders responseHeaders = new HttpHeaders();
		    responseHeaders.set("X-RqUID", 
		    		 headers.get("X-RqUID").get(0));

		try {

			// Si envia una lista vacia se retorna 0
			if (facturas.isEmpty()) {
				responseHeaders.set("X-ApprovalId","1");
				return ResponseEntity.ok()
					      .headers(responseHeaders)
					      .body("1");
			} else {
				for (FacturasDTO facturasEnviadas : facturas) {

					// Si no tiene los campos que se requiren no se ejecuta la actualizacion
					if (this.validaciones.validarCamposObligatorios(facturasEnviadas)) {
						this.appFactura.editarFactura(facturasEnviadas);
					}
				}
			}

		} catch (Exception e) {
			logger.info(e.getMessage());
			responseHeaders.set("X-ApprovalId","1");
			return ResponseEntity.ok()
				      .headers(responseHeaders)
				      .body("1");
		}
		// retorna uno si la lista no esta vacio y no se generan errores
		responseHeaders.set("X-ApprovalId","0");
		return ResponseEntity.ok()
			      .headers(responseHeaders)
			      .body("0");
	}

}
