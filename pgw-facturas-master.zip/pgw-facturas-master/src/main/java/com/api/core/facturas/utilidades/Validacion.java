package com.api.core.facturas.utilidades;

import com.api.core.facturas.dto.FacturasDTO;

public class Validacion {

	
	//Valida los campos vacios
	public static boolean validarCamposObligatorios(FacturasDTO factura) {
		if(factura.getCodeNura().isEmpty() || factura.getNameFile().isEmpty() || factura.getState().isEmpty()) {
			return false;
		}
			return true;
					
		
		
	}
}
