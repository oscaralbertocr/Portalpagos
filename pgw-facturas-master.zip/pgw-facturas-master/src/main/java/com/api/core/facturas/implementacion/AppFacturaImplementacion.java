package com.api.core.facturas.implementacion;

import com.api.core.facturas.dto.FacturasDTO;
import com.api.core.facturas.dto.MailServiceInDTO;
import com.api.core.facturas.entities.FacturasEntity;
import com.api.core.facturas.servicio.IParametroService;
import com.api.core.facturas.servicio.MailService;
import com.api.core.facturas.utilidades.*;
import com.api.core.facturas.Facturas;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

//@Repository
//@Stateless(mappedName = "Facturas")
//@Transactional
@Service
public class AppFacturaImplementacion extends PersistenciaFacade<FacturasEntity> implements Facturas{
	
	static Logger logger = LoggerFactory.getLogger(AppFacturaImplementacion.class);
	
	@Autowired
	MailService mailService;

	@Autowired
	private IParametroService parametroService;

	private final String formatMain = "dd/MM/yyyy hh:mm:ss a";

	public AppFacturaImplementacion() {
		super(FacturasEntity.class);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean editarFactura(FacturasDTO factura) {
		
		 try
		    {
			//consulta los registros segun el nombre de archivo y el codigo 
		Query query = this.getEntityManager().createNamedQuery("Factura.consultar");
		query.setParameter("nombreArchivo", factura.getNameFile());
		query.setParameter("codigoNura", factura.getCodeNura());
		//query.setParameter("fecha", factura.getFechaArchivo());
		//listan los registros
		
		List<FacturasEntity> facturasConsultadas=query.getResultList();
		
		//se recorren los registros y se actualizan con el estado
		for(FacturasEntity facturaConsultada:facturasConsultadas){
			logger.info(facturaConsultada.toString());

			facturaConsultada.setEstado(factura.getState());
			facturaConsultada.setCausalRechazo(factura.getRejection());
			//facturaConsultada.setPorcentaje(factura.getPercentage());
			this.getEntityManager().merge(facturaConsultada);
			logger.info(facturaConsultada.toString());
			//process(facturaConsultada);
			
		}
	
		  }catch (Exception e)
	    {
			  logger.error(e.getMessage());
	        return false;
	    }
		//return !query.getResultList().isEmpty();
		return true;
	
	}
	
	public FacturasEntity process(FacturasEntity item) throws Exception {
		try {
			MailServiceInDTO mail = new MailServiceInDTO();
			logger.info("Inicia el proceso del registro identificado con el ID: {} ", item.getId());
			FacturasEntity af = item;
			String message = parametroService.find("MailMessageSuccess").getValor();
			logger.info("Mensaje exitoso cargado");
			String messageError = parametroService.find("MailMessageErrorPYC").getValor();
			logger.info("Mensaje Error cargado");
			String subject = parametroService.find("SMTPSubject").getValor();
			logger.info("Asunto cargado");
		
				if(af.getCorreoUsuario()!=null) {
					mail.setTo(af.getCorreoUsuario());
					if(item.getEstado()!=null && !item.getEstado().equalsIgnoreCase("Rechazado")) {
						String mensajeExitoso;
						if(item.getPorcentaje() < 100) {
						 mensajeExitoso=message.replace("#fileName", (af.getNombreArchivo()!=null)?af.getNombreArchivo():"");
							mensajeExitoso=mensajeExitoso+", con un porcentaje de exito del "+item.getPorcentaje()+" %.";
							mail.setText(mensajeExitoso);
						}else {
							
							mail.setText(message.replace("#fileName", (af.getNombreArchivo()!=null)?af.getNombreArchivo():""));
						}
						
					}else if(item.getEstado()!=null && item.getEstado().equalsIgnoreCase("Rechazado")) {
						String mensajeModificado;
						if(item.getPorcentaje() < 100) {
							mensajeModificado=messageError.replace("#fileName", (af.getNombreArchivo()!=null)?af.getNombreArchivo():"");
							mensajeModificado=mensajeModificado.replace("#causalRechazo", (af.getCausalRechazo()!=null)?af.getCausalRechazo():"");
							mensajeModificado=mensajeModificado+", con un porcentaje de exito del "+item.getPorcentaje()+" %.";
							mail.setText(mensajeModificado);
						}else {
						mensajeModificado=messageError.replace("#fileName", (af.getNombreArchivo()!=null)?af.getNombreArchivo():"");
						mensajeModificado=mensajeModificado.replace("#causalRechazo", (af.getCausalRechazo()!=null)?af.getCausalRechazo():"");
						mail.setText(mensajeModificado);
						}
					
					}
					mail.setSubject((subject!=null)?subject:"");
					//mailService.sendMail(mail);
				}else {
					logger.info("no se encontro correo para el destinatario");
				}
			
			

			return item;
	
	
		} catch (Exception e) {
			logger.error("Error procesando el registro identificado con el ID: {}", item.getId());
			logger.error(e.getMessage());
			e.printStackTrace();
			return null;
		}
	}
	
	
	private String getDate() {
		SimpleDateFormat sdf = new SimpleDateFormat(this.formatMain);
		return sdf.format(new Date());
	}
	
	private String convertDate(String date) {
		DateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.sss");
		DateFormat sdf = new SimpleDateFormat(this.formatMain);
		try {
			Date newDate = sdf1.parse(date);
			return sdf.format(newDate);
		} catch (ParseException e) {
			try {
				return convertDateTwo(date);
			} catch (Exception e2) {
				try {
					return convertDateThree(date);
				}catch (Exception e3) {
					logger.error(e3.getMessage());
				}
				logger.error(e2.getMessage());
			}
			logger.error(e.getMessage());
			return null;
		}
	}
	
	private String convertDateTwo(String date) throws ParseException {
		DateFormat sdf = new SimpleDateFormat(this.formatMain);
		Date newDate = sdf.parse(date);
		return sdf.format(newDate);
	}
	
	private String convertDateThree(String date)throws ParseException {
		DateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
		DateFormat sdf2 = new SimpleDateFormat(this.formatMain);
		Date newDate = sdf.parse(date);
		return sdf2.format(newDate);
	}

}
