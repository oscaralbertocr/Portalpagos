package com.api.core.facturas.implementacion;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.api.core.facturas.IParametroDAO;
import com.api.core.facturas.dto.ParametroDTO;
import com.api.core.facturas.entities.Parametro;
import com.api.core.facturas.servicio.IParametroService;

/*
 * Clase : ParametroServiceImpl
 * Date  : 18-Nov-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Service
public class ParametroServiceImpl implements IParametroService {

	@Autowired
	private IParametroDAO parametroDAO;

	/* (non-Javadoc)
	 * @see co.com.ath.recaudadores.apirest.model.services.IParametroService#save(co.com.ath.recaudadores.apirest.model.dto.ParametroDTO)
	 */
	@Override
	public ParametroDTO save(ParametroDTO parametroDTO) {
		Parametro parametro = new Parametro();

		if (parametroDTO != null && parametroDTO.getClave() != null && !parametroDTO.getClave().isEmpty()) {
			parametro = parametroDAO.findById(parametroDTO.getClave());
			if (parametro != null) {
				parametroDTO.setFechaCreacion(parametro.getFechaCreacion());
				parametroDTO.setFechaModificacion(parametro.getFechaModificacion());
				if (!parametro.getValor().equals(parametroDTO.getValor())
						|| !parametro.getDescripcion().equals(parametroDTO.getDescripcion())
						|| !parametro.getEstado().equals(parametroDTO.getEstado())
						|| !parametro.getTipo().equals(parametroDTO.getTipo())) {
					parametroDTO.setFechaModificacion(new Date());
				}
			} else {
				parametro = new Parametro();
				parametroDTO.setFechaCreacion(new Date());
				parametroDTO.setFechaModificacion(new Date());
				parametroDTO.setEstado("A");
			}
			parametro.toParametro(parametroDTO);
			return parametroDAO.save(parametro).toParametroDAO();
		}
		return null;

	}

	/* (non-Javadoc)
	 * @see co.com.ath.recaudadores.apirest.model.services.IParametroService#find(java.lang.String)
	 */
	@Override
	public ParametroDTO find(String clave) {
		if (clave != null) {
			Parametro parametro = parametroDAO.findById(clave);
			if (parametro != null) {
				return parametro.toParametroDAO();
			}
		}
		return null;
	}
}
