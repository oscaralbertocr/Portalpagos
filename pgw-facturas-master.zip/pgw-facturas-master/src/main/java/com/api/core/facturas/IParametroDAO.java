package com.api.core.facturas;

import javax.ejb.Local;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.transaction.annotation.Transactional;

import com.api.core.facturas.entities.Parametro;


/*
 * Clase : IParametroDAO
 * Date  : 18-Nov-2020
 * Author: Javier Capera
 *         SOPHOS SOLUTIONS
 */
@Local
public interface IParametroDAO extends CrudRepository<Parametro, Long> {

	@Query(value = "select * from ext_param_recaudador_banco par where par.clave=?1", nativeQuery = true)
	public Parametro findById( String id);
	
}
