package com.portalrecaudadores.consultatransacciones.portlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.FacesException;
import javax.naming.NamingException;
import javax.portlet.PortletException;
import javax.portlet.PortletSession;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.exception.ExceptionUtils;

import com.ath.portalpagos.util.ExceptionManager;
import com.co.pragma.portal.utils.WCMCliente;
import com.google.gson.Gson;
import com.ibm.portal.portlet.service.PortletServiceUnavailableException;
import com.ibm.portal.puma.PumaException;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.exceptions.WCMException;
import com.portalrecaudadores.consultatransacciones.beans.ConsultaTransaccionesBeanWcm;
import com.portalrecaudadores.consultatransacciones.beans.EstadoTransaccion;
import com.portalrecaudadores.consultatransacciones.beans.RutaContenidoBean;
import com.portalrecaudadores.consultatransacciones.util.CommonUtils;
import com.portalrecaudadores.consultatransacciones.util.ErrorManager;
import com.portalrecaudadores.consultatransacciones.util.Puma;

import co.com.ath.logger.CustomLogger;
import co.com.ath.parameterspage.ParametersPage;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.cache.manager.CacheManager;
import co.com.ath.payments.mc.service.model.ErrorData;
import co.com.ath.payments.mc.service.model.json.GetConvenioInfoRq;
import co.com.ath.payments.mc.service.model.json.GetConvenioInfoRs;
import co.com.ath.payments.mc.service.model.json.MedioPagoType;
import co.com.ath.utilparamspage.util.GetPostfixDN;

public class ConsultaTransaccionesPortlet extends
		com.ibm.faces20.portlet.FacesPortlet {
	
	private CustomLogger logger= new CustomLogger(ConsultaTransaccionesPortlet.class);

	public void doView(RenderRequest request, RenderResponse response)
			throws PortletException, IOException {
		GetPostfixDN.getParamsPagePortal(request, response);
		RutaContenidoBean rContenido = null;
		String rquid = null;
		try {
			rquid = PublisherUtil.getInstance().generateRequestID();
			rContenido = rutaContenido(request,response,rquid);
			obtenerContenidoWCM(request, response, rquid, rContenido);
			super.doView(request, response);
		} catch (NoClassDefFoundError e){
			Exception e1=(Exception) ExceptionUtils.getRootCause(e);
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e1, rquid, ExceptionManager.PP_PORTAL_LIBRERIAS_01, rContenido.getUserName(), ExceptionManager.MSG_PORTAL_LIBRERIAS_01+" - Operación: Cargar vista, ConsultaTransacciones", "doView", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getBankName()); 
			logger.error(errorData, e1);
			String[] error= ErrorManager.getInstance(request, rquid, rContenido.getUserName()).obtenerErrorWCM(ExceptionManager.PP_PORTAL_LIBRERIAS_01);
			ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
			consulta.mostrarModal(error[0], "icon-error", error[1]);
		} catch(Exception e){
			try {
				throw ExceptionUtils.getRootCause(e);
			} catch(FacesException e1){
				ErrorData errorData= PublisherUtil.getInstance().getErrorData(e1, rquid, ExceptionManager.PP_PORTAL_FACES_01, rContenido.getUserName(), ExceptionManager.MSG_PORTAL_FACES_01+" - Operación: Cargar vista, ConsultaTransacciones", "doView", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getBankName()); 
				logger.error(errorData, e1);
				String[] error= ErrorManager.getInstance(request, rquid, rContenido.getUserName()).obtenerErrorWCM(ExceptionManager.PP_PORTAL_FACES_01);
				ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
				consulta.mostrarModal(error[0], "icon-error", error[1]);
			} catch (Throwable e1) {
				ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, rContenido.getUserName(), ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: Cargar vista, ConsultaTransacciones", "doView", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getBankName());
				logger.error(errorData, e);
				String[] error= ErrorManager.getInstance(request, rquid, rContenido.getUserName()).obtenerErrorWCM(ExceptionManager.PP_PORTAL_GENERIC_01);
				ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
				consulta.mostrarModal(error[0], "icon-error", error[1]);
			}
		}

	}


	/***
	 * HU72 Genera el ArrayList de estado Transaccion a partir del contenido
	 * ledido del WCM
	 * 
	 * @author Daniel Mejia
	 * @param txtMediosPago
	 * @throws Exception
	 */
	private List<EstadoTransaccion> cargarEstados(String txtMediosPago)
			throws Exception {
		List<EstadoTransaccion> estado = new ArrayList<EstadoTransaccion>();
		if (txtMediosPago != null && !txtMediosPago.equals("")) {
			String entradas[] = txtMediosPago.split(";");
			String mp[];
			for (String in : entradas) {
				mp = in.split(",");
				EstadoTransaccion estadoT = new EstadoTransaccion(mp[0], mp[1]);
				estado.add(estadoT);
			}
		}
		return estado;
	}

	/***
	 * HU 72 Obtiene los parametros ledidos del WCM
	 * 
	 * @author Daniel Mejia
	 * @param RenderRequest
	 * @param RenderResponse
	 */
	private void obtenerContenidoWCM(RenderRequest request,	RenderResponse response, String rquid, RutaContenidoBean rContenido) {
		WCMCliente cliente = null;
		try {
			String estadoT;

			
			request.setAttribute("urlHome", rContenido.getUrlHome());

			cliente = new WCMCliente(rContenido.getPathContentConsultaTransacciones());
			ConsultaTransaccionesBeanWcm contWcm = (ConsultaTransaccionesBeanWcm)request.getPortletSession().getAttribute("consultarTransaccionesBeanPortlet");

			if (null == contWcm) {
				contWcm = new ConsultaTransaccionesBeanWcm();	
			}
			contWcm.setLabelFechaInicial(((ShortTextComponent) cliente
					.getComponent("stLabelFechaInicial")).getText());
			contWcm.setLabelFechaFinal(((ShortTextComponent) cliente
					.getComponent("stLabelFechaFinal")).getText());
			contWcm.setLabelEstado(((ShortTextComponent) cliente
					.getComponent("stLabelEstadoT")).getText());
			contWcm.setLabelMedioPago(((ShortTextComponent) cliente
					.getComponent("stLabelMedioPago")).getText());
			contWcm.setLabelCUS(((ShortTextComponent) cliente
					.getComponent("stLabelCUS")).getText());
			contWcm.setLabelToolTip(((ShortTextComponent) cliente
					.getComponent("stTooltipCUS")).getText());
			contWcm.setLabelToolTipEstado(((TextComponent) cliente
					.getComponent("txtToolTipEstado")).getText());
			contWcm.setLabelIdTrans(((ShortTextComponent) cliente
					.getComponent("stLabelIdTrans")).getText());
			contWcm.setLabelBusqueda(((ShortTextComponent) cliente
					.getComponent("stLabelBusqueda")).getText());
			contWcm.setTxtNumCUS("");
			contWcm.setTxtNumIdTrans("");
			contWcm.setReferenciaPago("");
			contWcm.setPrimeraReferenciaAdicional("");
			contWcm.setSegundaReferenciaAdicional("");
			contWcm.setTerceraReferenciaAdicional("");
			contWcm.setLabelIdTrans(((ShortTextComponent) cliente
					.getComponent("stLabelIdTrans")).getText());
			contWcm.setLabelNumReferencia(((ShortTextComponent) cliente
					.getComponent("stLabelNumReferencia")).getText());
			contWcm.setLabelPrimeraReferenciaAdicional(((ShortTextComponent) cliente
					.getComponent("stLabelPrimeraRefAdicional")).getText());
			contWcm.setLabelSegundaReferenciaAdicional(((ShortTextComponent) cliente
					.getComponent("stLabelSegundaRefAdicional")).getText());
			contWcm.setLabelTerceraReferenciaAdicional(((ShortTextComponent) cliente
					.getComponent("stLabelTerceraRefAdicional")).getText());
			contWcm.setLabelValorPago(((ShortTextComponent) cliente
					.getComponent("stLabelValorPago")).getText());
			contWcm.setLabelSeleccione(((ShortTextComponent) cliente
					.getComponent("stLabelSeleccione")).getText());
			contWcm.setLabelNoMedio(((ShortTextComponent) cliente
					.getComponent("stNoMedio")).getText());
			contWcm.setTarjetaCredito("false");

			contWcm.setMediosPago(cargarMediosPago(request,rquid,rContenido));
			
			contWcm.setLabelConfiguracionDatosArchivo(((ShortTextComponent) cliente
					.getComponent("stLabelConfigDataFile")).getText());
			
			contWcm.setTooltipConfiguracionDatosArchivo(((TextComponent) cliente
					.getComponent("txtToolTipConfigDataFile")).getText());
		
			estadoT = ((TextComponent) cliente.getComponent("txtEstados"))
					.getText();

			if (estadoT != null) {
				contWcm.setEstadoTrans(cargarEstados(estadoT));
			}
			
			contWcm.cargarMasReferencias(request, rquid, rContenido);
			contWcm.setCantidadMesesCalen(rContenido.getCantidadMeses());
			contWcm.consultarConfiguracion(request, rquid, rContenido);
			cliente.endWorkspace();

			request.getPortletSession().setAttribute("consultarTransaccionesBeanPortlet", contWcm);
		} catch (WCMException e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_WCM_01, rContenido.getUserName(), ExceptionManager.MSG_PORTAL_WCM_01+" - Operación: obtenerContenidoWCM, ConsultaTransacciones", "obtenerContenidoWCM", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getBankName()); 
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, rquid, rContenido.getUserName()).obtenerErrorWCM(ExceptionManager.PP_PORTAL_WCM_01);
			ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
			consulta.mostrarModal(error[0], "icon-error", error[1]);
		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, rContenido.getUserName(), ExceptionManager.MSG_PORTAL_GENERIC_01+" Operación: obtenerContenidoWCM, ConsultaTransacciones", "obtenerContenidoWCM", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getBankName()); 
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, rquid, rContenido.getUserName()).obtenerErrorWCM(ExceptionManager.PP_PORTAL_GENERIC_01);
			ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
			consulta.mostrarModal(error[0], "icon-error", error[1]);
		}finally{
			if(null!=cliente){
				cliente.endWorkspace();
			}
			request.getPortletSession().removeAttribute("msjFormularios",PortletSession.PORTLET_SCOPE);
		}
	}

	/***
	 * HU 72 Genera el ArrayList de medios de pagos a partir del contenido
	 * ledido del WCM
	 * 
	 * @author Daniel Mejia
	 * @param txtMediosPago
	 * @throws Exception
	 */
	private List<MedioPagoType> cargarMediosPago(RenderRequest request, String rquid, RutaContenidoBean rContenido)throws Exception {
		List<MedioPagoType> mediosPago = null;
		try{
			
			GetConvenioInfoRs rs = new GetConvenioInfoRs();
			GetConvenioInfoRq rq = new GetConvenioInfoRq();
			Puma puma= new Puma();
			
			rq.setAgreementId(puma.getPropertyFromPuma("ath-codigoconvenio", request));	
			logger.info("[REQUEST - getConvenioInfo] DATA: "+new Gson().toJson(rq));
			rs = CacheManager.getInstance().getConvenioInfo(rq);	
			logger.info("[RESPONSE - getConvenioInfo] DATA: "+new Gson().toJson(rs));
			if ("SUCCESS".equals(rs.getStatus().getStatusCode())) {

				mediosPago = rs.getMediosPagoList();
			}
		
		
		} catch (NamingException ne) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(ne, rquid, ExceptionManager.PP_PORTAL_MIDD_01, rContenido.getUserName(), ExceptionManager.MSG_PORTAL_MIDD_01+" - Operación: cargarMediosPago, ConsultaTransacciones", "cargarMediosPago", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getBankName()); 
			logger.error(errorData, ne);
			String[] error= ErrorManager.getInstance(request, rquid, rContenido.getUserName()).obtenerErrorWCM(ExceptionManager.PP_PORTAL_MIDD_01);
			ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
			consulta.mostrarModal(error[0], "icon-error", error[1]);
			
		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, rContenido.getUserName(), ExceptionManager.PP_PORTAL_GENERIC_01+" - Operación: cargarMediosPago, ConsultaTransacciones", "cargarMediosPago", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getBankName()); 
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, rquid, rContenido.getUserName()).obtenerErrorWCM(ExceptionManager.PP_PORTAL_GENERIC_01);
			ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
			consulta.mostrarModal(error[0], "icon-error", error[1]);
		}
	
		return mediosPago;
	}
	
	/**
	 * HU 144 Funcion encargada de obtener la ip del usuario, dado un request
	 * @author melany.rozo
	 * @since 06/08/2015
	 */
	public String getIpAddr(HttpServletRequest request) {

		final String WL_PROXY_CLIENT_IP = "WL-Proxy-Client-IP";
		final String PROXY_CLIENT_IP = "Proxy-Client-IP";
		final String X_FORWARDER_FOR = "X-Forwarded-For";
		final String HTTP_X_FORWARDED_FOR = "HTTP_X_FORWARDED_FOR";
		final String HTTP_CLIENT_IP = "HTTP_CLIENT_IP";

		String ip = request.getHeader(X_FORWARDER_FOR);

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader(WL_PROXY_CLIENT_IP);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader(PROXY_CLIENT_IP);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader(HTTP_X_FORWARDED_FOR);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader(HTTP_CLIENT_IP);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}

		return ip;
	}
	
	/**
	 * HU112.1 Metodo para consultar la ruta de contenido del parametro de pagina
	 * @author santiago.cuervo
	 * */
	public RutaContenidoBean rutaContenido(RenderRequest request, RenderResponse response, String rquid){
		RutaContenidoBean rContenido = null;
		String user = null;
		try {
			rContenido = new RutaContenidoBean();
			Puma puma;
			puma = new Puma();
			user = puma.getPropertyFromPuma("uid", request);
			String email = puma.getPropertyFromPuma("ath-email", request);
			
			String ip = this.getIpAddr(com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(request));
			ResourceBundle rb = ResourceBundle.getBundle("com.portalrecaudadores.consultatransacciones.portlet.nl.ConsultaTransaccionesPortletResource");
			
			String pathContentConsultaTransacciones = getParameterPage("pathContent-consultaTransacciones",request,response, rquid, user);
			String bankName = getParameterPage("bankName",request,response, rquid, user);
			String paginaOrigen = getParameterPage("pagina-origen",request,response, rquid, user);
			String urlHome = getParameterPage("urlHome",request,response, rquid, user);
			int cantidadMesesCalen = CommonUtils.getInstance().obtenerMesesCalendario(rb);
			String bankId = rb.getString("request.bankId");
			rContenido.setBankName(bankName);
			rContenido.setCurrentPage(paginaOrigen);
			rContenido.setEmail(email);
			rContenido.setIpAdress(ip);
			rContenido.setPathContentConsultaTransacciones(pathContentConsultaTransacciones);
			rContenido.setPortlet(rb.getString("auditoria.nombrePortlet"));
			rContenido.setUrlHome(urlHome);
			rContenido.setUserName(user);
			rContenido.setCantidadMeses(cantidadMesesCalen);
			rContenido.setBankId(bankId);
			
			request.getPortletSession().setAttribute("RutaContenidoBean", rContenido);
			
		} catch (PortletServiceUnavailableException e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_PUMA_01, user, ExceptionManager.MSG_PORTAL_PUMA_01+" - Operación: Ruta contenido, ConsultaTransacciones", "rutaContenido", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getBankName()); 
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(ExceptionManager.PP_PORTAL_PUMA_01);
			ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
			consulta.mostrarModal(error[0], "icon-error", error[1]);
		} catch (NamingException e) { 
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_PUMA_01, user, ExceptionManager.MSG_PORTAL_PUMA_01+" - Operación: Ruta contenido, ConsultaTransacciones", "rutaContenido", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getBankName()); 
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(ExceptionManager.PP_PORTAL_PUMA_01);
			ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
			consulta.mostrarModal(error[0], "icon-error", error[1]);
		} catch (PumaException e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_PUMA_01, user, ExceptionManager.MSG_PORTAL_PUMA_01+" - Operación: Ruta contenido, ConsultaTransacciones", "rutaContenido", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getBankName()); 
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(ExceptionManager.PP_PORTAL_PUMA_01);
			ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
			consulta.mostrarModal(error[0], "icon-error", error[1]);
		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: Ruta contenido, ConsultaTransacciones", "rutaContenido");
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(ExceptionManager.PP_PORTAL_GENERIC_01);
			ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
			consulta.mostrarModal(error[0], "icon-error", error[1]);
		} 
		return rContenido;
	}
	
	private String getParameterPage(String nameParam,RenderRequest request, RenderResponse response, String rquid, String user){
		String param = "";
		try{
			param = (String) ParametersPage.getParameterPage(request, response, nameParam);
			if(null==param){
				param = request.getPreferences().getValue(nameParam, "");
			}
		}catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operacion: getParameterPage, ConsultaTransacciones", "getParameterPage");
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(ExceptionManager.PP_PORTAL_GENERIC_01);
			ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
			consulta.mostrarModal(error[0], "icon-error", error[1]);
		} 
		return param;
	}

}