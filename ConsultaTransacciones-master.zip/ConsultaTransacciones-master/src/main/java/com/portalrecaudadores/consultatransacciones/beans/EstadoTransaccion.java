package com.portalrecaudadores.consultatransacciones.beans;

/***
 * Clase para almacenar los medios de pagos que se configuran en el WCM
 * @author Daniel Mejia
 *
 */
public class EstadoTransaccion {

	private String id;
	private String nombre;
	
	public EstadoTransaccion() {
		id="0";
		nombre="";
	}
	
	public EstadoTransaccion(String id, String nombre) {
		super();
		this.id = id;
		this.nombre = nombre;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	
}
