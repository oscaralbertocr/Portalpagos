package com.portalrecaudadores.consultatransacciones.util;

import java.io.UnsupportedEncodingException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.portalrecaudadores.consultatransacciones.util.SQLValidator;

public class SQLValidator {
	private static SQLValidator instance;
	//lista de caracteres no permitidos
	private String patternToMatch = "[\\\\|!|\"|*|;|'|=|%]+";
	private Pattern pattern;
	
	private SQLValidator(){
		pattern = Pattern.compile(patternToMatch);
	}
	
	public static SQLValidator getInstance(){
		if(instance == null){
			instance = new SQLValidator();	
		}
		return instance;
	}
	
	/***
	 * Determina si el valor ingresado contiene caracteres
	 * o expresiones sql
	 * @param param
	 * @return
	 */
	private boolean isSafeValue(String param){					
		Matcher m = pattern.matcher(param);
		if(m!=null){
			return !m.find();
		}
		return false;
	}
	
	/***
	 * Devuelve el valor decodificado sin caracteres http
	 * @param param
	 * @return
	 */
	private String getDecodeValue(String param){
		if(param == null){
			return "";
		}
		String result = "";
		try {
			result = java.net.URLDecoder.decode(param, "UTF-8");
		} catch (UnsupportedEncodingException e) {			
			e.printStackTrace();
			result = param;
		}
		return result;
	}
	
	/***
	 * Devuelve el valor sin palabras claves o caracteres sql
	 * @param param
	 * @return
	 */
	public String getSafeValue(String param) {
		if(param == null){
			return null;
		}
		String oldValue = getDecodeValue(param);
		if(isSafeValue(oldValue)){
			return param;
		}else{
			return oldValue.replaceAll(patternToMatch, "");
		}
	} 
}
