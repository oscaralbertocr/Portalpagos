/**
 * 
 */
package com.portalrecaudadores.consultatransacciones.util;

import java.util.GregorianCalendar;
import java.util.ResourceBundle;

import javax.annotation.Resource;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import com.ibm.ws.http.Logger;
import com.portalrecaudadores.consultatransacciones.portlet.ConsultaTransaccionesPortlet;

import co.com.ath.logger.CustomLogger;
import co.com.ath.mc.utilities.util.ObtenerMesesCalendario;

/**
 * @author ricardo.paredes
 * 
 */
public class CommonUtils {

	private static CommonUtils instance;
	private static DatatypeFactory df = null;
	
	private CustomLogger logger= new CustomLogger(ConsultaTransaccionesPortlet.class);

	private CommonUtils() {
		try {
			df = DatatypeFactory.newInstance();
		} catch (DatatypeConfigurationException e) {
			// TODO Trazar error
			e.printStackTrace();
		}
	}

	public static CommonUtils getInstance() {
		if (null == instance)
			instance = new CommonUtils();
		return instance;
	}

	/**
	 * 
	 * @param xmlGC
	 * @return
	 */
	public java.util.Date asDate(XMLGregorianCalendar xmlGC) {
		if (xmlGC == null) {
			return null;
		} else {
			return xmlGC.toGregorianCalendar().getTime();
		}
	}

	public XMLGregorianCalendar asXMLGregorianCalendar(
			java.util.Date date) {
		if (date == null) {
			return null;
		} else {
			GregorianCalendar gc = new GregorianCalendar();
			gc.setTimeInMillis(date.getTime());
			return df.newXMLGregorianCalendar(gc);
		}
	}
	
	/**
	 * Permite obtener la cantidad de meses configurada en el properties
	 * para el calendario
	 * @param rb
	 * @return
	 */
	public int obtenerMesesCalendario(ResourceBundle rb){
	    int cantMeses = 0 ;
	    try{
	        cantMeses = Integer.parseInt(ObtenerMesesCalendario.getMesesCalenConsultaTransac());
	    }catch(Exception ex){
	        cantMeses = Integer.parseInt(rb.getString("cantidadMesesCalendario"));
	        logger.info("Ocurrio un error al obtener propiedad de cantidad de meses "+ ex.getCause() + " "+ ex.getMessage());
	    }
	    return cantMeses;
	}

}
