package com.portalrecaudadores.consultatransacciones.beans;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.faces.model.SelectItem;
import javax.naming.NamingException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletRequest;
import javax.portlet.RenderRequest;

import com.ath.portalpagos.util.ExceptionManager;
import com.ath.portalpagos.util.IpNodoPortal;
import com.ath.portalpagos.util.JSONUtil;
import com.google.gson.Gson;
import com.ibm.ObjectQuery.crud.util.Array;
import com.ibm.portal.portlet.service.PortletServiceUnavailableException;
import com.portalrecaudadores.consultatransacciones.portlet.ConsultaTransaccionesPortlet;
import com.portalrecaudadores.consultatransacciones.util.CommonUtils;
import com.portalrecaudadores.consultatransacciones.util.ErrorManager;
import com.portalrecaudadores.consultatransacciones.util.Puma;

import co.com.ath.logger.CustomLogger;
import co.com.ath.mc.utilities.util.EnmascararUtil;
import co.com.ath.payments.mc.auditor.publisher.traza.TrazaPublisher;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.auditor.publisher.util.WebServiceClientHTTPS;
import co.com.ath.payments.mc.cache.manager.CacheManager;
import co.com.ath.payments.mc.service.model.AuditorRq;
import co.com.ath.payments.mc.service.model.ErrorData;
import co.com.ath.payments.mc.service.model.json.BankInfoType;
import co.com.ath.payments.mc.service.model.json.GetConvenioInfoRq;
import co.com.ath.payments.mc.service.model.json.GetConvenioInfoRs;
import co.com.ath.payments.mc.service.model.json.GetParametroRs;
import co.com.ath.payments.mc.service.model.json.GetTransactionsBySelectedFieldsRq;
import co.com.ath.payments.mc.service.model.json.GetTransactionsBySelectedFieldsRs;
import co.com.ath.payments.mc.service.model.json.MedioPagoType;
import co.com.ath.payments.mc.service.model.json.ParamFilesType;
import co.com.ath.payments.mc.service.model.json.ReferenceAgreementType;
import co.com.ath.payments.mc.service.model.json.ReferenceType;
import co.com.ath.payments.mc.service.model.json.SearchPaymentHistoryFactRq;
import co.com.ath.payments.mc.service.model.json.SearchPaymentHistoryFactRs;
import co.com.ath.recaudadores.payments.mc.service.util.ConfigurationService;




/** HU72
 * ManagedBean utilizado para almacenar los datos del formulario de Consultar Transacciones.
 * @author: daniel.mejia
 * @Since: 25/05/2015
 **/

@ManagedBean(name = "consultarTransaccionesBeanPortlet", eager = true)
@SessionScoped
public class ConsultaTransaccionesBeanWcm implements Serializable {
	
	private CustomLogger logger= new CustomLogger(ConsultaTransaccionesPortlet.class);
	private static final String DOSPUNTOS = ":";
	private static final String NODO = "Nodo Portal";

	private static final long serialVersionUID = -3653547691288306151L;
	private static final Object SUCCESS = "SUCCESS";
	
	private String labelFechaInicial;
	private String labelFechaFinal;
	private String labelEstado;
	private String labelMedioPago;
	private String labelCUS;
	private String labelToolTip;
	private String labelToolTipEstado;
	/*HU-708 	Portal Recaudadores Ajuste Consulta de TX*/	
	private String labelToolTipDatosArchivo;
	/*FIN HU-708 	Portal Recaudadores Ajuste Consulta de TX*/
	private String labelBusqueda;
	private String btnConsultar;
	private String labelIdTrans;
	private String fechaInicial;
	private String fechaFinal;
	private List<MedioPagoType> mediosPago;
	private List<EstadoTransaccion> estadoTrans;
	private String idMedioPago;
	private String idEstadoTrans;
	private String labelSeleccione;
	private String labelNoMedio;
	private String txtNumCUS;
	private String txtNumIdTrans;
	private Boolean boolConsultar;
	private String labelNumReferencia;
	private String labelPrimeraReferenciaAdicional;
	private String labelSegundaReferenciaAdicional;
	private String labelTerceraReferenciaAdicional;
	private String labelValorPago;
	private String referenciaPago;
	private String primeraReferenciaAdicional;
	private String segundaReferenciaAdicional;
	private String terceraReferenciaAdicional;
	private String valorPago;
	private Boolean isPrimeraRefAdicional;
	private Boolean isSegundaRefAdicional;
	private Boolean isTerceraRefAdicional;
	private String labelConfiguracionDatosArchivo;
	private String tooltipConfiguracionDatosArchivo;
	private String mostrarModal;
	private String referenciaInput;	

	private String tituloModal;
	
	private String mensajeModal;
	
	private String tipoModal;
	
	private List<ReferenceAgreementType> listaReferencias;
	
	private List<ReferenceType> listaReferenciasCapt;
	
	private Boolean multiplesRef;
	
	private int totalReferencias;
	
	private int cantidadMesesCalen;
	
	private String tarjetaCredito;
	
	private String[] itemsTransacciones;
	
	// datos para enmascaramiento	
	private int enmascararIzquierda = 6;
	private int enmascararDerecha = 4;
	private char enmascararCaracter = '*';
	private ArrayList<SelectItem> itemsSelection;
	public List<String> tempSelected;
	private String[] configSelected;
	private String popUpClass;
	private String tituloPopUp;
	private String mensajePopUp;
	
	private final String TITULO_POPUP_ERROR = "Error";
	private final String TITULO_POPUP_EXITO = "Guardado Exitoso";
	private final String MENSAJE_POPUP_EXITO = "La configuración fue guardada de forma exitosa";
	private final String MENSAJE_POPUP_ERROR = "Ocurrio un error, favor intente mas tarde";
	private final String MENSAJE_POPUP_REQUERIDO = "Debes seleccionar al menos un campo";
	
	public String getTituloPopUp() {
		return tituloPopUp;
	}

	public void setTituloPopUp(String tituloPopUp) {
		this.tituloPopUp = tituloPopUp;
	}

	public String getMensajePopUp() {
		return mensajePopUp;
	}

	public void setMensajePopUp(String mensajePopUp) {
		this.mensajePopUp = mensajePopUp;
	}

	public ArrayList<SelectItem> getItemsSelection() {
		return itemsSelection;
	}

	public void setItemsSelection(ArrayList<SelectItem> itemsSelection) {
		this.itemsSelection = itemsSelection;
	}

	public String getPopUpClass() {
		return popUpClass;
	}

	public void setPopUpClass(String popUpClass) {
		this.popUpClass = popUpClass;
	}

	public String[] getItemsTransacciones() {
		return itemsTransacciones;
	}

	public void setItemsTransacciones(String[] itemsTransacciones) {
		this.itemsTransacciones = itemsTransacciones;
	}

	public String getMostrarModal() {
		return mostrarModal;
	}

	public void setMostrarModal(String mostrarModal) {
		this.mostrarModal = mostrarModal;
	}

	public String getTituloModal() {
		return tituloModal;
	}

	public void setTituloModal(String tituloModal) {
		this.tituloModal = tituloModal;
	}

	public String getMensajeModal() {
		return mensajeModal;
	}

	public void setMensajeModal(String mensajeModal) {
		this.mensajeModal = mensajeModal;
	}

	public String getTipoModal() {
		return tipoModal;
	}

	public void setTipoModal(String tipoModal) {
		this.tipoModal = tipoModal;
	}

	public Boolean getIsPrimeraRefAdicional() {
		return isPrimeraRefAdicional;
	}

	public void setIsPrimeraRefAdicional(Boolean isPrimeraRefAdicional) {
		this.isPrimeraRefAdicional = isPrimeraRefAdicional;
	}

	public Boolean getIsSegundaRefAdicional() {
		return isSegundaRefAdicional;
	}

	public void setIsSegundaRefAdicional(Boolean isSegundaRefAdicional) {
		this.isSegundaRefAdicional = isSegundaRefAdicional;
	}

	public Boolean getIsTerceraRefAdicional() {
		return isTerceraRefAdicional;
	}

	public void setIsTerceraRefAdicional(Boolean isTerceraRefAdicional) {
		this.isTerceraRefAdicional = isTerceraRefAdicional;
	}

	public String getReferenciaPago() {
		return referenciaPago;
	}

	public void setReferenciaPago(String referenciaPago) {
		this.referenciaPago = referenciaPago;
	}

	public String getPrimeraReferenciaAdicional() {
		return primeraReferenciaAdicional;
	}

	public void setPrimeraReferenciaAdicional(String primeraReferenciaAdicional) {
		this.primeraReferenciaAdicional = primeraReferenciaAdicional;
	}

	public String getSegundaReferenciaAdicional() {
		return segundaReferenciaAdicional;
	}

	public void setSegundaReferenciaAdicional(String segundaReferenciaAdicional) {
		this.segundaReferenciaAdicional = segundaReferenciaAdicional;
	}

	public String getTerceraReferenciaAdicional() {
		return terceraReferenciaAdicional;
	}

	public void setTerceraReferenciaAdicional(String terceraReferenciaAdicional) {
		this.terceraReferenciaAdicional = terceraReferenciaAdicional;
	}

	public String getValorPago() {
		return valorPago;
	}

	public void setValorPago(String valorPago) {
		this.valorPago = valorPago;
	}

	public String getLabelValorPago() {
		return labelValorPago;
	}

	public void setLabelValorPago(String labelValorPago) {
		this.labelValorPago = labelValorPago;
	}

	public String getLabelNumReferencia() {
		return labelNumReferencia;
	}

	public void setLabelNumReferencia(String labelNumReferencia) {
		this.labelNumReferencia = labelNumReferencia;
	}

	public String getLabelPrimeraReferenciaAdicional() {
		return labelPrimeraReferenciaAdicional;
	}

	public void setLabelPrimeraReferenciaAdicional(
			String labelPrimeraReferenciaAdicional) {
		this.labelPrimeraReferenciaAdicional = labelPrimeraReferenciaAdicional;
	}

	public String getLabelSegundaReferenciaAdicional() {
		return labelSegundaReferenciaAdicional;
	}

	public void setLabelSegundaReferenciaAdicional(
			String labelSegundaReferenciaAdicional) {
		this.labelSegundaReferenciaAdicional = labelSegundaReferenciaAdicional;
	}

	public String getLabelTerceraReferenciaAdicional() {
		return labelTerceraReferenciaAdicional;
	}

	public void setLabelTerceraReferenciaAdicional(
			String labelTerceraReferenciaAdicional) {
		this.labelTerceraReferenciaAdicional = labelTerceraReferenciaAdicional;
	}
	
	public ConsultaTransaccionesBeanWcm(){
		infoInicial();
		
	}

	public String getLabelFechaInicial() {
		return labelFechaInicial;
	}

	public void setLabelFechaInicial(String labelFechaInicial) {
		this.labelFechaInicial = labelFechaInicial;
	}

	public String getLabelFechaFinal() {
		return labelFechaFinal;
	}

	public void setLabelFechaFinal(String labelFechaFinal) {
		this.labelFechaFinal = labelFechaFinal;
	}

	public String getLabelEstado() {
		return labelEstado;
	}

	public void setLabelEstado(String labelEstado) {
		this.labelEstado = labelEstado;
	}

	/**
	 * @return the labelToolTipEstado
	 */
	public String getLabelToolTipEstado() {
		return labelToolTipEstado;
	}

	/**
	 * @param labelToolTipEstado the labelToolTipEstado to set
	 */
	public void setLabelToolTipEstado(String labelToolTipEstado) {
		this.labelToolTipEstado = labelToolTipEstado;
	}

	public String getLabelMedioPago() {
		return labelMedioPago;
	}

	public void setLabelMedioPago(String labelMedioPago) {
		this.labelMedioPago = labelMedioPago;
	}

	public String getLabelCUS() {
		return labelCUS;
	}

	public void setLabelCUS(String labelCUS) {
		this.labelCUS = labelCUS;
	}

	public String getBtnConsultar() {
		return btnConsultar;
	}

	public void setBtnConsultar(String btnConsultar) {
		this.btnConsultar = btnConsultar;
	}

	public String getLabelToolTip() {
		return labelToolTip;
	}

	public void setLabelToolTip(String labelToolTip) {
		this.labelToolTip = labelToolTip;
	}

	public String getLabelIdTrans() {
		return labelIdTrans;
	}

	public void setLabelIdTrans(String labelIdTrans) {
		this.labelIdTrans = labelIdTrans;
	}

	public String getFechaInicial() {
		return fechaInicial;
	}

	public void setFechaInicial(String fechaInicial) {
		this.fechaInicial = fechaInicial;
	}

	public String getFechaFinal() {
		return fechaFinal;
	}

	public void setFechaFinal(String fechaFinal) {
		this.fechaFinal = fechaFinal;
	}

	public List<MedioPagoType> getMediosPago() {
		return mediosPago;
	}

	public void setMediosPago(List<MedioPagoType> mediosPago) {
		this.mediosPago = mediosPago;
	}

	public String getIdMedioPago() {
		return idMedioPago;
	}

	public void setIdMedioPago(String idMedioPago) {
		this.idMedioPago = idMedioPago;
	}

	public String getLabelSeleccione() {
		return labelSeleccione;
	}

	public void setLabelSeleccione(String labelSeleccione) {
		this.labelSeleccione = labelSeleccione;
	}

	public String getLabelNoMedio() {
		return labelNoMedio;
	}

	public void setLabelNoMedio(String labelNoMedio) {
		this.labelNoMedio = labelNoMedio;
	}

	public String getIdEstadoTrans() {
		return idEstadoTrans;
	}

	public void setIdEstadoTrans(String idEstadoTrans) {
		this.idEstadoTrans = idEstadoTrans;
	}

	public List<EstadoTransaccion> getEstadoTrans() {
		return estadoTrans;
	}

	public void setEstadoTrans(List<EstadoTransaccion> estadoTrans) {
		this.estadoTrans = estadoTrans;
	}
	
	
	public int getTotalReferencias() {
		return totalReferencias;
	}

	public void setTotalReferencias(int totalReferencias) {
		this.totalReferencias = totalReferencias;
	}

	public String getLabelBusqueda() {
		return labelBusqueda;
	}

	public void setLabelBusqueda(String labelBusqueda) {
		this.labelBusqueda = labelBusqueda;
	}

	public String getLabelConfiguracionDatosArchivo() {
		return labelConfiguracionDatosArchivo;
	}

	public void setLabelConfiguracionDatosArchivo(String labelConfiguracionDatosArchivo) {
		this.labelConfiguracionDatosArchivo = labelConfiguracionDatosArchivo;
	}

	public String getLabelToolTipDatosArchivo() {
		return labelToolTipDatosArchivo;
	}

	public void setLabelToolTipDatosArchivo(String labelToolTipDatosArchivo) {
		this.labelToolTipDatosArchivo = labelToolTipDatosArchivo;
	}
	
	public String getReferenciaInput() {
		return referenciaInput;
	}

	public void setReferenciaInput(String referenciaInput) {
		this.referenciaInput = referenciaInput;
	}
	
	/*FIN HU-708 	Portal Recaudadores Ajuste Consulta de TX*/	
	
	public String getTooltipConfiguracionDatosArchivo() {
		return tooltipConfiguracionDatosArchivo;
	}

	public void setTooltipConfiguracionDatosArchivo(String tooltipConfiguracionDatosArchivo) {
		this.tooltipConfiguracionDatosArchivo = tooltipConfiguracionDatosArchivo;
	}

	public String[] getConfigSelected() {
		return configSelected;
	}

	public void setConfigSelected(String[] configSelected) {
		this.configSelected = configSelected;
	}

	
	private RenderRequest renderRequest;
	/***
	 * HU 72 Obtiene los datos ingresados en la vista e invoca el evento que muestra los resultados 
	 * @author Daniel Mejia
	 */
	public void consultar () {
		FacesContext context = FacesContext.getCurrentInstance();
		//Genera el response para enviar el evento
		com.ibm.faces20.portlet.httpbridge.PortletResponseWrapper responseWrapper = (com.ibm.faces20.portlet.httpbridge.PortletResponseWrapper) context
				.getExternalContext().getResponse();
		ActionResponse response = (ActionResponse) responseWrapper.getPortletResponse();
		
		//Genera el request para capturar los datos en session		
		com.ibm.faces20.portlet.httpbridge.PortletRequestWrapper requestWrapper = (com.ibm.faces20.portlet.httpbridge.PortletRequestWrapper) context
				.getExternalContext().getRequest();
		ActionRequest request = (ActionRequest) requestWrapper
				.getPortletRequest();
		SearchPaymentHistoryFactRq rq = new SearchPaymentHistoryFactRq(); 
		String rquid = null;
		RutaContenidoBean rContenido = null;
		String ip;
		String userId;
		String codConvenio;
		String bankId;
		Puma puma;
		BankInfoType bankInfo = new BankInfoType();
		try{
			
			puma = new Puma();
			codConvenio = puma.getPropertyFromPuma("ath-codigoconvenio", getRenderRequest());
			ip = com.ibm.ws.portletcontainer.portlet.PortletUtils
					.getHttpServletRequest(getRenderRequest()).getRemoteAddr();
			userId = puma.getPropertyFromPuma("uid", getRenderRequest());
			codConvenio = puma.getPropertyFromPuma("ath-codigoconvenio", getRenderRequest());
			
			String EndPointRESTConsultarTransaccionesArchivoParametrico = ConfigurationService.getInstance().getEndpointRest();
				//Se genera rquid para acción de consultar transacciones
				rquid = PublisherUtil.getInstance().generateRequestID();
				ExternalContext externalContext = context.getExternalContext();
				PortletRequest portletRequest = (PortletRequest) externalContext.getRequest();
				rContenido = (RutaContenidoBean) portletRequest.getPortletSession().getAttribute("RutaContenidoBean");
				ResourceBundle rb = ResourceBundle.getBundle("com.portalrecaudadores.consultatransacciones.portlet.nl.ConsultaTransaccionesPortletResource");
				bankId = rb.getString("request.bankId");
				bankInfo.setBankId(bankId);
				 if(this.txtNumCUS.equalsIgnoreCase("")){
					 this.setTxtNumCUS(null);					 
				 }
				 if(this.txtNumIdTrans.equalsIgnoreCase("")){
					 this.setTxtNumIdTrans(null);					 
				 }
				 if(this.idEstadoTrans.equalsIgnoreCase("0")){
					 this.setIdEstadoTrans(null);					 
				 }
				 if(this.idMedioPago.equalsIgnoreCase("0")){
					 this.setIdMedioPago(null);					 
				 }
				 if(this.referenciaPago.equalsIgnoreCase("")){
					 this.setReferenciaPago(null);					 
				 }
				 if(this.valorPago.equalsIgnoreCase("")){
					 this.setValorPago(null);					 
				 }
				 else{
					 this.setValorPago(this.valorPago.replace(".",""));
				 }
				 this.setBoolConsultar(true);
				 
				 //Si la consulta se realzia con el numero de referencia
				 String referenciaEnmascarada="false";
				 
				 this.listaReferenciasCapt = llenarListaReferencias(portletRequest);
				
				 logger.info("listaReferenciasCapt:: " + new Gson().toJson(this.listaReferenciasCapt));
				 String referencias ="false";
				 if(null != listaReferenciasCapt && listaReferenciasCapt.size() > 0){
					 this.tarjetaCredito = request.getParameter("istarjetaCredito");
					 if(Boolean.parseBoolean(this.tarjetaCredito)) {
						 //La primera referencia se enmascara y se utiliza para enviar el el metodo REST, esta referencia no es parametrizable el enmascarado
						 //listaReferenciasCapt.get(0).setReference(EnmascararUtil.enmascararTarjetaDeCredito(listaReferenciasCapt.get(0).getReference(),
						 //			enmascararCaracter, enmascararIzquierda, enmascararDerecha));
	
						 //Consulta de cache de parametros para enmascarar y truncar
						 getCacheParametros();
	
						 //Se enmascara la primera referencia para utilizar en la auditoria y logs
						 referenciaEnmascarada = EnmascararUtil.enmascararTarjetaDeCredito(listaReferenciasCapt.get(0).getReference(),
									enmascararCaracter, enmascararIzquierda, enmascararDerecha);
					 }
					 
					 referencias = new Gson().toJson(this.listaReferenciasCapt);

				 }
				 
				
				 if (null != listaReferenciasCapt && !listaReferenciasCapt.isEmpty()) {
					
						 logger.info("entra a setear la ref");
						 logger.info("Referencia::_- " + listaReferenciasCapt.get(0).getReference());
						 referenciaPago = listaReferenciasCapt.get(0).getReference();
					
				 }
				 
				 referenciaInput = referencias;
				 logger.info("Ref html:: " + referenciaInput);
				 logger.info("Ref html:: " + referenciaPago);
				 String newFechaInicial = fechaInicial.replace(" - ", " ");
				 String newFechaFinal = fechaFinal.replace(" - ", " ");
				 
				 DateFormat formato = new SimpleDateFormat("dd-MM-yyyy HH:mm");
				 
				 rq.setAgreementId(codConvenio); 
				 rq.setCus(txtNumCUS);
				 rq.setInitialDate(formato.parse(newFechaInicial));
				 rq.setFinalDate(formato.parse(newFechaFinal));
				 rq.setValorPago(valorPago);
				 rq.setListaReferences(listaReferenciasCapt);
				 rq.setPaymentMode(idMedioPago);
				 rq.setTransactionStatus(idEstadoTrans);
				 rq.setTransactionID(txtNumIdTrans);
				 rq.setAgreementId(codConvenio);
				 rq.setIpAddress(ip);
				 rq.setUserId(userId);
				 rq.setRequestID(rquid);
				 rq.setRequestDate(new Date());
				 logger.info("[REQUEST - consultarTransaccionesArchivoParametrico] Save DATA : "+new Gson().toJson(rq));
				 //TRAZA RQ CREAR USUARIO
				 trazaRqConsultar(rquid,rb,rContenido,portletRequest);

				 logger.info("Endpoint consulta" + EndPointRESTConsultarTransaccionesArchivoParametrico + "consultarTransaccionesArchivoParametrico");
				 SearchPaymentHistoryFactRs rs = 
							(SearchPaymentHistoryFactRs) WebServiceClientHTTPS.getInstance(SearchPaymentHistoryFactRs.class).procesarRequest(
							EndPointRESTConsultarTransaccionesArchivoParametrico + "consultarTransaccionesArchivoParametrico", rq);
				 
				 logger.info("[RESPONSE - consultarTransaccionesArchivoParametrico] Save DATA: "+new Gson().toJson(rs));
				 String paramsMap = "";
				 paramsMap = referenciaEnmascarada + "/";
				 paramsMap += this.tarjetaCredito + "/";
				 paramsMap += this.fechaInicial + "/";
				 paramsMap += this.fechaFinal + "/";
				 paramsMap += this.idEstadoTrans + "/";
				 paramsMap += this.idMedioPago + "/";	
				 paramsMap += this.txtNumCUS + "/";	
				 paramsMap += this.txtNumIdTrans + "/";	
				 paramsMap += referencias + "/"; 
				 paramsMap += this.valorPago + "&";		
				 paramsMap += rquid;	
				 				 
				 response.setEvent("rqFiltroResulTrans", paramsMap);
				 response.setRenderParameter("fromEvent","yes");
				 
		}catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, rContenido.getUserName(), ExceptionManager.PP_PORTAL_GENERIC_01+" - Operación: consultar, ConsultaTransacciones", "consultar", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getBankName()); 
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, rquid, rContenido.getUserName()).obtenerErrorWCM(ExceptionManager.PP_PORTAL_GENERIC_01);
			ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
			consulta.mostrarModal(error[0], "icon-error", error[1]);
		}
	}
	
	

	private void trazaRqConsultar(String requestId,ResourceBundle rb,RutaContenidoBean rContenido,PortletRequest request){
		try{
			//TRAZA
			AuditorRq auditorRq = new AuditorRq();
		
			auditorRq.setRequestId(requestId);
			auditorRq.setIpAddress(rContenido.getIpAdress());
			auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
			auditorRq.setAction(rb.getString("auditoria.consultarTransacciones"));
			auditorRq.setOriginPortal(rContenido.getBankName());
			auditorRq.setPage(rContenido.getCurrentPage());
			auditorRq.setPortlet(rb.getString("auditoria.nombrePortlet"));
			auditorRq.setUser(rContenido.getUserName());
			auditorRq.setTipoServicio("RQ");
			
			auditorRq.setAdditionalInfo(JSONUtil.getJson( "Fecha Inicial"+ DOSPUNTOS + this.fechaInicial , 
					"Fecha Final" + DOSPUNTOS + this.fechaFinal , 
					"Estado Transaccion" + DOSPUNTOS + idMedioPago, 
					"Medio Pago" + DOSPUNTOS + ("".equals(this.idMedioPago)?null:this.idMedioPago), 
					"Cus" + DOSPUNTOS + ("".equals(this.txtNumCUS)?null:this.txtNumCUS), 
					"Numero id Transaccion" + DOSPUNTOS + ("".equals(this.txtNumIdTrans)?null:this.txtNumIdTrans), 
					"Referencia Pago" + DOSPUNTOS + ("".equals(this.referenciaPago)?null:this.referenciaPago), 
//					"Primera Referencia Adicional" + DOSPUNTOS + ("".equals(this.primeraReferenciaAdicional)?null:this.primeraReferenciaAdicional), 
//					"Segunda Referencia Adicional" + DOSPUNTOS + ("".equals(this.segundaReferenciaAdicional)?null:this.segundaReferenciaAdicional), 
//					"Tercera Referencia Adicional" + DOSPUNTOS + ("".equals(this.terceraReferenciaAdicional)?null:this.terceraReferenciaAdicional), 
					"Valor pagar" + DOSPUNTOS + ("".equals(this.valorPago)?null:this.valorPago), 
					NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
			TrazaPublisher.getInstance().publish(auditorRq);
			//Fin de la traza
		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, requestId, ExceptionManager.PP_PORTAL_GENERIC_01,rContenido.getUserName(), ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: trazaRqConsultar, ConsultaTransacciones", "trazaRqConsultar", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getBankName());
			logger.error(errorData, e);
		} finally{
			
		}
	}
	
	/***
	 * HU 72 Carga la informacion por defecto de los campos de fecha inicial, fecha final, id medo de pago y id estado de transaccion 
	 * @author Daniel Mejia
	 */

	private void infoInicial() {
		this.boolConsultar = false;
		DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy - HH:mm");
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		this.fechaFinal =dateFormat.format(cal.getTime()).toString();
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.add(Calendar.DAY_OF_MONTH, -30);
		this.fechaInicial =dateFormat.format(cal.getTime()).toString();
		this.idMedioPago = "0";
		this.idEstadoTrans = "0";
		setPopUpClass("");
	}

	

	public String getTxtNumCUS() {
		return txtNumCUS;
	}

	public void setTxtNumCUS(String txtNumCUS) {
		this.txtNumCUS = txtNumCUS;
	}

	

	public String getTxtNumIdTrans() {
		return txtNumIdTrans;
	}

	public void setTxtNumIdTrans(String txtNumIdTrans) {
		this.txtNumIdTrans = txtNumIdTrans;
	}

	public Boolean getBoolConsultar() {
		return boolConsultar;
	}

	public void setBoolConsultar(Boolean boolConsultar) {
		this.boolConsultar = boolConsultar;
	}

	public List<ReferenceAgreementType> getListaReferencias() {
		return listaReferencias;
	}

	public void setListaReferencias(List<ReferenceAgreementType> listaReferencias) {
		this.listaReferencias = listaReferencias;
	}

	public List<ReferenceType> getListaReferenciasCapt() {
		return listaReferenciasCapt;
	}

	public void setListaReferenciasCapt(List<ReferenceType> listaReferenciasCapt) {
		this.listaReferenciasCapt = listaReferenciasCapt;
	}

	public Boolean getMultiplesRef() {
		return multiplesRef;
	}

	public void setMultiplesRef(Boolean multiplesRef) {
		this.multiplesRef = multiplesRef;
	}

	public int getCantidadMesesCalen() {
        return cantidadMesesCalen;
    }

    public void setCantidadMesesCalen(int cantidadMesesCalen) {
        this.cantidadMesesCalen = cantidadMesesCalen;
    }

    public void cargarMasReferencias(RenderRequest request, String rquid, RutaContenidoBean rContenido) {
		Puma puma;
		String codConvenio = null;
		
		
		try {
			puma = new Puma();
			codConvenio = puma.getPropertyFromPuma("ath-codigoconvenio", request);
			GetConvenioInfoRq rq = new GetConvenioInfoRq();
			
//			GregorianCalendar gcal = new GregorianCalendar();
//			gcal.setTime(new Date());
//			XMLGregorianCalendar cal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
			
			rq.setAgreementId(codConvenio);
			rq.setRequestDate(new Date());
			rq.setRequestID(rquid);
	
			logger.info("[REQUEST - getConvenioInfo] DATA: "+new Gson().toJson(rq));
			GetConvenioInfoRs rs = CacheManager.getInstance().getConvenioInfo(rq);
			logger.info("[RESPONSE - getConvenioInfo] DATA: "+new Gson().toJson(rs));
	
			//Lista las diferentes referencias configuradas en BD y ordena por la posición
			if(rs.getConfigAgreementType() != null && SUCCESS.equals(rs.getStatus().getStatusCode())) {
				
				this.listaReferencias = rs.getReferences();
				this.multiplesRef = rs.getConfigAgreementType().isMultiRef();
				this.totalReferencias = this.listaReferencias.size();
			} else {
				logger.info("Response ConvenioInfoRecaudadores "+ rs.getStatus().getStatusCode() + ": "+ rs.getStatus().getStatusDesc());
			}

		}  catch (NamingException ne) {
			ne.printStackTrace();
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(ne, rquid, ExceptionManager.PP_PORTAL_MIDD_01, rContenido.getUserName(), ExceptionManager.MSG_PORTAL_MIDD_01+" - Operación: cargarMasReferencias, ConsultaTransacciones", "cargarMasReferencias", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getBankName()); 
			logger.error(errorData, ne);
			String[] error= ErrorManager.getInstance(request, rquid, rContenido.getUserName()).obtenerErrorWCM(ExceptionManager.PP_PORTAL_MIDD_01);
			ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
			consulta.mostrarModal(error[0], "icon-error", error[1]);
			
		} catch (Exception e) {
			e.printStackTrace();
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, rContenido.getUserName(), ExceptionManager.PP_PORTAL_GENERIC_01+" - Operación: cargarMasReferencias, ConsultaTransacciones", "cargarMasReferencias", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getBankName()); 
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, rquid, rContenido.getUserName()).obtenerErrorWCM(ExceptionManager.PP_PORTAL_GENERIC_01);
			ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
			consulta.mostrarModal(error[0], "icon-error", error[1]);
		}
		
	}
	
	public static List <ReferenceType> llenarListaReferencias (PortletRequest request){
		String[] listaValores =  request.getParameterValues("referenciaAdicional");
		String[] listaPosiciones =  request.getParameterValues("referenciaAdicionalPos");  
		List <ReferenceType> listaReferencias = null;
		if(null != listaValores){
			List<String> ArrayRef = Arrays.asList(listaValores);  
			List<String> ArrayPos = Arrays.asList(listaPosiciones);  
			List<String> ArrayRefValued = new ArrayList<String>();  
			List<String> ArrayPosValued = new ArrayList<String>();

			for (int i = 0; i < ArrayRef.size(); i++) {
				if(!ArrayRef.get(i).isEmpty() && !ArrayRef.get(i).equalsIgnoreCase("Seleccione")){
						ArrayRefValued.add(ArrayRef.get(i));
						ArrayPosValued.add(ArrayPos.get(i));
				}
				
			}

			Iterator<String> ArrayRefe = ArrayRefValued.iterator();
			Iterator<String> ArrayPosi = ArrayPosValued.iterator();
			listaReferencias =	new ArrayList<ReferenceType>();

			while (ArrayRefe.hasNext()) {
		    	ReferenceType refe = new ReferenceType();
				refe.setReference(ArrayRefe.next());
				refe.setPosition(Integer.parseInt(ArrayPosi.next()));	
				listaReferencias.add(refe);
		    }

		}
		return listaReferencias;
	}
	
	/**
	 * HU107 Función encargada de setear los valores para mostrar el modal con el mensaje recibido
	 * @author melany.rozo
	 * @since 24/02/2015
	 * */
	public void mostrarModal(String mensaje, String tipo, String titulo){
		this.mensajeModal = mensaje;
		this.tipoModal = tipo;
		this.tituloModal = titulo;
		this.mostrarModal = "true";
	}
	
	/**
	 * HU tokenizacion, Metodo encargado de consultar la cache y obtener los parametros para enmascarar y truncar
	 * @author germandiaz
	 * @param idRequest 
	 * @throws Exception 
	 * @since 27/07/2017
	 * */
	private void getCacheParametros() throws Exception {
		// Cargamos los parametros desde la cache
			List<GetParametroRs> parametros;
		
				parametros = CacheManager.getInstance().obtenerParametros();
			for(GetParametroRs parametro : parametros){
				if(parametro.getNombre().equals("ATH_CANT_INICIAL_MASCARA")){
					enmascararIzquierda = Integer.parseInt(parametro.getValor());
				}
				else if(parametro.getNombre().equals("ATH_CANT_FINAL_MASCARA")){
					enmascararDerecha = Integer.parseInt(parametro.getValor());
				}
				else if(parametro.getNombre().equals("ATH_CARACTER_MASCARA")){
					enmascararCaracter = parametro.getValor().charAt(0);
				}
			}	
					
	}
	public List <ParamFilesType> responseParamFile;
	
	public void setListaConfiguracion() {
		configSelected = new String[0];
		itemsSelection = new ArrayList<SelectItem>();
		for (ParamFilesType confTransaction : responseParamFile) {
			SelectItem items = new SelectItem();
			items.setLabel(confTransaction.getName());
			items.setValue(confTransaction.getName());
			System.out.println("Registros IdParamFile retorno: " + confTransaction.getIdParamArchivo());
			logger.info("Registros IdParamFile retorno: " + confTransaction.getIdParamArchivo());
			itemsSelection.add(items);
		}
		
		tempSelected = new ArrayList<String>(); 
		for (ParamFilesType confSelected : responseParamFile) {
			if(confSelected.getStatusMark()) {
				tempSelected.add(confSelected.getName());
			}
		}
		configSelected = tempSelected.toArray(new String[tempSelected.size()]);
	}
	
	private String requestIdSave;
	

	public String getRequestIdSave() {
		return requestIdSave;
	}

	public void setRequestIdSave(String requestIdSave) {
		this.requestIdSave = requestIdSave;
	}

	public void consultarConfiguracion(RenderRequest request,String rquid, RutaContenidoBean rContenido ) {
		logger.info("Ingresa a consultar");
		System.out.println("Ingresa a consultar");
		String ip;
		String userId;
		String codConvenio;
		String bankId;
		Puma puma;
		this.setRenderRequest(request);
		
		logger.info("Ingresa a consultar renderREquest: " + request.getRequestedSessionId());
		System.out.println("Ingresa a consultar renderREquest: " + request.getRequestedSessionId());
		
		logger.info("Ingresa a consultar Set renderREquest: " + getRenderRequest().getRequestedSessionId());
		System.out.println("Ingresa a consultar Set renderREquest: " + getRenderRequest().getRequestedSessionId());

		BankInfoType bankInfo = new BankInfoType();
		responseParamFile = new ArrayList<ParamFilesType>();
		 try {
				puma = new Puma();
				codConvenio = puma.getPropertyFromPuma("ath-codigoconvenio", request);
				ip = com.ibm.ws.portletcontainer.portlet.PortletUtils
						.getHttpServletRequest(request).getRemoteAddr();
				userId = puma.getPropertyFromPuma("uid", request);
				codConvenio = puma.getPropertyFromPuma("ath-codigoconvenio", request);
				bankId = rContenido.getBankId();
				bankInfo.setBankId(bankId);
				
				String EndPointRESTTransactionsBySelectedField = ConfigurationService.getInstance().getEndpointRest();
				
				GetTransactionsBySelectedFieldsRq rq = new GetTransactionsBySelectedFieldsRq();
				
				setRequestIdSave(request.getRequestedSessionId());
				rq.setBankInfo(bankInfo);
				rq.setIpAddress(ip);
				rq.setRequestID(request.getRequestedSessionId());
				rq.setRequestSender(userId);
				rq.setRequestUser(userId);
				rq.setRequestDate(new Date());
				rq.setAgreementId(codConvenio); 
				
				logger.info("[REQUEST - getConfigurationBySelectedFields] DATA: "+new Gson().toJson(rq));
				System.out.println("[REQUEST - getConfigurationBySelectedFields] DATA: "+new Gson().toJson(rq));
				GetTransactionsBySelectedFieldsRs rs = 
						(GetTransactionsBySelectedFieldsRs) WebServiceClientHTTPS.getInstance(GetTransactionsBySelectedFieldsRs.class).procesarRequest(
						EndPointRESTTransactionsBySelectedField + "getTransactionsBySelectedFields", rq);
				logger.info("[RESPONSE - getConfigurationBySelectedFields] DATA: "+new Gson().toJson(rs));
				System.out.println("[RESPONSE - getConfigurationBySelectedFields] DATA: "+new Gson().toJson(rs));
				
//				responseParamFile = rs.getListaParametriaArchivo();
				responseParamFile = rs.getListaParametriaArchivoUsuario();
				
				setListaConfiguracion();
			} catch (PortletServiceUnavailableException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info("PortletServiceUnavailableException: "+e.getMessage());
				System.out.println("PortletServiceUnavailableException: "+e.getMessage());
				setPopUpClass("popUpError");
				setTituloPopUp(TITULO_POPUP_ERROR);
			} catch (NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info("NamingException: "+e.getMessage());
				System.out.println("NamingException: "+e.getMessage());
				setPopUpClass("popUpError");
				setTituloPopUp(TITULO_POPUP_ERROR);
			}catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
				logger.info("Generic Exception: "+e.getMessage());
				System.out.println("Generic Exception: "+e.getMessage());
				setPopUpClass("popUpError");
				setTituloPopUp(TITULO_POPUP_ERROR);
			}
	}
	
	public void guardarConfiguracion(AjaxBehaviorEvent event) throws Exception{
		System.out.println("Ingresa a guardar data: ");
		logger.info("Ingresa a guardar data: ");
		
		if(configSelected.length <= 0) {
			setPopUpClass("popUpError");
			setMensajePopUp(MENSAJE_POPUP_REQUERIDO);
			setTituloPopUp(TITULO_POPUP_ERROR);
			return;
		}
		ResourceBundle rb = ResourceBundle.getBundle("com.portalrecaudadores.consultatransacciones.portlet.nl.ConsultaTransaccionesPortletResource");
		
		for(int a = 0;a <configSelected.length; a++) {
			System.out.println("Config Selected: "+ a + configSelected[a]);
			logger.info("Config Selected: "+ a + configSelected[a]);
		}
		
		String ip;
		String userId;
		String codConvenio;
		String bankId;
		Puma puma;
		BankInfoType bankInfo = new BankInfoType();
		List<ParamFilesType> listaParametriaArchivo; 
		ConsultaTransaccionesBeanWcm consulta = new ConsultaTransaccionesBeanWcm();
		logger.info("V1");
		logger.info("Guardar: setea parametros iniciales");
		System.out.println("Guardar: setea parametros iniciales");
		try {
			bankId = rb.getString("request.bankId");
			puma = new Puma();
			codConvenio = puma.getPropertyFromPuma("ath-codigoconvenio", getRenderRequest());
			ip = com.ibm.ws.portletcontainer.portlet.PortletUtils
					.getHttpServletRequest(getRenderRequest()).getRemoteAddr();
			userId = puma.getPropertyFromPuma("uid", getRenderRequest());
			codConvenio = puma.getPropertyFromPuma("ath-codigoconvenio", getRenderRequest());
			bankInfo.setBankId(bankId);
			listaParametriaArchivo = new ArrayList<ParamFilesType>();
			
			logger.info("Guardar: setea Request");
			System.out.println("Guardar: setea Request");
			String EndPointRESTTransactionsBySelectedField = ConfigurationService.getInstance().getEndpointRest();
			GetTransactionsBySelectedFieldsRq rq = new GetTransactionsBySelectedFieldsRq();
			
			logger.info("Guardar: setea Request 1");
			System.out.println("Guardar: setea Request 1");
			rq.setBankInfo(bankInfo);
			rq.setIpAddress(ip);
			rq.setRequestID(getRequestIdSave());
			rq.setRequestSender(userId);
			rq.setRequestUser(userId);
			rq.setRequestDate(new Date());
			rq.setAgreementId(codConvenio); 
			
			int i = 0;
//			for(ParamFilesType j :responseParamFile) {
//				ParamFilesType e = new ParamFilesType();
////					if (i < configSelected.length) {
//					if(configSelected[i] != null && j.getName().equals(configSelected[i])) {
//						e.setIdParamArchivo(j.getIdParamArchivo());
//						System.out.println("Registros IdParamFile retorno marca True: " + j.getIdParamArchivo() +"Value: " +configSelected[i]);
//						logger.info("Registros IdParamFile retorno marca true: " + j.getIdParamArchivo() +"Value: " +configSelected[i]);
//						e.setStatusMark(true);
//						e.setIdParam(j.getIdParam());
//						listaParametriaArchivo.add(e);
//						i++;
//					}else {
//						e.setIdParamArchivo(j.getIdParamArchivo());
//						System.out.println("Registros IdParamFile retorno marca false: " + j.getIdParamArchivo());
//						logger.info("Registros IdParamFile retorno marca false: " + j.getIdParamArchivo());
//						e.setStatusMark(false);
//						e.setIdParam(j.getIdParam());
//						listaParametriaArchivo.add(e);
//					}
////					}
//			}
				
			for (ParamFilesType j : responseParamFile) {
				ParamFilesType e = new ParamFilesType();
				logger.info("parametro:: "+j.getName());
                for (String parametro : configSelected) {                 
                    e.setIdParamArchivo(j.getIdParamArchivo());
                    e.setIdParam(j.getIdParam());
                    if (j.getName().equals(parametro)) {
                        e.setStatusMark(true);
                        logger.info("Registros IdParamFile retorno marca true: " + j.getIdParamArchivo() +"Value: " + parametro);
                        break;
                    } else {
                        e.setStatusMark(false);
                        logger.info("Registros IdParamFile retorno marca false: " + j.getIdParamArchivo() +"Value: " + parametro);
                    }                
                }
                listaParametriaArchivo.add(e);
            }
			logger.info("lista parametría archivo:: " + new Gson().toJson(listaParametriaArchivo));
			rq.setListaParametriaArchivo(listaParametriaArchivo);
			
			logger.info("[REQUEST - getConfigurationBySelectedFields] Save DATA : "+new Gson().toJson(rq));
			System.out.println("[REQUEST - getConfigurationBySelectedFields] Save DATA: "+new Gson().toJson(rq));
			logger.info("Endpoint consulta" + EndPointRESTTransactionsBySelectedField + "consultarTransaccionesArchivoParametrico");
			GetTransactionsBySelectedFieldsRs rs = 
					(GetTransactionsBySelectedFieldsRs) WebServiceClientHTTPS.getInstance(GetTransactionsBySelectedFieldsRs.class).procesarRequest(
					EndPointRESTTransactionsBySelectedField + "getTransactionsBySelectedFields", rq);
			logger.info("[RESPONSE - getConfigurationBySelectedFields] Save DATA: "+new Gson().toJson(rs));
			System.out.println("[RESPONSE - getConfigurationBySelectedFields] Save DATA: "+new Gson().toJson(rs));
			responseParamFile = rs.getListaParametriaArchivoUsuario();
			itemsSelection = new ArrayList<SelectItem>();
			setListaConfiguracion();
			setPopUpClass("popUpSuccess");
			setMensajePopUp(MENSAJE_POPUP_EXITO);
			setTituloPopUp(TITULO_POPUP_EXITO);
		}catch (PortletServiceUnavailableException e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.info("PortletServiceUnavailableException: "+e.getMessage());
			System.out.println("PortletServiceUnavailableException: "+e.getMessage());
			consulta.mostrarModal("Error", "icon-error", "Error en el server favor formatear");
			setPopUpClass("popUpError");
			setTituloPopUp(TITULO_POPUP_ERROR);
			setMensajePopUp(MENSAJE_POPUP_ERROR);
		}catch (NamingException e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.info("NamingException: "+e.getMessage());
			System.out.println("NamingException: "+e.getMessage());
			consulta.mostrarModal("Error", "icon-error", "Error en el server favor formatear");
			setPopUpClass("popUpError");
			setTituloPopUp(TITULO_POPUP_ERROR);
			setMensajePopUp(MENSAJE_POPUP_ERROR);
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			logger.info("GenericException: "+e.getMessage());
			System.out.println("GenericException: "+e.getMessage());
			consulta.mostrarModal("Error", "icon-error", "Error en el server favor formatear");
			setPopUpClass("popUpError");
			setTituloPopUp(TITULO_POPUP_ERROR);
			setMensajePopUp(MENSAJE_POPUP_ERROR);
		}
	}
	public void selectAllCheckBox(AjaxBehaviorEvent event) {
		logger.info("itemsSelection: "+ itemsSelection.size() + "configSelected: "+ configSelected.length);
		
		if(itemsSelection.size() != configSelected.length) {
			ArrayList<String> selectedAll = new ArrayList<String>();
			for(SelectItem item: itemsSelection) {
				selectedAll.add(item.getLabel());
			}
			configSelected = selectedAll.toArray(new String[selectedAll.size()]);
			
			logger.info("Va a Selecionar Todo: "+ configSelected.toString());
		}else {
			configSelected = new String[0];
			logger.info("Va a desSelecionar Todo: "+ configSelected.toString());
		}
		FacesContext.getCurrentInstance().getPartialViewContext().getRenderIds().add("checkBoxConfig");
		
	}

    public void limpiarChecks(AjaxBehaviorEvent event) {
    	logger.info(":::::::Entra metodo limpiar checks::::::::::");
    	logger.info("tempSelected:: " + new Gson().toJson(tempSelected));
    	logger.info("configSelected:: " + new Gson().toJson(configSelected));
    	logger.info("responseParamFile:: " + new Gson().toJson(responseParamFile));
    	setListaConfiguracion();
    }
    
	public String getTarjetaCredito() {
		return tarjetaCredito;
	}

	public void setTarjetaCredito(String tarjetaCredito) {
		this.tarjetaCredito = tarjetaCredito;
	}

	public RenderRequest getRenderRequest() {
		return renderRequest;
	}

	public void setRenderRequest(RenderRequest renderRequest) {
		this.renderRequest = renderRequest;
	}
	
}
