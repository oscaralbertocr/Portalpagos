package com.portalrecaudadores.consultatransacciones.beans;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean(name = "RutaContenidoBean", eager = true)
@RequestScoped
public class RutaContenidoBean implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String bankName;
	
	private String userName;
	
	private String ipAdress;
	
	private String email;
	
	private String portlet;
	
	private String currentPage;
	
	private String urlHome;
	
	private String pathContentConsultaTransacciones;
	
	private int cantidadMeses;
	
	private String bankId;

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getIpAdress() {
		return ipAdress;
	}

	public void setIpAdress(String ipAdress) {
		this.ipAdress = ipAdress;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPortlet() {
		return portlet;
	}

	public void setPortlet(String portlet) {
		this.portlet = portlet;
	}

	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}

	public String getUrlHome() {
		return urlHome;
	}

	public void setUrlHome(String urlHome) {
		this.urlHome = urlHome;
	}

	public String getPathContentConsultaTransacciones() {
		return pathContentConsultaTransacciones;
	}

	public void setPathContentConsultaTransacciones(
			String pathContentConsultaTransacciones) {
		this.pathContentConsultaTransacciones = pathContentConsultaTransacciones;
	}

    public int getCantidadMeses() {
        return cantidadMeses;
    }

    public void setCantidadMeses(int cantidadMeses) {
        this.cantidadMeses = cantidadMeses;
    }

	public String getBankId() {
		return bankId;
	}

	public void setBankId(String bankId) {
		this.bankId = bankId;
	}
    
}
