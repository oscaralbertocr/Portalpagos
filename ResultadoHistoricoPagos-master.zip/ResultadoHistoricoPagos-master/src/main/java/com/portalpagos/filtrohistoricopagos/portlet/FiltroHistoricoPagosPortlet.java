package com.portalpagos.filtrohistoricopagos.portlet;

import java.io.IOException;
import java.util.ResourceBundle;

import javax.faces.FacesException;
import javax.portlet.*;

import co.com.ath.logger.CustomLogger;
import co.com.ath.parameterspage.ParametersPage;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.service.model.ErrorData;

import com.ath.portalpagos.util.ExceptionManager;
import com.portalpagos.filtrohistoricopagos.beans.RutaContenidoBean;
import com.portalpagos.filtrohistoricopagos.beans.FiltroHistoricoPagosBean;
import com.portalpagos.filtrohistoricopagos.util.Puma;

import org.apache.commons.lang.exception.ExceptionUtils;

/***
 * Portlet para la consulta historico de pagos
 * @author rafael.gutierrez
 *
 */
public class FiltroHistoricoPagosPortlet extends com.ibm.faces20.portlet.FacesPortlet {

	private CustomLogger logger= new CustomLogger(FiltroHistoricoPagosPortlet.class);
	private static String user;
	private static String rquid;	
	
		
	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		RutaContenidoBean rContenido = null;
		try{
			System.out.println("Filtro historico");
			rContenido = rutaContenido(request,response);
			asignarFechasFormulario(request, rContenido);
			super.doView(request, response);
		} catch (NoClassDefFoundError e){
			Exception e1=(Exception) ExceptionUtils.getRootCause(e);
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e1, rquid, ExceptionManager.PP_PORTAL_LIBRERIAS_01, user, ExceptionManager.MSG_PORTAL_LIBRERIAS_01+" - Operación: Cargar vista, FiltroHistoricoPago", "doView", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e1);
		}  catch(Exception e){
			try {
				throw ExceptionUtils.getRootCause(e);
			} catch(FacesException e1){
				ErrorData errorData= PublisherUtil.getInstance().getErrorData(e1, rquid, ExceptionManager.PP_PORTAL_FACES_01, user, ExceptionManager.MSG_PORTAL_FACES_01+" - Operación: Cargar vista, FiltroHistoricoPago", "doView", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
				logger.error(errorData, e1);
			} catch (Throwable e1) {
				ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: Cargar vista, FiltroHistoricoPago", "doView", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal());
				logger.error(errorData, e);
			}
		}
	}
	
	
	private void asignarFechasFormulario(RenderRequest request, RutaContenidoBean rContenido) {
		try{
			String fromEvent;		
			FiltroHistoricoPagosBean bean = (FiltroHistoricoPagosBean) request.getPortletSession().getAttribute("filtroHistoricoPagos");
			
			if(null==bean){
				bean= new FiltroHistoricoPagosBean();
				bean.cargarWCM(request);
			}
			
			//si el llamado viene de un evento
			fromEvent = request.getParameter("fromEvent");
			if(fromEvent == null){
				fromEvent = "";
			}
			//si el llamado viene del link, asigna los valores por defecto a las fechas
			if(fromEvent.equals("")){
				if(bean!=null){
					bean.cargar(rquid, user);
					bean.resetearFechas();
				}
			}
			request.getPortletSession().setAttribute("filtroHistoricoPagos",bean);
		}  catch(Exception e){
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: Asignar fechas formulario, FiltroHistoricoPago", "asignarFechasFormulario", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal());
			logger.error(errorData, e);
		}
								
	}

	public void destroy() {
		super.destroy();
	}			

	/**
	* Process an action request.
	* @see javax.portlet.Portlet#processEvent(javax.portlet.EventRequest, javax.portlet.EventResponse)
	*/
	public void processEvent(EventRequest eventRequest,EventResponse eventResponse) throws PortletException, java.io.IOException {	
		String portlet = "", pagina = "", portal = "";
		try {
			System.out.println("Procesar Evento" );
			Event event = eventRequest.getEvent();
			System.out.println( "event " + event.toString());
			if (event.getName().equals("rqFiltroHistoricoPagos")) {				
				String rqFiltroVerifica = event.getValue().toString();
				System.out.println("rqFiltroVerifica envio "+ rqFiltroVerifica);
				eventResponse.setRenderParameter("fromEvent", "yes");
			}
		} catch (Exception e) {
			System.out.println("error Filtro " + e);
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: processEvent, FiltroHistoricoPago", "processEvent", portlet, pagina, portal);
			logger.error(errorData, e);
		}
		//super.processEvent(eventRequest, eventResponse);
	}
	
	/**
	 * HU112.1 Metodo para consultar la ruta de contenido del parametro de pagina
	 * @author santiago.cuervo
	 * */
	public RutaContenidoBean rutaContenido(RenderRequest request, RenderResponse response){
		RutaContenidoBean rContenido = new RutaContenidoBean();
		System.out.println("Filtro historico");
		//Se genera RQUID inicial
		rquid= PublisherUtil.getInstance().generateRequestID();
		
		try {
			// Obtener la ruta de la plantilla de creación en Portal
			String rutaContenido = (String) ParametersPage.getParameterPage(request, response, "pathContent-contHistoricoPago");

			
			if(null==rutaContenido){
				rutaContenido = request.getPreferences().getValue("pathContent-contHistoricoPago", "");
				
			}
			String currentPage = (String) ParametersPage.getParameterPage(request, response, "pagina-origen");
			
			if(null==currentPage){
				currentPage = request.getPreferences().getValue("pagina-origen", "");
			}
			String originPortal = (String) ParametersPage.getParameterPage(request, response, "bankName");
			
			if(null==originPortal){
				originPortal = request.getPreferences().getValue("bankName", "");
			}
			String bankId = (String) ParametersPage.getParameterPage(request, response, "bankId");
			
			if(null==bankId){
				bankId = request.getPreferences().getValue("bankId", "");
			}
			
			Puma puma = new Puma();
			user = puma.getPropertyFromPuma("uid", request);

			ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.filtrohistoricopagos.portlet.nl.FiltroHistoricoPagosPortletResource");

			rContenido.setPathContentContHistoricoPago(rutaContenido);
			rContenido.setBankId(bankId);
			rContenido.setCurrentPage(currentPage);
			rContenido.setOriginPortal(originPortal);
			rContenido.setUserName(user);
			rContenido.setPortlet(rb.getString("auditoria.nombrePortlet"));

			String dn = (String) ParametersPage.getParameterPage(request, response, "dn");
			rContenido.setDn(dn);
			
			request.getPortletSession().setAttribute("RutaContenidoBean", rContenido);

		}	catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: Consultar ruta contenido, FiltroHistoricoPago", "rutaContenido", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal());
			logger.error(errorData, e);
		} 
		
		return rContenido;
	}
			
}