package com.portalpagos.filtrohistoricopagos.util;

import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.portlet.PortletRequest;

import com.ibm.portal.portlet.service.PortletServiceHome;
import com.ibm.portal.portlet.service.PortletServiceUnavailableException;
import com.ibm.portal.um.PumaEnvironment;
import com.ibm.portal.um.PumaLocator;
import com.ibm.portal.um.PumaProfile;
import com.ibm.portal.um.User;
import com.ibm.portal.um.exceptions.PumaException;
import com.ibm.portal.um.portletservice.PumaHome;
import com.portalpagos.filtrohistoricopagos.beans.RutaContenidoBean;


/**
 * HU105 Clase encargada de administrar los usuarios a trav�s del API PUMA
 * @author melany.rozo
 * @since 11/02/2015
 **/
public class Puma {

	private PumaHome pumaHome = null;	
	
	public Puma() throws NamingException, PortletServiceUnavailableException{		
		PortletServiceHome portletServiceHome = null;
		Context context = new InitialContext();
		portletServiceHome = (PortletServiceHome) context.lookup("portletservice/com.ibm.portal.um.portletservice.PumaHome");
		if (portletServiceHome != null) {
			pumaHome = (PumaHome) portletServiceHome.getPortletService(PumaHome.class);
		}		
	}
	

	/**
	 * HU105 Funci�n que devuelve el usuario actual logueado en el portal
	 * @author melany.rozo
	 * @since 11/02/2015
	 **/
	public User getCurrenUser(PortletRequest request) throws PumaException{
		PumaProfile pumaProfile = pumaHome.getProfile(request);
		User user = pumaProfile.getCurrentUser();	
		return user;
	}

	/**
	 * HU105 Funci�n que devuelve el valor relacionado a una de las propiedades del usuario actual
	 * @author melany.rozo
	 * @since 11/02/2015
	 **/
	public String getPropertyFromPuma(String property, PortletRequest request) throws Exception{
		PumaProfile pumaProfile = pumaHome.getProfile(request);
		User user = pumaProfile.getCurrentUser();
		List<String> attributeList = new ArrayList<String>();
		attributeList.add(property);
		Map<?,?> userAttributeMap = pumaProfile.getAttributes(user, attributeList);
		return (String)userAttributeMap.get(property);
	}
	
	/**
	 * HU 66.1 Método encargado de consultar el atributo ath-sessionID que tiene el usuario en el TDS
	 * @date 27/11/2015
	 * @author melany.rozo
	 * 
	 * **/
	public String getSessionIDUsuario(String ref_uid, PortletRequest request){

		final String uid= ref_uid;
		final PortletRequest requestFi = request;
		String sessionID = "";
		RutaContenidoBean rContenido= (RutaContenidoBean) request.getPortletSession().getAttribute("RutaContenidoBean");
		final String dn=rContenido.getDn();

		PumaEnvironment pe = pumaHome.getEnvironment();
		Object[] objUser = null;
		
		try{
			objUser = pe.runUnrestricted(new PrivilegedExceptionAction<Object[]>() {
				@Override
				public Object[] run() throws Exception {

					Object[] obj = new Object[1];
					
					PumaProfile pp = pumaHome.getProfile(requestFi);
					PumaLocator pl = pumaHome.getLocator(requestFi);

					String userDn="uid="+uid+dn;
					
					User usuario = pl.findUserByIdentifier(userDn);
					ArrayList<String> attributes = new ArrayList<String>();
					attributes.add("ath-sessionID");
					
					Map user = pp.getAttributes(usuario, attributes);
					obj[0] = user.get("ath-sessionID").toString();
					return obj;
				}
			
			});
		} catch (PrivilegedActionException e) {
			sessionID="";
		}
		 
				
		if(objUser!=null && objUser.length>0 && objUser[0]!= null){
			sessionID = objUser[0].toString();
		}
		
		return sessionID;
	}
}
