package com.portalpagos.filtrohistoricopagos.beans;

import java.io.Serializable;

/***
 * Clase para almacenar los medios de pagos que se configuran en el WCM
 * @author rafael.gutierrez
 *
 */
public class MedioPago implements Serializable {

	private static final long serialVersionUID = 7609484157186552500L;
	private String id;
	private String nombre;
	
	public MedioPago() {
		id="0";
		nombre="";
	}
	
	public MedioPago(String id, String nombre) {
		super();
		this.id = id;
		this.nombre = nombre;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	
}
