package com.portalpagos.filtrohistoricopagos.beans; 

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletRequest;
import javax.portlet.PortletSession;
import javax.portlet.RenderRequest;

import co.com.ath.logger.CustomLogger;
import co.com.ath.payments.mc.auditor.publisher.traza.TrazaPublisher;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.service.model.AuditorRq;
import co.com.ath.payments.mc.service.model.BankInfoType;
import co.com.ath.payments.mc.service.model.ErrorData;
import co.com.ath.payments.mc.service.model.GetTransactionStatusesRq;
import co.com.ath.payments.mc.service.model.GetTransactionStatusesRs;
import co.com.ath.payments.mc.service.model.MedioPagoType;
import co.com.ath.payments.mc.service.model.MediosPagosRq;
import co.com.ath.payments.mc.service.model.MediosPagosRs;
import co.com.ath.payments.mc.service.model.TxStatusType;

import com.ath.portalpagos.util.ExceptionManager;
import com.ath.portalpagos.util.IpNodoPortal;
import com.ath.portalpagos.util.JSONUtil;
import com.co.pragma.portal.utils.WCMCliente;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.exceptions.WCMException;
import com.portalpagos.filtrohistoricopagos.beans.RutaContenidoBean;
import com.portalpagos.filtrohistoricopagos.portlet.FiltroHistoricoPagosPortlet;
import com.portalpagos.filtrohistoricopagos.util.CommonUtils;
import com.portalpagos.filtrohistoricopagos.util.ServiceFactory;


/** HU61
 * ManagedBean utilizado para almacenar los datos del formulario de busqueda 
 * @author: rafael.gutierrez
 * @Since: 03/03/2015
 **/

@ManagedBean(name = "filtroHistoricoPagos", eager=true)
@SessionScoped
public class FiltroHistoricoPagosBean implements Serializable {

	private CustomLogger logger= new CustomLogger(FiltroHistoricoPagosPortlet.class);
	private static final long serialVersionUID = 1L;
	private String fechaInicial;
	private String fechaFinal;
	private String idMedioPago;
	private String idEstadoPago;
	private ResourceBundle rb = null;
	private String stMensajeValidacionFechas;	
	private List<MedioPagoType> mediosPago;
	private List<TxStatusType> estadosPago;
	private String labelFechaInicial;
	private String labelFechaFinal;
	private String labelMedioPago;
	private String btnConsultar;
	private String itemDefecto;
	private String labelEstadoPago;
	private static String user;
	private static String rquid;
	private int cantidadMesesCalen;
	

	private static final String DOSPUNTOS = ":";
	private static final String NODO = "Nodo Portal";
	private static final String COMA = ",";

	public FiltroHistoricoPagosBean(){	
		idMedioPago = "0";	
		idEstadoPago = "0";
	}
	
	public void cargar(String rq, String usuario){
		rquid=rq;
		user=usuario;
	}

	public void cargarWCM(RenderRequest request) {

		RutaContenidoBean rContenido = (RutaContenidoBean) request.getPortletSession().getAttribute("RutaContenidoBean");
	
		
		WCMCliente cliente;
		MediosPagosRq rq = null;
		MediosPagosRs rs = new MediosPagosRs();

		try {
			cliente = new WCMCliente(rContenido.getPathContentContHistoricoPago());
			ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.filtrohistoricopagos.portlet.nl.FiltroHistoricoPagosPortletResource");

			stMensajeValidacionFechas = ((ShortTextComponent) cliente.getComponent("stMensajeValidacionFechas")).getText();

			labelFechaInicial = ((ShortTextComponent) cliente.getComponent("stLabelFechaInicial")).getText();
			labelFechaFinal = ((ShortTextComponent) cliente.getComponent("stLabelFechaFinal")).getText();
			labelMedioPago = ((ShortTextComponent) cliente.getComponent("stLabelMedioPago")).getText();
			btnConsultar = ((ShortTextComponent) cliente.getComponent("stBotonConsultar")).getText();
			itemDefecto = ((ShortTextComponent) cliente.getComponent("stItemSeleccione")).getText();
			labelEstadoPago = ((ShortTextComponent) cliente.getComponent("stLabelEstado")).getText();
			cantidadMesesCalen = CommonUtils.getInstance().obtenerMesesCalendario(rb);
			cliente.endWorkspace();
			BankInfoType infoBanco = new BankInfoType();
			infoBanco.setBankId(rContenido.getBankId());
			infoBanco.setBankName(rContenido.getOriginPortal());
			
			rq = new MediosPagosRq();
			rq.setBankInfo(infoBanco);
			rq.setIPAddress(rContenido.getIpAdress());
			rq.setRequestDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
			rq.setRequestID(PublisherUtil.getInstance().generateRequestID());
			rq.setRequestOriginPortal(rContenido.getOriginPortal());
			rq.setRequestPage(rContenido.getCurrentPage());
			rq.setRequestSender(rContenido.getPortlet());
			rq.setRequestUser(rContenido.getUserName());
			rq.setClient(true);

			rs = ServiceFactory.getInstance().getServiceBean().getMediosPagos(rq);
			
			if (!("SUCCESS".equals(rs.getStatus().getStatusCode()))) {
				logger.info("getMediosPagos "+rContenido.getUserName()+". Response CODE: "+rs.getStatus().getStatusCode()+", DESC: "+rs.getStatus().getStatusDesc());
			}else{
				mediosPago = rs.getMediosPagoList();
			}
			
			cargarEstados(request);

		} catch (WCMException e) {			
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_WCM_01, user, ExceptionManager.MSG_PORTAL_WCM_01+" - Operación: Cargar contenido WCM, FiltroHistoricoPagos", "cargarWCM", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
		} catch (Exception ex){			
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(ex, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" Operación: Cargar contenido WCM, FiltroHistoricoPagos", "cargarWCM", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, ex);
		}
	}		

	private void cargarEstados(RenderRequest request) {
		
		GetTransactionStatusesRq rq = null;
		GetTransactionStatusesRs rs = new GetTransactionStatusesRs();
		
		RutaContenidoBean rContenido = (RutaContenidoBean) request.getPortletSession().getAttribute("RutaContenidoBean");
		
		try {

			BankInfoType infoBanco = new BankInfoType();
			infoBanco.setBankId(rContenido.getBankId());
			infoBanco.setBankName(rContenido.getOriginPortal());
			
			rq = new GetTransactionStatusesRq();
			rq.setBankInfo(infoBanco);
			rq.setIPAddress(rContenido.getIpAdress());
			rq.setRequestDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
			rq.setRequestID(PublisherUtil.getInstance().generateRequestID());
			rq.setRequestOriginPortal(rContenido.getOriginPortal());
			rq.setRequestPage(rContenido.getCurrentPage());
			rq.setRequestSender(rContenido.getPortlet());
			rq.setRequestUser(rContenido.getUserName());
			rs = ServiceFactory.getInstance().getServiceBean().getTransactionStatuses(rq);
			
			if (!("SUCCESS".equals(rs.getStatus().getStatusCode()))) {
				logger.info("getTransactionStatuses "+rContenido.getUserName()+". Response CODE: "+rs.getStatus().getStatusCode()+", DESC: "+rs.getStatus().getStatusDesc());
			}else{
				setEstadosPago(rs.getTxStatuses());
			}
			
		}  catch (Exception ex){			
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(ex, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" Operación: Cargar estados pago, FiltroHistoricoPagos", "cargarEstados", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, ex);
		}
		
	}

	public String getFechaInicial() {
		return fechaInicial;
	}

	public void setFechaInicial(String fechaInicial) {
		this.fechaInicial = fechaInicial;
	}

	public String getFechaFinal() {
		return fechaFinal;
	}

	public void setFechaFinal(String fechaFinal) {
		this.fechaFinal = fechaFinal;
	}

	public String getIdMedioPago() {
		return idMedioPago;
	}

	public void setIdMedioPago(String idMedioPago) {
		this.idMedioPago = idMedioPago;
	}				
	
	public List<MedioPagoType> getMediosPago() {		
		return mediosPago;
	}

	public void setMediosPago(List<MedioPagoType> mediosPago) {
		this.mediosPago = mediosPago;
	}		

	public String getStMensajeValidacionFechas() {
		return stMensajeValidacionFechas;
	}

	public void setStMensajeValidacionFechas(String stMensajeValidacionFechas) {
		this.stMensajeValidacionFechas = stMensajeValidacionFechas;
	}

	public String getLabelFechaInicial() {
		return labelFechaInicial;
	}

	public void setLabelFechaInicial(String labelFechaInicial) {
		this.labelFechaInicial = labelFechaInicial;
	}

	public String getLabelFechaFinal() {
		return labelFechaFinal;
	}

	public void setLabelFechaFinal(String labelFechaFinal) {
		this.labelFechaFinal = labelFechaFinal;
	}

	public String getLabelMedioPago() {
		return labelMedioPago;
	}

	public void setLabelMedioPago(String labelMedioPago) {
		this.labelMedioPago = labelMedioPago;
	}

	public String getBtnConsultar() {
		return btnConsultar;
	}

	public void setBtnConsultar(String btnConsultar) {
		this.btnConsultar = btnConsultar;
	}

	public String getItemDefecto() {
		return itemDefecto;
	}

	public void setItemDefecto(String itemDefecto) {
		this.itemDefecto = itemDefecto;
	}
	
	public List<TxStatusType> getEstadosPago() {
		return estadosPago;
	}

	public void setEstadosPago(List<TxStatusType> estadosPago) {
		this.estadosPago = estadosPago;
	}
	
	public String getIdEstadoPago() {
		return idEstadoPago;
	}

	public void setIdEstadoPago(String idEstadoPago) {
		this.idEstadoPago = idEstadoPago;
	}

	public String getLabelEstadoPago() {
		return labelEstadoPago;
	}

	public void setLabelEstadoPago(String labelEstadoPago) {
		this.labelEstadoPago = labelEstadoPago;
	}
	
	public int getCantidadMesesCalen() {
        return cantidadMesesCalen;
    }

    public void setCantidadMesesCalen(int cantidadMesesCalen) {
        this.cantidadMesesCalen = cantidadMesesCalen;
    }

    /***
	 * Devuelve los campos del formulario a su valor inicial 
	 * Se invoca cuando se accede a la pagina a traves del link
	 */
	public void resetearFechas(){
		try{
			Calendar calendar = Calendar.getInstance();
			Date hoy = new Date();
	        calendar.setTime(hoy);  
			calendar.add(Calendar.DAY_OF_YEAR, -30);
			Date fechAux = calendar.getTime();
			fechaInicial = formatearFecha(fechAux);
			fechaFinal = formatearFecha(hoy);
			idMedioPago = "0";
			idEstadoPago = "00";
		}catch(Exception ex){
			FacesContext context = FacesContext.getCurrentInstance();
			ExternalContext externalContext = context.getExternalContext();
			PortletRequest requestContenido = (PortletRequest) externalContext.getRequest();
			RutaContenidoBean rContenido = (RutaContenidoBean) requestContenido.getPortletSession().getAttribute("RutaContenidoBean");
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(ex, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" Operación: Resetear fechas, FiltroHistoricoPagos", "resetearFechas", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, ex);
		}
	}
	
	/***
	 * Devulve la fecha en el foramto leido del properties
	 * @param fecha
	 * @return
	 */
	private String formatearFecha(Date fecha){
		String fechaFormateada = "";
		try{
			// Captura los valores almacenados en el properties
			String formatFecha = getProperty("config.formatoFecha");
			SimpleDateFormat fechaformato = new SimpleDateFormat(formatFecha);
			fechaFormateada = fechaformato.format(fecha);
			
		}catch(Exception ex){
			FacesContext context = FacesContext.getCurrentInstance();
			ExternalContext externalContext = context.getExternalContext();
			PortletRequest requestContenido = (PortletRequest) externalContext.getRequest();
			RutaContenidoBean rContenido = (RutaContenidoBean) requestContenido.getPortletSession().getAttribute("RutaContenidoBean");
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(ex, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" Operación: Formatear fechas, FiltroHistoricoPagos", "formatearFecha", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, ex);
		}
		return fechaFormateada;
	}
	
	/***
	 * Obtiene el valor del archivo de propiedades
	 * @param key clave de la propiedad a leer
	 * @return valor de la propiedad
	 */
	private String getProperty(String key){
		if(rb == null){
			rb = ResourceBundle.getBundle("com.portalpagos.filtrohistoricopagos.prop.FiltroHistoricoPagosProp");
		}
		String value = rb.getString(key);
		return value;
	}
	
	public void Consultar(){
		rquid = PublisherUtil.getInstance().generateRequestID();
					
		
		FacesContext context = FacesContext.getCurrentInstance();
		//Genera el response para enviar el evento
		com.ibm.faces20.portlet.httpbridge.PortletResponseWrapper responseWrapper = (com.ibm.faces20.portlet.httpbridge.PortletResponseWrapper) context
				.getExternalContext().getResponse();
		ActionResponse response = (ActionResponse) responseWrapper.getPortletResponse();
		
		ExternalContext externalContext = context.getExternalContext();
		
		PortletRequest requestContenido = (PortletRequest) externalContext.getRequest();
		
		RutaContenidoBean rContenido = (RutaContenidoBean) requestContenido.getPortletSession().getAttribute("RutaContenidoBean");
		ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.filtrohistoricopagos.portlet.nl.FiltroHistoricoPagosPortletResource");
		
		trazaRqConsultaHistorico(rquid,rb,rContenido,this.fechaInicial,this.fechaFinal,this.idMedioPago, this.idEstadoPago);
		
		//Genera el request para capturar los datos en session		
		com.ibm.faces20.portlet.httpbridge.PortletRequestWrapper requestWrapper = (com.ibm.faces20.portlet.httpbridge.PortletRequestWrapper) context
				.getExternalContext().getRequest();
		ActionRequest request = (ActionRequest) requestWrapper
				.getPortletRequest();
		
		FiltroHistoricoPagosBean filtroHistPagosBean = (FiltroHistoricoPagosBean) request
				.getPortletSession().getAttribute("filtroHistoricoPagos");
		//obtiene los datos ingresados en la vista e invoca el evento que muestra los resultados
		try{
			System.out.println("Consultar ");
			 if(filtroHistPagosBean != null){
				 String paramsMap = "";
				 paramsMap = this.fechaInicial + "/";
				 paramsMap += this.fechaFinal + "/";
				 paramsMap += this.idMedioPago + "/";
				 paramsMap += this.idEstadoPago + "/";
				 paramsMap += rquid;
				 System.out.println("Consultar antes de enviar parametros " +paramsMap);
				 response.setEvent("rqFiltroHistoricoPagos", paramsMap);
				 response.setRenderParameter("fromEvent","yes");
			 }			 
		}catch(Exception ex){
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(ex, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" Operación: Consultar FiltroHistoricoPagos", "Consultar", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, ex);
		}finally{
			request.getPortletSession().removeAttribute("filtroHistoricoPagos", PortletSession.PORTLET_SCOPE);
		}
	}
	
	public void trazaRqConsultaHistorico(String requestId,ResourceBundle rb,RutaContenidoBean rContenido,String fInicial, String fFinal, String medioPago, String estadoPago){
		try{

			//TRAZA
			AuditorRq auditorRq = new AuditorRq();
		
			auditorRq.setRequestId(requestId);
			auditorRq.setIpAddress(rContenido.getIpAdress());
			auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
			auditorRq.setAction(rb.getString("auditoria.consultaHistorico"));
			auditorRq.setOriginPortal(rContenido.getOriginPortal());
			auditorRq.setPage(rContenido.getCurrentPage());
			auditorRq.setPortlet(rb.getString("auditoria.nombrePortlet"));
			auditorRq.setUser(rContenido.getUserName());
			auditorRq.setTipoServicio("RQ");
			auditorRq.setAdditionalInfo(JSONUtil.getJson("Criterios de busqueda (fechaInicial/fechaFial/medioPago/estadoPago)"+DOSPUNTOS+fInicial+"/"+fFinal+"/"+medioPago+"/"+estadoPago+COMA+NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
			
			TrazaPublisher.getInstance().publish(auditorRq);
			//Fin de la traza		 
		}catch(Exception ex){
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(ex, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" Operación: trazaRqConsultaHistorico, FiltroHistoricoPagos", "trazaRqConsultaHistorico", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, ex);
		}
	}
	
	
			
}
