package com.portalpagos.resultadohistoricopagos.portlet;

import java.io.IOException;
import java.util.ResourceBundle;

import javax.faces.FacesException;
import javax.naming.NamingException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Event;
import javax.portlet.EventRequest;
import javax.portlet.EventResponse;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.exception.ExceptionUtils;

import co.com.ath.logger.CustomLogger;
import co.com.ath.parameterspage.ParametersPage;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.service.model.ErrorData;

import com.ath.portalpagos.util.ExceptionManager;
import com.ibm.portal.portlet.service.PortletServiceUnavailableException;
import com.ibm.portal.um.exceptions.PumaException;
import com.portalpagos.resultadohistoricopagos.util.ErrorManager;
import com.portalpagos.resultadohistoricopagos.beans.ResuladoHistoricoPagosBean;
import com.portalpagos.resultadohistoricopagos.beans.ResultadoRutaContenidoBean;
import com.portalpagos.resultadohistoricopagos.util.Puma;


public class ResultadoHistoricoPagosPortlet extends com.ibm.faces20.portlet.FacesPortlet {
		
	private CustomLogger logger= new CustomLogger(ResultadoHistoricoPagosPortlet.class);
	private static String user;
	private static String ip;
	private static String rquid;
	
	
	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		ResultadoRutaContenidoBean rContenido = null;
		try {
			System.out.println("Resultado Historico de pagos");
			rContenido = rutaContenido(request,response);
			ResuladoHistoricoPagosBean bean = (ResuladoHistoricoPagosBean) request.getPortletSession().getAttribute("resultadHistoricoPagosBean");
			if(bean==null){
				System.out.println("bean Null");
				bean=new ResuladoHistoricoPagosBean();
			}
			bean.cargarWCM(rContenido,rquid, request);
			System.out.println("carga WCM");
			String rqFilters = request.getParameter("rqFiltroHistoricoPagos");
			System.out.println("rqFiltro");
			bean.cargarResultados(rqFilters,request,rContenido,rquid);
			System.out.println("cargar resultado");
			request.getPortletSession().setAttribute("resultadHistoricoPagosBean", bean);
			System.out.println("atribute");
			super.doView(request, response);
		} catch (NoClassDefFoundError e){
			Exception e1=(Exception) ExceptionUtils.getRootCause(e);
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e1, rquid, ExceptionManager.PP_PORTAL_LIBRERIAS_01, user, ExceptionManager.MSG_PORTAL_LIBRERIAS_01+" - Operación: Cargar vista, Resultado Historico Pagos", "doView", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e1);
			System.out.println( " " +errorData + e1);
			String[] error= ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(), ExceptionManager.PP_PORTAL_LIBRERIAS_01);
			ResuladoHistoricoPagosBean consulta = new ResuladoHistoricoPagosBean();
			consulta.setStMensajeFallaComunicacion(error[0]);
		} catch(Exception e){
			try {
				throw ExceptionUtils.getRootCause(e);
			} catch(FacesException e1){
				ErrorData errorData= PublisherUtil.getInstance().getErrorData(e1, rquid, ExceptionManager.PP_PORTAL_FACES_01, user, ExceptionManager.MSG_PORTAL_FACES_01+" - Operación: Cargar vista, Resultado Historico Pagos", "doView", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
				logger.error(errorData, e1);
				String[] error= ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(), ExceptionManager.PP_PORTAL_LIBRERIAS_01);
				ResuladoHistoricoPagosBean consulta = new ResuladoHistoricoPagosBean();
				consulta.setStMensajeFallaComunicacion(error[0]);
			} catch (Throwable e1) {
				ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: Cargar vista, Resultado Historico Pagos", "doView", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal());
				logger.error(errorData, e);
				String[] error= ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(), ExceptionManager.PP_PORTAL_LIBRERIAS_01);
				ResuladoHistoricoPagosBean consulta = new ResuladoHistoricoPagosBean();
				consulta.setStMensajeFallaComunicacion(error[0]);
			}
		}

	}
		
	public void processAction(ActionRequest request, ActionResponse response) throws PortletException {
		super.processAction(request, response);
	}

	/**
		* Process an action request.
		* @see javax.portlet.Portlet#processEvent(javax.portlet.EventRequest, javax.portlet.EventResponse)
		*/
	public void processEvent(EventRequest eventRequest,EventResponse eventResponse) throws PortletException, java.io.IOException {		
		Event sampleEvent = eventRequest.getEvent();
		if(sampleEvent.getName().toString().equals("rqFiltroHistoricoPagos")) {
			String rqFiltroHistoricoPagos = sampleEvent.getValue().toString();
			eventResponse.setRenderParameter("rqFiltroHistoricoPagos", rqFiltroHistoricoPagos);
			eventRequest.getPortletSession().setAttribute("rqFiltroHistoricoPagos", rqFiltroHistoricoPagos);
		}		
	}
	
	/**
	 * HU112.1 Metodo para consultar la ruta de contenido del parametro de pagina
	 * @author santiago.cuervo
	 * */
	public ResultadoRutaContenidoBean rutaContenido(RenderRequest request, RenderResponse response){
		rquid = PublisherUtil.getInstance().generateRequestID();
		ResultadoRutaContenidoBean rContenido = new ResultadoRutaContenidoBean();
		try {
			// Obtener la ruta de la plantilla de creación en Portal
			System.out.println("rutaContenido" );
			String pathContentContHistoricoPago = (String) ParametersPage.getParameterPage(request, response, "pathContent-contHistoricoPago");
			if(null==pathContentContHistoricoPago){
				System.out.println("pathContentContHistoricoPago"  + pathContentContHistoricoPago);
				pathContentContHistoricoPago = request.getPreferences().getValue("pathContent-contHistoricoPago", "");
			}
			System.out.println("currentPage" );
			String currentPage = (String) ParametersPage.getParameterPage(request, response, "pagina-origen");
			
			if(null==currentPage){
				System.out.println("currentPage null" );
				currentPage = request.getPreferences().getValue("pagina-origen", "");
			}
			String originPortal = (String) ParametersPage.getParameterPage(request, response, "bankName");
			
			if(null==originPortal){
				System.out.println("originPortal null" );
				originPortal = request.getPreferences().getValue("bankName", "");
			}
			String bankId = (String) ParametersPage.getParameterPage(request, response, "bankId");
			
			if(null==bankId){
				System.out.println("bankId null" );
				bankId = request.getPreferences().getValue("bankId", "");
			}
			System.out.println("bankId null" );
			String dn = (String) ParametersPage.getParameterPage(request, response, "dn");
			rContenido.setDn(dn);
			
			String pathErroresTecnicos = (String) ParametersPage.getParameterPage(request, response, "pathErroresTecnicos");
			
			if(null==pathErroresTecnicos){
				pathErroresTecnicos = request.getPreferences().getValue("pathErroresTecnicos", "");
			}
			
			Puma puma;
			puma = new Puma();
			user = puma.getPropertyFromPuma("uid", request); 
			
			ip = this.getIpAddr(com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(request));
			
			ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.resultadohistoricopagos.portlet.nl.ResultadoHistoricoPagosPortletResource");

			rContenido.setPathContentContHistoricoPago(pathContentContHistoricoPago);
			rContenido.setBankId(bankId);
			rContenido.setCurrentPage(currentPage);
			rContenido.setIpAdress(ip);
			rContenido.setOriginPortal(originPortal);
			rContenido.setUserName(user);
			rContenido.setPortlet(rb.getString("auditoria.nombrePortlet"));
			rContenido.setPathErroresTecnicos(pathErroresTecnicos);
			
			request.getPortletSession().setAttribute("RutaContenidoBean", rContenido);

		}	catch (PortletServiceUnavailableException e) {
			System.out.println("PortletServiceUnavailableException " + e.getMessage());
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_PUMA_01, user, ExceptionManager.MSG_PORTAL_PUMA_01+" - Operación: Ruta contenido, Inscripcion Servicios", "rutaContenido", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(), ExceptionManager.PP_PORTAL_LIBRERIAS_01);
			ResuladoHistoricoPagosBean consulta = new ResuladoHistoricoPagosBean();
			consulta.setStMensajeFallaComunicacion(error[0]);
		} catch (NamingException e) { 
			System.out.println("PortletServiceUnavailableException " + e.getMessage());
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_PUMA_01, user, ExceptionManager.MSG_PORTAL_PUMA_01+" - Operación: Ruta contenido, Inscripcion Servicios", "rutaContenido", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(), ExceptionManager.PP_PORTAL_LIBRERIAS_01);
			ResuladoHistoricoPagosBean consulta = new ResuladoHistoricoPagosBean();
			consulta.setStMensajeFallaComunicacion(error[0]);
		} catch (PumaException e) {
			System.out.println("PortletServiceUnavailableException " + e.getMessage());
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_PUMA_01, user, ExceptionManager.MSG_PORTAL_PUMA_01+" - Operación: Ruta contenido, Resultado Historico Pagos", "rutaContenido", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(), ExceptionManager.PP_PORTAL_LIBRERIAS_01);
			ResuladoHistoricoPagosBean consulta = new ResuladoHistoricoPagosBean();
			consulta.setStMensajeFallaComunicacion(error[0]);
		} catch (Exception e) {
			System.out.println("PortletServiceUnavailableException " + e.getMessage());
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: Ruta contenido, Resultado Historico Pagos", "rutaContenido", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal());
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(), ExceptionManager.PP_PORTAL_LIBRERIAS_01);
			ResuladoHistoricoPagosBean consulta = new ResuladoHistoricoPagosBean();
			consulta.setStMensajeFallaComunicacion(error[0]);
		} 
		return rContenido;
	}
	/**
	 * HU 144 Funcion encargada de obtener la ip del usuario, dado un request
	 * @author melany.rozo
	 * @since 06/08/2015
	 */
	public String getIpAddr(HttpServletRequest request) {

		final String WL_PROXY_CLIENT_IP = "WL-Proxy-Client-IP";
		final String PROXY_CLIENT_IP = "Proxy-Client-IP";
		final String X_FORWARDER_FOR = "X-Forwarded-For";
		final String HTTP_X_FORWARDED_FOR = "HTTP_X_FORWARDED_FOR";
		final String HTTP_CLIENT_IP = "HTTP_CLIENT_IP";

		String ip = request.getHeader(X_FORWARDER_FOR);

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader(WL_PROXY_CLIENT_IP);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader(PROXY_CLIENT_IP);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader(HTTP_X_FORWARDED_FOR);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader(HTTP_CLIENT_IP);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}

		return ip;
	}
		
	
}