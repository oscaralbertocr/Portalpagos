package com.portalpagos.resultadohistoricopagos.beans;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.portlet.RenderRequest;

import co.com.ath.clientes.payments.mc.service.util.ConfigurationService;
import co.com.ath.logger.CustomLogger;
import co.com.ath.mc.utilities.util.TruncarUtil;
import co.com.ath.payments.mc.auditor.publisher.traza.TrazaPublisher;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.auditor.publisher.util.WebServiceClientHTTPS;
import co.com.ath.payments.mc.cache.manager.CacheManager;
import co.com.ath.payments.mc.service.model.AuditorRq;
import co.com.ath.payments.mc.service.model.ErrorData;
import co.com.ath.payments.mc.service.model.json.BankInfoType;
import co.com.ath.payments.mc.service.model.json.GetParametroRs;
import co.com.ath.payments.mc.service.model.json.GetPaymentHistoryRq;
import co.com.ath.payments.mc.service.model.json.GetPaymentHistoryRs;
import co.com.ath.payments.mc.service.model.json.ReferenceType;
import co.com.ath.payments.mc.service.model.json.TransactionDataType;
import co.com.ath.payments.mc.service.util.CommonUtils;

import com.ath.portalpagos.util.ExceptionManager;
import com.ath.portalpagos.util.IpNodoPortal;
import com.ath.portalpagos.util.JSONUtil;
import com.co.pragma.portal.utils.WCMCliente;
import com.google.gson.Gson;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.exceptions.WCMException;
import com.portalpagos.resultadohistoricopagos.portlet.ResultadoHistoricoPagosPortlet;
import com.portalpagos.resultadohistoricopagos.util.ErrorManager;

/***
 * ManagedBean para mostrar la tabla de resultados de historico de pedidos
 * @author rafael.gutierrez
 *
 */
@ManagedBean(name = "resultadHistoricoPagosBean", eager = true)
@SessionScoped
public class ResuladoHistoricoPagosBean implements Serializable{
	

	private static final String DOSPUNTOS = ":";
	private static final String NODO = "Nodo Portal";
	private static final String COMA = ",";
	
	private CustomLogger logger= new CustomLogger(ResultadoHistoricoPagosPortlet.class);
		
	private static final long serialVersionUID = 7947780839986700488L;
	private final static String SUCCESS = "SUCCESS";
	private int cantidadresultados;
	private String mensajeerror;
	private boolean renderMensajeError;
	private boolean renderTable;
	private String fechaInicial;
	private String fechaFinal;
	private String idMedioPago;
	private String idEstadoPago;
	private List<HistoricoPago> historicoPagos;
	private final String dateFormat = "dd-MM-yyyy";
	
	private String stColumnaServicio;
	private String stColumnaFecha;
	private String stColumnaValor;
	private String stColumnaRefPago;
	private String stColumnaMedioPago;
	private String stColumnaEstado;
	private String stColumnaComprobante;
	private String stMensajeNoHayResultados;
	private String stMensajeFallaComunicacion;
	private ResourceBundle rb;
	//atributo del TDS con el nombre del usuario
	private String usernameAttr;
	private String tableDateFormat;
	private String botonVer;
	private String rutaComprobante;
	private int truncarIzquierda = 4;
	private int truncarDerecha = 2;
	private char truncarCaracter = '*';

	public ResuladoHistoricoPagosBean(){
		logger.info("ResuladoHistoricoPagosBean");
		usernameAttr = getProperty("config.usernameAttr", "sn");
		logger.info("usernameAttr : " +usernameAttr);
		
		tableDateFormat = getProperty("config.externalDateFormat", "yyyy-MM-dd HH:mm:ss");
		logger.info("tableDateFormat : " + tableDateFormat);
	}

	/***
	 * Carga los contenidos del WCM
	 * @throws WCMException
	 */
	public void cargarWCM(ResultadoRutaContenidoBean rContenido, String rquid, RenderRequest request) throws WCMException {

		String rutaContenidoVP = rContenido.getPathContentContHistoricoPago();		
		
		WCMCliente cliente;
		try {
			cliente = new WCMCliente(rutaContenidoVP);

			stColumnaServicio = ((ShortTextComponent) cliente.getComponent("stColumnaServicio")).getText();
			stColumnaFecha = ((ShortTextComponent) cliente.getComponent("stColumnaFecha")).getText();
			stColumnaValor = ((ShortTextComponent) cliente.getComponent("stColumnaValor")).getText();
			stColumnaRefPago = ((ShortTextComponent) cliente.getComponent("stColumnaRefPago")).getText();
			stColumnaMedioPago = ((ShortTextComponent) cliente.getComponent("stColumnaMedioPago")).getText();
			stColumnaEstado = ((ShortTextComponent) cliente.getComponent("stColumnaEstado")).getText();
			stColumnaComprobante = ((ShortTextComponent) cliente.getComponent("stColumnaComprobante")).getText();
			stMensajeNoHayResultados = ((ShortTextComponent) cliente.getComponent("stMensajeNoHayResultados")).getText();
			stMensajeFallaComunicacion = ((ShortTextComponent) cliente.getComponent("stMensajeFallaComunicacion")).getText();
			botonVer = ((ShortTextComponent) cliente.getComponent("stBotonVer")).getText();
			rutaComprobante = ((ShortTextComponent) cliente.getComponent("stEnlaceComprobante")).getText();
			cliente.endWorkspace();
		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01,  rContenido.getUserName(), ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: cargarWCM, Resultado Historico Pagos", "cargarWCM", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal());
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, rquid, rContenido.getUserName()).obtenerErrorWCM(rContenido.getPathErroresTecnicos(), ExceptionManager.PP_PORTAL_LIBRERIAS_01);
			ResuladoHistoricoPagosBean consulta = new ResuladoHistoricoPagosBean();
			consulta.setStMensajeFallaComunicacion(error[0]);
		} 
	}		
	
	/***
	 * Carga la lista de resultados invocando los servicios del Mildware de comunicaciones
	 * Este metodo se llama en doView del portlet para cargar los resultados, ya sean los 
	 * por defecto, o tomando los valores que le llegan del formulario de busqueda cuando el 
	 * usuario da click en el boton consultar
	 * @author rafael.gutierrez 
	 */
	public void cargarResultados(String rqFiltroHistoricoPagos, RenderRequest request,ResultadoRutaContenidoBean rContenido,String requestId) {
		String errorCode = "";
		logger.info("cargarResultados");
		ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.resultadohistoricopagos.portlet.nl.ResultadoHistoricoPagosPortletResource");
		logger.info("cargar resultados");
		
		GetPaymentHistoryRs res = null;
		GetPaymentHistoryRq rq = null;
		logger.info("cargar resultados");
		logger.info("cargarResultados");
		try{
			logger.info("rqFiltroHistoricoPagos" + rqFiltroHistoricoPagos);
			logger.info("rqFiltroHistoricoPagos" + rqFiltroHistoricoPagos);
			if(rqFiltroHistoricoPagos !=null ){				
				String aux[] = rqFiltroHistoricoPagos.split("/");
				fechaInicial = aux[0];
				fechaFinal = aux[1];
				idMedioPago = aux[2];
				idEstadoPago = aux[3];
				requestId = aux[4];
			}else{
				logger.info("valores por defecto ");
				valoresPorDefecto();	
				requestId = PublisherUtil.getInstance().generateRequestID();
				logger.info("requestId" + requestId);
				trazaRqConsultaDefecto(requestId,rb,rContenido,fechaInicial,fechaFinal,idMedioPago,idEstadoPago);
			}
						
			//no se selecciona ningun medio de pago
			if("0".equals(idMedioPago)){
				idMedioPago = null;
			}
			
			//no se selecciona ningun estado de pago
			if("00".equals(idEstadoPago)){
				idEstadoPago = null;
			}
			
			rq = new GetPaymentHistoryRq();
			
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy hh:mm:ss");
			Date fechaIn = formatter.parse(fechaInicial.substring(0, 10) +" 00:00:00");
			Date fechaFn = formatter.parse(fechaFinal.substring(0, 10) +" 23:59:59");
			//Date fechadia= formatter.parse(new Date());
			rq.setIpAddress(rContenido.getIpAdress());
			rq.setPaymentMode(idMedioPago);
			rq.setTxIdStatus(idEstadoPago);
			rq.setRequestDate(new Date());
			rq.setRequestSender(rb.getString("auditoria.nombrePortlet"));
			rq.setRequestID(requestId);
			rq.setRequestOriginPortal(rContenido.getOriginPortal());
			rq.setRequestPage(rContenido.getCurrentPage());
			rq.setRequestUser(rContenido.getUserName());
			BankInfoType bank = new BankInfoType();
			bank.setBankId(rContenido.getBankId());
			bank.setBankName(rContenido.getOriginPortal());
			rq.setBankInfo(bank);
			
			rq.setInitialDate(fechaIn);
			rq.setFinalDate(fechaFn);
			rq.setUserName(rContenido.getUserName());			
			//res = ServiceFactory.getInstance().getServiceBean().getPaymentHistory(rq);
			logger.info("[REQUEST - getResultPaymentHistory] DATA: "+new Gson().toJson(rq));
			logger.info("[REQUEST - getResultPaymentHistory] DATA: "+new Gson().toJson(rq));
			String EndPointRESTServicePayCentralBillRequest = ConfigurationService.getInstance().getEndpointRest();

			res = (GetPaymentHistoryRs) WebServiceClientHTTPS.getInstance(GetPaymentHistoryRs.class).procesarRequest(EndPointRESTServicePayCentralBillRequest+"getResultPaymentHistory", rq);			
			
			logger.info("[RESPONSE - getResultPaymentHistory] DATA: "+new Gson().toJson(res));
			logger.info("[RESPONSE - getResultPaymentHistory] DATA: "+new Gson().toJson(res));			
			historicoPagos = new ArrayList<HistoricoPago>();
			
			if (null!=res && null!= res.getExcepcion() && null!= res.getExcepcion().getCodigo()) {
				errorCode = res.getExcepcion().getCodigo();
			}
			logger.info("Succes");
			if(SUCCESS.equals(res.getStatus().getStatusCode())){ //realizo el llamado al integrador exitosamente
				if(res.getTransactions().size() > 0){ //trajo resultados
					for(TransactionDataType data : res.getTransactions()){
						HistoricoPago pago = new HistoricoPago();
						pago.setConvenio(data.getAgreementName());
						pago.setFechaHora(formatearFecha(data.getTransactionDate(), tableDateFormat));
						pago.setValor(data.getAmount());
						pago.setMedioPago(data.getPaymentMode());
						pago.setEstado(data.getTransactionState());
						pago.setIdPago(data.getPaymentId());
						
						//Si la lista tiene referencias
						if(data.getListReferences().size() > 0){
								List<String> refers = new ArrayList<String>();
								
								for (ReferenceType ref : data.getListReferences()) {
									refers.add(ref.getReference().trim());
								}
							
							//Si el convenio tiene configurado pafos con tarjeta de credito
							if(data.isValidarBin()){
								//Metodo donde consulta los parametros para truncar
								getCacheParametros();							
								refers.set(0, TruncarUtil.truncarTarjetaDeCredito(data.getListReferences().get(0).getReference().trim(), truncarIzquierda, truncarCaracter, truncarDerecha)) ;	
							}
							pago.setReferences(refers);
						}
						
						
						historicoPagos.add(pago);
					}
					mensajeerror = "";
				}else{
					mensajeerror = getStMensajeNoHayResultados();
				}
			}else{
				logger.info("getPaymentHistory "+rContenido.getUserName()+". Response CODE: "+res.getStatus().getStatusCode()+", DESC: "+res.getStatus().getStatusDesc());
				mensajeerror = getStMensajeFallaComunicacion();
			}

			cantidadresultados = historicoPagos.size();
			logger.info("cantidadresultados");
		} catch (Exception e) {
			logger.info("cantidadresultados Exception"  + e);
			errorCode = ExceptionManager.PP_PORTAL_GENERIC_01;
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, requestId, ExceptionManager.PP_PORTAL_GENERIC_01, null, ExceptionManager.PP_PORTAL_GENERIC_01+" - Operación: cargarResultados, Resultado Historico Pagos", "cargarResultados", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
			String[] error= ErrorManager.getInstance(request, requestId, null).obtenerErrorWCM(rContenido.getPathErroresTecnicos(), errorCode);
			ResuladoHistoricoPagosBean consulta = new ResuladoHistoricoPagosBean();
			consulta.setStMensajeFallaComunicacion(error[0]);
		}finally{
			trazaConsultarRs(rq,res,errorCode,rb);
		}
				
		
	}	
	
	public void trazaConsultarRs(GetPaymentHistoryRq rq, GetPaymentHistoryRs rs,String errorCode, ResourceBundle rb){
		try {
			//TRAZA
			AuditorRq auditorRq = new AuditorRq();
		
			auditorRq.setRequestId(rq.getRequestID());
			auditorRq.setIpAddress(rq.getIpAddress());
			auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
			auditorRq.setAction(rb.getString("auditoria.accionConsultar"));
			auditorRq.setOriginPortal(rq.getRequestOriginPortal());
			auditorRq.setPage(rq.getRequestPage());
			auditorRq.setPortlet(rq.getRequestSender());
			auditorRq.setUser(rq.getRequestUser());
			auditorRq.setTipoServicio("RS");
			auditorRq.setErrorCode(errorCode);
			auditorRq.setCodigoServicioInt(rs.getCodigoServicio());
			auditorRq.setAdditionalInfo(JSONUtil.getJson("Criterios de busqueda (fechaInicial/fechaFial/medioPago/estadoPago)"+DOSPUNTOS+rq.getInitialDate()+"/"+rq.getFinalDate()+"/"+rq.getPaymentMode()+"/"+rq.getTxIdStatus()+COMA+NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
			
			TrazaPublisher.getInstance().publish(auditorRq);
			//Fin de la traza
		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rq.getRequestID(), ExceptionManager.PP_PORTAL_GENERIC_01,rq.getRequestUser(), ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: trazaConsultarRs, Resultado Historico Pagos", "trazaConsultarRs", rq.getRequestSender(), rq.getRequestPage(), rq.getRequestOriginPortal());
			logger.error(errorData, e);
		}

	}
	
	/***
	 * Asigna a los campos de busqueda los valores por defecto
	 * cuando se ingresa a la pantalla por primera vez antes de presionar el 
	 * boton consultar
	 */
	public void valoresPorDefecto(){
		Calendar calendar = Calendar.getInstance();
		Date hoy = new Date();
        calendar.setTime(hoy);  
		calendar.add(Calendar.DAY_OF_YEAR, -30);
		Date fechAux = calendar.getTime();
		fechaInicial = formatearFecha(fechAux,dateFormat);
		fechaFinal = formatearFecha(hoy,dateFormat);
		idMedioPago = "0";
		idEstadoPago = "00";
	}
	
	/***
	 * Convierte el String en tipo Date
	 * El String debe tener el formato indicado por la variable dateFormat
	 * @param fecha
	 * @return
	 */
	private Date convertStringtoDate(String fecha) throws Exception{
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
		return sdf.parse(fecha);
	}
	
	/***
	 * Devulve la fehca formateada en formato dd-MM-yyyy
	 * @param fecha
	 * @return
	 */
	private String formatearFecha(Date fecha,String format){
		String fechaFormateada = "";
		try{			
			SimpleDateFormat fechaformato = new SimpleDateFormat(format);
			fechaFormateada = fechaformato.format(fecha);
			
		}catch(Exception e){
			return "";
		}
		return fechaFormateada;
	}
	
	/***
	 * Obtiene el valor del archivo de propiedades
	 * @param key clave de la propiedad a leer
	 * @return valor de la propiedad
	 */
	private String getProperty(String key,String defaultValue){
		logger.info("getProperty");
		if(rb == null){
			rb = ResourceBundle.getBundle("com.portalpagos.resultadohistoricopagos.prop.ResuladoHistoricoPagosProp");
		}
		String value = rb.getString(key);
		if(value == null || "".equals(value)){
			return defaultValue;
		}
		return value;
	}

	public String getBotonVer() {
		return botonVer;
	}

	public void setBotonVer(String botonVer) {
		this.botonVer = botonVer;
	}

	public String getRutaComprobante() {
		return rutaComprobante;
	}

	public void setRutaComprobante(String rutaComprobante) {
		this.rutaComprobante = rutaComprobante;
	}

	public String getMensajeerror() {
		return mensajeerror;
	}

	public void setMensajeerror(String mensajeerror) {
		this.mensajeerror = mensajeerror;
	}

	public boolean isRenderMensajeError() {
		return renderMensajeError;
	}

	public void setRenderMensajeError(boolean renderMensajeError) {
		this.renderMensajeError = renderMensajeError;
	}

	public boolean isRenderTable() {
		return renderTable;
	}

	public void setRenderTable(boolean renderTable) {
		this.renderTable = renderTable;
	}

	public String getFechaInicial() {
		return fechaInicial;
	}

	public void setFechaInicial(String fechaInicial) {
		this.fechaInicial = fechaInicial;
	}

	public String getFechaFinal() {
		return fechaFinal;
	}

	public void setFechaFinal(String fechaFinal) {
		this.fechaFinal = fechaFinal;
	}

	public String getIdMedioPago() {
		return idMedioPago;
	}

	public void setIdMedioPago(String idMedioPago) {
		this.idMedioPago = idMedioPago;
	}

	public List<HistoricoPago> getHistoricoPagos() {				
		return historicoPagos;
	}

	public void setHistoricoPagos(List<HistoricoPago> historicoPagos) {		
		this.historicoPagos = historicoPagos;
	}

	public String getStColumnaServicio() {
		return stColumnaServicio;
	}

	public void setStColumnaServicio(String stColumnaServicio) {
		this.stColumnaServicio = stColumnaServicio;
	}

	public String getStColumnaFecha() {
		return stColumnaFecha;
	}

	public void setStColumnaFecha(String stColumnaFecha) {
		this.stColumnaFecha = stColumnaFecha;
	}

	public String getStColumnaValor() {
		return stColumnaValor;
	}

	public void setStColumnaValor(String stColumnaValor) {
		this.stColumnaValor = stColumnaValor;
	}

	public String getStColumnaRefPago() {
		return stColumnaRefPago;
	}

	public void setStColumnaRefPago(String stColumnaRefPago) {
		this.stColumnaRefPago = stColumnaRefPago;
	}

	public String getStColumnaMedioPago() {
		return stColumnaMedioPago;
	}

	public void setStColumnaMedioPago(String stColumnaMedioPago) {
		this.stColumnaMedioPago = stColumnaMedioPago;
	}

	public String getStColumnaEstado() {
		return stColumnaEstado;
	}

	public void setStColumnaEstado(String stColumnaEstado) {
		this.stColumnaEstado = stColumnaEstado;
	}

	public String getStColumnaComprobante() {
		return stColumnaComprobante;
	}

	public void setStColumnaComprobante(String stColumnaComprobante) {
		this.stColumnaComprobante = stColumnaComprobante;
	}

	public int getCantidadresultados() {
		return cantidadresultados;
	}

	public void setCantidadresultados(int cantidadresultados) {
		this.cantidadresultados = cantidadresultados;
	}

	public String getStMensajeNoHayResultados() {
		return stMensajeNoHayResultados;
	}

	public void setStMensajeNoHayResultados(String stMensajeNoHayResultados) {
		this.stMensajeNoHayResultados = stMensajeNoHayResultados;
	}

	public String getStMensajeFallaComunicacion() {
		return stMensajeFallaComunicacion;
	}

	public void setStMensajeFallaComunicacion(String stMensajeFallaComunicacion) {
		this.stMensajeFallaComunicacion = stMensajeFallaComunicacion;
	}
		
	public String getIdEstadoPago() {
		return idEstadoPago;
	}

	public void setIdEstadoPago(String idEstadoPago) {
		this.idEstadoPago = idEstadoPago;
	}

	public void trazaRqConsultaDefecto(String requestId,ResourceBundle rb,ResultadoRutaContenidoBean rContenido,String fInicial, String fFinal, String medioPago, String estadoPago){
		try {
			logger.info("auditoria");
			//TRAZA
			AuditorRq auditorRq = new AuditorRq();
		
			auditorRq.setRequestId(requestId);
			auditorRq.setIpAddress(rContenido.getIpAdress());
			auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
			auditorRq.setAction(rb.getString("auditoria.accionConsultar"));
			auditorRq.setOriginPortal(rContenido.getOriginPortal());
			auditorRq.setPage(rContenido.getCurrentPage());
			auditorRq.setPortlet(rb.getString("auditoria.nombrePortlet"));
			auditorRq.setUser(rContenido.getUserName());
			auditorRq.setTipoServicio("RQ");
			auditorRq.setAdditionalInfo(JSONUtil.getJson("Criterios de busqueda (fechaInicial/fechaFial/medioPago/estadoPago)"+DOSPUNTOS+fInicial+"/"+fFinal+"/"+medioPago+"/"+estadoPago+COMA+NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
			
			TrazaPublisher.getInstance().publish(auditorRq);
			//Fin de la traza
		} catch (Exception e) {
			logger.info("auditoria error " + e);
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, requestId, ExceptionManager.PP_PORTAL_GENERIC_01,rContenido.getUserName(), ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: trazaRqConsultaDefecto, Resultado Historico Pagos", "trazaRqConsultaDefecto", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal());
			logger.error(errorData, e);
		}

	}
	
	/**
	 * HU tokenizacion, Metodo encargado de consultar la cache y obtener los parametros para enmascarar y truncar
	 * @author germandiaz
	 * @param idRequest 
	 * @throws Exception 
	 * @since 27/07/2017
	 * */
	private void getCacheParametros() throws Exception {
		// Cargamos los parametros desde la cache
			List<GetParametroRs> parametros;
		
			parametros = CacheManager.getInstance().obtenerParametros();
			if(null != parametros){
				for(GetParametroRs parametro : parametros){
					if(parametro.getNombre().equals("ATH_CANT_PREVIA_TRUNCADO")){
						truncarDerecha = Integer.parseInt(parametro.getValor());
					}
					else if(parametro.getNombre().equals("ATH_CANT_FINAL_TRUNCADO")){
						truncarIzquierda = Integer.parseInt(parametro.getValor());
					}
					else if(parametro.getNombre().equals("ATH_CARACTER_PREVIO_TRUNCADO")){
						truncarCaracter  = parametro.getValor().charAt(0);
					}
				}
			}
					
	}
}
