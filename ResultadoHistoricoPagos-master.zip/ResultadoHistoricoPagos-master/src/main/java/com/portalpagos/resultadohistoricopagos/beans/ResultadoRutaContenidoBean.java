package com.portalpagos.resultadohistoricopagos.beans;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;


@ManagedBean(name = "ResultadoRutaContenidoBean", eager = true)
@RequestScoped
public class ResultadoRutaContenidoBean implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String pathContentContHistoricoPago;
	
	private String currentPage;
	
	private String originPortal;
	
	private String bankId;
	
	private String userName;
	
	private String ipAdress;
	
	private String portlet;
	
	private String dn;
	
	private String pathErroresTecnicos;

	public String getPortlet() {
		return portlet;
	}

	public void setPortlet(String portlet) {
		this.portlet = portlet;
	}

	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}

	public String getOriginPortal() {
		return originPortal;
	}

	public void setOriginPortal(String originPortal) {
		this.originPortal = originPortal;
	}

	public String getBankId() {
		return bankId;
	}

	public void setBankId(String bankId) {
		this.bankId = bankId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getIpAdress() {
		return ipAdress;
	}

	public void setIpAdress(String ipAdress) {
		this.ipAdress = ipAdress;
	}

	public String getPathContentContHistoricoPago() {
		return pathContentContHistoricoPago;
	}

	public void setPathContentContHistoricoPago(String pathContentContHistoricoPago) {
		this.pathContentContHistoricoPago = pathContentContHistoricoPago;
	}

	public String getDn() {
		return dn;
	}

	public void setDn(String dn) {
		this.dn = dn;
	}

	public String getPathErroresTecnicos() {
		return pathErroresTecnicos;
	}

	public void setPathErroresTecnicos(String pathErroresTecnicos) {
		this.pathErroresTecnicos = pathErroresTecnicos;
	}

}
