package com.portalpagos.resultadohistoricopagos.beans;

import java.io.Serializable;
import java.util.List;

public class HistoricoPago implements Serializable {

	private static final long serialVersionUID = -6808340186159561302L;
	private String convenio;
	private String fechaHora;
	private String valor;
	private String medioPago;
	private String estado;
	private String idPago;
	private List<String> references;
	
	public HistoricoPago(){
		
	}

	public String getIdPago() {
		return idPago;
	}

	public void setIdPago(String idPago) {
		this.idPago = idPago;
	}

	public String getConvenio() {
		return convenio;
	}

	public void setConvenio(String convenio) {
		this.convenio = convenio;
	}

	public String getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(String fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	

	public String getMedioPago() {
		return medioPago;
	}

	public void setMedioPago(String medioPago) {
		this.medioPago = medioPago;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public List<String> getReferences() {
		return references;
	}

	public void setReferences(List<String> references) {
		this.references = references;
	}
	

}
