package com.portalpagos.resultadohistoricopagos.util;

import java.util.Map;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;
import javax.faces.event.ActionListener;
import javax.portlet.ActionResponse;
import javax.portlet.PortletRequest;

import com.ath.portalpagos.util.ExceptionManager;
import com.portalpagos.resultadohistoricopagos.beans.ResultadoRutaContenidoBean;
import com.portalpagos.resultadohistoricopagos.portlet.ResultadoHistoricoPagosPortlet;

import co.com.ath.logger.CustomLogger;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.service.model.ErrorData;

public class VerComprobanteListener implements ActionListener {
	private CustomLogger logger= new CustomLogger(ResultadoHistoricoPagosPortlet.class);

	@Override
	public void processAction(ActionEvent e) throws AbortProcessingException {
		FacesContext context = FacesContext.getCurrentInstance();
		com.ibm.faces20.portlet.httpbridge.PortletResponseWrapper responseWrapper = (com.ibm.faces20.portlet.httpbridge.PortletResponseWrapper) context.getExternalContext().getResponse();
		ActionResponse response = (ActionResponse) responseWrapper.getPortletResponse();
		ExternalContext externalContext = context.getExternalContext();
		PortletRequest portletRequest = (PortletRequest) externalContext.getRequest();
		ResultadoRutaContenidoBean rContenido = (ResultadoRutaContenidoBean) portletRequest.getPortletSession().getAttribute("RutaContenidoBean");
		String rquid = PublisherUtil.getInstance().generateRequestID();
		try {
			Map<String, String> param = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
			String idPago = param.get("idPago");
			response.setEvent("requestEventVerComprobante", idPago);
		} catch (Exception ex) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(ex, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, rContenido.getUserName() , ExceptionManager.MSG_PORTAL_GENERIC_01+" Operacion: processAction, ResultadoHistoricoPagos", "VerComprobanteListener"); 
			logger.error(errorData, ex);
		}
	}
}
