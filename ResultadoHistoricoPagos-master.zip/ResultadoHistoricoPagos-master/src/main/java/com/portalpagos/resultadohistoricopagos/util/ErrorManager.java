/**
 * 
 */
package com.portalpagos.resultadohistoricopagos.util;

import javax.portlet.PortletRequest;

import co.com.ath.logger.CustomLogger;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.service.model.ErrorData;

import com.ath.portalpagos.util.ExceptionManager;
import com.co.pragma.portal.utils.WCMCliente;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.exceptions.WCMException;
import com.portalpagos.resultadohistoricopagos.portlet.ResultadoHistoricoPagosPortlet;
/**
 * HU 157.0.1 Clase que se encarga de consultar el mensaje indicado para el error técnico capturado
 * @author melany.rozo
 * 
 */
public class ErrorManager {


	private CustomLogger logger= new CustomLogger(ResultadoHistoricoPagosPortlet.class);
	
	private static ErrorManager instance;
	private static final String TITULO_ERROR_DEF="ERROR";
	private static final String MSG_ERROR_DEF="Fallas técnicas";
	private static final String CONT_DEFECTO="contErrorDefecto";
	private static final String BASE_CONTENIDO="cont";
	private String ruta = null;
	private static String user;
	private static String rquid;
	

	
	private ErrorManager() {
		super();
	}

	public static ErrorManager getInstance(PortletRequest request, String rq, String usuario) {
		if (null == instance){
			instance = new ErrorManager();
		}

		rquid= rq;
		user= usuario;
		
		return instance;
	}
	
	/**
	 * HU 157.0.1 Función encargada de consultar en WCM el contenido correspondiente al código de error técnico
	 * @param RenderRequest
	 * @param codError - Código de error técnico que identifica la excepción capturada
	 * @exception Busca el contenido de error técnico por defecto en caso de no encontrar el contenido específico
	 * @author melany.rozo
	 * @since 04/09/2015 
	 * */
	
	public String[] obtenerErrorWCM(String ruta, String codError){

		String contenidoError=BASE_CONTENIDO+codError;
		WCMCliente cliente = null;
		String mensaje=MSG_ERROR_DEF, titulo=TITULO_ERROR_DEF;
				
		try{
			cliente=new WCMCliente(ruta+contenidoError);
			mensaje = ((ShortTextComponent) cliente.getComponent("stMensajeError")).getText();
			titulo = ((ShortTextComponent) cliente.getComponent("stTituloError")).getText();
		}catch(WCMException e){
			try {
				cliente=new WCMCliente(ruta+CONT_DEFECTO);
				mensaje = ((ShortTextComponent) cliente.getComponent("stMensajeError")).getText();
				titulo = ((ShortTextComponent) cliente.getComponent("stTituloError")).getText();
			} catch (WCMException e1) {
				ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_WCM_01, user, ExceptionManager.MSG_PORTAL_WCM_01+" - Operación: obtenerErrorWCM", "obtenerErrorWCM"); 
				logger.error(errorData, e);
			}
		}finally{
			if(null!=cliente){
				cliente.endWorkspace();
			}
		}

		String[] rs= new String[2];
		rs[0]=mensaje;
		rs[1]=titulo;
		
		return rs;
	}

}
