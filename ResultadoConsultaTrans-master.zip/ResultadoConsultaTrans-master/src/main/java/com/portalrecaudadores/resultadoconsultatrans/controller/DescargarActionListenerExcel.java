package com.portalrecaudadores.resultadoconsultatrans.controller;

import java.util.Date;
import java.util.ResourceBundle;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ActionEvent;
import javax.faces.event.ActionListener;
import javax.portlet.PortletRequest;

import co.com.ath.logger.CustomLogger;
import co.com.ath.payments.mc.auditor.publisher.traza.TrazaPublisher;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.service.model.AuditorRq;
import co.com.ath.payments.mc.service.model.ErrorData;
import co.com.ath.payments.mc.service.util.CommonUtils;

import com.ath.portalpagos.util.ExceptionManager;
import com.ath.portalpagos.util.IpNodoPortal;
import com.ath.portalpagos.util.JSONUtil;
import com.portalrecaudadores.resultadoconsultatrans.beans.ResultadoConsultaTransBean;
import com.portalrecaudadores.resultadoconsultatrans.beans.RutaContenidoBean;
import com.portalrecaudadores.resultadoconsultatrans.portlet.ResultadoConsultaTransPortlet;

public class DescargarActionListenerExcel implements ActionListener{
	private static final String EXCEL = "EXCEL";
	private static final String PDF = "PDF";

	private static String NODO="Nodo Portal";
	private static String DOSPUNTOS=":";
	
	protected CustomLogger logger = new CustomLogger(ResultadoConsultaTransPortlet.class);
	
	@Override
	public void processAction(ActionEvent event) throws AbortProcessingException {
		
		FacesContext context = FacesContext.getCurrentInstance();
		ExternalContext externalContext = context.getExternalContext();
		PortletRequest portletRequest = (PortletRequest) externalContext.getRequest();
		String baseURL = context.getExternalContext().getRequestContextPath();
		String url = null;
		
		//Se genera RQUID para acción de descarga de archivo consulta transacciones
		String rquid = PublisherUtil.getInstance().generateRequestID();
		portletRequest.getPortletSession().setAttribute("rquid", rquid);
		
		ResultadoConsultaTransBean bean = (ResultadoConsultaTransBean) portletRequest.getPortletSession().getAttribute("resultadoConsultaTransBean");

		RutaContenidoBean rContenido= (RutaContenidoBean) portletRequest.getPortletSession().getAttribute("RutaContenidoBean");
		
		trazaRqDescargaArchivo(rquid, bean, rContenido);
		
		try {	
			String tipoArchivo = bean.getOpcionSelect();

			if(null!=tipoArchivo){
				if(EXCEL.equalsIgnoreCase(tipoArchivo)){
					url = baseURL + "/EXCELServlet";
				} else if (PDF.equalsIgnoreCase(tipoArchivo)) {
					url = baseURL + "/PDFServlet";
				} else {
					url = baseURL + "/TXTServlet";
				}
			}
			context.getExternalContext().redirect(url);

		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, null, ExceptionManager.PP_PORTAL_GENERIC_01+" - Operación: downloadFile, ZIPServlet Resultado consulta transacciones", "downloadFile", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
		} finally {
			context.renderResponse();
		}
		
	}


	/**
	 * Función encargada de trazar RQ de la acción de descargar archivo
	 * @author melany.rozo
	 * @since 25/02/2016
	 * */
	public void trazaRqDescargaArchivo(String requestId,  ResultadoConsultaTransBean bean, RutaContenidoBean rContenido){
		try {			
			//Llamado a Properties para consultar el nombre del portlet
			ResourceBundle rb = ResourceBundle.getBundle("com.portalrecaudadores.resultadoconsultatrans.portlet.nl.ResultadoConsultaTransPortletResource");
			
			//TRAZA
			AuditorRq auditorRq = new AuditorRq();

			auditorRq.setRequestId(requestId);
			auditorRq.setIpAddress(rContenido.getIpAdress());
			auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
			auditorRq.setAction(rb.getString("auditoria.descargarArchivoConsulta"));
			auditorRq.setOriginPortal(rContenido.getOriginPortal());
			auditorRq.setPage(rContenido.getCurrentPage());
			auditorRq.setPortlet(rContenido.getPortlet());
			auditorRq.setUser(rContenido.getUserName());
			auditorRq.setTipoServicio("RQ");
			auditorRq.setAdditionalInfo(JSONUtil.getJson(NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(),
					"Formato archivo" + DOSPUNTOS + ("".equals(bean.getOpcionSelect())?null:bean.getOpcionSelect()), 
					"Fecha Inicial"+ DOSPUNTOS + bean.getFechaInicial(), 
					"Fecha Final" + DOSPUNTOS + bean.getFechaFinal(), 
					"Estado Transacción" + DOSPUNTOS +("".equals(bean.getEstado())?null:bean.getEstado()), 
					"Medio Pago" + DOSPUNTOS + ("".equals(bean.getMedioPago())?null:bean.getMedioPago()), 
					"Cus" + DOSPUNTOS + ("".equals(bean.getCus())?null:bean.getCus()) , 
					"Numero Id Transaccion" + DOSPUNTOS + ("".equals(bean.getIdTransaccion())?null:bean.getIdTransaccion()), 
					"Referencia Pago" + DOSPUNTOS + ("".equals(bean.getReferenciaPago() )?null:bean.getReferenciaPago() ), 
					"Primera Referencia Adicional" + DOSPUNTOS + ("".equals(bean.getPrimeraReferenciaAd())?null:bean.getPrimeraReferenciaAd()), 
					"Segunda Referencia Adicional" + DOSPUNTOS + ("".equals(bean.getSegundaReferenciaAd())?null:bean.getSegundaReferenciaAd()), 
					"Tercera Referencia Adicional" + DOSPUNTOS + ("".equals(bean.getTerceraReferenciaAd())?null:bean.getTerceraReferenciaAd()), 
					"Valor pagar" + DOSPUNTOS + ("".equals(bean.getValorPago())?null:bean.getValorPago())));
			
			TrazaPublisher.getInstance().publish(auditorRq);
			//Fin de la traza
		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, requestId, ExceptionManager.PP_PORTAL_GENERIC_01,rContenido.getUserName(), ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: trazaRqDescargaArchivo, Resultado consulta transacciones", "trazaRqDescargaArchivo", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal());
			logger.error(errorData, e);
		}
	}
}
