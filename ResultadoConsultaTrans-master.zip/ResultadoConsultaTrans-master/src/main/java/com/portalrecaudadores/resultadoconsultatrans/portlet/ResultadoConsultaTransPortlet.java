package com.portalrecaudadores.resultadoconsultatrans.portlet;

import java.io.IOException;
import java.util.ResourceBundle;

import javax.faces.FacesException;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.naming.NamingException;
import javax.portlet.Event;
import javax.portlet.EventRequest;
import javax.portlet.EventResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletRequest;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.exception.ExceptionUtils;

import co.com.ath.logger.CustomLogger;
import co.com.ath.parameterspage.ParametersPage;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.service.model.ErrorData;
import co.com.ath.utilparamspage.util.GetPostfixDN;

import com.ath.portalpagos.util.ExceptionManager;
import com.ath.portalpagos.util.Modal;
import com.ibm.portal.portlet.service.PortletServiceUnavailableException;
import com.ibm.portal.um.User;
import com.ibm.portal.um.exceptions.PumaException;
import com.portalrecaudadores.resultadoconsultatrans.beans.ResultadoConsultaTransBean;
import com.portalrecaudadores.resultadoconsultatrans.beans.RutaContenidoBean;
import com.portalrecaudadores.resultadoconsultatrans.util.ErrorManager;
import com.portalrecaudadores.resultadoconsultatrans.util.ObtenerContenido;
import com.portalrecaudadores.resultadoconsultatrans.util.Puma;

public class ResultadoConsultaTransPortlet extends	com.ibm.faces20.portlet.FacesPortlet {

	protected CustomLogger logger = new CustomLogger(ResultadoConsultaTransPortlet.class);

	private static String rquid;
	private static String user;
	
	public void init() throws PortletException {
		super.init();
	}

	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		GetPostfixDN.getParamsPagePortal(request, response);
		RutaContenidoBean rContenido= null;
		try{
			rContenido = this.consultarDatosIniciales(request, response);
			ObtenerContenido.getInstance().cargarWCM(request, response, rquid, rContenido);
			ResultadoConsultaTransBean bean = (ResultadoConsultaTransBean) request.getPortletSession().getAttribute("resultadoConsultaTransBean");
			if (bean != null) {
				String rqFilters = request.getParameter("rqFiltroResulTrans");
				rqFilters = (String) request.getPortletSession().getAttribute("rqFiltroResulTrans");
				String event=(String) request.getPortletSession().getAttribute("evento");
				String isConsulta = (String) request.getPortletSession().getAttribute("isConsultado");
				
				
				if (rqFilters != null && !"".equalsIgnoreCase(rqFilters) && isConsulta != null && !"".equalsIgnoreCase(isConsulta)){
					bean.cargarResultados(rqFilters, request, response);
					
					String conteMsForm = "false";
					String titulo=bean.getTituloError();
					bean.setMostrarLighbox("true");
					String valorErrForm = (String) request.getPortletSession().getAttribute("msjFormularios");
					
					bean.setTipoModal("icon-error");
	
					if (valorErrForm != null) {
						request.getPortletSession().removeAttribute("msjFormularios");
						request.getPortletSession().removeAttribute("isConsultado");
						if (valorErrForm.equals("ErrorCom")) {
							
							String[] error= ErrorManager.getInstance(request, rquid, null).obtenerErrorWCM(ExceptionManager.PP_PORTAL_GENERIC_01);
							conteMsForm = error[0];
							titulo= error[1];
						} if (valorErrForm.equals("NoDatos")) {
//							request.getPortletSession().removeAttribute("isConsultado");
							conteMsForm = bean.getMensajeNoResultados();
						} 
						else {
							if (valorErrForm.equals("MaxResul")) {
								//bean.setCapturaMensajeErrorForm("Descargar");
								bean.setMostrarModalDescarga(true);
							} else if (valorErrForm.equals("Exito")) {
//								request.getPortletSession().removeAttribute("msjFormularios");
							}
						}
						
					}
	
					if (conteMsForm == "false") {
						bean.setMostrarLighbox("false");
					}
	
					bean.setTituloLighbox(titulo);
					bean.setCuerpoLighbox(conteMsForm);
					String categoriaArray[] = Modal.calcularDimensionModal(bean.getCuerpoLighbox());
					bean.setWidhtLightbox(categoriaArray[0]);
					bean.setHeightLightbox(categoriaArray[1]);
					
				}
			}
			super.doView(request, response);
		} catch (NoClassDefFoundError e){
			Exception e1=(Exception) ExceptionUtils.getRootCause(e);
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e1, rquid, ExceptionManager.PP_PORTAL_LIBRERIAS_01, user, ExceptionManager.MSG_PORTAL_LIBRERIAS_01+" - Operación: Cargar vista, Resultado consulta transacciones", "doView", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e1);
		} catch(Exception e){
			try {
				throw ExceptionUtils.getRootCause(e);
			} catch(FacesException e1){
				ErrorData errorData= PublisherUtil.getInstance().getErrorData(e1, rquid, ExceptionManager.PP_PORTAL_FACES_01, user, ExceptionManager.MSG_PORTAL_FACES_01+" - Operación: Cargar vista, Resultado consulta transacciones", "doView", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
				logger.error(errorData, e1);
			} catch (Throwable e1) {
				ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: Cargar vista, Resultado consulta transacciones", "doView", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal());
				logger.error(errorData, e);
			}
		} finally {
			request.getPortletSession().removeAttribute("evento");
		}
	}

	public void processEvent(EventRequest eventRequest, EventResponse eventResponse) throws PortletException {
		RutaContenidoBean rContenido = (RutaContenidoBean)eventRequest.getPortletSession().getAttribute("RutaContenidoBean");
		
		
		try{
			Event sampleEvent = eventRequest.getEvent();
			if (sampleEvent.getName().toString().equals("rqFiltroResulTrans")) {
				String rqFiltroConsultaTrans = sampleEvent.getValue().toString();
				if(null!=rqFiltroConsultaTrans){
					String rq[]=rqFiltroConsultaTrans.split("&");
					String rquest= rq[0];
					eventResponse.setRenderParameter("rqFiltroResulTrans", rquest);
					eventRequest.getPortletSession().setAttribute("rqFiltroResulTrans", rquest);
					eventRequest.getPortletSession().setAttribute("isConsultado", "true");
					eventRequest.getPortletSession().setAttribute("evento", "true");
					//Se obtiene RQUID que viene del portlet de consulta de transacciones
					rquid=rq[1];
				}
			}
		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: processEvent, Resultado consulta transacciones", "processEvent", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
		}
	}
	
	/**
	 * Método encargado de obtener los datos básicos necesarios para traza, auditoría y logs
	 * @author melany.rozo
	 * @return 
	 * @since 25/02/2016
	 * */
	public RutaContenidoBean consultarDatosIniciales(RenderRequest request, RenderResponse response){

		RutaContenidoBean rContenido = new RutaContenidoBean();
		try {
			   //Se consulta el usuario autenticado y se guarda en sesi�n
				Puma puma = new Puma();
				User currentUser=puma.getCurrenUser(request);
				String codConvenio="";
				if(null != currentUser){
					user=puma.getPropertyFromPuma("uid", request);
					codConvenio=puma.getPropertyFromPuma("ath-codigoconvenio", request);
				}
			
				//Se obtiene ip del usuario y se guarda en sesi�n
				String ip=getIpAddr(com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(request));
			
				// Consulta de parámetos de p�gina y preferencias
				String bankName = (String) ParametersPage.getParameterPage(request, response, "bankName");
				if (null == bankName) {
					bankName = request.getPreferences().getValue("bankName", "");
				}

				String paginaOrigen = (String) ParametersPage.getParameterPage(request, response, "pagina-origen");
				if(null==paginaOrigen){
					paginaOrigen = request.getPreferences().getValue("pagina-origen", "");	
				}
								
				ResourceBundle rb = ResourceBundle.getBundle("com.portalrecaudadores.resultadoconsultatrans.portlet.nl.ResultadoConsultaTransPortletResource");
				
				rContenido.setCurrentPage(paginaOrigen);
				rContenido.setOriginPortal(bankName);
				rContenido.setPortlet(rb.getString("auditoria.nombrePortlet"));
				rContenido.setIpAdress(ip);
				rContenido.setUserName(user);
				rContenido.setCodConvenio(codConvenio);
				
				request.getPortletSession().setAttribute("RutaContenidoBean", rContenido);
				
		} catch (PortletServiceUnavailableException e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_PUMA_01, user, ExceptionManager.MSG_PORTAL_PUMA_01+" - Operaci�n: consultarDatosIniciales, Resultado consulta transacciones", "consultarDatosIniciales", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
		} catch (NamingException e) { 
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_PUMA_01, user, ExceptionManager.MSG_PORTAL_PUMA_01+" - Operaci�n: consultarDatosIniciales, Resultado consulta transacciones", "consultarDatosIniciales", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
		} catch (PumaException e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_PUMA_01, user, ExceptionManager.MSG_PORTAL_PUMA_01+" - Operaci�n: consultarDatosIniciales, Resultado consulta transacciones", "consultarDatosIniciales", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operaci�n: consultarDatosIniciales, Resultado consulta transacciones", "consultarDatosIniciales", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
		}
		return rContenido;
	}
	
	/**
	 * HU 205 Funcion encargada de obtener la ip del usuario, dado un request
	 * @author melany.rozo
	 * @since 25/02/2016
	 */
	public String getIpAddr(HttpServletRequest request) {

		String ip=null;
		
		try{
			final String WL_PROXY_CLIENT_IP = "WL-Proxy-Client-IP";
			final String PROXY_CLIENT_IP = "Proxy-Client-IP";
			final String X_FORWARDER_FOR = "X-Forwarded-For";
			final String HTTP_X_FORWARDED_FOR = "HTTP_X_FORWARDED_FOR";
			final String HTTP_CLIENT_IP = "HTTP_CLIENT_IP";
	
			ip = request.getHeader(X_FORWARDER_FOR);
	
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader(WL_PROXY_CLIENT_IP);
			}
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader(PROXY_CLIENT_IP);
			}
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader(HTTP_X_FORWARDED_FOR);
			}
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getHeader(HTTP_CLIENT_IP);
			}
			if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
				ip = request.getRemoteAddr();
			}
	
		} catch (Exception e){
			FacesContext context = FacesContext.getCurrentInstance();
			ExternalContext externalContext = context.getExternalContext();
			PortletRequest requestContenido = (PortletRequest) externalContext.getRequest();
			RutaContenidoBean rContenido = (RutaContenidoBean) requestContenido.getPortletSession().getAttribute("RutaContenidoBean");
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user, ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: getIpAddr, Resultado consulta transacciones", "getIpAddr", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
		}

		return ip;
	}
}