package com.portalrecaudadores.resultadoconsultatrans.beans;

import java.util.List;

import co.com.ath.payments.mc.service.model.json.ReferenceType;

public class Transaction {
	
	private String idTransaccion;
	private String fechaHora;
	private String valTransaccion;
	private String estado;
	private String numAutorizacion;
	private String medioPago;
	private String refPago;
	private String correoElectronico;
	private String nombre;
	private String ip;
	private String valorPago;
	private String cicloACH;
	private String bancoAutorizador;
	private List<ReferenceType> listaReferenciasCapt;
	private String convenioName;
	private String observaciones;
	private String concepto;
	
	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}

	public String getConvenioName() {
		return convenioName;
	}

	public void setConvenioName(String convenioName) {
		this.convenioName = convenioName;
	}

	public String getBancoAutorizador() {
		return bancoAutorizador;
	}

	public void setBancoAutorizador(String bancoAutorizador) {
		this.bancoAutorizador = bancoAutorizador;
	}
	
	public String getCicloACH() {
		return cicloACH;
	}

	public void setCicloACH(String cicloACH) {
		this.cicloACH = cicloACH;
	}

	public String getValorPago() {
		return valorPago;
	}

	public void setValorPago(String valorPago) {
		this.valorPago = valorPago;
	}

	public Transaction(){
		
	}

	public String getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(String idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public String getFechaHora() {
		return fechaHora;
	}

	public void setFechaHora(String fechaHora) {
		this.fechaHora = fechaHora;
	}

	public String getValTransaccion() {
		return valTransaccion;
	}

	public void setValTransaccion(String valTransaccion) {
		this.valTransaccion = valTransaccion;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getNumAutorizacion() {
		return numAutorizacion;
	}

	public void setNumAutorizacion(String numAutorizacion) {
		this.numAutorizacion = numAutorizacion;
	}

	public String getMedioPago() {
		return medioPago;
	}

	public void setMedioPago(String medioPago) {
		this.medioPago = medioPago;
	}

	public String getRefPago() {
		return refPago;
	}

	public void setRefPago(String refPago) {
		this.refPago = refPago;
	}

	public String getCorreoElectronico() {
		return correoElectronico;
	}

	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public List<ReferenceType> getListaReferenciasCapt() {
		return listaReferenciasCapt;
	}

	public void setListaReferenciasCapt(List<ReferenceType> listaReferenciasCapt) {
		this.listaReferenciasCapt = listaReferenciasCapt;
	}
}
