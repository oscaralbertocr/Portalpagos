package com.portalrecaudadores.resultadoconsultatrans.beans;

public class Consolidado {
	
	private String medioPago;
	private String numTransaccionesAprobadas;
	private String numTransaccionesFallidas;
	private String valorTransaccionesAprobadas;
	private String valorTransaccionesFallidas;
	
	
	public Consolidado(){
		this.numTransaccionesAprobadas = "0";
		this.numTransaccionesFallidas = "0";
		this.valorTransaccionesAprobadas = "0";
		this.valorTransaccionesFallidas = "0";
	}

	public String getMedioPago() {
		return medioPago;
	}

	public void setMedioPago(String medioPago) {
		this.medioPago = medioPago;
	}

	public String getNumTransaccionesAprobadas() {
		return numTransaccionesAprobadas;
	}

	public void setNumTransaccionesAprobadas(String numTransaccionesAprobadas) {
		this.numTransaccionesAprobadas = numTransaccionesAprobadas;
	}

	public String getNumTransaccionesFallidas() {
		return numTransaccionesFallidas;
	}

	public void setNumTransaccionesFallidas(String numTransaccionesFallidas) {
		this.numTransaccionesFallidas = numTransaccionesFallidas;
	}

	public String getValorTransaccionesAprobadas() {
		return valorTransaccionesAprobadas;
	}

	public void setValorTransaccionesAprobadas(
			String valorTransaccionesAprobadas) {
		this.valorTransaccionesAprobadas = valorTransaccionesAprobadas;
	}

	public String getValorTransaccionesFallidas() {
		return valorTransaccionesFallidas;
	}

	public void setValorTransaccionesFallidas(String valorTransaccionesFallidas) {
		this.valorTransaccionesFallidas = valorTransaccionesFallidas;
	}

}
