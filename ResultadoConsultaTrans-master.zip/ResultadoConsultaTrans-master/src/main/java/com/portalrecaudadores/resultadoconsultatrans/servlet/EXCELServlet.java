package com.portalrecaudadores.resultadoconsultatrans.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.ResourceBundle;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.datatype.XMLGregorianCalendar;

import co.com.ath.logger.CustomLogger;
import co.com.ath.payments.mc.auditor.publisher.traza.TrazaPublisher;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.auditor.publisher.util.WebServiceClientHTTPS;
import co.com.ath.payments.mc.service.model.AuditorRq;
import co.com.ath.payments.mc.service.model.json.BankInfoType;
import co.com.ath.payments.mc.service.model.DownloadPaymentsReportRs;
import co.com.ath.payments.mc.service.model.ErrorData;
import co.com.ath.payments.mc.service.model.json.SearchPaymentHistoryFactRq;
import co.com.ath.payments.mc.service.model.json.SearchPaymentHistoryFactRs;
import co.com.ath.payments.mc.service.util.CommonUtils;
import co.com.ath.recaudadores.payments.mc.service.util.ConfigurationService;

import com.ath.portalpagos.util.ExceptionManager;
import com.ath.portalpagos.util.IpNodoPortal;
import com.ath.portalpagos.util.JSONUtil;
import com.google.gson.Gson;
import com.portalrecaudadores.resultadoconsultatrans.beans.ResultadoConsultaTransBean;
import com.portalrecaudadores.resultadoconsultatrans.beans.RutaContenidoBean;
import com.portalrecaudadores.resultadoconsultatrans.portlet.ResultadoConsultaTransPortlet;
import com.portalrecaudadores.resultadoconsultatrans.util.ServiceFactory;

/**
 * Servlet implementation class EXCELServlet
 */

public class EXCELServlet extends HttpServlet implements javax.servlet.Servlet{
	private static final long serialVersionUID = 1L;

	private CustomLogger logger= new CustomLogger(ResultadoConsultaTransPortlet.class);

	private static String NODO_WL="Nodo WebLogic";
	private static String NODO="Nodo Portal";
	private static String DOSPUNTOS=":";
	
	
	protected static String NOMBREPDF = "Informe de transacciones Portal de pagos";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EXCELServlet() {

        super();
 
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		downloadFile(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		downloadFile(request, response);
	}
	
	private void downloadFile(HttpServletRequest request, HttpServletResponse response) {

		String rquid= "";
		String errorCode="";
		RutaContenidoBean rContenido = null;
		SearchPaymentHistoryFactRs responseExcel = new SearchPaymentHistoryFactRs(); 
				
		try {
			ResultadoConsultaTransBean resultadoConsultaTransBean = null;
			String txtNombrePDF = "";
			Enumeration attributes = request.getSession().getAttributeNames();
			while (attributes.hasMoreElements()) {
				String attributeNames = (String) attributes.nextElement();
				if (attributeNames.contains("resultadoConsultaTransBean")) {
					resultadoConsultaTransBean = (ResultadoConsultaTransBean) request.getSession().getAttribute(attributeNames);
				}else if (attributeNames.contains("RutaContenidoBean")) {
					rContenido = (RutaContenidoBean) request.getSession().getAttribute(attributeNames);
				}else if (attributeNames.contains("rquid")) {
					rquid = (String) request.getSession().getAttribute(attributeNames);
				}
			}
			
			SearchPaymentHistoryFactRq rq = new SearchPaymentHistoryFactRq();
			rq = getexcelRequest(resultadoConsultaTransBean, rquid, rContenido);
			
			
			
			
			
			
			
			//responseExcel = (ServiceFactory.getInstance().getServiceBean()).getPaymentHistoryFact(rq);
			
String EndPointRESTServiceGetPaymentHistoryFact = ConfigurationService.getInstance().getEndpointRest();
			
			System.out.println("[REQUEST - getPaymentHistoryFact] DATA: "+new Gson().toJson(rq));
			
			
			 responseExcel = (SearchPaymentHistoryFactRs) WebServiceClientHTTPS.getInstance(SearchPaymentHistoryFactRs.class).procesarRequest(
					EndPointRESTServiceGetPaymentHistoryFact + "getPaymentHistoryFact", rq);
			
			
			
			System.out.println("[RESPONSE - getPaymentHistoryFact] DATA: "+new Gson().toJson(responseExcel));
			
			
			
			if (null!=responseExcel && null!= responseExcel.getExcepcion() && null!= responseExcel.getExcepcion().getCodigo()) {
				errorCode = responseExcel.getExcepcion().getCodigo();
			}
			
			
			if("SUCCESS".equals(responseExcel.getStatus().getStatusCode())){
				txtNombrePDF = NOMBREPDF;		
				response.setContentType("application/vnd.ms-excel");
				response.setHeader("Set-Cookie", "fileDownload=true; path=/");
				response.setHeader("Content-disposition", "attachment; filename="+NOMBREPDF+".xls");
				ServletOutputStream servletStream;
				servletStream = response.getOutputStream();
				servletStream.write(responseExcel.getFile());
				servletStream.flush();
				servletStream.close();
			} else {
				txtNombrePDF = NOMBREPDF;
				response.setContentType("application/vnd.ms-excel");
				response.setHeader("Set-Cookie", "fileDownload=true; path=/");
				response.setHeader("Content-disposition", "attachment; filename=" + txtNombrePDF + ".xls");
				ServletOutputStream servletStream;
				servletStream = response.getOutputStream();
				logger.info("bean"+resultadoConsultaTransBean);
				servletStream.write(resultadoConsultaTransBean.getArchivo());
				servletStream.flush();
				servletStream.close();
			}

		}  catch (IOException e) {
			errorCode=ExceptionManager.PP_PORTAL_GENERIC_01;
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, null, ExceptionManager.PP_PORTAL_GENERIC_01+" - Operación: downloadFile, EXCELServlet Resultado consulta transacciones", "downloadFile", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
		} catch (Exception e) {
			errorCode=ExceptionManager.PP_PORTAL_GENERIC_01;
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, null, ExceptionManager.PP_PORTAL_GENERIC_01+" - Operación: downloadFile, EXCELServlet Resultado consulta transacciones", "downloadFile", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
		} finally {
			trazaRsDescargaArchivo(rquid, rContenido, errorCode, responseExcel);
		}
	}
	
	private SearchPaymentHistoryFactRq getexcelRequest(ResultadoConsultaTransBean resultadoConsultaTransBean, String rquid, RutaContenidoBean rContenido){
		SearchPaymentHistoryFactRq rq = new SearchPaymentHistoryFactRq();
		try {
			rq.setRequestID(rquid);
			rq.setRequestDate(new Date());
			rq.setRequestSender(rContenido.getPortlet());
			rq.setIpAddress(rContenido.getIpAdress());
			rq.setRequestOriginPortal(rContenido.getOriginPortal());
			rq.setRequestPage(rContenido.getCurrentPage());
			rq.setRequestUser(rContenido.getUserName());
			BankInfoType infoBanco = new BankInfoType();
			infoBanco.setBankName(rContenido.getOriginPortal());
			rq.setBankInfo(infoBanco);
	
			XMLGregorianCalendar xgcIni = CommonUtils.getInstance().asXMLGregorianCalendar(convertStringtoDate(resultadoConsultaTransBean.getFechaInicial(), rquid, rContenido));
			XMLGregorianCalendar xgcFin = CommonUtils.getInstance().asXMLGregorianCalendar(convertStringtoDate(resultadoConsultaTransBean.getFechaFinal(), rquid, rContenido));
			
			rq.setInitialDate(convertStringtoDate(resultadoConsultaTransBean.getFechaInicial(), rquid, rContenido));
			rq.setFinalDate(convertStringtoDate(resultadoConsultaTransBean.getFechaFinal(), rquid, rContenido));
			rq.setTransactionStatus(resultadoConsultaTransBean.getEstado());
			rq.setPaymentMode(resultadoConsultaTransBean.getMedioPago());
			rq.setCus(resultadoConsultaTransBean.getCus());
			rq.setAgreementId(resultadoConsultaTransBean.getCodConvenio());
			rq.setTransactionID(resultadoConsultaTransBean.getIdTransaccion());
			rq.setListaReferences(resultadoConsultaTransBean.getListaReferenciasCapt());
			rq.setValorPago(resultadoConsultaTransBean.getValorPago());
			rq.setTypeDownload(resultadoConsultaTransBean.getOpcionSelect());
			rq.setOrderBy(null);
			rq.setOrderType(null);
			rq.setDownload(true);
			rq.setEnmascararReferencia(resultadoConsultaTransBean.isEnmascararRef());
		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, null, ExceptionManager.PP_PORTAL_GENERIC_01+" - Operación: getexcelRequest, EXCELServlet Resultado consulta transacciones", "getexcelRequest", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
		}
		
		return rq;
	}

	/***
	 * Convierte el String en tipo Date El String debe tener el formato indicado
	 * por la variable dateFormat
	 * 
	 * @param fecha
	 * @return
	 */
	private Date convertStringtoDate(String fecha, String rquid, RutaContenidoBean rContenido) {
		try{
			String dateFormat = "dd-MM-yyyy - HH:mm";
			SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
			return sdf.parse(fecha);
		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, null, ExceptionManager.PP_PORTAL_GENERIC_01+" - Operación: convertStringtoDate, EXCELServlet Resultado consulta transacciones", "convertStringtoDate", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
			return null;
		}
	}
	
	
	/**
	 * Función encargada de trazar RS de la acción de descargar archivo
	 * @author melany.rozo
	 * @since 25/02/2016
	 * */
	public void trazaRsDescargaArchivo(String requestId, RutaContenidoBean rContenido, String errorCode, SearchPaymentHistoryFactRs rs){
		try {			
			//Llamado a Properties para consultar el nombre del portlet
			ResourceBundle rb = ResourceBundle.getBundle("com.portalrecaudadores.resultadoconsultatrans.portlet.nl.ResultadoConsultaTransPortletResource");
			
			//TRAZA
			AuditorRq auditorRq = new AuditorRq();
	
			auditorRq.setRequestId(requestId);
			auditorRq.setIpAddress(rContenido.getIpAdress());
			auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
			auditorRq.setAction(rb.getString("auditoria.descargarArchivoConsulta"));
			auditorRq.setOriginPortal(rContenido.getOriginPortal());
			auditorRq.setPage(rContenido.getCurrentPage());
			auditorRq.setPortlet(rContenido.getPortlet());
			auditorRq.setUser(rContenido.getUserName());
			auditorRq.setTipoServicio("RS");
			auditorRq.setAdditionalInfo(JSONUtil.getJson(NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(), NODO_WL+DOSPUNTOS+rs.getIpIntegracion()));
			auditorRq.setErrorCode(errorCode);
			
			TrazaPublisher.getInstance().publish(auditorRq);
			//Fin de la traza
		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, requestId, ExceptionManager.PP_PORTAL_GENERIC_01,rContenido.getUserName(), ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: trazaRqDescargaArchivo, Reporte Pagos", "trazaRqDescargaArchivo", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal());
			logger.error(errorData, e);
		}
	}
}
