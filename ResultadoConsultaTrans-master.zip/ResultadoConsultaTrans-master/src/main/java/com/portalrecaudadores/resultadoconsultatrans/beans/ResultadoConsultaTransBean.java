package com.portalrecaudadores.resultadoconsultatrans.beans;

import java.io.Serializable;
import java.lang.reflect.Type;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.AjaxBehaviorEvent;
import javax.naming.NamingException;
import javax.portlet.PortletRequest;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import co.com.ath.logger.CustomLogger;
import co.com.ath.mc.utilities.util.CloneUtil;
import co.com.ath.mc.utilities.util.EnmascararUtil;
import co.com.ath.mc.utilities.util.TruncarUtil;
import co.com.ath.payments.mc.auditor.publisher.traza.TrazaPublisher;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.auditor.publisher.util.WebServiceClientHTTPS;
import co.com.ath.payments.mc.cache.manager.CacheManager;
import co.com.ath.payments.mc.service.model.AuditorRq;
import co.com.ath.payments.mc.service.model.ErrorData;
import co.com.ath.payments.mc.service.model.json.ConsolidatedFactType;
import co.com.ath.payments.mc.service.model.json.GetConvenioInfoRq;
import co.com.ath.payments.mc.service.model.json.GetConvenioInfoRs;
import co.com.ath.payments.mc.service.model.json.GetParametroRs;
import co.com.ath.payments.mc.service.model.json.ParamFilesType;
import co.com.ath.payments.mc.service.model.json.ReferenceAgreementType;
import co.com.ath.payments.mc.service.model.json.ReferenceType;
import co.com.ath.payments.mc.service.model.json.SearchPaymentHistoryFactRq;
import co.com.ath.payments.mc.service.model.json.SearchPaymentHistoryFactRs;
import co.com.ath.payments.mc.service.model.json.TransactionFactType;
import co.com.ath.payments.mc.service.util.CommonUtils;
import co.com.ath.recaudadores.payments.mc.service.util.ConfigurationService;

import com.ath.portalpagos.util.ExceptionManager;
import com.ath.portalpagos.util.IpNodoPortal;
import com.ath.portalpagos.util.JSONUtil;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.ibm.faces20.portlet.httpbridge.PortletRequestWrapper;
import com.ibm.portal.portlet.service.PortletServiceUnavailableException;
import com.portalrecaudadores.resultadoconsultatrans.portlet.ResultadoConsultaTransPortlet;
import com.portalrecaudadores.resultadoconsultatrans.util.Puma;

/***
 * ManagedBean para mostrar la tabla de resultados de consulta de transacciones
 * 
 * @author john.perez
 * 
 */
@ManagedBean(name = "resultadoConsultaTransBean", eager = true)
@SessionScoped
public class ResultadoConsultaTransBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private final static String SUCCESS = "SUCCESS";
	
	protected CustomLogger logger = new CustomLogger(ResultadoConsultaTransPortlet.class);
	
	private final String dateFormat = "dd-MM-yyyy - HH:mm";
	private String rqFiltros;
	private int maximoTransacciones;
	private byte[] archivo;
	// atributo del TDS con el nombre del usuario
	private String usernameAttr;
	private String tableDateFormat;
	private String codConvenioAttr;
	// Variables donde se guarda el contenido traido del WCM
	private String labelResumen;
	private String labelMedioPago;
	private String labelNumTransacciones;
	private String labelValorTransacciones;
	private String labelPagosAval;
	private String labelPSE;
	private String labelTC;
	private String labelFechaHora;
	private String labelValortransaccion;
	private String labelEstado;
	private String labelNumAutorizacion;
	private String labelMedioPagoMin;
	private String labelRefPago;
	private String labelCorreoElectronico;
	private String labelNombre;
	private String labelIP;
	private String botonDescargar;
	private String tituloError;
	private String mensajeError;
	private String tituloModalDescarga;
	private String mensajeModalDescarga;
	private String botonCancelar;
	private String labelIdTransaccion;
	private String mensajeNoResultados;
	private String mensajePieTablaConsolidado;
	private int paginaActual = 1;
	private String opcionSelect;
	private Boolean mostrarModalDescarga;
	private String labelCicloACH;
	private String labelBancoAutorizado;
	/*HU 72.15 VG 09/12/2016 INI SP38*/
	private String labelRefPago1;
	private String labelRefPago2;
	private String labelRefPago3;
	
	private boolean showRefPago1;
	private boolean showRefPago2;
	private boolean showRefPago3;
	/*HU 72.15 VG 09/12/2016 FIN*/

	// Variables para Modal
	private String mostrarLighbox;
	private String tituloLighbox;
	private String cuerpoLighbox;
	private String widhtLightbox;
	private String heightLightbox;
	private String tipoModal;
	private String capturaMensajeErrorForm;

	// Variables para los valores que vienen del evento del portlet de filtro
	// para la consulta de resultados
	private String fechaInicial;
	private String fechaFinal;
	private String estado;
	private String medioPago;
	private String cus;
	private String idTransaccion;
	private String referenciaPago;
	private String primeraReferenciaAd;
	private String segundaReferenciaAd;
	private String terceraReferenciaAd;
	private String valorPago;
	private boolean enmascararRef;

	// lista que se mostrara en la vista
	private List<Transaction> transacciones;
	private List<Consolidado> consolidados;
	private int cantidadresultados;
	private String userName;
	private String codConvenio;
	
	private int numTransaccionesExitosas;
	private String valorTransaccionesExitosas;
	private int numTransaccionesFallidas;
	private String valorTransaccionesFallidas;
	private int auxValorTransaccionesExitosas;
	private int auxValorTransaccionesFallidas;
	
	private static String NODO="Nodo Portal";
	private static String DOSPUNTOS=":";
	
	private List<ReferenceType> listaReferenciasCapt;
	private boolean multiplesRef;
	private List<ReferenceAgreementType> numeroReferencias;
	private Boolean[] NumeroReferenciasTot;
	private int truncarIzquierda = 4;
	private int truncarDerecha = 2;
	private char truncarCaracter = '*';
	
	/*Campos para render de tabla*/
	private boolean renderColIdTransaction;
	private boolean renderColNombre;
	private boolean renderColNombreConvenio;
	private boolean renderColIP;
	private boolean renderColReferencias;
	private boolean renderFechaPago;
	private boolean renderColValTransaccion;
	private boolean renderColEstadoTransaccion;
	private boolean renderColBankAutorizador;
	private boolean renderColTipoPago;
	private boolean renderColNumAutorizacion;
	private boolean renderColCiclo;
	private boolean renderColCorreoElectronico;
	private boolean renderColObservaciones;
	private boolean renderColConcepto;
	
	/*Labels campos adicionales*/
	public final static String OBSERVACIONESLABEL = "Observaciones";
	public final static String CONCEPTOLABEL = "Concepto";
	public final static String REFERENCIAPAGOLABEL = "Referencias";
	public final static String CONVENIONAMELABEL = "Nombre Convenio";
	private String labelObservaciones;
	private String labelConcepto;
	private String labelReferenciaPago;
	private String labelConvenioName;
	
	
	
	public String getLabelObservaciones() {
		return labelObservaciones;
	}

	public void setLabelObservaciones(String labelObservaciones) {
		this.labelObservaciones = labelObservaciones;
	}

	public String getLabelConcepto() {
		return labelConcepto;
	}

	public void setLabelConcepto(String labelConcepto) {
		this.labelConcepto = labelConcepto;
	}

	public String getLabelReferenciaPago() {
		return labelReferenciaPago;
	}

	public void setLabelReferenciaPago(String labelReferenciaPago) {
		this.labelReferenciaPago = labelReferenciaPago;
	}

	public String getLabelConvenioName() {
		return labelConvenioName;
	}

	public void setLabelConvenioName(String labelConvenioName) {
		this.labelConvenioName = labelConvenioName;
	}

	public boolean isRenderFechaPago() {
		return renderFechaPago;
	}

	public void setRenderFechaPago(boolean renderFechaPago) {
		this.renderFechaPago = renderFechaPago;
	}

	public boolean isRenderColValTransaccion() {
		return renderColValTransaccion;
	}

	public void setRenderColValTransaccion(boolean renderColValTransaccion) {
		this.renderColValTransaccion = renderColValTransaccion;
	}

	public boolean isRenderColIdTransaction() {
		return renderColIdTransaction;
	}

	public void setRenderColIdTransaction(boolean renderColIdTransaction) {
		this.renderColIdTransaction = renderColIdTransaction;
	}

	public boolean isRenderColNombre() {
		return renderColNombre;
	}

	public void setRenderColNombre(boolean renderColNombre) {
		this.renderColNombre = renderColNombre;
	}

	public boolean isRenderColNombreConvenio() {
		return renderColNombreConvenio;
	}

	public void setRenderColNombreConvenio(boolean renderColNombreConvenio) {
		this.renderColNombreConvenio = renderColNombreConvenio;
	}

	public boolean isRenderColIP() {
		return renderColIP;
	}

	public void setRenderColIP(boolean renderColIP) {
		this.renderColIP = renderColIP;
	}

	public boolean isRenderColReferencias() {
		return renderColReferencias;
	}

	public void setRenderColReferencias(boolean renderColReferencias) {
		this.renderColReferencias = renderColReferencias;
	}

	public boolean isRenderColEstadoTransaccion() {
		return renderColEstadoTransaccion;
	}

	public void setRenderColEstadoTransaccion(boolean renderColEstadoTransaccion) {
		this.renderColEstadoTransaccion = renderColEstadoTransaccion;
	}

	public boolean isRenderColBankAutorizador() {
		return renderColBankAutorizador;
	}

	public void setRenderColBankAutorizador(boolean renderColBankAutorizador) {
		this.renderColBankAutorizador = renderColBankAutorizador;
	}

	public boolean isRenderColTipoPago() {
		return renderColTipoPago;
	}

	public void setRenderColTipoPago(boolean renderColTipoPago) {
		this.renderColTipoPago = renderColTipoPago;
	}

	public boolean isRenderColNumAutorizacion() {
		return renderColNumAutorizacion;
	}

	public void setRenderColNumAutorizacion(boolean renderColNumAutorizacion) {
		this.renderColNumAutorizacion = renderColNumAutorizacion;
	}

	public boolean isRenderColCiclo() {
		return renderColCiclo;
	}

	public void setRenderColCiclo(boolean renderColCiclo) {
		this.renderColCiclo = renderColCiclo;
	}

	public boolean isRenderColCorreoElectronico() {
		return renderColCorreoElectronico;
	}

	public void setRenderColCorreoElectronico(boolean renderColCorreoElectronico) {
		this.renderColCorreoElectronico = renderColCorreoElectronico;
	}

	public boolean isRenderColObservaciones() {
		return renderColObservaciones;
	}

	public void setRenderColObservaciones(boolean renderColObservaciones) {
		this.renderColObservaciones = renderColObservaciones;
	}

	public boolean isRenderColConcepto() {
		return renderColConcepto;
	}

	public void setRenderColConcepto(boolean renderColConcepto) {
		this.renderColConcepto = renderColConcepto;
	}

	public ResultadoConsultaTransBean(String rquid, RutaContenidoBean rContenido) {
		tableDateFormat = getProperty("config.externalDateFormat","dd-MM-yyyy hh:mm:ss aa", rquid, rContenido);
		usernameAttr = getProperty("config.usernameAttr", "sn", rquid, rContenido);
		codConvenioAttr = getProperty("config.codConvenioAttr", "ath-codigoconvenio", rquid, rContenido);
		setLabelObservaciones(OBSERVACIONESLABEL);
		setLabelConcepto(CONCEPTOLABEL);
		setLabelReferenciaPago(REFERENCIAPAGOLABEL);
		setLabelConvenioName(CONVENIONAMELABEL);
		
	}

	public ResultadoConsultaTransBean cargarListaReferencias(RenderRequest request, String rquid, RutaContenidoBean rContenido, ResultadoConsultaTransBean bean) {
		// TODO Auto-generated method stub
		try{
		Puma puma = new Puma();
		Boolean[] arrayRef = new Boolean[30];
		codConvenio = puma.getPropertyFromPuma(codConvenioAttr, request);
		GetConvenioInfoRq req = new GetConvenioInfoRq();
		

		req.setAgreementId(codConvenio);

		logger.info("[REQUEST - getConvenioInfo] DATA: "+new Gson().toJson(req));
		GetConvenioInfoRs res = CacheManager.getInstance().getConvenioInfo(req);
		logger.info("[RESPONSE - getConvenioInfo] DATA: "+new Gson().toJson(res));
		
		
		if(res != null){
			bean.setNumeroReferencias(res.getReferences());
			for (int i = 0; i < res.getReferences().size(); i++) {
				arrayRef[i] = true;
			}
			bean.setNumeroReferenciasTot(arrayRef);
		}
		}catch(Exception e){
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, rContenido.getUserName(), ExceptionManager.PP_PORTAL_GENERIC_01+" - Operación: getProperty, Reporte Pagos", "getProperty", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
		}
		
		return bean;
	}

	/***
	 * Obtiene el valor del archivo de propiedades
	 * 
	 * @param key
	 *            clave de la propiedad a leer
	 * @return valor de la propiedad
	 */
	private String getProperty(String key, String defaultValue, String rquid, RutaContenidoBean rContenido) {
		String value = ""; 
		
		try{
			ResourceBundle rb = null;
			if (rb == null) {
				rb = ResourceBundle.getBundle("com.portalrecaudadores.resultadoconsultatrans.properties.ResultadoConsultaTransProp");
			}
			value = rb.getString(key);
			if (value == null || "".equals(value)) {
				return defaultValue;
			}
		}catch(Exception e){
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, rContenido.getUserName(), ExceptionManager.PP_PORTAL_GENERIC_01+" - Operación: getProperty, Reporte Pagos", "getProperty", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
		}
		
		return value;
	}

	/**
	 * HU72.3
	 * 
	 * @Metodo Obtiene los resultados que se mostraran en la vista
	 * @author John Perez
	 * @since 21/05/2015
	 * @param request
	 *            , response
	 */
	public String cargarResultados(String rqFilters, RenderRequest request,
			RenderResponse response) {
		String ip;
		Puma puma;
		rqFiltros = rqFilters;
		this.mostrarModalDescarga = false;
		logger.info("Version 1.3");
		
		try {
			puma = new Puma();
			String aux[] = null;
			if (request != null) {
				ip = com.ibm.ws.portletcontainer.portlet.PortletUtils
						.getHttpServletRequest(request).getRemoteAddr();
				userName = puma.getPropertyFromPuma(usernameAttr, request);
			    codConvenio = puma.getPropertyFromPuma(codConvenioAttr, request);
			} else {
				FacesContext facesContext = FacesContext.getCurrentInstance();
				PortletRequestWrapper requestWrapper = (PortletRequestWrapper) facesContext
						.getExternalContext().getRequest();
				PortletRequest portletRequest = (PortletRequest) requestWrapper
						.getPortletRequest();
				ip = com.ibm.ws.portletcontainer.portlet.PortletUtils
						.getHttpServletRequest(portletRequest).getRemoteAddr();
				userName = puma.getPropertyFromPuma(usernameAttr,
						portletRequest);
				codConvenio = puma.getPropertyFromPuma(codConvenioAttr,
						portletRequest);
			}
			//logger.info("Username: " + userName);
			GregorianCalendar gcal = new GregorianCalendar();
			gcal.setTime(new Date());
			XMLGregorianCalendar cal = DatatypeFactory.newInstance()
					.newXMLGregorianCalendar(gcal);
			
			if (rqFilters != null) {
				aux = rqFilters.split("/");
				fechaInicial = aux[2];
				fechaFinal = aux[3];
				if ("null".equalsIgnoreCase(aux[4])) {
					estado = null;
				} else {
					estado = aux[4];
				}
				if ("null".equalsIgnoreCase(aux[5])) {
					medioPago = null;
				} else {
					medioPago = aux[5];
				}
				if (aux[6].equalsIgnoreCase("null")) {
					cus = null;
				} else {
					cus = aux[6];
				}
				if (aux[7].equalsIgnoreCase("null")) {
					idTransaccion = null;
				} else {
					idTransaccion = aux[7];
				}
				
				if (null == aux[8] || aux[8].equalsIgnoreCase("null") || aux[8].equalsIgnoreCase("false")) {
					listaReferenciasCapt = null;
				} else {
					Gson gson = new Gson();
					Type type = new TypeToken<List<ReferenceType>>(){}.getType();
					List<ReferenceType> listaReferencias = gson.fromJson(aux[8],type);
					listaReferenciasCapt = listaReferencias;	
				}
				if (aux[9].equalsIgnoreCase("null")) {
					valorPago = null;
				} else {
					valorPago = aux[9];
				}
				if (!aux[1].equalsIgnoreCase("null")) {
					enmascararRef = Boolean.parseBoolean(aux[1]);
				}
				
			} else {
				valoresPorDefecto();
			}
			SearchPaymentHistoryFactRq rq = new SearchPaymentHistoryFactRq();

			rq.setIpAddress(ip);
			rq.setTransactionID(idTransaccion);
			rq.setAgreementId(codConvenio);
			if(null != listaReferenciasCapt && listaReferenciasCapt.size()> 1 )
			{
				this.multiplesRef = true;	
			}
			
			rq.setListaReferences(listaReferenciasCapt);
			rq.setValorPago(valorPago);
			rq.setRequestDate(new Date());
			//rq.setRequestSender(NombrePortlet.NOMBRE_PORTLET.getNombre());
			rq.setInitialDate(convertStringtoDate(fechaInicial));
			rq.setFinalDate(convertStringtoDate(fechaFinal));
			rq.setTransactionStatus(estado);
			rq.setPaymentMode(medioPago);
			rq.setCus(cus);
			rq.setRequestUser(userName);
			
			
			rq.setMaxResult(Integer.toString(maximoTransacciones));
			rq.setOrderBy(null);
			rq.setOrderType(null);
			rq.setPageSize(10);
			rq.setRequestID(PublisherUtil.getInstance().generateRequestID());
			rq.setEnmascararReferencia(enmascararRef);
			
			
			String EndPointRESTServiceGetPaymentHistoryFact = ConfigurationService.getInstance().getEndpointRest();
			
			//Si la referencia es de tipo tarjeta de credito, se clona el objeto request para enmascarar la referencia
			if(Boolean.parseBoolean(aux[1])){
				// utilizamos clone para evitar problemas con referencias en memoria
				SearchPaymentHistoryFactRq searchPayLog = (SearchPaymentHistoryFactRq) CloneUtil.clone(rq);
				searchPayLog.getListaReferences().get(0).setReference(aux[0]);
				logger.info("[REQUEST - getPaymentHistoryFact] DATA: "+new Gson().toJson(searchPayLog));
			}else{
				logger.info("[REQUEST - getPaymentHistoryFact] DATA: "+new Gson().toJson(rq));
			}
			List <ParamFilesType> responseParamFile;
			SearchPaymentHistoryFactRs rs = (SearchPaymentHistoryFactRs) WebServiceClientHTTPS.getInstance(SearchPaymentHistoryFactRs.class).procesarRequest(
					EndPointRESTServiceGetPaymentHistoryFact + "getPaymentHistoryFact", rq);
			logger.info("[RESPONSE - getPaymentHistoryFact] DATA: "+new Gson().toJson(rs));
			
			transacciones = new ArrayList<Transaction>();
			consolidados = new ArrayList<Consolidado>();
			responseParamFile = rs.getLiParamFilesTypes();
			int noMedioA = 0 ;
			int noMedioF = 0 ;
			double noMedioAValor = 0 ;
			double noMedioFValor = 0 ;
			
			/*HU 72.15 VG 09/12/2016 INI SP38*/
			boolean contPrimeraRef=false;
			boolean contSegundaRef=false;
			boolean contTerceraRef=false;
			/*HU 72.15 VG 09/12/2016 FIN*/
			
			if (rs != null) {
				if (SUCCESS.equals(rs.getStatus().getStatusCode())) {
					cantidadresultados = rs.getTransactionsTotal();
					// Valido que la consulta no tenga mas de 200 registros
					if (cantidadresultados >= maximoTransacciones) {
						//archivo = rs.getFile();
						request.getPortletSession().setAttribute(
								"msjFormularios", "MaxResul");
						return "ResultadoConsultaTransView";
					} else {
						// realizo el llamado al integrador exitosamente
						if (rs.getTransactions().size() > 0) {
							
							//Consulta del cache manager los parametros para truncar
							getCacheParametros();
							
							int contador = 1;
							for (int i = 0; i <= (cantidadresultados - rs
									.getTransactions().size()); i++) {
								if (contador == paginaActual) {
									/*HU 72.15 VG 09/12/2016 INI SP38*/
									contPrimeraRef=false;
									contSegundaRef=false;
									contTerceraRef=false;
									/*HU 72.15 VG 09/12/2016 FIN*/
									int conteoCampo = 0;
									int cantidadColumnas = responseParamFile.size();
									boolean renderColums[] = new boolean[cantidadColumnas];
									for (ParamFilesType paramConf: responseParamFile) {
										renderColums[conteoCampo] = paramConf.getStatusMark();
										conteoCampo++;
									}
									
									setRenderColIdTransaction(renderColums[0]);
									setRenderColNombreConvenio(renderColums[1]);
									setRenderColReferencias(renderColums[2]);
									setRenderColValTransaccion(renderColums[3]);
									setRenderColBankAutorizador(renderColums[4]);
									setRenderColNumAutorizacion(renderColums[5]);
									setRenderColCorreoElectronico(renderColums[6]);
									setRenderColIP(renderColums[7]);
									setRenderColNombre(renderColums[8]);							
									setRenderFechaPago(renderColums[9]);
									setRenderColEstadoTransaccion(renderColums[10]);
									setRenderColTipoPago(renderColums[11]);
									setRenderColCiclo(renderColums[12]);
									setRenderColObservaciones(renderColums[13]);
									setRenderColConcepto(renderColums[14]);
																								
									for (TransactionFactType transaction : rs
											.getTransactions()) {
																					
										Transaction transaccion = new Transaction();
										transaccion.setIdTransaccion(transaction.getTransactionID());
										transaccion.setNombre(transaction.getCustomerName());
										transaccion.setConvenioName(transaction.getConvenioName());
										String referencias = "";
										for(ReferenceType refs : transaction.getListaReferences()) {
											referencias += refs.getReference()+"-";
										}
										referencias = referencias.substring(0,referencias.length()-1);
										transaccion.setRefPago(referencias);									
										transaccion.setValTransaccion(formatoValor(Double.parseDouble(transaction.getTransactionValue())));
										transaccion.setBancoAutorizador(transaction.getBankName());
										transaccion.setNumAutorizacion(transaction.getAuthorizationNumber());
										transaccion.setCorreoElectronico(transaction.getEmail());
										String fecAmpM = "dd-MM-yyyy hh:mm:ss aa";
										String fechaAux = formatearFecha(transaction.getTransactionDate(),fecAmpM);
										transaccion.setFechaHora(fechaAux.replace(" ", "\n"));
										transaccion.setEstado(transaction.getTransactionStatus());
										if(transaction.getPaymentMode().equalsIgnoreCase("")){
											transaccion.setMedioPago("Sin medio de pago");
											if(transaction.getTransactionStatus().equalsIgnoreCase("APROBADA")){
												noMedioA ++;
												noMedioAValor = noMedioAValor + Double.parseDouble(transaction.getTransactionValue());
											}else {
												noMedioF ++;
												noMedioFValor = noMedioFValor + Double.parseDouble(transaction.getTransactionValue());
											}
											
										}else{
											transaccion.setMedioPago(transaction.getPaymentMode());
										}
										transaccion.setCicloACH(transaction.getCicloACH());
										
										//Validacion que indica si la referencia es de tipo tarjeta de credito
//										if(transaction.isValidarBin() && transaction.getListaReferences().size() > 0){
//											//Se modifica la referencia principal para truncarla
//											transaction.getListaReferences().get(0).setReference(TruncarUtil.truncarTarjetaDeCredito(transaction.getListaReferences().get(0).getReference(), truncarIzquierda, truncarCaracter, truncarDerecha));
//										}
//										transaccion.setListaReferenciasCapt(transaction.getListaReferences());
										transaccion.setListaReferenciasCapt(listaReferenciasCapt);										
										//transaccion.setRefPago(transaction.getPaymentReference());
										transaccion.setIp(transaction.getIpAddress());
//										transaccion.setPrimeraRefAdicional(primeraRefPagoTx);
//										transaccion.setSegundaRefAdicional(segundaRefPagoTx);
//										transaccion.setTerceraRefAdicional(terceraRefPagoTx);				
										transaccion.setObservaciones(transaction.getTransactionObservation());
										transaccion.setConcepto(transaction.getTransactionConcepto());
										transacciones.add(transaccion);
										contador++;
										
									}

								} else {
									Transaction transaccion = new Transaction();
									transaccion.setIdTransaccion("");
									transaccion.setFechaHora("");
									transaccion.setValTransaccion("");
									transaccion.setEstado("");
									transaccion.setMedioPago("");
									transaccion.setCorreoElectronico("");
									transaccion.setNombre("");
									transaccion.setIp("");
									transaccion.setCicloACH("");
									transaccion.setBancoAutorizador("");
									transacciones.add(transaccion);
									if (i % 10 == 0) {
										contador++;
									}
								}

							}
				
							
							if (cantidadresultados > 1 && rs.getConsolidate().size() > 0) {
								for (ConsolidatedFactType consolidateObject : rs.getConsolidate()) {
									for(int i = 0; i < consolidateObject.getConsolidateEstado().size();i++){
										
										//Incidencia 04-04-2017 Se valida que el medio de pago no sea vacio o null INI
										String valorMedioPago= consolidateObject.getConsolidateEstado().get(i).getPaymentMode();
										
										if(valorMedioPago!=null && !(valorMedioPago.trim().equalsIgnoreCase("null")) && !(valorMedioPago.trim().equalsIgnoreCase(""))){
										//Fin Incidencia
											Consolidado consolidado = new Consolidado();
										
											int posicion = verificarPaymentMode(consolidateObject.getConsolidateEstado().get(i).getPaymentMode(), consolidados);
											if( posicion != -1){
												consolidado = consolidados.remove(posicion);
												agregarConsolidado(consolidateObject.getConsolidateEstado().get(i).getNombreEstado(), i, consolidado, consolidateObject);
												consolidados.add(posicion, consolidado);
											}										
											else{
												consolidado.setMedioPago(consolidateObject.getConsolidateEstado().get(i).getPaymentMode());
												agregarConsolidado(consolidateObject.getConsolidateEstado().get(i).getNombreEstado(), i, consolidado, consolidateObject);
												consolidados.add(consolidado);
											}
										//INI Incidencia	
										}
										//Fin Incidencia
									}								
								}
								
								this.setNumTransaccionesExitosas(numTransaccionesExitosas + noMedioA);
								this.setNumTransaccionesFallidas(numTransaccionesFallidas + noMedioF);
								this.setValorTransaccionesExitosas(formatoValor((double) auxValorTransaccionesExitosas+ + noMedioAValor));
								this.setValorTransaccionesFallidas(formatoValor((double) auxValorTransaccionesFallidas + noMedioFValor));
								
								if((noMedioA + noMedioF) > 0){
									Consolidado consolidado = new Consolidado();
									consolidado.setMedioPago("Sin medio de Pago");
									consolidado.setNumTransaccionesAprobadas(String.valueOf(noMedioA));
									consolidado.setNumTransaccionesFallidas(String.valueOf(noMedioF));
									
									if (noMedioAValor > 0)
									consolidado.setValorTransaccionesAprobadas(formatoValor(noMedioAValor));
									else consolidado.setValorTransaccionesAprobadas(String.valueOf((int) noMedioAValor));
									
									
									if (noMedioFValor > 0)
									consolidado.setValorTransaccionesFallidas(formatoValor(noMedioFValor));
									else consolidado.setValorTransaccionesFallidas(String.valueOf((int) noMedioFValor));
										
									consolidados.add(consolidado);
							    }
							}
							
							
						} else {
						
							request.getPortletSession().setAttribute(
									"msjFormularios", "NoDatos");
							return "ResultadoConsultaTransView";
						}
					}
				} else {
				
					request.getPortletSession().setAttribute("msjFormularios",
							"ErrorCom");
					return "ResultadoConsultaTransView";
				}
				
				/*HU 72.15 VG 12/12/2016 INI SP38*/
				setShowRefPago1(contPrimeraRef);
				setShowRefPago2(contSegundaRef);
				setShowRefPago3(contTerceraRef);
				/*HU 72.15 VG 12/12/2016 FIN*/
				
			} else {
				
				request.getPortletSession().setAttribute("msjFormularios",
						"ErrorCom");
				return "ResultadoConsultaTransView";
			}
		} catch (PortletServiceUnavailableException e) {
			request.getPortletSession().setAttribute("msjFormularios",
					"ErrorCom");
			
			return "ResultadoConsultaTransView";
		} catch (NamingException e) {
			request.getPortletSession().setAttribute("msjFormularios",
					"ErrorCom");
			
			return "ResultadoConsultaTransView";
		} catch (Exception e) {
			request.getPortletSession().setAttribute("msjFormularios",
					"ErrorCom");
		
			return "ResultadoConsultaTransView";
		}
		request.getPortletSession().setAttribute("msjFormularios", "Exito");
		
		return "ResultadoConsultaTransView";
	}
	
	

	public int verificarPaymentMode(String paymentMode, List<Consolidado> lista ){
		
		int posicion = -1;
		for(int i=0; i<lista.size(); i++){
			if (lista.get(i).getMedioPago().equalsIgnoreCase(paymentMode)){
			return i;
			}
		}
		
		return posicion;
	}
	
	public void agregarConsolidado(String nombreEstado, int posicionConsolidado, Consolidado consolidado, ConsolidatedFactType consolidateObject){
		if(nombreEstado.equals("APROBADA")){
		consolidado.setNumTransaccionesAprobadas(consolidateObject.getConsolidateEstado().get(posicionConsolidado).getTotalTransactions());
		consolidado.setValorTransaccionesAprobadas(formatoValor(Double.parseDouble(consolidateObject.getConsolidateEstado().get(posicionConsolidado).getTotalValue())));
		numTransaccionesExitosas += Integer.parseInt(consolidateObject.getConsolidateEstado().get(posicionConsolidado).getTotalTransactions());
		auxValorTransaccionesExitosas += Integer.parseInt(consolidateObject.getConsolidateEstado().get(posicionConsolidado).getTotalValue());
		} else if(nombreEstado.equals("FALLIDA")){
		consolidado.setNumTransaccionesFallidas(consolidateObject.getConsolidateEstado().get(posicionConsolidado).getTotalTransactions());
		consolidado.setValorTransaccionesFallidas(formatoValor(Double.parseDouble(consolidateObject.getConsolidateEstado().get(posicionConsolidado).getTotalValue())));
		numTransaccionesFallidas += Integer.parseInt(consolidateObject.getConsolidateEstado().get(posicionConsolidado).getTotalTransactions());
		auxValorTransaccionesFallidas += Integer.parseInt(consolidateObject.getConsolidateEstado().get(posicionConsolidado).getTotalValue());
		}
		
		
		
	}
	

	/**
	 * Función encargada de trazar RS de la acción de consulta de transacciones
	 * @author melany.rozo
	 * @since 25/02/2016
	 * */
	public void trazaRsConsultarTransacciones(String requestId, RutaContenidoBean rContenido, String errorCode, SearchPaymentHistoryFactRs rs){
		try {
			//Llamado a Properties para consultar el nombre del portlet
			ResourceBundle rb = ResourceBundle.getBundle("com.portalrecaudadores.resultadoconsultatrans.portlet.nl.ResultadoConsultaTransPortletResource");
			
			//TRAZA
			AuditorRq auditorRq = new AuditorRq();

			auditorRq.setRequestId(requestId);
			auditorRq.setIpAddress(rContenido.getIpAdress());
			auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
			auditorRq.setAction(rb.getString("auditoria.consultarTransacciones"));
			auditorRq.setOriginPortal(rContenido.getOriginPortal());
			auditorRq.setPage(rContenido.getCurrentPage());
			auditorRq.setPortlet(rContenido.getPortlet());
			auditorRq.setUser(rContenido.getUserName());
			auditorRq.setTipoServicio("RS");
			auditorRq.setAdditionalInfo(JSONUtil.getJson(NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
			auditorRq.setErrorCode(errorCode);

			TrazaPublisher.getInstance().publish(auditorRq);
			//Fin de la traza
		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, requestId, ExceptionManager.PP_PORTAL_GENERIC_01,rContenido.getUserName(), ExceptionManager.MSG_PORTAL_GENERIC_01+" - Operación: trazaRqDescargaArchivo, Reporte Pagos", "trazaRqDescargaArchivo", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal());
			logger.error(errorData, e);
		}
	}
	
	/***
	 * Asigna a los campos de busqueda los valores por defecto cuando se ingresa
	 * a la pantalla por primera vez antes de presionar el boton consultar
	 */
	public void valoresPorDefecto() {
		Calendar calendar = Calendar.getInstance();
		Date hoy = new Date();
		calendar.setTime(hoy);
		calendar.add(Calendar.DAY_OF_YEAR, -30);
		Date fechAux = calendar.getTime();
		fechaInicial = formatearFecha(fechAux, dateFormat);
		fechaFinal = formatearFecha(hoy, dateFormat);
		medioPago = null;
		estado = null;
		cus = null;
		idTransaccion = null;
		referenciaPago = null;
		primeraReferenciaAd = null;
		segundaReferenciaAd = null;
		terceraReferenciaAd = null;
		valorPago = null;
	}
	
	/**
	 * HU tokenizacion, Metodo encargado de consultar la cache y obtener los parametros para enmascarar y truncar
	 * @author germandiaz
	 * @param idRequest 
	 * @throws Exception 
	 * @since 27/07/2017
	 * */
	private void getCacheParametros() throws Exception {
		// Cargamos los parametros desde la cache
			List<GetParametroRs> parametros;
		
			parametros = CacheManager.getInstance().obtenerParametros();
			if(null != parametros){
				for(GetParametroRs parametro : parametros){
					if(parametro.getNombre().equals("ATH_CANT_PREVIA_TRUNCADO")){
						truncarDerecha	 = Integer.parseInt(parametro.getValor());
					}
					else if(parametro.getNombre().equals("ATH_CANT_FINAL_TRUNCADO")){
						truncarIzquierda = Integer.parseInt(parametro.getValor());
					}
					else if(parametro.getNombre().equals("ATH_CARACTER_PREVIO_TRUNCADO")){
						truncarCaracter  = parametro.getValor().charAt(0);
					}
				}
			}
					
	}

	/***
	 * Devulve la fehca formateada en formato dd-MM-yyyy
	 * 
	 * @param fecha
	 * @return
	 */
	private String formatearFecha(Date fecha, String format) {
		String fechaFormateada = "";
		try {
			SimpleDateFormat fechaformato = new SimpleDateFormat(format);
			fechaFormateada = fechaformato.format(fecha);
		} catch (Exception e) {
			return "";
		}
		return fechaFormateada;
	}

	/***
	 * Convierte el String en tipo Date El String debe tener el formato indicado
	 * por la variable dateFormat
	 * 
	 * @param fecha
	 * @return
	 */
	private Date convertStringtoDate(String fecha) {
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
		try {
			return sdf.parse(fecha);
		}  catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	/***
	 * metodo encargado de dar formato al valor que se mostrara en la tabla de
	 * resultados
	 */
	private String formatoValor(Double valor) {
		String valorPago = "";
			Locale cop = new Locale("es", "CO");
			NumberFormat nf = NumberFormat.getCurrencyInstance(cop);
			DecimalFormatSymbols decimalFormatSymbols = ((DecimalFormat) nf).getDecimalFormatSymbols();
			decimalFormatSymbols.setCurrencySymbol("");
			((DecimalFormat) nf).setDecimalFormatSymbols(decimalFormatSymbols);
			valorPago = nf.format(valor).trim();
		return valorPago;
	}

	public String getLabelBancoAutorizado() {
		return labelBancoAutorizado;
	}

	public void setLabelBancoAutorizado(String labelBancoAutorizado) {
		this.labelBancoAutorizado = labelBancoAutorizado;
	}

	public String getLabelCicloACH() {
		return labelCicloACH;
	}

	public void setLabelCicloACH(String labelCicloACH) {
		this.labelCicloACH = labelCicloACH;
	}

	public String getLabelResumen() {
		return labelResumen;
	}

	public void setLabelResumen(String labelResumen) {
		this.labelResumen = labelResumen;
	}

	public String getLabelMedioPago() {
		return labelMedioPago;
	}

	public void setLabelMedioPago(String labelMedioPago) {
		this.labelMedioPago = labelMedioPago;
	}

	public String getLabelNumTransacciones() {
		return labelNumTransacciones;
	}

	public void setLabelNumTransacciones(String labelNumTransacciones) {
		this.labelNumTransacciones = labelNumTransacciones;
	}

	public String getLabelValorTransacciones() {
		return labelValorTransacciones;
	}

	public void setLabelValorTransacciones(String labelValorTransacciones) {
		this.labelValorTransacciones = labelValorTransacciones;
	}

	public String getLabelPagosAval() {
		return labelPagosAval;
	}

	public void setLabelPagosAval(String labelPagosAval) {
		this.labelPagosAval = labelPagosAval;
	}

	public String getLabelPSE() {
		return labelPSE;
	}

	public void setLabelPSE(String labelPSE) {
		this.labelPSE = labelPSE;
	}

	public String getLabelTC() {
		return labelTC;
	}

	public void setLabelTC(String labelTC) {
		this.labelTC = labelTC;
	}

	public String getLabelFechaHora() {
		return labelFechaHora;
	}

	public void setLabelFechaHora(String labelFechaHora) {
		this.labelFechaHora = labelFechaHora;
	}

	public String getLabelValortransaccion() {
		return labelValortransaccion;
	}

	public void setLabelValortransaccion(String labelValortransaccion) {
		this.labelValortransaccion = labelValortransaccion;
	}

	public String getLabelEstado() {
		return labelEstado;
	}

	public void setLabelEstado(String labelEstado) {
		this.labelEstado = labelEstado;
	}

	public String getLabelNumAutorizacion() {
		return labelNumAutorizacion;
	}

	public void setLabelNumAutorizacion(String labelNumAutorizacion) {
		this.labelNumAutorizacion = labelNumAutorizacion;
	}

	public String getLabelMedioPagoMin() {
		return labelMedioPagoMin;
	}

	public void setLabelMedioPagoMin(String labelMedioPagoMin) {
		this.labelMedioPagoMin = labelMedioPagoMin;
	}

	public String getLabelRefPago() {
		return labelRefPago;
	}

	public void setLabelRefPago(String labelRefPago) {
		this.labelRefPago = labelRefPago;
	}

	public String getLabelCorreoElectronico() {
		return labelCorreoElectronico;
	}

	public void setLabelCorreoElectronico(String labelCorreoElectronico) {
		this.labelCorreoElectronico = labelCorreoElectronico;
	}

	public String getLabelNombre() {
		return labelNombre;
	}

	public void setLabelNombre(String labelNombre) {
		this.labelNombre = labelNombre;
	}

	public String getLabelIP() {
		return labelIP;
	}

	public void setLabelIP(String labelIP) {
		this.labelIP = labelIP;
	}

	public String getBotonDescargar() {
		return botonDescargar;
	}

	public void setBotonDescargar(String botonDescargar) {
		this.botonDescargar = botonDescargar;
	}

	public String getTituloError() {
		return tituloError;
	}

	public void setTituloError(String tituloError) {
		this.tituloError = tituloError;
	}

	public String getMensajeError() {
		return mensajeError;
	}

	public void setMensajeError(String mensajeError) {
		this.mensajeError = mensajeError;
	}

	public String getTituloModalDescarga() {
		return tituloModalDescarga;
	}

	public void setTituloModalDescarga(String tituloModalDescarga) {
		this.tituloModalDescarga = tituloModalDescarga;
	}

	public String getMensajeModalDescarga() {
		return mensajeModalDescarga;
	}

	public void setMensajeModalDescarga(String mensajeModalDescarga) {
		this.mensajeModalDescarga = mensajeModalDescarga;
	}

	public String getBotonCancelar() {
		return botonCancelar;
	}

	public void setBotonCancelar(String botonCancelar) {
		this.botonCancelar = botonCancelar;
	}

	public String getMostrarLighbox() {
		return mostrarLighbox;
	}

	public void setMostrarLighbox(String mostrarLighbox) {
		this.mostrarLighbox = mostrarLighbox;
	}

	public String getTituloLighbox() {
		return tituloLighbox;
	}

	public void setTituloLighbox(String tituloLighbox) {
		this.tituloLighbox = tituloLighbox;
	}

	public String getCuerpoLighbox() {
		return cuerpoLighbox;
	}

	public void setCuerpoLighbox(String cuerpoLighbox) {
		this.cuerpoLighbox = cuerpoLighbox;
	}

	public String getWidhtLightbox() {
		return widhtLightbox;
	}

	public void setWidhtLightbox(String widhtLightbox) {
		this.widhtLightbox = widhtLightbox;
	}

	public String getHeightLightbox() {
		return heightLightbox;
	}

	public void setHeightLightbox(String heightLightbox) {
		this.heightLightbox = heightLightbox;
	}

	public String getTipoModal() {
		return tipoModal;
	}

	public void setTipoModal(String tipoModal) {
		this.tipoModal = tipoModal;
	}

	public String getCapturaMensajeErrorForm() {
		return capturaMensajeErrorForm;
	}

	public void setCapturaMensajeErrorForm(String capturaMensajeErrorForm) {
		this.capturaMensajeErrorForm = capturaMensajeErrorForm;
	}

	public String getFechaInicial() {
		return fechaInicial;
	}

	public void setFechaInicial(String fechaInicial) {
		this.fechaInicial = fechaInicial;
	}

	public String getFechaFinal() {
		return fechaFinal;
	}

	public void setFechaFinal(String fechaFinal) {
		this.fechaFinal = fechaFinal;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getMedioPago() {
		return medioPago;
	}

	public void setMedioPago(String medioPago) {
		this.medioPago = medioPago;
	}

	public String getCus() {
		return cus;
	}

	public void setCus(String cus) {
		this.cus = cus;
	}

	public String getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(String idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public int getCantidadresultados() {
		return cantidadresultados;
	}

	public void setCantidadresultados(int cantidadresultados) {
		this.cantidadresultados = cantidadresultados;
	}

	public String getLabelIdTransaccion() {
		return labelIdTransaccion;
	}

	public List<Transaction> getTransacciones() {
		return transacciones;
	}

	public void setTransacciones(List<Transaction> transacciones) {
		this.transacciones = transacciones;
	}

	public void setLabelIdTransaccion(String labelIdTransaccion) {
		this.labelIdTransaccion = labelIdTransaccion;
	}

	public List<Consolidado> getConsolidados() {
		return consolidados;
	}

	public void setConsolidados(List<Consolidado> consolidados) {
		this.consolidados = consolidados;
	}

	public String getRqFiltros() {
		return rqFiltros;
	}

	public void setRqFiltros(String rqFiltros) {
		this.rqFiltros = rqFiltros;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCodConvenio() {
		return codConvenio;
	}

	public void setCodConvenio(String codConvenio) {
		this.codConvenio = codConvenio;
	}

	public int getMaximoTransacciones() {
		return maximoTransacciones;
	}

	public void setMaximoTransacciones(int maximoTransacciones) {
		this.maximoTransacciones = maximoTransacciones;
	}

	public byte[] getArchivo() {
		return archivo;
	}

	public void setArchivo(byte[] archivo) {
		this.archivo = archivo;
	}

	public String getMensajeNoResultados() {
		return mensajeNoResultados;
	}

	public void setMensajeNoResultados(String mensajeNoResultados) {
		this.mensajeNoResultados = mensajeNoResultados;
	}

	public String getMensajePieTablaConsolidado() {
		return mensajePieTablaConsolidado;
	}

	public void setMensajePieTablaConsolidado(String mensajePieTablaConsolidado) {
		this.mensajePieTablaConsolidado = mensajePieTablaConsolidado;
	}
	
	public String getReferenciaPago() {
		return referenciaPago;
	}

	public void setReferenciaPago(String referenciaPago) {
		this.referenciaPago = referenciaPago;
	}

	public String getPrimeraReferenciaAd() {
		return primeraReferenciaAd;
	}

	
	
	public int getNumTransaccionesExitosas() {
		return numTransaccionesExitosas;
	}

	public void setNumTransaccionesExitosas(int numTransaccionesExitosas) {
		this.numTransaccionesExitosas = numTransaccionesExitosas;
	}

	public String getValorTransaccionesExitosas() {
		return valorTransaccionesExitosas;
	}

	public void setValorTransaccionesExitosas(String valorTransaccionesExitosas) {
		this.valorTransaccionesExitosas = valorTransaccionesExitosas;
	}

	public int getNumTransaccionesFallidas() {
		return numTransaccionesFallidas;
	}

	public void setNumTransaccionesFallidas(int numTransaccionesFallidas) {
		this.numTransaccionesFallidas = numTransaccionesFallidas;
	}

	public String getValorTransaccionesFallidas() {
		return valorTransaccionesFallidas;
	}

	public void setValorTransaccionesFallidas(String valorTransaccionesFallidas) {
		this.valorTransaccionesFallidas = valorTransaccionesFallidas;
	}

	public void setPrimeraReferenciaAd(String primeraReferenciaAd) {
		this.primeraReferenciaAd = primeraReferenciaAd;
	}

	public String getSegundaReferenciaAd() {
		return segundaReferenciaAd;
	}

	public void setSegundaReferenciaAd(String segundaReferenciaAd) {
		this.segundaReferenciaAd = segundaReferenciaAd;
	}

	public List<ReferenceType> getListaReferenciasCapt() {
		return listaReferenciasCapt;
	}

	public void setListaReferenciasCapt(List<ReferenceType> listaReferenciasCapt) {
		this.listaReferenciasCapt = listaReferenciasCapt;
	}

	public String getTerceraReferenciaAd() {
		return terceraReferenciaAd;
	}

	public void setTerceraReferenciaAd(String terceraReferenciaAd) {
		this.terceraReferenciaAd = terceraReferenciaAd;
	}

	public String getValorPago() {
		return valorPago;
	}

	public void setValorPago(String valorPago) {
		this.valorPago = valorPago;
	}
	public String getOpcionSelect() {
		return opcionSelect;
	}

	public void setOpcionSelect(String opcionSelect) {
		this.opcionSelect = opcionSelect;
	}
	
	public Boolean getMostrarModalDescarga() {
		return mostrarModalDescarga;
	}

	public void setMostrarModalDescarga(Boolean mostrarModalDescarga) {
		this.mostrarModalDescarga = mostrarModalDescarga;
	}
	
	public List<ReferenceAgreementType> getNumeroReferencias() {
		return numeroReferencias;
	}

	public void setNumeroReferencias(List<ReferenceAgreementType> numeroReferencias) {
		this.numeroReferencias = numeroReferencias;
	}

	public void descargar(AjaxBehaviorEvent event) {
		ResourceBundle rb = ResourceBundle.getBundle("com.portalrecaudadores.resultadoconsultatrans.portlet.nl.ResultadoConsultaTransPortletResource");
		this.mensajeModalDescarga = rb.getString("msg.ligthbox.mindescarga");
		this.mostrarModalDescarga = true;
	}
	
	public void ocultarModalDescarga() {
		this.mostrarModalDescarga = false;
	}
	
	/*HU 72.15 VG 09/12/2016 INI SP38*/
	public String getLabelRefPago1() {
		return labelRefPago1;
	}

	public void setLabelRefPago1(String labelRefPago1) {
		this.labelRefPago1 = labelRefPago1;
	}

	public String getLabelRefPago2() {
		return labelRefPago2;
	}

	public void setLabelRefPago2(String labelRefPago2) {
		this.labelRefPago2 = labelRefPago2;
	}

	public String getLabelRefPago3() {
		return labelRefPago3;
	}

	public void setLabelRefPago3(String labelRefPago3) {
		this.labelRefPago3 = labelRefPago3;
	}

	

	public boolean isShowRefPago1() {
		return showRefPago1;
	}

	public void setShowRefPago1(boolean showRefPago1) {
		this.showRefPago1 = showRefPago1;
	}

	public boolean isShowRefPago2() {
		return showRefPago2;
	}

	public void setShowRefPago2(boolean showRefPago2) {
		this.showRefPago2 = showRefPago2;
	}

	public boolean isShowRefPago3() {
		return showRefPago3;
	}

	public void setShowRefPago3(boolean showRefPago3) {
		this.showRefPago3 = showRefPago3;
	}
	/*HU 72.15 VG 09/12/2016 FIN*/

	public Boolean[] getNumeroReferenciasTot() {
		return NumeroReferenciasTot;
	}

	public void setNumeroReferenciasTot(Boolean[] numeroReferenciasTot) {
		NumeroReferenciasTot = numeroReferenciasTot;
	}

	public boolean isEnmascararRef() {
		return enmascararRef;
	}

	public void setEnmascararRef(boolean enmascararRef) {
		this.enmascararRef = enmascararRef;
	}
}
