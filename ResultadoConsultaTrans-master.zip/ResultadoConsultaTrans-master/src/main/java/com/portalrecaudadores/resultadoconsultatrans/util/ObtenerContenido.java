package com.portalrecaudadores.resultadoconsultatrans.util;

import javax.portlet.PortletPreferences;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import co.com.ath.logger.CustomLogger;
import co.com.ath.parameterspage.ParametersPage;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.service.model.ErrorData;

import com.ath.portalpagos.util.ExceptionManager;
import com.co.pragma.portal.utils.WCMCliente;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.exceptions.WCMException;
import com.portalrecaudadores.resultadoconsultatrans.beans.ResultadoConsultaTransBean;
import com.portalrecaudadores.resultadoconsultatrans.beans.RutaContenidoBean;
import com.portalrecaudadores.resultadoconsultatrans.portlet.ResultadoConsultaTransPortlet;

/**
 * HU76 Clase encargada de Obtener el contenido WCM
 * @author john.perez
 * @since 03/06/2015
 **/
public class ObtenerContenido {

	private CustomLogger logger= new CustomLogger(ResultadoConsultaTransPortlet.class);
	
	private static ObtenerContenido instance;

	public ObtenerContenido (){
	}
	
	/**
	 * Retorna instancia de ObtenerCOntenido
	 * @return
	 * 
	 */
	public static ObtenerContenido getInstance() {
		if(null == instance)
			instance = new ObtenerContenido();
		return instance;
	}
	
	
	/***
	 * Carga los contenidos del WCM
	 * 
	 * 
	 */
	public void cargarWCM(RenderRequest request, RenderResponse response, String rquid, RutaContenidoBean rContenido) {
		WCMCliente cliente = null;
		try {
			PortletPreferences prefs = request.getPreferences();

			String rutaContenido = (String) ParametersPage.getParameterPage(request, response, "pathContent-consultaTransacciones");
			String urlHome = (String) ParametersPage.getParameterPage(request, response, "urlHome");
			String maximoTransacciones = (String) ParametersPage.getParameterPage(request, response, "maximoTransacciones");
			
			if (null == rutaContenido) {
				rutaContenido = prefs.getValue("pathContent-consultaTransacciones", "");
			}
			if (null == urlHome) {
				urlHome = prefs.getValue("urlHome", "");
			}
			if (null == maximoTransacciones){
				maximoTransacciones = prefs.getValue("maximoTransacciones", "");
			}
			request.setAttribute("urlHome", urlHome);

			cliente = new WCMCliente(rutaContenido);
			ResultadoConsultaTransBean bean = new ResultadoConsultaTransBean(rquid, rContenido);
			
			bean = bean.cargarListaReferencias(request,rquid, rContenido, bean);
			bean.setMaximoTransacciones(Integer.parseInt(maximoTransacciones));
			bean.setLabelResumen(((ShortTextComponent) cliente.getComponent("stLabelResumen")).getText());
			bean.setLabelNumTransacciones(((ShortTextComponent) cliente.getComponent("stLabelNumeroTransacciones")).getText());
			bean.setLabelMedioPago(((ShortTextComponent) cliente.getComponent("stLabelColMedioPago")).getText());
			bean.setLabelValorTransacciones(((ShortTextComponent) cliente.getComponent("stLabelValorTransacciones")).getText());
			bean.setLabelPagosAval(((ShortTextComponent) cliente.getComponent("stLabelPagosAval")).getText());
			bean.setLabelPSE(((ShortTextComponent) cliente.getComponent("stLabelPSE")).getText());
			bean.setLabelTC(((ShortTextComponent) cliente.getComponent("stLabelTarjetaCredito")).getText());
			bean.setLabelFechaHora(((ShortTextComponent) cliente.getComponent("stLabelFechaHora")).getText());
			bean.setLabelValortransaccion(((ShortTextComponent) cliente.getComponent("stLabelValorTransaccion")).getText());
			bean.setLabelEstado(((ShortTextComponent) cliente.getComponent("stLabelEstado")).getText());
			bean.setLabelNumAutorizacion(((ShortTextComponent) cliente.getComponent("stLabelNumAutorizacion")).getText());
			bean.setLabelMedioPagoMin(((ShortTextComponent) cliente.getComponent("stLabelMedioPagoMin")).getText());
			bean.setLabelRefPago(((ShortTextComponent) cliente.getComponent("stLabelRefPago")).getText());
			bean.setLabelCorreoElectronico(((ShortTextComponent) cliente.getComponent("stLabelCorreo")).getText());
			bean.setLabelNombre(((ShortTextComponent) cliente.getComponent("stLabelNombre")).getText());
			bean.setLabelIP(((ShortTextComponent) cliente.getComponent("stLabelIP")).getText());
			bean.setBotonDescargar(((ShortTextComponent) cliente.getComponent("stBtnDescargar")).getText());
			bean.setTituloError(((ShortTextComponent) cliente.getComponent("stTituloError")).getText());
			bean.setMensajeError(((TextComponent) cliente.getComponent("stMensajeError")).getText());
			bean.setTituloModalDescarga(((ShortTextComponent) cliente.getComponent("stTituloModalDescarga")).getText());
			bean.setMensajeModalDescarga(((ShortTextComponent) cliente.getComponent("stMensajeModalDescarga")).getText());
			bean.setBotonCancelar(((ShortTextComponent) cliente.getComponent("stBtnCancelar")).getText());
			bean.setLabelIdTransaccion(((ShortTextComponent) cliente.getComponent("stLabelIdTransaccionCol")).getText());
			bean.setMensajeNoResultados(((ShortTextComponent) cliente.getComponent("stMensajeNoResultados")).getText());
			bean.setMensajePieTablaConsolidado(((ShortTextComponent) cliente.getComponent("stLabelPieTablaConsolidado")).getText());
			bean.setLabelCicloACH(((ShortTextComponent) cliente.getComponent("stLabelCicloACH")).getText());
			bean.setLabelBancoAutorizado(((ShortTextComponent) cliente.getComponent("stLabelBancoAutorizador")).getText());
			/*HU 72.15 VG 09/12/2016 INI*/
			bean.setLabelRefPago1(((ShortTextComponent) cliente.getComponent("stLabelRefPago1")).getText());
			bean.setLabelRefPago2(((ShortTextComponent) cliente.getComponent("stLabelRefPago2")).getText());
			bean.setLabelRefPago3(((ShortTextComponent) cliente.getComponent("stLabelRefPago3")).getText());
			/*HU 72.15 VG 09/12/2016 FIN*/
			request.setAttribute("resultadoConsultaTransBean", bean);
			request.getPortletSession().setAttribute("resultadoConsultaTransBean", bean);
		} catch (WCMException e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_WCM_01, rContenido.getUserName(), ExceptionManager.MSG_PORTAL_WCM_01+" - Operación: Cargar Contenido WCM, Resultado consulta transacciones", "cargarWCM", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
		} catch (Exception e) {
			ErrorData errorData= PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, rContenido.getUserName(), ExceptionManager.MSG_PORTAL_GENERIC_01+" Operación: Cargar Contenido WCM, Resultado consulta transacciones", "cargarWCM", rContenido.getPortlet(), rContenido.getCurrentPage(), rContenido.getOriginPortal()); 
			logger.error(errorData, e);
		} finally {
			if(null!=cliente){
				cliente.endWorkspace();
			}
		}
	}
	
}
