package co.com.portales.commonweb.validadores;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

import org.apache.log4j.Logger;

import co.com.portales.commonweb.util.WebLocator;

public class AlfanumericoValidator implements Validator {
	protected static Logger log = Logger.getLogger(WebLocator.class);
	private ResourceBundle bundleCategorias;
	
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		bundleCategorias = ResourceBundle.getBundle("co.com.portales.commonweb.bundle.mensajes_validaciones");
		if(!value.toString().equalsIgnoreCase("")){
			if (!ValidadorDatosFormulario.validarCampoAlfanumerico(value.toString())) {
				throw new ValidatorException(new FacesMessage(bundleCategorias.getString("error_campo_alfanumerico"), null));		
			}
		} 
	}
}

