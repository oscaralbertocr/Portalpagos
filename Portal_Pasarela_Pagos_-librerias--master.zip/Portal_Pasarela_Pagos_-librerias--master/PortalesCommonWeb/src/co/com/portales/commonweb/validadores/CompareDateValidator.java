package co.com.portales.commonweb.validadores;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import javax.servlet.http.HttpServletRequest;

import co.com.portales.common.contants.IConstants;
import co.com.portales.commonweb.util.DatosUtil;

public class CompareDateValidator implements Validator {
	
	private ResourceBundle bundleCategorias;

	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		
		bundleCategorias = ResourceBundle.getBundle("co.com.portales.commonweb.bundle.mensajes_validaciones");
		
		String fechaFinal = (String) value;
		String fieldFechaInicial = (String) component.getAttributes().get(IConstants.CAMPO_FECHA_MENOR);
		String fieldHoraInicial = (String) component.getAttributes().get(IConstants.CAMPO_HORA_INICIAL);
		String fieldMinutoInicial = (String) component.getAttributes().get(IConstants.CAMPO_MINUTO_INICIAL);
		String fieldHoraFinal = (String) component.getAttributes().get(IConstants.CAMPO_HORA_FINAL);
		String fieldMinutoFinal = (String) component.getAttributes().get(IConstants.CAMPO_MINUTO_FINAL);
		String form = component.getParent().getId();
		String formatoFecha = (String) component.getAttributes().get(IConstants.CAMPO_FORMATO_FECHA);
		String diferenciaMeses = (String) component.getAttributes().get(IConstants.CAMPO_DIFERENCIA_MESES);
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		if(formatoFecha!=null && !("".equals(formatoFecha.trim()))){
			df = new SimpleDateFormat(formatoFecha);
		}
		
		String fechaInicial = null;
		String horaInicial = null;
		String horaFinal = null;
		String minutoInicial = null;
		String minutoFinal = null;
		
		if(fechaFinal==null||"".equals(fechaFinal)){
			throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_fecha_final_obligatoria"), null ));
		}else{
			fechaInicial = getParameterValue(form, fieldFechaInicial);
			horaInicial = getParameterValue(form, fieldHoraInicial);
			horaFinal = getParameterValue(form, fieldHoraFinal);
			minutoInicial = getParameterValue(form, fieldMinutoInicial);
			minutoFinal = getParameterValue(form, fieldMinutoFinal);

			Date fechaIni = null;
			Date fechaFin = null;
			try {
				fechaFin = df.parse(fechaFinal + " " + horaFinal + ":" + minutoFinal);
			}catch(ParseException e) {
				throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_formato_fecha"), null ));
			}
			try {
				fechaIni = df.parse(fechaInicial + " " + horaInicial + ":" + minutoInicial);
				if(! (DatosUtil.calcularMinutosDiferencia(fechaIni, fechaFin) > new Double(0))){
					throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_fecha_final_menor_inicial"), null ));
				}
				if(diferenciaMeses!=null){
					Calendar calFechaInicial=Calendar.getInstance(); 
					calFechaInicial.setTime(fechaIni);
					calFechaInicial.add(Calendar.MONTH, Integer.parseInt(diferenciaMeses));
					Date nuevaFechaIni = calFechaInicial.getTime();
					if(nuevaFechaIni.compareTo(fechaFin)<0){
						throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_rango_maximo"), null ));
					}
				}
			}catch(ParseException e) {
			}
			
		}
		
	}
	
	private String getFullParameterName(HttpServletRequest hsr, String field) {
		String tmpParam = null;
		for (Object obj : hsr.getParameterMap().keySet().toArray()) {			
			if (obj.toString().endsWith(field)) {
				tmpParam = obj.toString();
				break;
			}
		} 
		return tmpParam;
	}
	
	private String getParameterValue(String formName, String fieldName){
		ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
		HttpServletRequest hsr = (HttpServletRequest) externalContext.getRequest();
		String paramName = getFullParameterName(hsr, fieldName);
        if (paramName == null || paramName.length() == 0) {
        	paramName = formName + ":" + fieldName;
        }
        String param = (String) hsr.getParameter(paramName);
        return param;
	}

}
