package co.com.portales.commonweb.validadores;

import java.util.regex.Pattern;

import co.com.portales.common.contants.IConstants;
import co.com.portales.commonweb.util.DatosUtil;

public class ValidadorDatosFormulario {

	public static final Pattern PATTERN_FORMATO_TELEFONO_CELULAR = Pattern
			.compile("[0-9]\\d{9}");
	public static final Pattern PATTERN_FORMATO_TELEFONO = Pattern
			.compile("[0-9]\\d{6}");
	public static final Pattern PATTERN_FORMATO_EXTENSION_TELEFONO = Pattern
			.compile("[0-9]{1,5}+");
	public static final Pattern PATTERN_FORMATO_CELULAR = Pattern
			.compile("[0-9]\\d{9}");
	// public static final Pattern PATTERN_FORMATO_EMAIL =
	// Pattern.compile("[a-zA-Z0-9._%+-]*+@[a-zA-Z0-9_%+-]*+(\\.[a-zA-Z0-9_%+-]+)+");
	public static final Pattern PATTERN_FORMATO_EMAIL = Pattern
			.compile("[a-zA-Z0-9._-]*+@[a-zA-Z0-9]+[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9]*[a-zA-Z0-9_-]*[a-zA-Z0-9]+)+");
	public static final Pattern PATTERN_FORMATO_DIGITO = Pattern
			.compile("\\d*");
	public static final Pattern PATTERN_FORMATO_HTML = Pattern
			.compile("^((ht|f)tp(s?)\\:\\/\\/|~/|/)?([\\w]+:\\w+@)?"
					+ "([a-zA-Z]{1}([\\w\\-]+\\.)+([\\w]{2,5}))(:[\\d]{1,5})?"
					+ "((/?\\w+/)+|/?)((\\w+\\.[\\w]{3,4})|(\\w+))?((\\?\\w+=\\w+)?"
					+ "(&\\w+=\\w+)*)?");
	public static final Pattern PATTERN_FORMATO_SOLO_LETRAS = Pattern
			.compile("[a-zA-Z������������\\s]*");

	private static final Pattern PATTERN_FORMATO_SOLO_NUMEROS = Pattern
			.compile("[0-9]+");

	private static final Pattern PATTERN_FORMATO_ALFANUMERICO = Pattern
			.compile("[a-zA-Z0-9������������\\s]*");

	private static final Pattern PATTERN_FORMATO_DIRECCION = Pattern
			.compile("[a-zA-Z0-9.\\-#������������\\s]*");

	private static final Pattern PATTERN_FORMATO_GENERAL = Pattern
			.compile("[a-zA-Z0-9.\\-\\/\\(\\)\\_������������\\s]*");

	private static final Pattern PATTERN_FORMATO_IP = Pattern
			.compile("^([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])\\.([01]?\\d\\d?|2[0-4]\\d|25[0-5])$");

	/**
	 * Patrones numeros tarjetas de credito
	 */
	@SuppressWarnings("unused")
	private static final Pattern PATTERN_GENERAL_CARD = Pattern
			.compile("(\\d{1,4})g");
	private static final Pattern PATTERN_VISA_CARD = Pattern.compile("^4");
	private static final Pattern PATTERN_MASTER_CARD = Pattern
			.compile("^5[0-5]");
	private static final Pattern PATTERN_AMERICAN_CARD = Pattern
			.compile("^3[47]");
	private static final Pattern PATTERN_DINERS_CARD = Pattern
			.compile("^3[0689]");

	private static final Pattern PATTERN_EXPIRATION_DATE = Pattern
			.compile("^[0-1][0-9]+(/)+[0-9][0-9]");

	private static final String[] PALABRAS_RESERVADAS = { "script", "SCRIPT",
			"text/javascript", "TEXT/JAVASCRIPT", "SELECT", "select", "FROM",
			"from", "'", "=", "&", "\"", "DROP", "drop", "delete", "DELETE" };

	public ValidadorDatosFormulario() {
		super();
	}

	public static boolean validarCampoSoloTexto(String campoTexto) {
		boolean valido = true;
		if (DatosUtil.validarCadenaNulaVacia(campoTexto)) {
			if (PATTERN_FORMATO_SOLO_LETRAS.matcher(campoTexto).matches()) {
				valido = true;
			} else {
				valido = false;
			}
		}
		return valido;
	}

	public static boolean validarCampoIP(String ip) {
		boolean valido = true;
		if (DatosUtil.validarCadenaNulaVacia(ip)) {
			if (PATTERN_FORMATO_IP.matcher(ip).matches()) {
				valido = true;
			} else {
				valido = false;
			}
		}
		return valido;
	}

	public static boolean validarCampoAlfanumerico(String campoTexto) {
		boolean valido = true;
		if (DatosUtil.validarCadenaNulaVacia(campoTexto)) {
			if (PATTERN_FORMATO_ALFANUMERICO.matcher(campoTexto).matches()) {
				valido = true;
			} else {
				valido = false;
			}
		}
		return valido;
	}

	public static boolean validarFechaExpiracion(String campoTexto) {
		boolean valido = true;
		if (DatosUtil.validarCadenaNulaVacia(campoTexto)) {
			if (PATTERN_EXPIRATION_DATE.matcher(campoTexto).matches()) {
				valido = true;
			} else {
				valido = false;
			}
		}
		return valido;
	}

	public static boolean validarNumeroFranquicia(String numeroTarjeta,
			String idFranquicia) {
		boolean valido = true;
		if (IConstants.ID_VISA.equals(idFranquicia)) {
			if (PATTERN_VISA_CARD.matcher(numeroTarjeta).find()) {
				if (numeroTarjeta.trim().length() == 13
						|| numeroTarjeta.trim().length() == 16) {
					valido = true;
				} else {
					valido = false;
				}
			} else {
				valido = false;
			}
		} else if (IConstants.ID_MASTER.equals(idFranquicia)) {
			if (PATTERN_MASTER_CARD.matcher(numeroTarjeta).find()) {
				if (numeroTarjeta.trim().length() == 16) {
					valido = true;
				} else {
					valido = false;
				}
			} else {
				valido = false;
			}
		} else if (IConstants.ID_AMERICAN.equals(idFranquicia)) {
			if (PATTERN_AMERICAN_CARD.matcher(numeroTarjeta).find()) {
				if (numeroTarjeta.trim().length() == 15) {
					valido = true;
				} else {
					valido = false;
				}
			} else {
				valido = false;
			}
		} else if (IConstants.ID_DINERS.equals(idFranquicia)) {
			if (PATTERN_DINERS_CARD.matcher(numeroTarjeta).find()) {
				if (numeroTarjeta.trim().length() == 14) {
					valido = true;
				} else {
					valido = false;
				}
			} else {
				valido = false;
			}
		} else {
			valido = false;
		}
		if (valido) {
			int sum = 0;
			String[] numeros = numeroTarjeta.split("");
			boolean odd = false;
			for (int i = numeros.length - 1; i > 0; i--) {
				int valor = Integer.parseInt(numeros[i]);
				if (odd) {
					valor = valor * 2;
				}
				if (valor > 9) {
					valor = valor - 9;
				}
				odd = !odd;
				sum += valor;
			}
			if (sum % 10 != 0) {
				valido = false;
			}
		}
		return valido;
	}

	public static boolean validarDireccion(String campoTexto) {
		boolean valido = true;
		if (DatosUtil.validarCadenaNulaVacia(campoTexto)) {
			if (PATTERN_FORMATO_DIRECCION.matcher(campoTexto).matches()) {
				valido = true;
			} else {
				valido = false;
			}
		}
		return valido;
	}

	public static boolean validarFormatoGenerico(String campoTexto) {
		boolean valido = true;
		if (DatosUtil.validarCadenaNulaVacia(campoTexto)) {
			if (PATTERN_FORMATO_GENERAL.matcher(campoTexto).matches()) {
				valido = true;
			} else {
				valido = false;
			}
		}
		return valido;
	}

	/**
	 * 
	 * @param campoNumerico
	 * @return retorna true si el campo tiene solo numeros, de lo contrario
	 *         false
	 */
	public static boolean validarCampoSoloNumeros(String campoNumerico) {

		boolean respuesta = true;

		if (!PATTERN_FORMATO_SOLO_NUMEROS.matcher(campoNumerico).matches()) {

			respuesta = false;
		}

		return respuesta;
	}

	public static boolean validarTelefonoFijoLocal(String numeroTelefono) {
		boolean valido = true;
		if (DatosUtil.validarCadenaNulaVacia(numeroTelefono)) {
			if (PATTERN_FORMATO_TELEFONO.matcher(numeroTelefono).matches()) {
				String prefijo = numeroTelefono.substring(0, 1);
				if ("1".equals(prefijo) || "0".equals(prefijo)) {
					// Por regla de negocio, un telefono fijo no puede iniciar
					// por 0 ni 1
					valido = false;
				}
			} else {
				valido = false;
			}
		} else {
			valido = false;
		}
		return valido;
	}

	public static boolean validarCedulaCiudadania(String numeroCedulaCiudadania) {
		boolean valido = true;
		if (DatosUtil.validarCadenaNulaVacia(numeroCedulaCiudadania)) {
			// La longitud no puede ser igual a 9 d�gitos ni mayor a 10.
			int longitud = numeroCedulaCiudadania.length();
			if (longitud == 9 || longitud > 10) {
				valido = false;
			} else if (longitud < 9) {
				// Si la longitud es menor de 9 d�gitos el valor no puede ser
				// menor de 100 ni mayor de 99999999
				long numero = new Long(numeroCedulaCiudadania);
				valido = numero > 100 && numero < 99999999L;
				// Por decision de reunion, no se ejecutara esto:
				// Si la longitud es menor
				// de 9 d�gitos se valida que
				// el rango corresponda al
				// lugar de expedici�n (ver
				// tabla de rangos)
			} else if (longitud == 10) {
				// Si la longitud es de 10 d�gitos el valor no puede ser menor
				// que 1000000000 ni mayor que 1999999999
				long numero = new Long(numeroCedulaCiudadania);
				valido = numero > 1000000000L && numero < 1999999999L;
			}
		}
		return valido;
	}

	public static boolean validarCedulaCiudadania(
			String numeroCedulaCiudadania, String genero) {
		boolean valido = validarCedulaCiudadania(numeroCedulaCiudadania);

		if (DatosUtil.validarCadenaNulaVacia(genero)
				&& DatosUtil.validarCadenaNulaVacia(numeroCedulaCiudadania)
				&& numeroCedulaCiudadania.length() < 9) {
			long numero = new Long(numeroCedulaCiudadania);
			if ("F".equals(genero)) {
				// Si el g�nero es femenino y la longitud es menor de 9 d�gitos
				// �l numero de cedula debe ser mayor que 19999999 y menor que
				// 70000000
				valido &= numero > 19999999L && numero < 70000000L;
			} else if ("M".equals(genero)) {
				// cuando �l genero es masculino los n�meros de cedula no deben
				// estar en estos rangos.
				valido &= !(numero > 19999999L && numero < 70000000L);
			}
		}
		return valido;
	}

	public static boolean validarCedulaExtranjeria(
			String numeroCedulaExtranjeria) {
		boolean valido = true;
		if (DatosUtil.validarCadenaNulaVacia(numeroCedulaExtranjeria)) {
			// Longitud debe ser menor que 7 d�gitos
			valido = numeroCedulaExtranjeria.length() < 7;
		}
		return valido;
	}

	public static boolean validarTarjetaIdentidad(String numeroTarjetaIdentidad) {

		if (DatosUtil.validarCadenaNulaVacia(numeroTarjetaIdentidad)) {

			if (numeroTarjetaIdentidad.length() == 10
					|| numeroTarjetaIdentidad.length() == 11) {

				if (numeroTarjetaIdentidad.length() == 10) {
					String primerosDigitos = numeroTarjetaIdentidad.substring(
							0, 1);

					if (!("1".equals(primerosDigitos))) {
						return false;
					}
				}

				else if (numeroTarjetaIdentidad.length() == 11) {

					int anio = Integer.parseInt(numeroTarjetaIdentidad
							.substring(0, 2));
					int mes = Integer.parseInt(numeroTarjetaIdentidad
							.substring(2, 4));
					int dia = Integer.parseInt(numeroTarjetaIdentidad
							.substring(4, 6));

					if (anio < 93 || anio > 99) {
						return false;
					} else if (mes < 1 || mes > 12) {
						return false;
					} else if (dia < 1 || dia > 31) {
						return false;
					}
				}
				return true;
			} else {
				return false;
			}
		}
		return false;
	}

	public static boolean validarCorreoElectronico(String correoElectronico) {
		return PATTERN_FORMATO_EMAIL.matcher(correoElectronico).matches();
	}

	/**
	 * Valida el valor que retorna un String para evitar valores nulos que
	 * puedan ocasionar NullPointerException.
	 * 
	 * @param value
	 * @return
	 */
	public static String validateStringValue(String value) {
		return isNullString(value) ? "" : value;
	}

	/**
	 * Valida que un string sea nulo o contenga valores nulos
	 * 
	 * @param text
	 * @return
	 */
	public static boolean isNullString(String text) {
		return (text == null || "".equals(text.trim()));
	}

	/**
	 * Valida que sean iguales dos valores no nulos, si alguno de los dos es
	 * nulo retornar� falso.
	 * 
	 * @param text1
	 * @param text2
	 * @return
	 */
	public static boolean isEqualNotNullValues(String text1, String text2) {
		return !isNullString(text1) && !isNullString(text2)
				&& text1.equalsIgnoreCase(text2);
	}

	public static boolean validarPalabrasReservadas(String cadena) {
		boolean valido = true;
		for (String dat : PALABRAS_RESERVADAS) {
			if (cadena.contains(dat)) {
				valido = false;
				break;
			}
		}
		return valido;
	}

	public static boolean validarTelefono(String cadena) {
		boolean valido = true;
		if (PATTERN_FORMATO_TELEFONO_CELULAR.matcher(cadena).matches()) {
			String prefijo = cadena.substring(0, 1);
			if (!("3".equals(prefijo))) {
				// Por regla de negocio, un telefono celular no puede iniciar
				// por un muero diferente de 3
				valido = false;
			}
		} else {
			valido = false;
		}
		return valido;

	}
	//fucion para validar que sea diferente a cero
	public static boolean validarTelefonoOtr(String cadena) {
		boolean valido = true;
		//if (PATTERN_FORMATO_TELEFONO_CELULAR.matcher(cadena).matches()) {
			String prefijo = cadena.substring(0, 1);
			if (("3".equals(prefijo))) {
				// Por regla de negocio, un telefono celular de otro pais debe empezar
				// por un muero diferente de 3
				valido = false;
			}
		//} else {
		//	valido = false;
		//}
		return valido;

	}
	
}
