package co.com.portales.commonweb.validadores;



import java.text.MessageFormat;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;
import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import javax.servlet.http.HttpServletRequest;
import org.apache.log4j.Logger;


/**
 * @author proveedor_cacortes
 */
public class CompareValidator implements Validator{	
	private ResourceBundle commonBundle;
    private String VALIDATE_FIELD = "validateField";
    private String FORM = "form";
    private String FIELD = "Field";
    private String COMPARE_FIELD = "compareField";
    private String compareValue;
    private String myForm;
    Map<String, String[]> map;
	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		commonBundle = ResourceBundle.getBundle("co.com.portales.commonweb.bundle.mensajes_validaciones");
		try {
			ExternalContext externalContext = context.getExternalContext();
			HttpServletRequest hsr = (HttpServletRequest) externalContext.getRequest();			
			myForm = (String)component.getAttributes().get(FORM);
			map = hsr.getParameterMap();
			Iterator<Entry<String, String[]>> iterator = map.entrySet().iterator();
		    while (iterator.hasNext()) {
		    	Entry<String, String[]> entry = (Entry<String, String[]>) iterator.next();
		    	String mapParam =  entry.getKey().toString();
		    	if(mapParam.contains(myForm+":"+(String) component.getAttributes().get(VALIDATE_FIELD))){
		    		compareValue = (String) hsr.getParameter(mapParam);	
		    		break;
		    	}
			}
			// validamos si el valor de los dos campos es el mismo 
		    if (!value.toString().equals(compareValue)) {
				throw new ValidatorException(new FacesMessage(null,MessageFormat.format(commonBundle.getString("error_general_compareValidator"),(String)component.getAttributes().get(FIELD),(String)component.getAttributes().get(COMPARE_FIELD))));
			}
		} catch (Throwable t) {
			Logger.getLogger(this.getClass()).debug(t.getMessage());
			throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_ERROR, t.getMessage(),null));
		}

	}
}
