package co.com.portales.commonweb.validadores;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

public class AlphaNumericValidator implements Validator {

	private ResourceBundle bundleCategorias;
	
	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		bundleCategorias = ResourceBundle.getBundle("co.com.portales.commonweb.bundle.mensajes_validaciones");
		// validamos si el campo es alfa numerico
		if (!ValidadorDatosFormulario.validarCampoAlfanumerico(value.toString())) {
			throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_general_soloLetras"), null ));
		}
	}
}
