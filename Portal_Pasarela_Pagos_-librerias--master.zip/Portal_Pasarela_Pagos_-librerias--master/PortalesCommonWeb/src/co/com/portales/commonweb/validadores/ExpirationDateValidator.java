package co.com.portales.commonweb.validadores;

import java.util.Calendar;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

public class ExpirationDateValidator implements Validator {
	
private ResourceBundle bundleCategorias;
	
	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		bundleCategorias = ResourceBundle.getBundle("co.com.portales.commonweb.bundle.mensajes_validaciones");
		String rangoAnios = (String) component.getAttributes().get("rango_anios");
		if(value==null||value.toString()==null||value.toString().equalsIgnoreCase("null")){
			throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_campo_requerido"), null ));
		}else{
			String fechaExpiracion = value.toString();
			if (!ValidadorDatosFormulario.validarFechaExpiracion(fechaExpiracion)) {
				throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("mensaje_formato_campo"), null ));
			}
			try{
				int mes = Integer.parseInt(fechaExpiracion.substring(0, 2));
				if(mes<1||mes>12){
					throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("mensaje_formato_campo"), null ));
				}
			}catch (Exception e) {
				throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("mensaje_formato_campo"), null ));
			}
			int anioVencimiento = Integer.parseInt(fechaExpiracion.substring(3, 5));
			Calendar now = Calendar.getInstance();   // Gets the current date and time
			int anioActual = Integer.parseInt(String.valueOf(now.get(Calendar.YEAR)).substring(2, 4));
			int mesVencimiento = Integer.parseInt(fechaExpiracion.substring(0, 2));
			int mesActual = Integer.parseInt(String.valueOf(now.get(Calendar.MONTH)))+1;
			if(rangoAnios==null || rangoAnios.trim().equalsIgnoreCase("") || rangoAnios.trim().equalsIgnoreCase("null")){
				if(anioVencimiento-anioActual > 10){
					throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_rango_anio_vencimiento"), null ));
				}
			}else{				
				if(anioVencimiento-anioActual > Integer.parseInt(rangoAnios)){
					throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_rango_anio_vencimiento"), null ));
				}
			}
			if(anioVencimiento<anioActual ){
				throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_fecha_no_valida"), null ));
			}else if(anioVencimiento == anioActual && mesVencimiento < mesActual){
				throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_fecha_no_valida"), null ));
			}
		}
	}

}
