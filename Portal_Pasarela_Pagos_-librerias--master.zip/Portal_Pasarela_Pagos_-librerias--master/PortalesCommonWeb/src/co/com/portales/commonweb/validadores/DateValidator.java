package co.com.portales.commonweb.validadores;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import javax.servlet.http.HttpServletRequest;

import co.com.portales.common.contants.IConstants;

public class DateValidator implements Validator {
	
	private ResourceBundle bundleCategorias;
	
	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		
		bundleCategorias = ResourceBundle.getBundle("co.com.portales.commonweb.bundle.mensajes_validaciones");
		String fecha = (String) value;
		String fieldHoraInicial = (String) component.getAttributes().get(IConstants.CAMPO_HORA_INICIAL);
		String fieldMinutoInicial = (String) component.getAttributes().get(IConstants.CAMPO_MINUTO_INICIAL);
		String hora = null;
		String minuto = null;
		String form = component.getParent().getId();
		String formatoFecha = (String) component.getAttributes().get(IConstants.CAMPO_FORMATO_FECHA);
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		if(formatoFecha!=null && !("".equals(formatoFecha.trim()))){
			df = new SimpleDateFormat(formatoFecha);
		}
		if(fecha==null||"".equals(fecha)){
			throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_fecha_inicial_obligatoria"), null ));
		}else{
			hora = getParameterValue(form, fieldHoraInicial);
			minuto = getParameterValue(form, fieldMinutoInicial);
			try {
				df.parse(fecha + " " + hora + ":" + minuto);
			}catch(ParseException e) {
				throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_formato_fecha"), null ));
			}
		}
		
	}
	
	private String getFullParameterName(HttpServletRequest hsr, String field) {
		String tmpParam = null;
		for (Object obj : hsr.getParameterMap().keySet().toArray()) {			
			if (obj.toString().endsWith(field)) {
				tmpParam = obj.toString();
				break;
			}
		} 
		return tmpParam;
	}
	
	private String getParameterValue(String formName, String fieldName){
		ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
		HttpServletRequest hsr = (HttpServletRequest) externalContext.getRequest();
		String paramName = getFullParameterName(hsr, fieldName);
        if (paramName == null || paramName.length() == 0) {
        	paramName = formName + ":" + fieldName;
        }
        String param = (String) hsr.getParameter(paramName);
        return param;
	}

}
