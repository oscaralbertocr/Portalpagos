package co.com.portales.commonweb.validadores;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import javax.servlet.http.HttpServletRequest;

import co.com.portales.common.contants.IConstants;

public class FileNameValidator implements Validator {

	private ResourceBundle bundleCategorias;
	
	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		bundleCategorias = ResourceBundle.getBundle("co.com.portales.commonweb.bundle.mensajes_validaciones");
		String nombreArchivo = null;
		String idExtensionArchivo = null;
		String fieldExtension = (String) component.getAttributes().get(IConstants.CAMPO_EXTENSION_ARCHIVO);
		String form = component.getParent().getId();
		String longitudNombreArchivo = (String) component.getAttributes().get("longitudNombreArchivo");
		if(value != null){
			nombreArchivo = value.toString();
		}
		// validamos si el campo es solo texto
		if (nombreArchivo == null || "".equals(nombreArchivo.trim())) {
			throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_nombre_archivo_en_blanco"), null ));
		}
		if (nombreArchivo.contains(" ")) {
			throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_nombre_archivo_espacios"), null ));
		}
		if(fieldExtension!=null){
			idExtensionArchivo = getParameterValue(form, fieldExtension);
			String extensionArchivo = "." + IConstants.tiposArchivo.get(Integer.parseInt(idExtensionArchivo));
			if (nombreArchivo.endsWith(extensionArchivo)) {
				throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_nombre_archivo_con_ext"), null ));
			}
		}
		if(longitudNombreArchivo!=null){
			if (nombreArchivo.length()>Integer.parseInt(longitudNombreArchivo)) {
				throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_nombre_archivo_con_ext"), null ));
			}
		}
		// validamos si el campo es solo texto
		if (!ValidadorDatosFormulario.validarCampoAlfanumerico(nombreArchivo)) {
			throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_WARN, bundleCategorias.getString("error_nombre_archivo_solo_letras"), null ));
		}
	}
	
	private String getFullParameterName(HttpServletRequest hsr, String field) {
		String tmpParam = null;
		for (Object obj : hsr.getParameterMap().keySet().toArray()) {			
			if (obj.toString().endsWith(field)) {
				tmpParam = obj.toString();
				break;
			}
		} 
		return tmpParam;
	}
	
	private String getParameterValue(String formName, String fieldName){
		ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
		HttpServletRequest hsr = (HttpServletRequest) externalContext.getRequest();
		String paramName = getFullParameterName(hsr, fieldName);
        if (paramName == null || paramName.length() == 0) {
        	paramName = formName + ":" + fieldName;
        }
        String param = (String) hsr.getParameter(paramName);
        return param;
	}
}
