package co.com.portales.commonweb.converters;

import java.math.BigDecimal;
import java.text.DecimalFormat;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;

import org.apache.log4j.Logger;

public class MontoConverter implements Converter {
	
	/**
	 * Variable encargada de manejar los logs de la aplicaci�n.
	 */
	private static Logger log = Logger.getLogger(MontoConverter.class);

	@Override
	public Object getAsObject(FacesContext context, UIComponent component, String value) {
		return null;
	}

	@Override
	public String getAsString(FacesContext context, UIComponent component, Object value) {
		String montoFormateado = "";
		try{
			String simboloMoneda = (String) component.getAttributes().get("simboloMoneda");
			DecimalFormat formateador = new DecimalFormat("###,###.##");
			montoFormateado = formateador.format(new BigDecimal(value.toString()));
			if(simboloMoneda!=null){
				montoFormateado = simboloMoneda + montoFormateado;
			}
		}catch (Exception eException) {
			log.error("::: SE PRESENTARON PROBLEMAS AL FORMATEAR EL VALOR " + value + " :::", eException);
			try{
				montoFormateado = value.toString();
			}catch (Exception e) {
				montoFormateado = "";
			}
		}
		return montoFormateado;
	}

}
