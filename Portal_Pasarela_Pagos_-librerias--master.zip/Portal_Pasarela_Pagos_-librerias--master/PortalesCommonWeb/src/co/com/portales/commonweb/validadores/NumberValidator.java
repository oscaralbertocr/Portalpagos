/**
 * @author ATH
 * Clase que implementa la interface Valdator, para garantizar solo contenido 
 * numerico dentro del componente que dispara la validacion. 
 */

package co.com.portales.commonweb.validadores;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

public class NumberValidator implements Validator{
	
	private ResourceBundle bundleCategorias;
	
	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		bundleCategorias = ResourceBundle.getBundle("co.com.portales.commonweb.bundle.mensajes_validaciones");	
		// validamos si el campo tiene solo n�meros
		if(value != null){
			if (value.toString().length() > 0 && !ValidadorDatosFormulario.validarCampoSoloNumeros(value.toString())) {
				throw new ValidatorException(new FacesMessage(bundleCategorias.getString("error_general_soloNumeros"), null));
			}
		}
	}

}
