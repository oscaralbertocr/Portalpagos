package co.com.portales.commonweb.util;


import java.util.Map;
import java.util.Properties;

import javax.faces.application.Application;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import co.com.pasarelapagos.dto.ComercioDTO;
import co.com.pasarelapagos.dto.UsuarioDTO;
import co.com.portales.common.exceptions.LDAPException;
import co.com.portales.common.ldap.LDAPAccess;
import co.com.portales.common.util.PropertiesLoader;

/**
 * Locator para acceso a objetos Web (JSF, Preferences)
 * @author ATH
 *
 */
public class WebLocator {
	
	
	protected static Logger log = Logger.getLogger(WebLocator.class);
	
	
	/**
	 * Variable de instancia
	 */
	private static WebLocator instance;
	
	
	static Properties propertiesError;
	
	static {
		try {
			PropertiesLoader propertiesLoader = PropertiesLoader.getInstance();			
			propertiesError = propertiesLoader.getProperties("error.properties");

		} catch (Exception e) {
			Logger.getLogger(WebLocator.class).error(e);
		}
	}
	
	
	/**
	 * M�todo que recupera la instancia del <code>ServiceLocator</code>.
	 * 
	 * @return
	 * @throws ServiceException
	 */
	static public WebLocator getInstance() {
		if (instance == null) {
			instance = new WebLocator();
		}
		return instance;
	}
	
	

	protected static Application getApplication() {
		return FacesContext.getCurrentInstance().getApplication();
	}

	public static ExternalContext getExternalContext() {
		try {
			FacesContext context = FacesContext.getCurrentInstance();
			ExternalContext externalContext = null;

			if ((null != context) && (null != context.getExternalContext())) {
				externalContext = context.getExternalContext();
			}

			return externalContext;
		} catch (Throwable t) {
			log.error(t);
		}
		return null;
	}

	/**
	 * Recupera el objeto Request
	 * 
	 * @return
	 */
	public static HttpServletRequest getRequest() {
		try {
			FacesContext context = FacesContext.getCurrentInstance();
			HttpServletRequest request = null;

			if ((null != context) && (null != context.getExternalContext())) {
				request = (HttpServletRequest) context.getExternalContext().getRequest();
			}

			return request;
		} catch (Throwable t) {
			log.error(t);
		}
		return null;
	}

	/**
	 * Recupera el objeto Request
	 * 
	 * @return
	 */
	public static HttpServletResponse getResponse() {
		try {
			FacesContext context = FacesContext.getCurrentInstance();
			HttpServletResponse response = null;

			if ((null != context) && (null != context.getExternalContext())) {
				response = (HttpServletResponse) context.getExternalContext().getResponse();
			}

			return response;
		} catch (Throwable t) {
			log.error(t);
		}
		return null;
	}

	/**
	 * Recupera el objeto RequestMap
	 * 
	 * @return
	 */
	public static Map<String, Object> getRequestMap() {
		try {
			FacesContext context = FacesContext.getCurrentInstance();
			return context.getExternalContext().getRequestMap();
		} catch (Throwable t) {
			log.error(t);
		}
		return null;
	}

	/**
	 * 
	 * @param param
	 * @return
	 */
	public static String getRequestParameterMap(String param) {
		try {
			FacesContext context = FacesContext.getCurrentInstance();
			return context.getExternalContext().getRequestParameterMap().get(param);
		} catch (Throwable t) {
			log.error(t);
		}
		return null;
	}

	/**
	 * Recupera el objeto session
	 * 
	 * @return
	 */
	public static HttpSession getSession() {
		try {
			HttpSession session = getRequest().getSession();
			return session;
		} catch (Throwable t) {
			log.error(t);
		}
		return null;
	}

	/**
	 * Recupera el objeto session
	 * 
	 * @param arg
	 * @return
	 */
	public static HttpSession getSession(boolean arg) {
		try {
			HttpSession session = getRequest().getSession(arg);
			return session;
		} catch (Throwable t) {
			log.error(t);
		}
		return null;
	}

	/**
	 * Recupera el objeto SessionMap
	 * 
	 * @return
	 */
	public static Map<String, Object> getSessionMap() {
		try {
			FacesContext context = FacesContext.getCurrentInstance();
			return context.getExternalContext().getSessionMap();
		} catch (Throwable t) {
			log.error(t);
		}
		return null;
	}

	/**
	 * Recupera el objeto del SessionMap
	 * 
	 * @param parametro
	 * @return
	 */
	public static Object getSessionMap(String parametro) {
		return getSessionMap().get(parametro);
	}

	/**
	 * Recupera el String de un obketo en el SessionMap
	 * 
	 * @param parametro
	 * @return
	 */
	public static String getStringSessionMap(String parametro) {
		return (String) getSessionMap(parametro);
	}

	/**
	 * Establece un atributo en el Session
	 * 
	 * @param nombre
	 * @param parametro
	 */
	public static void setSessionAttribute(String nombre, Object parametro) {
		getSession().setAttribute(nombre, parametro);
	}

	/**
	 * Establece un objeto en el SessionMap
	 * 
	 * @param nombre
	 * @param parametro
	 */
	public static void setSessionMap(String nombre, Object parametro) {
		getSessionMap().put(nombre, parametro);
	}

	/**
	 * Establece un obketo en el RequestMap
	 * 
	 * @param nombre
	 * @param parametro
	 */
	public static void setRequestMap(String nombre, Object parametro) {
		getRequestMap().put(nombre, parametro);
	}

	/**
	 * 
	 * @return
	 */
	public static String getIdSesion() {
		String idSesion = getSession() != null ? getSession().getId() : "";
		return idSesion;
	}

	/**
	 * Metodo que monta un mensaje de error en el contexto del faces
	 * 
	 * @param mensaje
	 */
	public static void addMessageFacesError(String codigo, String keyDescription) {

		StringBuilder mensaje = null;
		try {
			mensaje = new StringBuilder(codigo);
			mensaje.append(" : ");
			mensaje.append(propertiesError.getProperty(keyDescription));
			FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, mensaje.toString(),
					mensaje.toString());
			FacesContext.getCurrentInstance().addMessage(null, msg);
		} catch (Exception e) {
			FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					propertiesError.getProperty("error_general"), propertiesError.getProperty("error_general"));
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}

	}

	/**
	 * Metodo que monta un mensaje de error en el contexto del faces
	 * 
	 * @param mensaje
	 */
	public static void addMessageFacesError(String keyDescription) {

		StringBuilder mensaje = null;
		try {
			mensaje = new StringBuilder(propertiesError.getProperty(keyDescription));
			FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR, mensaje.toString(),
					mensaje.toString());
			FacesContext.getCurrentInstance().addMessage(null, msg);
		} catch (Exception e) {
			FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_ERROR,
					propertiesError.getProperty("error_general"), propertiesError.getProperty("error_general"));
			FacesContext.getCurrentInstance().addMessage(null, msg);
		}

	}
	

	/**
	 * Metodo que monta un mensaje informativo en el contexto del faces
	 * 
	 * @param mensaje
	 */
	public static void addMessageFacesInfo(String mensaje) {
		FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_INFO, mensaje, mensaje);
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	/**
	 * Metodo que monta un mensaje fatal en el contexto del faces,
	 * 
	 * @param mensaje
	 */
	public static void addMessageFacesFatal(String mensaje) {
		FacesMessage msg = new FacesMessage(FacesMessage.SEVERITY_FATAL, mensaje, mensaje);
		FacesContext.getCurrentInstance().addMessage(null, msg);
	}

	public static PortletPreferences getPreferences() {
		WebLocator.getInstance();
		PortletRequest request = (PortletRequest) WebLocator.getRequest();
		return request.getPreferences();
	}
	
	/**
	 * Recupera el usuario que se encuentra en sesi�n
	 * 
	 * @return
	 */
	 public static UsuarioDTO getUserSesion()
	  {
	    UsuarioDTO usuario = null;
	    if ((getRequest() != null) && (getRequest().getUserPrincipal() != null))
	    {
	      String userAutenticado = "";
	      String userPortal = getRequest().getUserPrincipal().getName();
	      userPortal = userPortal.replace("cn=", "");
	      String[] datosUser = userPortal.split(",");
	      if (datosUser.length > 0) {
	        for (int i = 0; i < datosUser.length; i++) {
	          if (i == 0) {
	            userAutenticado = datosUser[i];
	          }
	        }
	      }
	      ComercioDTO comercio = new ComercioDTO();
	      if (userAutenticado.indexOf("_") > 0)
	      {
	        String nombreComercioTDS = userAutenticado.substring(userAutenticado.indexOf("_") + 1);
	        LDAPAccess ldap = new LDAPAccess(nombreComercioTDS);
	        try
	        {
	          log.info("Usuarion en sesion:" + userAutenticado);
	          usuario = ldap.searchUserVoByUsername(userAutenticado);
	          comercio = ldap.searchComercioByName(nombreComercioTDS);
	        }
	        catch (LDAPException e)
	        {
	          log.error("No se encontr� el usuario en el ldap " + userAutenticado);
	        }
	        usuario.setComercio(comercio);
	      }
	      else
	      {
	        log.error("No se pudo reconocer el comercio del usuario " + userAutenticado);
	      }
	    }
	    else
	    {
	      log.error("No se encuentra ningun usuario autenicado en el portal");
	    }
	    return usuario;
	  }

	/**
	 * Metodo que devuelve un mensaje de error dependiendo del c�digo recibido
	 * 
	 * @param mensaje
	 */
	public static String getMessageError(String keyDescription) {

		String mensaje = "";
		try {
			mensaje = propertiesError.getProperty(keyDescription);
		} catch (Exception e) {
			log.error(e.getMessage());
			log.error("No se encontr� el mensaje de error con c�digo "+keyDescription);
		}
		return mensaje;
	}
	
}
