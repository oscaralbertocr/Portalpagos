package co.com.portales.commonweb.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;

import co.com.portales.common.contants.IConstants;

public class DatosUtil {
	private static final DecimalFormat decimalFormatMoneda = new DecimalFormat("$#,###,###.00");
	private static final DecimalFormat decimalFormatMoneda2 = new DecimalFormat("$#,###,###");
	private static final DecimalFormat decimalFormat3_2 = new DecimalFormat("###.00");
	private static final DecimalFormat decimalFormatPorcentaje = new DecimalFormat("#0.00");
	private static final DecimalFormat integerFormat = new DecimalFormat("#");
	private static final Logger log = Logger.getLogger(DatosUtil.class);

	static {
		DecimalFormatSymbols dfs = new DecimalFormatSymbols();
		dfs.setGroupingSeparator(',');
		dfs.setDecimalSeparator('.');
		decimalFormatMoneda.setDecimalFormatSymbols(dfs);
		decimalFormatMoneda.setParseBigDecimal(true);
		decimalFormatMoneda.setParseIntegerOnly(true);

		decimalFormatMoneda2.setDecimalFormatSymbols(dfs);
		decimalFormatMoneda2.setParseBigDecimal(true);
		decimalFormatMoneda2.setParseIntegerOnly(true);

		
		decimalFormat3_2.setDecimalFormatSymbols(dfs);
		decimalFormat3_2.setParseIntegerOnly(false);
	}

	public static void addToMDC(String cadena, Object valor)
	{
		//Se eliminaron los cambios de formato para centralizarlo en log4j.properties
		if (valor != null) {
			MDC.put( cadena , "".equals(valor) ? " " : valor);
		}		
	}
	
	public static void removeToMDC(String cadena){
		MDC.remove(cadena);
	}
	

	public static String reemplazarCaracteresEspecialesMayuscula(String origen) {
		StringBuffer sb = null;
		if (origen != null) {
			int longitud = origen.length();
			sb = new StringBuffer(longitud);
			Pattern patron = Pattern.compile("[A-Za-z0-9]+");
			Matcher macheo = patron.matcher(origen);
			if (!macheo.matches()) {
				if (longitud > 0) {
					char[] chars = new char[longitud];
					origen.getChars(0, longitud, chars, 0);
					for (int i = 0; i < longitud; i++) {
						int c = chars[i];
						switch (c) {
						case 225:
						case 193:
							chars[i] = 'A';
							break;
						case 233:
						case 201:
							chars[i] = 'E';
							break;
						case 237:
						case 205:
							chars[i] = 'I';
							break;
						case 243:
						case 211:
							chars[i] = 'O';
							break;
						case 250:
						case 218:
							chars[i] = 'U';
							break;
						case 241:
						case 209:
							chars[i] = 'N';
							break;
						default:
							chars[i] = (char) Character.toUpperCase(c);
							break;
						}
					}
					sb.append(chars);
				}
			}
		}
		return sb.toString();
	}

	
	
	public static final Long promedioLong(Long... nums) {
		Long resultado = 0L;
		if (nums != null) {
			int cuantos = 0;
			for (Long num : nums) {
				resultado += num;
				cuantos++;
			}
			resultado = resultado / cuantos;
		}
		return resultado;
	}

	
	/**
	 * perimte valida si una cadena de caracteres enviada contine solo
	 * caracteres correspondientes a los numeros del 0 a 9
	 * 
	 * @return false si la cadena contiene caracteres no numericos, si es vacia
	 *         o es nula, de lo contrario true
	 */
	
	
	public static Integer longToInteger(Long valorLong) {
		Integer valorInteger = null;
		if (valorLong != null) {
			try {
				valorInteger = valorLong.intValue();
			} catch (Exception ex) {
				// no se hace nada solo se devuelve nulo
				log.error(ex);
			}
		}
		return valorInteger;
	}

	public static String objectToString(Object objeto) {
		String respuesta = "";
		if (objeto != null) {
			respuesta = objeto.toString();
		}
		return respuesta;
	}

	public static Long stringToLong(String valor) {
		Long respuesta = 0L;
		if (valor != null) {
			try {
				respuesta = Long.parseLong(valor);
			} catch (Exception ex) {
				// no se hace nada simplemente se retorna el objeto nulo.
				log.error(ex);
			}
		}
		return respuesta;
	}
	
    
    public static Long stringToLongNull(String valor) {
        if (valor != null) {
            try {
                return  Long.parseLong(valor);
            } catch (Exception ex) {
                // no se hace nada simplemente se retorna el objeto nulo.
                log.error(ex);
            }
        }
        return null;
    }

	public static Short stringToShort(String valor) {
		Short respuesta = null;
		if (valor != null) {
			try {
				respuesta = Short.parseShort(valor.trim());
			} catch (Exception ex) {
				// no se hace nada simplemente se retorna el objeto nulo.
				log.error(ex);
			}
		}
		return respuesta;
	}

	public static BigInteger stringMonedaToBigInteger(String numeroFormatoMoneda) {
		BigInteger retorno = BigInteger.ZERO;
		if (numeroFormatoMoneda != null) {
			if(!("N/A".equals(numeroFormatoMoneda))){
				try {
					BigDecimal d = null;
					if("$.00".equals(numeroFormatoMoneda)){
						d = (BigDecimal) decimalFormatMoneda.parse("$0");
					}else{
						d = (BigDecimal) decimalFormatMoneda.parse(numeroFormatoMoneda);
					}
					retorno = d.unscaledValue();
				} catch (ParseException e) {
					// no se hace nada simplemente se retorna el objeto nulo.
					log.error(e);
				}
			}
		}
		return retorno;
	}

	public static BigInteger stringToBigInteger2(String numero) {
		BigInteger resultado = BigInteger.ZERO;
		if (numero != null) {
			try {
				resultado = BigInteger.valueOf(new Long(numero));
			} catch (Exception ex) {
				log.error(ex);

			}
		}
		return resultado;
	}

	public static String formatearAMoneda(Long numero) {
		if (numero == null) {
			numero = new Long(0);
		}
		BigInteger numeroB = new BigInteger("" + numero);
		return formatearAMoneda(numeroB);
	}

	public static String formatearAMoneda(BigInteger numero) {
		String numeroFormateado = null;
		if (numero == null) {
			numero = BigInteger.ZERO;
			numeroFormateado =  decimalFormatMoneda.format(numero);
		}else if(numero != null && BigInteger.ZERO.equals(numero)){
			numeroFormateado =  decimalFormatMoneda.format(numero);
		}else if(numero != null && !BigInteger.ZERO.equals(numero)){
			numeroFormateado =  decimalFormatMoneda2.format(numero);
		}
		return numeroFormateado;
	}

	public static String formatearA3_2(BigDecimal numero) {
		if (numero == null) {
			numero = BigDecimal.ZERO;
		}
		return decimalFormat3_2.format(numero);
	}

	public static String formatearAMoneda(BigDecimal numero) {
		if (numero == null) {
			numero = BigDecimal.ZERO;
		}
		return decimalFormatMoneda.format(numero);
	}

	

	public static XMLGregorianCalendar dateToXMLGregorianCalendar(Date fecha) {
		XMLGregorianCalendar xgcal = null;
		if (fecha != null) {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(fecha);
			try {
				GregorianCalendar gcal = new GregorianCalendar(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH), calendar.get(Calendar.HOUR), calendar.get(Calendar.MINUTE), calendar.get(Calendar.SECOND));
				xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
			} catch (Exception e) {
				log.error(e);
			}
		}
		return xgcal;
	}

	public static double calcularHorasDiferencia(Date fechaInicial, Date fechaFinal) {
		return Math.round(calcularDiferenciaFechas(fechaInicial, fechaFinal));
	}
	
	public static double calcularMinutosDiferencia(Date fechaInicial, Date fechaFinal) {
		return Math.round(calcularDiferenciaMinFechas(fechaInicial, fechaFinal));
	}

	public static double calcularDiasDiferencia(Date fechaInicial, Date fechaFinal) {
		return Math.round(calcularDiferenciaFechas(fechaInicial, fechaFinal) / 24);
	}

	private static double calcularDiferenciaFechas(Date fechaInicial, Date fechaFinal) {
		long fechaInicialMs = fechaInicial.getTime();
		long fechaFinalMs = fechaFinal.getTime();
		long diferencia = fechaFinalMs - fechaInicialMs;
		return diferencia / (1000 * 60 * 60);
	}
	
	private static double calcularDiferenciaMinFechas(Date fechaInicial, Date fechaFinal) {
		Calendar calFechaInicial=Calendar.getInstance(); 
		Calendar calFechaFinal=Calendar.getInstance();
		calFechaInicial.setTime(fechaInicial); 
		calFechaFinal.setTime(fechaFinal);
		long diferenciaMinutos = cantidadTotalMinutos(calFechaInicial, calFechaFinal);
		return diferenciaMinutos;
	}
	
	/*Metodo que devuelve el Numero total de minutos que hay entre las dos Fechas */ 
	public static long cantidadTotalMinutos(Calendar fechaInicial ,Calendar fechaFinal){  
		long totalMinutos=0; 
		totalMinutos=((fechaFinal.getTimeInMillis()-fechaInicial.getTimeInMillis())/1000/60); 
		return totalMinutos;
	}
	
	public static XMLGregorianCalendar getCurrentDate() {
			GregorianCalendar gcal = new GregorianCalendar();
			return toXMLGregorianCalendar(gcal);
	}
	
	public static XMLGregorianCalendar toXMLGregorianCalendar(GregorianCalendar gCal)
	{
		if(gCal==null) return null;
		
		XMLGregorianCalendar xgcal = null;
		try {
			xgcal = DatatypeFactory.newInstance().newXMLGregorianCalendar(gCal);
		} catch (DatatypeConfigurationException e) {
			log.error(e);
		} catch (Exception e) {
			log.error(e);
		}
		return xgcal;
	}
	
	public static GregorianCalendar toGregorianCalendar(Date date)
	{
		if(date == null)return null;	
		GregorianCalendar gCal = new GregorianCalendar();
		gCal.setTime(date);
		return gCal;
	}

	public static Timestamp getCurrentTimestamp() {
		return new Timestamp(new Date().getTime());
	}

	public static Integer stringToInteger(String numero) {
		Integer respuesta = 0;
		try {
			respuesta = Integer.parseInt(numero);
		} catch (Exception ex) {
			// no hago nada simplemente es para devolver nulo si no es valido.
			log.error(ex);
		}
		return respuesta;
	}

	public static boolean esCollectionNulaVacia(Collection<?> lst) {
		return lst == null || lst.isEmpty();
	}

	public static char[] stringToArrayChars(String string) {
		char[] retorno = new char[0];
		if (string != null) {
			retorno = new char[string.length()];
			string.getChars(0, string.length(), retorno, 0);
		}
		return retorno;
	}

	public static Double stringToDouble(String numero) {
		Double respuesta = null;
		try {
			respuesta = Double.parseDouble(numero);
		} catch (Exception ex) {
			// no hago nada simplemente es para devolver nulo si no es valido.
			log.error(ex);
		}
		return respuesta;
	}

	public static Long intToLong(int numero) {
		Long respuesta = null;
		try {

			respuesta = new Long(numero);

		} catch (Exception ex) {
			log.error(ex);
		}
		return respuesta;
	}

	public static BigInteger longToBigInterer(long numero) {
		BigInteger respuesta = null;
		try {
			respuesta = BigInteger.valueOf(numero);
		} catch (Exception ex) {
			log.error(ex);
		}
		return respuesta;
	}

	public static BigDecimal bigIntegerToBigDecimal(BigInteger numero) {
		BigDecimal resultado = BigDecimal.ZERO;
		try {
			resultado = new BigDecimal(numero);
		} catch (Exception ex) {
			log.error(ex);
		}
		return resultado;
	}

	public static BigDecimal longToBigDecimal(Long numero) {
		BigDecimal resultado = BigDecimal.ZERO;
		try {
			resultado = new BigDecimal(numero);
		} catch (Exception ex) {
			log.error(ex);
		}
		return resultado;
	}

	

	

	public static BigInteger doubleToBigInteger(Double numero) {
		BigInteger resultado = BigInteger.ZERO;
		try {
			resultado = BigInteger.valueOf(numero.longValue());
		} catch (Exception ex) {
			log.error(ex);
		}
		return resultado;
	}

	public static BigDecimal doubleToBigDecimal(Double numero) {
		BigDecimal resultado = BigDecimal.ZERO;
		try {
			resultado = BigDecimal.valueOf(numero.doubleValue());
		} catch (Exception ex) {
			log.error(ex);
		}
		return resultado;
	}

	/**
	 * M�todo que completa con caracteres una cadena a la izquierda 
	 * @param cadenaOriginal
	 * @param numeroCaracteres
	 * @param caracter
	 * @return
	 */
	

	

	/**
	 * Metodo que convierte un arreglo de byte a una cadena Hexadecimal Adaptado
	 * de la clase com.ath.psj.common.utility.DataHandlingUtility PB
	 * 
	 * Ricardo Su�rez
	 * 
	 * @since 02-12-2009
	 * 
	 * @param data
	 *            el byte[] a convertir
	 * @return String the converted byte[]
	 */
	public static String bytesToHex(byte[] data) {
		StringBuffer retString = new StringBuffer();
		for (int i = 0; i < data.length; ++i) {
			retString.append(Integer.toHexString(0x0100 + (data[i] & 0x00FF)).substring(1).toUpperCase());
		}
		return retString.toString();
	}

	/**
	 * Metodo que retorna un arreglo de bytes a partir de una cadena de
	 * caracteres hexadecimales Adaptado de la clase
	 * com.ath.psj.common.utility.DataHandlingUtility PB
	 * 
	 * Ricardo Su�rez
	 * 
	 * @since 02-12-2009
	 * 
	 * @param data
	 *            el String a convertir
	 * @return String the converted String
	 */
	public static byte[] bytesFromHex(String data) {
		byte[] bts = new byte[data.length() / 2];
		for (int i = 0; i < bts.length; i++) {
			bts[i] = (byte) Integer.parseInt(data.substring(2 * i, 2 * i + 2), 16);
		}
		return bts;
	}

	/**
	 * Permite cambiar la longitud de una cadena a?adiendole caracteres de
	 * relleno a la derecha Adaptado de la clase
	 * com.ath.psj.common.utility.DataHandlingUtility PB
	 * 
	 * Ricardo Su�rez
	 * 
	 * @since 02-12-2009
	 * 
	 * @param inBound
	 *            - Cadena de entrada
	 * @param length
	 *            - Longitud obligatoria
	 * @param token
	 *            - Simbolo de relleno. Pudede ser un espacio en blanco o un
	 *            cero
	 * @return String - La cadena mas el relleno
	 */
	public static String fillString(String inBound, int length, String token) {
		StringBuffer original = new StringBuffer(inBound);
		while (original.length() != length) {
			original.append(token);
		}
		return original.toString();
	}

	/**
	 * Elimina los espacios ubicados a la izquierda del primer caracter.
	 * 
	 * @param string
	 *            Texto a evaluar.
	 * @return Texto sin espacios a la izquierda del primer car�cter.
	 */
	public static String ltrim(String string) {
		if (string == null || "".equals(string.trim()))
			return "";

		int cont = 0;
		while (cont < string.length() && string.charAt(cont) == ' ') {
			cont++;
		}
		return string.substring(cont);
	}

	/**
	 * Elimina los espacios ubicados a la derecha del �ltimo caracter.
	 * 
	 * @param string
	 *            Texto a evaluar.
	 * @return Texto sin espacios a la derecha del �ltimo car�cter.
	 */
	public static String rtrim(String string) {
		if (string == null || "".equals(string.trim()))
			return "";

		int cont = string.length() - 1;
		while (cont > 0 && string.charAt(cont) == ' ') {
			cont--;
		}
		return string.substring(0, cont + 1);
	}

	/**
	 * Elimina los espacios ubicados a la derecha del �ltimo caracter y a la
	 * izquierda del primer caracter.
	 * 
	 * @param string
	 *            Texto a evaluar.
	 * @return Texto sin espacios a la derecha del �ltimo car�cter y a la
	 *         izquierda del primer caracter.
	 */
	public static String lrtrim(String string) {
		return ltrim(rtrim(string));
	}

	public static String cutText(String str, int size) {
		return str != null && str.length() > size ? str.substring(0, size - 1) : str;
	}

	
	public static String formatearAPorcentaje(Double numero) {
		if (numero == null) {
			numero = new Double(0);
		}
		return decimalFormatPorcentaje.format(numero) + "%";
	}

	public static String formatearAEntero(Double numero) {
		if (numero == null) {
			numero = new Double(0);
		}
		return integerFormat.format(numero);
	}

	

	/**
	 * Convierte una cadena de texto claro a una cadena con el dato en
	 * hexadecimal.
	 * 
	 * @author Ricardo Su�rez
	 * @since 21-10-2010
	 * 
	 * @param message
	 *            Texto que se desea convertir a hexadecimal
	 * @return Texto en hexadecimal
	 */
	public static String getHexFromString(String message) {
		StringBuilder result = new StringBuilder("");
		// Se obtienen los bytes del mensaje enviado
		byte[] buffer = message.getBytes();

		// Se recorren los bytes del buffer para convertirlos en hexadecimal.
		for (byte aux : buffer) {
			int b = aux & 0xff;
			if (Integer.toHexString(b).length() == 1) {
				result.append(IConstants.CARACTER_CERO);
			}
			result.append(Integer.toHexString(b));
		}
		return result.toString();
	}

	/**
	 * Convierte una cadena de texto, que contiene el dato en hexadecimal, a una
	 * cadena de texto claro.
	 * 
	 * @author Ricardo Su�rez
	 * @since 21-10-2010
	 * 
	 * @param message
	 *            Hexadecimal que se desea convertir a texto claro
	 * @return Texto resultante
	 */
	public static String getStringFromHex(String message) {
		StringBuilder result = new StringBuilder("");
		int value = 0;

		// Se recorre el mensaje enviado en grupos de dos para obtener el valor
		// entero y luego
		// se obtiene el caracter correspondiente a dicho valor.
		for (int i = 0; i <= message.length() - 2; i = i + 2) {
			// Se convierte el texto que viene en hexadecimal a su valor
			// correspondiente en entero. El segundo
			// parametro de la funcion valueOf corresponde a la base del numero,
			// en este caso 16.
			value = Integer.valueOf(message.substring(i, i + 2), 16);
			char c = (char) value;
			result.append(c);
		}
		return result.toString();
	}

	/**
	 * Obtiene la informaci�n de los campos delimitados por una cadena de
	 * caracteres.
	 * 
	 * @param texto
	 *            Texto a examinar
	 * @param delimitador
	 *            Delimitador de caracteres.
	 * @return Lista de los campos que fueron delimitados.
	 */
	public static List<String> obtenerListaCamposDelimitados(String texto, String delimitador) {
		StringTokenizer st = new StringTokenizer(texto, delimitador);
		List<String> lista = new ArrayList<String>();
		while (st.hasMoreElements()) {
			lista.add(st.nextElement().toString());
		}
		return lista;
	}

	/**
	 * Enamsacara el n�mero recibido de la siguiente forma:<br>
	 * Cuatros signos '#' y los �ltimos cuatro digitos del n�mero<br>
	 * Ejemplo: ####4561
	 * 
	 * @author Carlos Fajardo
	 * @since 25-05-2011
	 * 
	 * @param numero
	 * @return
	 */
	public static String enmascararNumero(String numero) {

		String mascara = "####";
		int nDigitos = 4;

		String numeroEnmascarado = null;
		if (numero != null && numero.length() > 0) {
			if (numero.length() <= nDigitos) {
				numeroEnmascarado = numero;
			} else {
				numeroEnmascarado = mascara + numero.substring(numero.length() - nDigitos, numero.length());
			}
		}
		return numeroEnmascarado;

	}

	/**
	 * Convierte el texto para que la primera letra de cada palabra quede en
	 * mayuscula
	 * 
	 * @author Carlos Fajardo
	 * @since 25-05-2011
	 * 
	 * @param texto
	 * @return
	 */
	public static String textoEnCapital(String texto) {

		StringBuffer textoCapital = new StringBuffer();
		if (texto != null && texto.trim().length() > 2) {
			String[] palabras = texto.trim().split(" ");
			for (String palabra : palabras) {
				if (palabra != null && palabra.trim().length() > 0) {
					String resto = palabra.substring(1).toLowerCase();
					char letra = palabra.charAt(0);
					textoCapital.append(Character.toUpperCase(letra));
					textoCapital.append(resto);
					textoCapital.append(" ");
				}
			}
		} else {
			return texto;
		}
		return textoCapital.toString().trim();
	}
	
	/**
	 * 
	 * @param data
	 * @return
	 */
	public static String eraseSpecialCharacter(String data) {
		data = data.replaceAll("�", "a");
		data = data.replaceAll("�", "e");
		data = data.replaceAll("�", "i");
		data = data.replaceAll("�", "o");
		data = data.replaceAll("�", "u");
		data = data.replaceAll("�", "n");
		data = data.replaceAll("�", "A");
		data = data.replaceAll("�", "E");
		data = data.replaceAll("�", "I");
		data = data.replaceAll("�", "O");
		data = data.replaceAll("�", "U");
		data = data.replaceAll("�", "N");
		data = data.replaceAll("&lt;", "\n#"); 
		data = data.replaceAll("&gt;", "#");
		return data;
	}

	/**
	 * Enmascara un correo electronico de la siguiente manera:
	 *
	 * Se cuenta el numero de caracteres del Nombre de usuario, y si este es par,
	 * debe mostrar la mitad de los caracteres; de lo contrario se calcula la mitad
	 * y se redondea al numero entero anterior.
	 * (Ej: nombreu******@hotmail.com)
	 *
	 * @author Ricardo Suarez
	 * @since 26-12-2012
	 *
	 * @param correo
	 * @return correo enmascarado
	 */
	public static String enmascararCorreoElectronico(String correo) {
		StringBuffer mascara = new StringBuffer();

		if(correo != null) {
			correo = correo.trim();

			int indiceArroba = correo.indexOf("@") >= 0 ? correo.indexOf("@") : 0;

			String usuario = correo.substring(0, indiceArroba);
			int mitad = (int)Math.round(usuario.length() / 2);

			for (int i = 0; i < correo.length(); i++) {
				if((i < mitad) || (i >= indiceArroba)) {
					mascara.append(correo.charAt(i));
				} else {
					mascara.append("*");
				}
			}
		}
		return mascara.toString();
	}

	/**
	 * Enmascara un celular de la siguiente manera:
	 * Muestra los ultimos 4 digitos del celular
	 * (Ej: ******1234)
	 *
	 * @author Ricardo Suarez
	 * @since 26-12-2012
	 *
	 * @param celular
	 * @return celular enmascarado
	 */
	public static String enmascararCelular(String celular) {
		StringBuffer mascara = new StringBuffer();

		if(celular != null) {
			celular = celular.trim();
			for (int i = 0; i < celular.length(); i++) {
				if(i >= celular.length() - 4) {
					mascara.append(celular.charAt(i));
				} else {
					mascara.append("*");
				}
			}
		}
		return mascara.toString();
	}
	
	/**
	 * Enmascara un texto
	 * @param textContent texto a enmascarr
	 * @param showLength cantidad de caracteres que se pueden mostrar
	 * @return
	 */
	public static boolean validarCadenaNulaVacia(String cadena) {
		return cadena != null && !("".equals(cadena.trim())) && !("null".equals(cadena));
	}
	
	public static String getIpAddress() {
		final String WL_PROXY_CLIENT_IP = "WL-Proxy-Client-IP";
		final String PROXY_CLIENT_IP = "Proxy-Client-IP";
		final String X_FORWARDER_FOR = "X-Forwarded-For";
		final String HTTP_X_FORWARDED_FOR = "HTTP_X_FORWARDED_FOR";
		final String HTTP_CLIENT_IP = "HTTP_CLIENT_IP";
		
		String ip = null;
		
		HttpServletRequest requestBase = null;

		FacesContext context = FacesContext.getCurrentInstance();
		requestBase = (HttpServletRequest) context.getExternalContext().getRequest();

		ip = requestBase.getHeader(X_FORWARDER_FOR);

		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = requestBase.getHeader(WL_PROXY_CLIENT_IP);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = requestBase.getHeader(PROXY_CLIENT_IP);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = requestBase.getHeader(HTTP_X_FORWARDED_FOR);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = requestBase.getHeader(HTTP_CLIENT_IP);
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = requestBase.getRemoteAddr();
		}

		return ip;
	}
}
