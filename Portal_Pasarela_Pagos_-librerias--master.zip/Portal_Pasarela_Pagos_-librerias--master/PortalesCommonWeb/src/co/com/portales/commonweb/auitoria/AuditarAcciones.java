package co.com.portales.commonweb.auitoria;

import java.util.Date;

import org.apache.log4j.Logger;

import co.com.portales.common.util.jms.JMSSendUtil;
import co.com.portales.commonweb.util.DatosUtil;
import co.com.portalservicio.auditoria.dto.AuditoriaMessage;

public class AuditarAcciones {
	private static Logger log = Logger.getLogger(AuditarAcciones.class);
	
	public AuditarAcciones(){
		
	}
	
	// Metodo encargado de registrar las acciones del usuario
	public static void auditar(AuditoriaMessage mensaje) {
		log.info("::: INICIA EL METODO auditar DEL BACKING BEAN AuditarAcciones() :::");
		
		try {
			JMSSendUtil su = new JMSSendUtil("PSAuditoriaJMSQueue",
 					"jmsQueueSenderName");
			AuditoriaMessage mensajeAud = new AuditoriaMessage();
			mensajeAud.setFechaRegistro(new Date());
			mensajeAud.setUsuario(mensaje.getUsuario());
			mensajeAud.setDireccionIp(DatosUtil.getIpAddress());
			mensajeAud.setFuncionalidad(mensaje.getFuncionalidad());
			mensajeAud.setAccion(mensaje.getAccion());
			mensajeAud.setEstado(mensaje.getEstado());
			mensajeAud.setDescripcion(mensaje.getDescripcion());
			su.sendMessage(mensajeAud);
		} catch (Exception eException) {
			log.error("::: ERROR EN EL ENVIO DE LA AUDITORIA ::: ");
		}

		log.info("::: TERMINA EL M�TODO auditar DEL BACKING BEAN AuditarAcciones() :::");
	}
}
