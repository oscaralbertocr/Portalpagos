package co.com.portales.commonweb.validadores;

import java.util.ResourceBundle;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;
import javax.servlet.http.HttpServletRequest;

public class NumberFranchiseValidator implements Validator {
	
	private ResourceBundle bundlePasarela;

	@Override
	public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
		
		bundlePasarela = ResourceBundle.getBundle("co.com.portales.commonweb.bundle.mensajes_pasarela");
		
		if(value==null || "".equals(value.toString().trim())){
			throw new ValidatorException(new FacesMessage(bundlePasarela.getString("mensaje_campo_obligatorio"), null));
		}
		
		String form = component.getParent().getId();
		String numeroTarjeta = (String) value;		
		String fieldIdFranquicia = (String) component.getAttributes().get("idFranquicia");
		String idFranquicia = getParameterValue(form, fieldIdFranquicia);
		
		// validamos si el campo tiene solo n�meros
		if(numeroTarjeta.length() > 0 && !ValidadorDatosFormulario.validarCampoSoloNumeros(numeroTarjeta)) {
			throw new ValidatorException(new FacesMessage(bundlePasarela.getString("mensaje_formato_campo"), null));
		}
		
		if (!ValidadorDatosFormulario.validarNumeroFranquicia(numeroTarjeta, idFranquicia)){
			throw new ValidatorException(new FacesMessage(bundlePasarela.getString("mensaje_error_franquicia"), null));
		}
		
	}
	
	private String getFullParameterName(HttpServletRequest hsr, String field) {
		String tmpParam = null;
		for (Object obj : hsr.getParameterMap().keySet().toArray()) {			
			if (obj.toString().endsWith(field)) {
				tmpParam = obj.toString();
				break;
			}
		} 
		return tmpParam;
	}
	
	private String getParameterValue(String formName, String fieldName){
		ExternalContext externalContext = FacesContext.getCurrentInstance().getExternalContext();
		HttpServletRequest hsr = (HttpServletRequest) externalContext.getRequest();
		String paramName = getFullParameterName(hsr, fieldName);
        if (paramName == null || paramName.length() == 0) {
        	paramName = formName + ":" + fieldName;
        }
        String param = (String) hsr.getParameter(paramName);
        return param;
	}

}
