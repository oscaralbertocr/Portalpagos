package co.com.portales.commonweb.validadores;

import java.util.HashSet;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

public class PasswordValidator implements Validator {
	
	private ResourceBundle bundleMessages;

	

	@Override
	public void validate(FacesContext context, UIComponent component, Object value)
			throws ValidatorException {

		bundleMessages = ResourceBundle.getBundle("co.com.portales.commonweb.bundle.mensajes_validaciones");
		String clave = (String) value;
		
		//Valida minimo 5 caracteres diferentes
		char[] pass = clave.toCharArray();
		Set<Character> set = new HashSet<Character>();
		for(int i = 0; i < pass.length; i++){
		  set.add(pass[i]);
		}
		if(set.size()<5){
			throw new ValidatorException(new FacesMessage(null, bundleMessages.getString("error_validacion_clave") ));	
		}
		
		//Valida 1 min�scula, 1 may�scula, 1 n�mero, 1 caracter especial, longitud m�nima 8, no mas de 4 d�gitos consecutivos
		if(!validateRegex("^(?=.*?[a-z])(?=.*?[A-Z])(?=.*?[0-9])(?!.*?0-9{5})(?=.*[�#$%&=?*+])[a-zA-Z0-9�#$%&=?*+]{8,}$",clave)){
			throw new ValidatorException(new FacesMessage(null, bundleMessages.getString("error_validacion_clave") ));	
		}
		//Valida que no tenga caracteres diferentes a los descritos ni caracteres consecutivos
		if(!validateRegex("^(([a-zA-Z0-9�#$%&=?*+])(?!\\2))*$",clave)){
			throw new ValidatorException(new FacesMessage(null, bundleMessages.getString("error_validacion_clave") ));	
		}
		//Valida que no tenga caracteres diferentes a los descritos ni caracteres consecutivos
		if(validateRegex("\\S*(.)\\1\\S*",clave)){
			throw new ValidatorException(new FacesMessage(null, bundleMessages.getString("error_validacion_clave") ));	
		}
	}
	
	public static boolean validateRegex(String pattern, String line){
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(line);
		return  m.matches();
	 }
	
	

}
