# Portal_Pasarela_Pagos_-librerias-
Repositorio que contiene los fuentes de las librerías compartidas del Portal de la Pasarela de Pagos para los desarrollos evolutivos (ON-PREMISE)
