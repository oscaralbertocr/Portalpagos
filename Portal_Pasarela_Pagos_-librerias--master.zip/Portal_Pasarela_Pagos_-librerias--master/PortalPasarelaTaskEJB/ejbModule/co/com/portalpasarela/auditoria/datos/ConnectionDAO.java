package co.com.portalpasarela.auditoria.datos;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

public class ConnectionDAO {

	/**
	 * Variable encargada de manejar los logs de la aplicaci�n.
	 */
	private static Logger log = Logger.getLogger(ConnectionDAO.class);

	private static ConnectionDAO instance;

	private static DataSource dataSource;

	/**
	 * Metodo constructor privado para el singleton.
	 */
	private ConnectionDAO() {
		InitialContext initialContext = null;
		try {
			initialContext = new InitialContext();
			try {
				dataSource = (DataSource) initialContext
						.lookup("jdbc/PasarelaAuditoriaDS");
			} catch (NamingException e) {
				log.error(
						"::: SE PRESENTARION PROBLEMAS AL OBTENER EL DATA SOURCE :::",
						e);
			}
		} catch (NamingException e) {
			log.error(
					"::: SE PRESENTARION PROBLEMAS AL OBTENER EL INITIAL CONTEXT :::",
					e);
		}
	}

	/**
	 * Metodo encargado de obtener una unica instancia para el manejo de
	 * conexiones.
	 * 
	 * @return ConnectionDAO
	 */
	public static ConnectionDAO getInstance() {
		if (instance == null) {
			instance = new ConnectionDAO();
		}
		return instance;
	}

	/**
	 * Metodo encargado de retornar una conexion a la base de datos.
	 * 
	 * @return Connection Objeto con la conexion a la base de datos.
	 */
	public Connection createConnection() throws Exception {
		try {
			return dataSource.getConnection();
		} catch (Exception eException) {
			log.error(
					"::: SE PRESENTARION PROBLEMAS AL OBTENER LA CONEXION CON LA BASE DE DATOS :::",
					eException);
			throw eException;
		}
	}

}
