package co.com.portalpasarela.auditoria.datos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;

import org.apache.log4j.Logger;

import co.com.portalservicio.auditoria.dto.AuditoriaPasarelaMessage;

public class AuditoriaPortalPasarelaDAO {

	/**
	 * Variable encargada de manejar los logs de la aplicaci�n.
	 */
	private static Logger log = Logger
			.getLogger(AuditoriaPortalPasarelaDAO.class);

	/**
	 * Metodo encargado de almacenar un registro en la tabla de auditoria
	 * pasarela de la aplicacion.
	 * 
	 * @param auditoria
	 *            AuditoriaPasarelaMessage Objeto con la informacion del
	 *            registro que se quiere almacenar.
	 * @throws Exception
	 *             Al momento de almacenar el registro.
	 */
	public void insertAuditoria(AuditoriaPasarelaMessage auditoria)
			throws Exception {
		PreparedStatement insertStatement = null;
		Connection dbConnection = null;
		StringBuilder mensaje = new StringBuilder("");
		try {
			dbConnection = ConnectionDAO.getInstance().createConnection();
			String insertQuery = "INSERT INTO PASARELA.AUDITORIA_PASARELA (ID, TOKEN, DIRECCION_IP, FECHA_REGISTRO, "
					+ "ACCION, COMERCIO, PANTALLA, RESULTADO, INFORMACION_ADICIONAL) "
					+ "VALUES (PASARELA.INCR_ID_AUDITORIA_PASARELA.nextVal,?,?,?,?,?,?,?,?)";
			insertStatement = dbConnection.prepareStatement(insertQuery);
			insertStatement.setString(1, auditoria.getToken());
			insertStatement.setString(2, auditoria.getDireccionIp());
			insertStatement.setTimestamp(3, new Timestamp(auditoria
					.getFechaRegistro().getTime()));
			insertStatement.setString(4, auditoria.getAccion());
			insertStatement.setString(5, auditoria.getComercio());
			insertStatement.setString(6, auditoria.getPantalla());
			insertStatement.setString(7, auditoria.getResultado());
			insertStatement.setString(8, auditoria.getInformacionAdicional());
			int cantidadRegistros = insertStatement.executeUpdate();
			if (cantidadRegistros == 0) {
				mensaje.append("::: NO FUE POSIBLE ALMACENAR EL REGISTRO DE AUDITORIA DE LA PASARELA ");
				mensaje.append(auditoria);
				mensaje.append(" :::");
				log.error(mensaje);
			}
		} catch (Exception eException) {
			mensaje.setLength(0);
			mensaje.append("::: SE PRESENTARION PROBLEMAS AL ALMACENAR LA AUDITORIA DE LA PASARELA ");
			mensaje.append(auditoria);
			mensaje.append(" :::");
			
			log.error(mensaje, eException);
			throw eException;
		} finally {
			if (insertStatement != null) {
				insertStatement.close();
			}
			if (dbConnection != null) {
				safeClose(dbConnection);
			}
		}
	}

	public static void safeClose(Connection dbConnection) {
		if (dbConnection != null) {
			try {
				dbConnection.close();
			} catch (SQLException e) {
				log.error("::: NO SE PUEDE CERRAR LA CONEXION");
			}
		}
	}

}
