package co.com.portalpasarela.auditoria.service;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;


/**
 * Session Bean implementation class AuditoriaService
 */
@Stateless
@LocalBean
public class AuditoriaService {

    /**
     * Default constructor. 
     */
    public AuditoriaService() {
        
    }

}
