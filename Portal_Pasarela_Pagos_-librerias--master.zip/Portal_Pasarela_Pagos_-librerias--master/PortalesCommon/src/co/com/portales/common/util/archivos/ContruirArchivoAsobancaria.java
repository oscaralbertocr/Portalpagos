package co.com.portales.common.util.archivos;

/**
 * Construye archivos en formato Asobancaria 
 * @author saruiz
 *
 */
public abstract class ContruirArchivoAsobancaria {

	//public abstract void contruirArchivo();
}
