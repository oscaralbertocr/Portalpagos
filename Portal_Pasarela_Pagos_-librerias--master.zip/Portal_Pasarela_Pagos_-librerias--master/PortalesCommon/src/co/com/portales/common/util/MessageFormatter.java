package co.com.portales.common.util;

import java.text.MessageFormat;


/**
 * Clase que formatea un mensaje, adicionandole los parametros que lleguen
 * en el arreglo de objetos.
 * Ej. "mensaje de prueba{0}"
 * @author A Toda Hora S.A
 * @author Oscar Yovany Baquero Moreno
 * @version 1.0
 * @create 21/11/2006
 */
public class MessageFormatter {
    private static MessageFormat formatter = new MessageFormat("");

    public static String format(String message, Object[] params) {
        formatter.applyPattern(message);

        String messageOut = formatter.format(params);

        return messageOut;
    }
}
