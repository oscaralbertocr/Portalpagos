package co.com.portales.common.ldap;


public class AtributosVO {
    private String objectclass;    
    private String inetOrgPerson;
    private String organizationalPerson;
    private String person;
    private String type;   
    
    public AtributosVO(String objectclass, String orcluserv2, String orcluser,
        String inetOrgPerson, String organizationalPerson, String person,
        String type) {
        this.objectclass = objectclass;
        this.inetOrgPerson = inetOrgPerson;
        this.organizationalPerson = organizationalPerson;
        this.person = person;
        this.type = type;
    }
    
    /**
     * Uso de atributos para IBM Tivoli
     * @param objectclass
     * @param inetOrgPerson
     * @param organizationalPerson
     * @param person
     * @param type
     */
    public AtributosVO(String objectclass, String inetOrgPerson, 
		String organizationalPerson, String person, String type) {
	    this.objectclass = objectclass;
	    this.inetOrgPerson = inetOrgPerson;
	    this.organizationalPerson = organizationalPerson;
	    this.person = person;
	    this.type = type;
    }
    
    /**
     * Uso de atributos para IBM TDS QA
     * @param objectclass
     * @param inetOrgPerson
     * @param organizationalPerson
     * @param person
     * @param type
     */
    public AtributosVO(String objectclass, String person, String type) {
        this.objectclass = objectclass;
        this.person = person;
        this.type = type;
    } 
        
    
    public void setObjectclass(String objectclass) {
        this.objectclass = objectclass;
    }

    public String getObjectclass() {
        return objectclass;
    }

    public void setInetOrgPerson(String inetOrgPerson) {
        this.inetOrgPerson = inetOrgPerson;
    }

    public String getInetOrgPerson() {
        return inetOrgPerson;
    }

    public void setOrganizationalPerson(String organizationalPerson) {
        this.organizationalPerson = organizationalPerson;
    }

    public String getOrganizationalPerson() {
        return organizationalPerson;
    }

    public void setPerson(String person) {
        this.person = person;
    }

    public String getPerson() {
        return person;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

}
