package co.com.portales.common.contants;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Constantes de la aplicaci�n
 * @author saruiz a
 *
 */
public interface IConstants {

	String MIN_LENGTH_PSWD = "longitudMinimaClave";
    String MAX_LENGTH_PSWD = "longitudMaximaClave";
    String MIN_NUMERIC_CHARACTERS = "minimoCaracteresNumericos";
    
    /**
     * Nombre de los campos JSF para las validaciones de fechas
     */
    String CAMPO_FECHA_MENOR = "fechaMenor";
    String CAMPO_FECHA_MENOR_IGUAL = "fechaMenorIgual";
    String CAMPO_FECHA_MAYOR = "fechaMayor";
    String CAMPO_FECHA_MAYOR_IGUAL = "fechaMayorIgual";
    String CAMPO_HORA_INICIAL = "horaInicial";
    String CAMPO_MINUTO_INICIAL = "minutoInicial";
    String CAMPO_HORA_FINAL = "horaFinal";
    String CAMPO_MINUTO_FINAL = "minutoFinal";
    String CAMPO_FORMATO_FECHA = "formatoFecha";
    String CAMPO_EXTENSION_ARCHIVO = "tipoArchivo";
    String CAMPO_DIFERENCIA_MESES = "diferenciaMeses";
    
    /**
     * Constantes para la descarga del archivo de transacciones
     */
    Integer ID_CSV = 1;
    Integer ID_XLS = 2;
    Integer ID_XLSX = 3;
    String LABEL_CSV = "csv";
    String LABEL_XLS = "xls";
    String LABEL_XLSX = "xlsx";
    @SuppressWarnings("serial")
	Map<Integer, String> tiposArchivo = new LinkedHashMap<Integer, String>(){
    	static final long serialVersionUID = 1L;
		{
    		put(ID_CSV, LABEL_CSV);
    		put(ID_XLS, LABEL_XLS);
    		put(ID_XLSX, LABEL_XLSX);
    	}
    };
    
    String ID_VISA = "1";
    String ID_MASTER = "2";
    String ID_AMERICAN = "3";
    String ID_DINERS = "4";
    String LABEL_VISA = "Visa";
    String LABEL_MASTER = "Mastercard";
    String LABEL_AMERICAN = "American Express";
    String LABEL_DINERS = "Diners Club";
    @SuppressWarnings("serial")
	Map<String, String> tiposTarjeta = new LinkedHashMap<String, String>(){
    	static final long serialVersionUID = 1L;

		{
    		put(ID_VISA, LABEL_VISA);
    		put(ID_MASTER, LABEL_MASTER);
    		put(ID_AMERICAN, LABEL_AMERICAN);
    		put(ID_DINERS, LABEL_DINERS);
    	}
    };
    
    String PERSONA_NATURAL = "1";
    String PERSONA_JURIDICA = "2";
    
    Integer ID_DESCARGA_ARCH_EN_PROCESO = 1;
    Integer ID_DESCARGA_ARCH_GENERADO = 2;
    Integer ID_DESCARGA_ARCH_DESCARGADO = 3;
    Integer ID_DESCARGA_ARCH_ERROR = 99;
    String LABEL_DESCARGA_ARCH_EN_PROCESO = "En Proceso";
    String LABEL_DESCARGA_ARCH_GENERADO = "Generado";
    String LABEL_DESCARGA_ARCH_DESCARGADO = "Descargado";
    String LABEL_DESCARGA_ARCH_ERROR = "Error";
    
    String CONSULTA_BASICA = "0";
    String CONSULTA_AVANZADA = "1";
    
    /**
     * Constantes para los filtros de los reportes
     */
    String FILTRO_HOY = "Hoy";
    String FILTRO_AYER= "Ayer";
    String FILTRO_ULTIMA_SEMANA= "�ltima semana";
    String FILTRO_ULTIMO_MES= "�ltimo mes";
    String FILTRO_MES_ACTUAL= "Mes actual";
    String FILTRO_ULTIMO_TRIMESTRE= "�ltimo trimestre";
    
    String FILTRO_ULTIMO_A�O = "�ltimo a�o";
    String FILTRO_ULTIMOS_DOS_A�OS= "�ltimos dos a�os";
    String FILTRO_ULTIMOS_TRES_A�OS= "�ltimos tres a�os";
    
    /**
     * Constantes para los estados de las transacciones
     */    
    String ESTADO_PENDIENTE= "Pendiente";
    String ESTADO_RECHAZADA= "Rechazada";
    String ESTADO_FALLIDA= "Fallida";
    String ESTADO_APROBADA = "Aprobada";
    String ESTADO_EXPIRADA = "Expirada";
    String ESTADO_NOAUTORIZADA = "No Autorizada";
    
    /**
     * Constantes para los ID estados de las transacciones
     */
    String ID_ESTADO_PENDIENTE= "1";
    String ID_ESTADO_RECHAZADA= "2";
    String ID_ESTADO_FALLIDA= "3";
    String ID_ESTADO_APROBADA = "4";
    String ID_ESTADO_EXPIRADA = "5";
    String ID_ESTADO_NOAUTORIZADA = "6";
    
    @SuppressWarnings("serial")
	Map<String, String> estadosTransacciones = new LinkedHashMap<String, String>(){
    	static final long serialVersionUID = 1L;

		{
    		put(ID_ESTADO_PENDIENTE, ESTADO_PENDIENTE);
    		put(ID_ESTADO_RECHAZADA, ESTADO_RECHAZADA);
    		put(ID_ESTADO_FALLIDA, ESTADO_FALLIDA);
    		put(ID_ESTADO_APROBADA, ESTADO_APROBADA);
    		put(ID_ESTADO_EXPIRADA, ESTADO_EXPIRADA);
    		put(ID_ESTADO_NOAUTORIZADA, ESTADO_NOAUTORIZADA);
    	}
    };
    
    
    /**
     * Constantes para los meses del a�o
     */
    String MES_ENERO = "Enero";
    String MES_FEBRERO = "Febrero";
    String MES_MARZO = "Marzo";
    String MES_ABRIL = "Abril";
    String MES_MAYO = "Mayo";
    String MES_JUNIO = "Junio";
    String MES_JULIO = "Julio";
    String MES_AGOSTO = "Agosto";
    String MES_SEPTIEMBRE = "Septiembre";
    String MES_OCTUBRE = "Octubre";
    String MES_NOVIEMBRE = "Noviembre";
    String MES_DICIEMBRE = "Diciembre";
    
    /**
     * Constantes para los estados de usuarios
     */
    String ACTIVO = "Activo";
    String INACTIVO = "Inactivo";
    
    String CANAL_PASARELA = "1";
    String CANAL_CALL_CENTER = "2";
    
    String ESTADO_INICIAL = "INITIAL";
    String ESTADO_FINAL = "FINAL";
    
    String AVVILLAS = "1";
    String BOGOTA = "2";
    String OCCIDENTE = "3";
    String POPULAR = "4";
    
    String AVVILLAS_BANK_ID = "00010524";
    String BOGOTA_BANK_ID = "00010016";
    String OCCIDENTE_BANK_ID = "00010236";
    String POPULAR_BANK_ID = "00010029";
    
    String AVVILLAS_NOMBRE = "Banco AV Villas";
    String BOGOTA_NOMBRE = "Banco de Bogot�";
    String OCCIDENTE_NOMBRE = "Banco de Occidente";
    String POPULAR_NOMBRE = "Banco Popular";
    
    @SuppressWarnings("serial")
	Map<String, String> bancos = new LinkedHashMap<String, String>(){
    	static final long serialVersionUID = 1L;

		{
    		put(AVVILLAS_BANK_ID, AVVILLAS_NOMBRE);
    		put(BOGOTA_BANK_ID, BOGOTA_NOMBRE);
    		put(OCCIDENTE_BANK_ID, OCCIDENTE_NOMBRE);
    		put(POPULAR_BANK_ID, POPULAR_NOMBRE);
    	}
    };
    
    String PAGOS_AVAL_ID = "1";
    String PAGOS_TC_ID = "2";
    String PAGOS_PSE_ID = "3";
    
    String PAGOS_AVAL_LABEL = "Pagos Aval";
    String PAGOS_TC_LABEL = "TC";
    String PAGOS_PSE_LABEL = "PSE";
    
    String SSC_EXITOSO = "0";
    String SSC_ERROR_GENERAL = "100";
    String SSC_ERROR_COMERCIO_INACTIVO = "101";
    String SSC_ERROR_PROCESO_TRANS = "200";
    String SSC_ERROR_DATOS_INCONS = "201";
    String SSC_ERROR_TRAMA_INVALIDA = "202";
    String SSC_ERROR_PAGO_NO_REGISTRADO = "203";
    String SSC_ERROR_SISTEMA_NO_DISPONIBLE = "300";
    String SSC_ERROR_PROCESO_TRANS_600 = "600";
    String SSC_ERROR_PROCESO_TRANS_700 = "700";
    String SSC_ERROR_TRANS_PENDIENTE = "27";
    String SSC_ERROR_TOKEN = "50";
    String SSC_ERROR_LISTAS_NEGRAS = "30";
    String SSC_ERROR_DOCUMENTO = "1860";
    String SSC_ERROR_IVA = "3040";
    String SSC_ACH_ERROR_FAIL = "400";
    
    String SSC_DESC_ERROR_GENERAL = "Error general";
    String SSC_DESC_ERROR_COMERCIO_INACTIVO = "El comercio no est� activo";
    String SSC_DESC_ERROR_PROCESO_TRANS = "No es posible procesar la transacci�n";
    String SSC_DESC_ERROR_DATOS_INCONS = "Datos inconsistentes";
    String SSC_DESC_ERROR_TRAMA_INVALIDA = "Error por trama Inv�lida";
    String SSC_DESC_ERROR_PAGO_NO_REGISTRADO = "El pago no se encuentra registrado";
    String SSC_DESC_ERROR_SISTEMA_NO_DISPONIBLE = "Sistema no disponible";
    String SSC_DESC_ERROR_PROCESO_TRANS_600 = "No es posible procesar la transacci�n";
    String SSC_DESC_ERROR_PROCESO_TRANS_700 = "Ocurri� un error durante el procesamiento de su solicitud";
    String SSC_DESC_ERROR_TRANS_PENDIENTE = "Estimado cliente, en este momento para su referencia de pago";
    String SSC_DESC_CONTACTO_TRANS_PENDIENTE = "tenemos una transacci�n Pendiente, estamos esperando una respuesta de la entidad financiera. Agradecemos espere unos minutos mientras confirmamos la transacci�n  o comun�quese con nuestras l�neas de atenci�n al cliente al tel�fono 01 8000 512825 para obtener m�s informaci�n ";
    String SSC_DESC_ERROR_BANCOS = "No se pudo obtener la lista de Bancos, por favor intente m�s tarde";
    String SSC_DESC_TRANSACCION_PENDIENTE = "Estimado cliente, en este momento su transacci�n se encuentra en estado Pendiente, por favor verifique si el d�bito fue realizado en el Banco. Una vez resolvamos el estado de su transacci�n le notificaremos al correo electr�nico registrado o comun�quese con nuestras l�neas de atenci�n al cliente al tel�fono 01 8000 512825.";
    String SSC_DESC_ERROR_TOKEN = "Estimado cliente la transacci�n se encuentra en proceso, comun�quese con nuestras l�neas de atenci�n al cliente al tel�fono 01 8000 512825 para verificar el resultado de la transacci�n.";
    String SSC_DESC_ERROR_LISTAS = "La transacci�n que intenta realizar no ha sido autorizada, por favor comun�quese con nuestras l�neas de atenci�n al cliente al tel�fono 01 8000 512825 para verificar el resultado de la transacci�n.";
    String SSC_DESC_ERROR_DOCUMENTO = "Excede el n�mero de caracteres permitido, por  favor verifica el n�mero de identificaci�n.";
    String SSC_DESC_ERROR_IVA = "El monto de pago no es correcto, por favor verifica el valor a pagar.";
    String SSC_DESC_ERROR_GENERAL_PP = "Lo sentimos. Ha habido un problema de comunicaci�n intermitente. Int�ntelo de nuevo mas tarde.";
    String SSC_DESC_ERROR_PP = "por favor intente m�s tarde o comun�quese con nuestras l�neas de atenci�n al cliente al tel�fono 01 8000 512825 o al correo electr�nico AvalPayCenter@en-contacto.co";
    // Validaci�n de Topes LGNC RQ26199 INI
    String SSC_DESC_ERROR_VT = "Transacci�n no autorizada, por favor verifique los datos de pago e intente nuevamente";
    // Validaci�n de Topes LGNC RQ26199 FIN
    // Mapeo de Errores RBM RQ30573 INI
    String SSC_DESC_ERROR_PAGO_RECHAZADO = "Su pago ha sido rechazado";
    String SSC_DESC_ERROR_TARJETA_RESTRINGIDA = "Su tarjeta se encuentra restringida";
    String SSC_DESC_ERROR_PROBLEMA_TECNICO = "Por problemas t�cnicos su transacci�n no ha sido procesada";
    String SSC_DESC_ERROR_PROCESO_VALIDACION = "Su pago se encuentra en proceso de validaci�n"; 
 // Mapeo de Errores RBM RQ30573 FIN
    String ERROR_TOKEN = "Estimado cliente no ha presentado actividad dentro de la p�gina en los �ltimos minutos, si estaba realizando una transacci�n por favor comun�quese con nuestras l�neas de atenci�n al cliente al tel�fono 01 8000 512825 para verificar el resultado";
    
    
    String ACH_ESTADO_COD_OK = "OK";
    String ACH_ESTADO_COD_PEND = "PENDING";
    String ACH_ESTADO_COD_NOTAUT = "NOT AUTHORIZED";
    String ACH_ESTADO_COD_FAIL = "FAILED";
    String ACH_ESTADO_COD_FAIL_SUCESS = "SUCCESS";
    String ACH_ESTADO_COD_FAIL_INVALID = "FAIL_INVALIDTRAZABILITYCODE";
    String ACH_ESTADO_COD_FAIL_ACCESS = "FAIL_ACCESSDENIED";
    String ACH_ESTADO_COD_FAIL_TIMEOUT = "FAIL_TIMEOUT";
    
    String ACH_ESTADO_DESC_OK = "Aprobada";
    String ACH_ESTADO_DESC_PEND = "Pendiente";
    String ACH_ESTADO_DESC_NOTAUT = "Rechazada";
    String ACH_ESTADO_DESC_FAIL = "Fallida";
    
    String ACH_PAGO_COD_SUCCESS = "SUCCESS";
    String ACH_PAGO_COD_FAIL_EXCEEDED = "FAIL_EXCEEDEDLIMIT";
    String ACH_PAGO_COD_FAIL_BANK = "FAIL_BANKUNREACHEABLE";
    
    String ACH_PAGO_DESC_FAIL_EXCEEDED = "El monto de la transacci�n excede los l�mites establecidos en PSE para la empresa,";
    String ACH_PAGO_DESC_FAIL_BANK = "La entidad financiera no puede ser contactada para iniciar la transacci�n, por favor seleccione otra o intente m�s tarde";
    String ACH_PAGO_DESC_FAIL_GENERAL = "No se pudo crear la transacci�n,";

    
    @SuppressWarnings("serial")
	Map<String, String> erroresServer = new LinkedHashMap<String, String>(){
    	static final long serialVersionUID = 1L;

		{
    		put(SSC_ERROR_GENERAL, SSC_DESC_ERROR_GENERAL);
    		put(SSC_ERROR_COMERCIO_INACTIVO, SSC_DESC_ERROR_COMERCIO_INACTIVO);
    		put(SSC_ERROR_PROCESO_TRANS, SSC_DESC_ERROR_PROCESO_TRANS);
    		put(SSC_ERROR_DATOS_INCONS, SSC_DESC_ERROR_DATOS_INCONS);
    		put(SSC_ERROR_TRAMA_INVALIDA, SSC_DESC_ERROR_TRAMA_INVALIDA);
    		put(SSC_ERROR_PAGO_NO_REGISTRADO, SSC_DESC_ERROR_PAGO_NO_REGISTRADO);
    		put(SSC_ERROR_SISTEMA_NO_DISPONIBLE, SSC_DESC_ERROR_SISTEMA_NO_DISPONIBLE);
    		put(SSC_ERROR_PROCESO_TRANS_600, SSC_DESC_ERROR_PROCESO_TRANS_600);
    		put(SSC_ERROR_PROCESO_TRANS_700, SSC_DESC_ERROR_PROCESO_TRANS_700);
    		put(SSC_ERROR_TOKEN, SSC_DESC_ERROR_TOKEN);
    		put(SSC_ERROR_DOCUMENTO, SSC_DESC_ERROR_DOCUMENTO);
    		put(SSC_ERROR_IVA, SSC_DESC_ERROR_IVA);
    	}
    };
    
    @SuppressWarnings("serial")
	Map<String, String> estadosTransaccion = new LinkedHashMap<String, String>(){
    	static final long serialVersionUID = 1L;

		{
    		put(ACH_ESTADO_COD_OK, ACH_ESTADO_DESC_OK);
    		put(ACH_ESTADO_COD_PEND, ACH_ESTADO_DESC_PEND);
    		put(ACH_ESTADO_COD_NOTAUT, ACH_ESTADO_DESC_NOTAUT);
    		put(ACH_ESTADO_COD_FAIL, ACH_ESTADO_DESC_FAIL);
    		put(ACH_ESTADO_COD_FAIL_SUCESS, ACH_ESTADO_DESC_OK);
    		put(ACH_ESTADO_COD_FAIL_INVALID, ACH_ESTADO_DESC_PEND);
    		put(ACH_ESTADO_COD_FAIL_ACCESS, ACH_ESTADO_DESC_PEND);
    		put(ACH_ESTADO_COD_FAIL_TIMEOUT, ACH_ESTADO_DESC_PEND);
    	}
    };
    
    @SuppressWarnings("serial")
	Map<String, String> estadoPago = new LinkedHashMap<String, String>(){
    	static final long serialVersionUID = 1L;

		{
    		put(ACH_PAGO_COD_FAIL_EXCEEDED, ACH_PAGO_DESC_FAIL_EXCEEDED);
    		put(ACH_PAGO_COD_FAIL_BANK, ACH_PAGO_DESC_FAIL_BANK);
    	}
    };
    
    /**
     * Constantes para el manejo de temas 
     * */
 
    /*Theme 1*/
    String NAME_THEME_ONE = "name_theme_one";
    String CSS_THEME_ONE = "css_theme_one";
    String NAME_LAYAOUT_THEME_ONE = "name_layaout_theme_one";
    String PAY_LAYAOUT_THEME_ONE = "pay_layaout_theme_one";
    String RESPONSE_LAYAOUT_THEME_ONE = "response_layaout_theme_one";
    
    /*Theme 2*/
    String NAME_THEME_TWO = "name_theme_two";
    String CSS_THEME_TWO = "css_theme_two";
    String NAME_LAYAOUT_THEME_TWO = "name_layaout_theme_two";
    String PAY_LAYAOUT_THEME_TWO = "pay_layaout_theme_two";
    String RESPONSE_LAYAOUT_THEME_TWO = "response_layaout_theme_two";
    
    /**
     * Constantes para el manejo de taquillas RQ26210
     * */
    String ENCABEZADO_DEFAULT = "encabezado_default";
	String FOOTER_AZUL = "footer_azul";
	String FOOTER_ROJO = "footer_rojo";
	String FOOTER_GRIS = "footer_gris";
	String COLOR_ROJO = "color_rojo";
	String COLOR_AZUL = "color_azul";
	String COLOR_GRIS = "color_gris";
    
    /**
     * Constantes web service GatewayPaymentAdm
     */
    int  STATUS_CODE_DECLINADA = 2;
    String STATUS_DESCRIPTION_DECLINADA = "Declinada";
    
    /**Mensajes Auditoria **/
    String FUNCIONALIDAD_AT = "Login Usuarios";
    String FUNCIONALIDAD_RC = "Olvido Contrase�a";
    String FUNCIONALIDAD_AC = "Administracion de Contrase�a";
    String FUNCIONALIDAD_AI = "Actualizar Informacion";
    String FUNCIONALIDAD_DA = "Descarga de Archivos";
    String FUNCIONALIDAD_CT = "Consulta de Transacciones";
    String FUNCIONALIDAD_RE = "Reportes y Estadisticas"; 
    String FUNCIONALIDAD_C = "Conciliacion";
    String FUNCIONALIDAD_AU = "Administracion de Usuarios";
    
    String ACCION_AT 	 = "Autenticaci�n Usuario";
    String ACCION_RC 	 = "Recuperaci�n Contrase�a"; 
    String ACCION_AC 	 = "Actualizaci�n Contrase�a";
    String ACCION_AI1	 = "Actualizacion Informaci�n de Contacto";
    String ACCION_AI2    = "Obtener informacion del comercio"; 
    String ACCION_DA	 = "Descargar Archivo Transacciones";
    String ACCION_CT1	 = "Consulta Basica de Transacciones";
    String ACCION_CT2	 = "Consulta Avanzada de Transacciones";
    String ACCION_CT3	 = "Generacion Archivo de Descarga";
    String ACCION_RE1	 = "Consulta Resumen Anual";
    String ACCION_RE2	 = "Consulta OrigenTransaccion";
    String ACCION_RE3	 = "Consulta Estados Transaccion";
    String ACCION_RE4	 = "Consulta Estad�sticas por Medio de Pago";
    String ACCION_C1	 = "Consulta Conciliaci�n de transacciones";
    String ACCION_C2	 = "Descarga Archivo Conciliaci�n de transacciones";
    String ACCION_AU1	 = "Creacion de Usuario";
    String ACCION_AU2	 = "Edicion de Usuario";
    String ACCION_AU3	 = " Eliminacion de Usuario ";
    String ACCION_AU4	 = "Generacion de Clave";
    String ACCION_AU5	 = "Consulta roles LDAP";
    String ACCION_AU6    = "Consulta usuarios LDAP";
    String ACCION_AU7	 = "Adicion de usuario a grupo LDAP";
    
    String ESTADO_FAU = "Fallido";
    String ESTADO_EAU = "Exitoso";
    
    /* Constantes para manejo de estilos por banco*/
    String ESTILOSPP = "pagos-aval";
    String ESTILOSBB = "banco-bogota";
    String ESTILOSBO = "banco-de-occidente";
    String ESTILOSBP = "banco-popular";
    String ESTILOSBAV = "banco-avvillas";
    
    String CSS_BB = "css_banco_bogota";
    String CSS_BO = "css_banco_de_occidente";
    String CSS_BP = "css_banco_popular";
    String CSS_BAV = "css_banco_avvillas";
    
    /* Constantes para manejo de estilos Taquillas RQ26210*/
    
    String ESTILOSAZ = "taquilla-azul";
    String ESTILOSRJ = "taquilla-rojo";
    String ESTILOSGR = "taquilla-gris";
    
    String CCS_AZ= "ccs_taquilla_azul";
    String CCS_RJ= "ccs_taquilla_rojo";
    String CCS_GR= "ccs_taquilla_gris";
    
    /* Constantes Validaci�n de topes RQ262199*/
    
    String CODVAL_TOPES = "codigovalidaciopes";
     /**
     * Constante para obligaciones de los Bancos
     */
    static final String PREFIJO_OBLIGACIONES_BBOG = "O01";

   
    /**
     * Constantes para el manejo de enmascaramiento con * (Asterisco)
     */
    String ENMASCARAR_UN_ASTERISCO = "*";
    String ENMASCARAR_DOS_ASTERISCO = "**";
    String ENMASCARAR_TRES_ASTERISCO = "***";
    String ENMASCARAR_CUATRO_ASTERISCO = "****";
    String CARACTER_ARROBA = "@";
    String CARACTER_PUNTO = ".";
    String CORREO_ENMASCARADO_EXCEPTION = "****@****.com";
    String ENMASCARAR_TC_EXCEPTION = "****************";
    String CARACTER_CERO = "0";
    
    /**
     * Constantes para el LDAPAccess
     */
	String CARACTER_DOS_PUNTOS = ":";
	
    //RQ25542 MotorDeRiesgosPortal
    /**
     *	Constantes para manejo de RSA
     * 
     *	- MR_NOM_DEVICE_PRINT	Nombre identificador del DevicePrint
     *	- MR_NOM_DEVICE_TOKEN_COOKIE	Nombre identificador del DeviceTokenCookie
     *	- MR_NOM_DEVICE_TOKEN_COOKIE_MAX_AGE	Tiempo maximo de vida de la cookie
     *											3600*24*365=31536000, Corresponde a un a�o
     */
    String MR_NOM_DEVICE_PRINT = "DevicePrint";
    String MR_NOM_DEVICE_TOKEN_COOKIE = "DeviceTokenCookie";
    String MR_NOM_DEVICE_TOKEN_COOKIE_MAX_AGE = "31536000";
	String MR_HEADER_HTTP_ACCEPT = "httpAccept";
	String MR_HEADER_REFERER = "httpReferrer";
	String MR_HEADER_USER_AGENT = "userAgent";
	String MR_HEADER_HTTP_ACCEPT_LANG = "httpAcceptLanguage";
	
}
