package co.com.portales.common.correo;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;

import org.apache.log4j.Logger;

import co.com.portales.common.util.BeanLocator;
import co.com.portales.common.util.PropertiesLoader;
import co.com.portalservicio.correo.dto.CorreoDTO;

public class Notificacion{
	
	
	static Properties properties_mail;	

	
	static {
		try {
			PropertiesLoader propertiesLoader = PropertiesLoader.getInstance(); 
			properties_mail = propertiesLoader.getProperties("correo.properties");			
		} catch (Exception e) {
			Logger.getLogger(BeanLocator.class).error(e);
		}
	}
	public static void EnviarNotificacion(CorreoDTO mailDto) throws MessagingException
			 {
		
		Properties properties = new Properties();
		properties.put("mail.smtp.host", properties_mail.get("SMTP_MAIL_HOST"));
		properties.put("mail.smtp.localhost", properties_mail.get("SMTP_HOST"));
		properties.put("hostname", properties_mail.get("SMTP_HOST"));
		properties.put("mail.smtp.port", properties_mail.get("SMTP_PORT"));
		Session session = Session.getInstance(properties);
		session.setDebug(false);

		MimeMessage message = new MimeMessage(session);

		message.setSubject(mailDto.getSubject());
		message.setSentDate(new Date());
		message.setFrom(new InternetAddress(mailDto.getFrom()));
		
	
		int numeroDestinos = mailDto.getTo() != null ? mailDto.getTo().size():0;		
		InternetAddress[] addresses = new InternetAddress[numeroDestinos];		
		
		for (int j = 0; j < mailDto.getTo().size(); j++) {			
			if(mailDto.getTo().get(j) != null){
				message.addRecipient(Message.RecipientType.TO, new InternetAddress((String)mailDto.getTo().get(j)));
				addresses[j] = new InternetAddress(mailDto.getTo().get(j));
			}			
		}
				
		MimeBodyPart bodyPart = new MimeBodyPart();
		bodyPart.setContent(mailDto.getBody(),"text/html");
		message.setHeader("Content-Transfer-Encoding", (String) properties_mail.get("SMTP_ENCODED"));
		message.setHeader("Content-Type", (String) properties_mail.get("SMTP_CONTENT_TYPE"));
		message.setHeader("MIME-Version", (String) properties_mail.get("SMTP_MIME-Version") );
		message.setHeader("Content-Type", (String) properties_mail.get("SMTP_CONTENT_TYPE") );		
		message.setContent(mailDto.getBody(),(String) properties_mail.get("SMTP_CONTENT_TYPE"));		
		Transport transport = session.getTransport((String) properties_mail.get("SMTP_TRANSPORT"));
		transport.connect();
		transport.sendMessage(message, addresses);
		transport.close();

	}

}
