package co.com.portales.common.ldap;

import java.util.Hashtable;

import javax.naming.Binding;
import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NameClassPair;
import javax.naming.NameNotFoundException;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.apache.log4j.Logger;


/**
 * Clase que almacena datos del usuario a crear.
 */
public class User implements DirContext 
 {
    private String type;
    private Attributes attrs;
    private Logger log = Logger.getLogger(this.getClass()); 

    /**
     * Constructor para TDS
     * @param userDTO
     * @param objectClassDTO
     */
    public User(UserVO userVO, AtributosVO attr) {

		// Atributos: Usamos la clase BasicAttribute para almacenar los
		// atributos y sus valores
		attrs = new BasicAttributes(true); // true: ignore may�sculas-min�sculas

		Attribute oc = new BasicAttribute(attr.getObjectclass());                                
        oc.add(attr.getPerson());
        oc.add(attr.getType());

		attrs.put(oc);
		attrs.put("cn", userVO.getCn());
		attrs.put("uid", userVO.getUid());
		attrs.put("userPassword", userVO.getUserPassword());
		attrs.put("name", userVO.getName());
		attrs.put("sn", userVO.getSn());
		

		// OPCIONALES
		if(userVO.getGivenname() != null){
			attrs.put("givenname", userVO.getGivenname());
		}
		
		if(userVO.getMail() != null){
			attrs.put("mail", userVO.getMail());
		}		

	}
    
    public User(String cn, String uid, String sn, String pass, String primerNombre, 
    		String segundoNombre, String primerApellido, String segundoApellido, 
    		String mail, String estado, String direccion, String telefono, AtributosVO attr) {
        type = cn;

        //Atributos: Usamos la clase BasicAttribute para almacenar los
        //atributos y sus valores
        attrs = new BasicAttributes(true); //true: ignore may�sculas-min�sculas

        //OJO:  Definir estos valores - begin
        Attribute oc = new BasicAttribute(attr.getObjectclass());
       
        oc.add(attr.getInetOrgPerson());
        oc.add(attr.getOrganizationalPerson());
        oc.add(attr.getPerson());
        oc.add(attr.getType());
        
        attrs.put(oc);
        attrs.put(LDAPAccess.ATTRIB_CN, cn);
        attrs.put(LDAPAccess.ATTRIB_UID, uid);              
        attrs.put(LDAPAccess.ATTRIB_SN, sn);
        attrs.put(LDAPAccess.ATTRIB_PSWD, pass);
        attrs.put(LDAPAccess.ATTRIB_EMAIL, mail);
        attrs.put(LDAPAccess.ATTRIB_ESTADO, estado);
        attrs.put(LDAPAccess.ATTRIB_NOMBRE1, primerNombre);
        attrs.put(LDAPAccess.ATTRIB_NOMBRE2, segundoNombre);
        attrs.put(LDAPAccess.ATTRIB_APELLIDO1, primerApellido);
        attrs.put(LDAPAccess.ATTRIB_APELLIDO2, segundoApellido);
        attrs.put(LDAPAccess.ATTRIB_DIRECCION, direccion);
        attrs.put(LDAPAccess.ATTRIB_TELEFONO, telefono);
    }

    public Attributes getAttributes(String name) throws NamingException {
        if (!("".equals(name))) {
            throw new NameNotFoundException();
        }

        return attrs;
    }

    public Attributes getAttributes(Name name) throws NamingException {
        return getAttributes(name.toString());
    }

    public Attributes getAttributes(String name, String[] ids)
        throws NamingException {
        if (!("".equals(name))) {
            throw new NameNotFoundException();
        }

        Attributes answer = new BasicAttributes(true);
        Attribute target;

        for (int i = 0; i < ids.length; i++) {
            target = attrs.get(ids[i]);

            if (target != null) {
                answer.put(target);
            }
        }

        return answer;
    }

    
    ///////////////////////////////////////////////////////////////////////////
    /////////////// METODOS NO USADOS PERO REQUERIDOS POR DirContext 
    ////////////////////////////////////////////////////////////////////////////
    
    public Attributes getAttributes(Name name, String[] ids)
        throws NamingException {
        return getAttributes(name.toString(), ids);
    }

    public String toString() {
        return type;
    }

	@Override
	public Object addToEnvironment(String s, Object o) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void bind(Name n, Object o) throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void bind(String s, Object o) throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void close() throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Name composeName(Name n, Name pfx) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String composeName(String s, String pfx) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Context createSubcontext(Name n) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Context createSubcontext(String s) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void destroySubcontext(Name n) throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void destroySubcontext(String s) throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Hashtable<?, ?> getEnvironment() throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getNameInNamespace() throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NameParser getNameParser(Name n) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NameParser getNameParser(String s) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NamingEnumeration<NameClassPair> list(Name n) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NamingEnumeration<NameClassPair> list(String s)
			throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NamingEnumeration<Binding> listBindings(Name n)
			throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NamingEnumeration<Binding> listBindings(String s)
			throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object lookup(Name n) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object lookup(String s) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object lookupLink(Name n) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object lookupLink(String s) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void rebind(Name n, Object o) throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void rebind(String s, Object o) throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object removeFromEnvironment(String s) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void rename(Name nOld, Name nNew) throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void rename(String sOld, String sNew) throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void unbind(Name n) throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void unbind(String s) throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void bind(Name name, Object obj, Attributes attributes)
			throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void bind(String s, Object obj, Attributes attributes)
			throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public DirContext createSubcontext(Name name, Attributes attributes)
			throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DirContext createSubcontext(String s, Attributes attributes)
			throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DirContext getSchema(Name name) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DirContext getSchema(String s) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DirContext getSchemaClassDefinition(Name name)
			throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public DirContext getSchemaClassDefinition(String s) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void modifyAttributes(Name name, int i, Attributes attributes)
			throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modifyAttributes(Name name, ModificationItem[] modificationItems)
			throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modifyAttributes(String s, int i, Attributes attributes)
			throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modifyAttributes(String s, ModificationItem[] modificationItems)
			throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void rebind(Name name, Object obj, Attributes attributes)
			throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void rebind(String s, Object obj, Attributes attributes)
			throws NamingException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public NamingEnumeration<SearchResult> search(Name name,
			Attributes attributes) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NamingEnumeration<SearchResult> search(Name name,
			Attributes attributes, String[] as) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NamingEnumeration<SearchResult> search(Name name, String filter,
			Object[] objs, SearchControls searchControls)
			throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NamingEnumeration<SearchResult> search(Name name, String filter,
			SearchControls searchControls) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NamingEnumeration<SearchResult> search(String name,
			Attributes attributes) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NamingEnumeration<SearchResult> search(String name,
			Attributes attributes, String[] as) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NamingEnumeration<SearchResult> search(String name, String filter,
			Object[] objs, SearchControls searchControls)
			throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public NamingEnumeration<SearchResult> search(String name, String filter,
			SearchControls searchControls) throws NamingException {
		// TODO Auto-generated method stub
		return null;
	}

    
}
