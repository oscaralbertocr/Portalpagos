package co.com.portales.common.util;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;
import java.util.Properties;

import org.apache.log4j.Logger;

/**
 * Clase encargada de recuperar archivos de propiedades (.properties) Busca un
 * recurso con nombre (name) en el classpath. El recurso debe tener extensi�n
 * .properties.
 * 
 * @author ATH S.A
 * @create
 */
public class PropertiesLoader {

	/**
	 * Variable para manejar los logs de la aplicaci�n.
	 */
	private static Logger log = Logger.getLogger(PropertiesLoader.class);

	/* Atributo que representa la instancia de la clase */
	public static PropertiesLoader propertiesLoader;	
	private Hashtable<String, Properties> cache;
	private Hashtable<String, Properties> cacheDir;
	static Properties properties;

	/**
	 * Constructor privado para el singleton
	 */
	private PropertiesLoader() {
		super();
		cache = new Hashtable<String, Properties>();
		cacheDir = new Hashtable<String, Properties>();
	}

	/**
	 * M�todo que devuelve la instancia de la clase
	 * 
	 * @return PropertiesLoader Instancia de la clase
	 */
	public static PropertiesLoader getInstance() {
		if (propertiesLoader == null) {
			propertiesLoader = new PropertiesLoader();
		}
		return propertiesLoader;
	}

	/**
	 * M�todo que retorna un properties buscado en el mismo ClassLoader de la
	 * clase que lo solicita Primero lo busca en el cache de la instancia de la
	 * clase, sino esta lo busca a nivel de clases y lo sube al cache de la
	 * clase, para cuando se vuelva a necesitar
	 * 
	 * @param name
	 *            nombre del properties, se sube con el mismo nombre al cache de
	 *            la clase
	 * @return Properties properties recuperado
	 */
	public Properties getProperties(String name) {
		Object objProperties = cache.get(name);
		if (objProperties != null) {
			if (objProperties instanceof Properties) {
				return (Properties) objProperties;
			}
		}else{
			loadProperties(name);
			objProperties = cache.get(name);
			if (objProperties instanceof Properties) {
				return (Properties) objProperties;
			}
		}
		return null;
	}
	
	/**
	 * M�todo que retorna un properties buscado en el mismo ClassLoader de la
	 * clase que lo solicita Primero lo busca en el cache de la instancia de la
	 * clase, sino esta lo busca a nivel de clases y lo sube al cache de la
	 * clase, para cuando se vuelva a necesitar
	 * 
	 * @param name
	 *            nombre del properties, se sube con el mismo nombre al cache de
	 *            la clase
	 * @return Properties properties recuperado
	 */
	public Properties getProperties(String dirProperties, String name) {
		Object objProperties = cacheDir.get(name);
		if (objProperties != null) {
			if (objProperties instanceof Properties) {
				return (Properties) objProperties;
			}
		}else{
			loadProperties(dirProperties, name);
			objProperties = cacheDir.get(name);
			if (objProperties instanceof Properties) {
				return (Properties) objProperties;
			}
		}
		return null;
	}

	/**
	 * 
	 * @param name
	 *            nombre del recurso
	 * @return Properties recurso cargado
	 */
	public void loadProperties(final String name) {
		InputStream is = null;
		try {
			final String folder = "PasarelaPagosConf";
			final String ARCHIVO_PROPIEDADES = name;
			StringBuilder filePathSB = new StringBuilder(System.getProperty("user.dir") + File.separator + folder + File.separator + ARCHIVO_PROPIEDADES);
			final String filePath = filePathSB.toString();
			try {
				is = new FileInputStream(filePath);
				properties = new Properties();
				properties.load(is);
				if(this.cache==null || (this.cache!=null && this.cache.size()==0)){
					cache = new Hashtable<String, Properties>();
				}
				this.cache.put(name, properties);
			} catch (FileNotFoundException e) {
				log.error("ERROR AL LEER EL ARCHIVO, NO SE ENCUENTRA EL DOCUMENTO...", e);
			}

		} catch (Exception e) {
			log.error("ERROR AL LEER EL ARCHIVO DE PROPIEDADES...", e);
		} finally {
			try {
				if(is != null)
					is.close();
			} catch (IOException e) {
				log.error("ERROR CERRANDO EL ARCHIVO EN MEMORIA...", e);
			}
		}
	}
	
	/**
	 * 
	 * @param name
	 *            nombre del recurso
	 * @return Properties recurso cargado
	 */
	public void loadProperties(String dirProperties, final String name) {
		InputStream is = null;
		try {
			final String folder = dirProperties;
			final String ARCHIVO_PROPIEDADES = name;
			final String filePath = System.getProperty("user.dir") + File.separator + folder + File.separator + ARCHIVO_PROPIEDADES;
			try {
				is = new FileInputStream(filePath);
				properties = new Properties();
				properties.load(is);
				if(this.cacheDir==null || (this.cacheDir!=null && this.cacheDir.size()==0)){
					cacheDir = new Hashtable<String, Properties>();
				}
				this.cacheDir.put(name, properties);
			} catch (FileNotFoundException e) {
				log.error("ERROR AL LEER EL ARCHIVO, NO SE ENCUENTRA EL DOCUMENTO...", e);
			}

		} catch (Exception e) {
			log.error("ERROR AL LEER EL ARCHIVO, NO SE ENCUENTRA EL DOCUMENTO...", e);
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				log.error("ERROR CERRANDO EL DOCUMENTO EN MEMORIA...", e);
			}
		}
	}

}