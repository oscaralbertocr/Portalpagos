package co.com.portales.common.ldap;
/**
 * Listado de los posibles mensajes de excepciones para la inserci�n de los
 * usuarios al LDAP.
 * 
 * @author A Toda Hora S.A
 * @author Oscar Yovany Baquero Moreno
 * @version 1.0
 * @create 02/04/2007
 */
public interface ILDAPErrors {
    String NumericCharacterSet = "[LDAP: error code 53 - Password Policy Error :9003: GSL_PWDNUMERIC_EXCP"; //Your Password must contain atleast 1 numeric characters
    String LessCharactersSet   = "[LDAP: error code 53 - Password Policy Error :9003: GSL_PWDMINLENGTH_EXCP"; //Your Password must contain atleast 8 characters along
    String NumericCharacter    = "[LDAP: error code 53 - Password Policy Error :9004: GSL_PWDNUMERIC_EXCP"; //Your Password must contain atleast 1 numeric characters
    String LessCharacters      = "[LDAP: error code 53 - Password Policy Error :9004: GSL_PWDMINLENGTH_EXCP"; //Your Password must contain atleast 8 characters along
    String OldPswd     		   = "[LDAP: error code 19 - Error, Password in History]"; //Your New Password cannot be the same as your Old Password.    
    String UserExists          = "[LDAP: error code 68"; // Object already exists
    String UserExistsInGroup   = "[LDAP: error code 20"; // uniquemember attribute has duplicate value
    String NoSuchObject        = "[LDAP: error code 32 - No Such Object]";
    String PswdMinDiffChars    = "[LDAP: error code 19 - Failed passwordMinDiffChars policy]";
   // [LDAP: error code 19 - Failed passwordMinDiffChars policy]
   // [LDAP: error code 19 - Error, Password too short]
   // [LDAP: error code 19 - Failed passwordMinAlphaChars policy]
    String LockedAccount       = "[LDAP: error code 53 - Error, Account is locked]";
   	String PswdExpired	       = "[LDAP: error code 49 - Error, Password has expired]";
   	String InvalidCredentials  = "[LDAP: error code 49 - Invalid Credentials]";
   String NoSuchAttribute = "[LDAP: error code 16 - No Such Attribute]";
}
