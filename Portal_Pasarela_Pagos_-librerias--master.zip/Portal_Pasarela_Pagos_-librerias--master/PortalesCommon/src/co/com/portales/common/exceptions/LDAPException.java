package co.com.portales.common.exceptions;

/**
 * Clase encargada de gestionar la excepciones LDAP
 * 
 * @author ATH S.A
 * @author Alejandro Victoria
 * @version 1.0
 * @create 04/05/2012
 */

public class LDAPException extends Exception {

	private static final long serialVersionUID = 1L;
	private String errorCode;
	private Exception excepcion;

	public LDAPException(String errorCode, String message, Exception e) {
		super(message);
		this.errorCode = errorCode;
		this.excepcion = e;

	}

	public LDAPException(String message, Exception e) {
		super(message, e);
	}

	public LDAPException(String message) {
		super(message);
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public Exception getExcepcion() {
		return excepcion;
	}

	public void setExcepcion(Exception excepcion) {
		this.excepcion = excepcion;
	}

}
