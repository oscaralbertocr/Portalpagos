package co.com.portales.common.ldap;

/**
 * Clase VO con el ID del usuario, nombre y correo electr�nico
 */
public class UserVO {
	private String cn;
	private String uid;
	private String name;
	private String userPassword;
	private String givenname;
	private String sn;
	private String ou;
	private String mail;
	private String cedula;
	private String estado;

	/**
	 * @return the estado
	 */
	public String getEstado() {
		return estado;
	}

	/**
	 * @param estado the estado to set
	 */
	public void setEstado(String estado) {
		this.estado = estado;
	}

	public UserVO(String cn, String uid, String pass, String givenname,
			String sn, String ou, String mail) {
		this.cn = cn;
		this.uid = uid;
		this.userPassword = pass;
		this.givenname = givenname;
		this.sn = sn;
		this.ou = ou;
		this.mail = mail;
	}

	public UserVO(String cn, String uid, String pass, String givenname,
			String sn, String ou, String mail, String name, String estado) {
		this.cn = cn;
		this.uid = uid;
		this.userPassword = pass;
		this.givenname = givenname;
		this.sn = sn;
		this.ou = ou;
		this.mail = mail;
		this.name = name;
		this.estado = estado;
	}

	public void setCn(String cn) {
		this.cn = cn;
	}

	public String getCn() {
		return cn;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setGivenname(String givenname) {
		this.givenname = givenname;
	}

	public String getGivenname() {
		return givenname;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public String getSn() {
		return sn;
	}

	public void setOu(String ou) {
		this.ou = ou;
	}

	public String getOu() {
		return ou;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getMail() {
		return mail;
	}

	
	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getUid() {
		return uid;
	}

	
}
