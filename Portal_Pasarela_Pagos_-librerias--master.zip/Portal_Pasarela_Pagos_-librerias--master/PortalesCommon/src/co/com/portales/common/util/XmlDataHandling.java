package co.com.portales.common.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringReader;
import org.apache.xml.serialize.Method;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.Marshaller;
import org.exolab.castor.xml.Unmarshaller;
import org.exolab.castor.xml.ValidationException;
import org.xml.sax.ContentHandler;

public class XmlDataHandling {
	/**
	 * Marshalling (serializacion) del mensaje
	 * @param message
	 * @param cdataFields
	 * @return byte[]
	 * @throws IOException
	 * @throws MarshalException
	 * @throws ValidationException
	 */
    public byte[] marshalObject(Object message, String[] cdataFields) throws IOException, MarshalException, ValidationException
    {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        OutputFormat format = new OutputFormat(Method.XML, "UTF-8", true);

        // Define the names of the XML elements to put > around
        format.setCDataElements(cdataFields);
        format.setNonEscapingElements(cdataFields); // Those elements should NOT
        // be escaped..

        // Create the serializer
        XMLSerializer serializer = new XMLSerializer(baos, format);

        // Create the document handler
        serializer.setOutputFormat(format);
        ContentHandler handler = serializer.asContentHandler();

        // Create the marshaller
        Marshaller marshaller = new Marshaller(handler);
        // The object you wanna marshal
        marshaller.marshal(message);

        byte [] result = baos.toByteArray();
        baos.flush();
        baos.close();

        return result;
    }
    /**
	 * Marshalling (serializacion) del mensaje 
     * @param message
     * @return byte[]
     * @throws IOException
     * @throws MarshalException
     * @throws ValidationException
     */
    public byte[] marshalObject(Object message) throws IOException, MarshalException, ValidationException
    {
        return marshalObject(message, null);
    }
    /**
     * Marshalling (serializacion) del mensaje con envoltorio
     * @param message
     * @param envelopeHeader
     * @param envelopeClose
     * @return
     * @throws IOException
     * @throws MarshalException
     * @throws ValidationException
     */
    public byte[] marshalObjectWithEnvelope(Object message, String envelopeHeader, String envelopeClose)
            throws IOException, MarshalException, ValidationException
    {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        OutputFormat format = new OutputFormat(Method.TEXT, "UTF-8", true);
        format.setOmitXMLDeclaration(true);
        // Create the serializer
        XMLSerializer serializer = new XMLSerializer(baos, format);
        // Create the document handler
        serializer.setOutputFormat(format);
        ContentHandler handler = serializer.asContentHandler();
        // Create the marshaller
        Marshaller marshaller = new Marshaller(handler);
        // The object you wanna marshal
        marshaller.setSupressXMLDeclaration(true);
        marshaller.marshal(message);
        byte []result = baos.toByteArray();
        String msg = new String(result);
        msg = envelopeHeader + msg + envelopeClose;
        result = msg.getBytes();
        baos.flush();
        baos.close();
        return result;
    }
    /**
     * Unmarshalling (des - serializacion) del mensaje 
     * @param c
     * @param xmlBytes
     * @return
     * @throws MarshalException
     * @throws ValidationException
     */
    @SuppressWarnings("rawtypes")
	public Object unmarshalObject(Class c, byte[] xmlBytes) throws MarshalException, ValidationException
    {
        StringReader sr = new StringReader(new String(xmlBytes));
        Object response = Unmarshaller.unmarshal(c, sr);
        sr.close();
        return response;
    }
    /**
     * 
     * @param message
     * @param element
     * @return
     * @throws IOException
     * @throws MarshalException
     * @throws ValidationException
     */
    public byte[] marshalObjectWithOutEscapingElements(Object message, String[] element) throws IOException,
            MarshalException, ValidationException
    {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        OutputFormat format = new OutputFormat(Method.XML, "UTF-8", true);
        format.setOmitXMLDeclaration(true);
        // Define the names of the XML elements to put > around
        format.setNonEscapingElements(element); // Those elements should NOT
        // be escaped..
        // Create the serializer
        XMLSerializer serializer = new XMLSerializer(baos, format);
        // Create the document handler
        serializer.setOutputFormat(format);
        ContentHandler handler = serializer.asContentHandler();

        // Create the marshaller
        Marshaller marshaller = new Marshaller(handler);
        // The object you wanna marshal
        marshaller.marshal(message);

        byte [] result = baos.toByteArray();
        baos.flush();
        baos.close();

        return result;
    }
}