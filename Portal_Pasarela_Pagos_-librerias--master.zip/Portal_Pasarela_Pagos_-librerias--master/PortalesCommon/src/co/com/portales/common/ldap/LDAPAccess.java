package co.com.portales.common.ldap;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;

import javax.naming.AuthenticationException;
import javax.naming.CommunicationException;
import javax.naming.Context;
import javax.naming.NameNotFoundException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.apache.log4j.Logger;

import co.com.pasarelapagos.dto.ComercioDTO;
import co.com.pasarelapagos.dto.UsuarioDTO;
import co.com.portales.common.contants.IConstants;
import co.com.portales.common.contants.IMessageException;
import co.com.portales.common.exceptions.LDAPException;
import co.com.portales.common.util.BeanLocator;
import co.com.portales.common.util.MessageFormatter;
import co.com.portales.common.util.PropertiesLoader;

/**
 * Ofrece accesso a LDAP Clase implementada para negocio con TDS
 */
public class LDAPAccess {

	private static final String MENSAJE_ERROR_PROCESO_AUTENTICACION = "Error al realizar proceso de autenticaci�n."; //$NON-NLS-1$
	private static final String STRING_VACIO = ""; //$NON-NLS-1$
	private static final String LDAP_CREDENT_ROOT = "CREDENT_ROOT"; //$NON-NLS-1$
	private static final String LDAP_USER_ROOT = "USER_ROOT"; //$NON-NLS-1$
	private static final String MENSAJE_CREACION_LDAPACCESS = "Creacion de LDAPAccess..."; //$NON-NLS-1$
	private static final String LDAP_SECURITY_AUTHENTICATION = "SECURITY_AUTHENTICATION";
	private static final String LDAP_CREDENT = "CREDENT";
	private static final String LDAP_USER = "USER";
	private static final String LDAP_PORT = "PORT";
	private static final String LDAP_SERVER = "SERVER";
	private static final String LDAP_DN_BASE = "DN_BASE";
	private static final String LDAP_DN_BASE_COMERCIOS = "DN_BASE_COMERCIOS";
	private static final String LDAP_DN_BASE_GROUPS = "DN_BASE_GROUPS";
	
	
	private static final String ERROR_CERRANDO_EL_CONTEXTO = "ERROR CERRANDO EL CONTEXTO...";
	private static final String LDAP_CADENA_CN = "cn=";
	private static final String CARACTER_COMMA = ",";
	private static final String BUSQUEDA_REPLACE_COMERCIO = "*COMERCIO*";
	private static final String LDAP_PROPERTIES = "ldap.properties";
	private static final String INITIAL_CONTEXT = "com.sun.jndi.ldap.LdapCtxFactory";

	/*
	 * Variables para normalizar el nombre de los atributos
	 */
	public static final String ATTRIB_EMAIL = "ath-email";
	public static final String ATTRIB_ESTADO = "ath-estado";
	public static final String ATTRIB_APELLIDO1 = "ath-primer-apellido";
	public static final String ATTRIB_APELLIDO2 = "ath-segundo-apellido";
	public static final String ATTRIB_NOMBRE1 = "ath-primer-nombre";
	public static final String ATTRIB_NOMBRE2 = "ath-segundo-nombre";
	public static final String ATTRIB_CLAVE_TEMPORAL = "ath-clavetemporal";
	public static final String ATTRIB_CN = "cn";
	public static final String ATTRIB_SN = "sn";
	public static final String ATTRIB_UID = "uid";
	public static final String ATTRIB_DIRECCION = "ath-direccion";
	public static final String ATTRIB_TELEFONO = "ath-telefono";
	public static final String ATTRIB_ULT_LOGIN = "ath-fechaultimologin";
	public static final String ATTRIB_ID_COMERCIO = "ath-id";
	public static final String ATTRIB_DESCRIPCION = "description";
	public static final String ATTRIB_PSWD = "userPassword";
	public static final String ATTRIB_FECHA_PWD_TMP = "ath-fechaClaveTemporal";
	public static final String ATTRIB_INTENTOS = "ath-intentos";
	public static final String ATTRIB_MIEMBROS = "member";
	private static Properties properties;

	static {
		try {
			PropertiesLoader propertiesLoader = PropertiesLoader.getInstance();
			properties = propertiesLoader.getProperties(LDAP_PROPERTIES);
		} catch (Exception e) {
			Logger.getLogger(BeanLocator.class).error(e);
		}
	}

	/**
	 * log4java
	 */
	static Logger log = Logger.getLogger(LDAPAccess.class);
	private String initCtx;
	private String host;
	private String mgrDN;
	private String mgrPW;
	private String sec_aut;
	private String searchBase;
	private String searchBaseGroups;
	private String searchBaseComercio;
	private DirContext ctx = null;

	public LDAPAccess(String comercio) {
		// Lee atributos desde ldap.properties:
		try {
			String searchBase = properties.getProperty(LDAP_DN_BASE);
			String ldapServer = properties.getProperty(LDAP_SERVER);
			String ldapPort = properties.getProperty(LDAP_PORT);
			String ldapUser = properties.getProperty(LDAP_USER);
			String ldapCred = properties.getProperty(LDAP_CREDENT);

			String sec_aut = properties.getProperty(LDAP_SECURITY_AUTHENTICATION);
			String searchBaseComercio = properties.getProperty(LDAP_DN_BASE_COMERCIOS);
			String searchBaseGroups = properties.getProperty(LDAP_DN_BASE_GROUPS);

			log.info(MENSAJE_CREACION_LDAPACCESS);
			this.initCtx = INITIAL_CONTEXT;
			StringBuilder hostSt = new StringBuilder(ldapServer);
			hostSt.append(IConstants.CARACTER_DOS_PUNTOS);
			hostSt.append(ldapPort);
			this.host = hostSt.toString();
			this.mgrDN = ldapUser;
			this.mgrPW = ldapCred;
			this.sec_aut = sec_aut;
			this.searchBase = searchBase.replace(BUSQUEDA_REPLACE_COMERCIO, comercio);
			this.searchBaseComercio = searchBaseComercio;
			this.searchBaseGroups = searchBaseGroups;

		} catch (Throwable t) {
			log.error(t.getMessage(), t);
		}
	}

	public LDAPAccess(String comercio, boolean isRoot) {
		// Lee atributos desde ldap.properties:
		try {

			String searchBase = properties.getProperty(LDAP_DN_BASE);
			String ldapServer = properties.getProperty(LDAP_SERVER);
			String ldapPort = properties.getProperty(LDAP_PORT);
			String ldapUser = STRING_VACIO;
			String ldapCred = STRING_VACIO;
			if (isRoot) {
				ldapUser = properties.getProperty(LDAP_USER_ROOT);
				ldapCred = properties.getProperty(LDAP_CREDENT_ROOT);
			} else {
				ldapUser = properties.getProperty(LDAP_USER);
				ldapCred = properties.getProperty(LDAP_CREDENT);
			}
			String sec_aut = properties.getProperty(LDAP_SECURITY_AUTHENTICATION);
			String searchBaseComercio = properties.getProperty(LDAP_DN_BASE_COMERCIOS);

			log.info(MENSAJE_CREACION_LDAPACCESS);
			this.initCtx = INITIAL_CONTEXT;
			StringBuilder hostSt = new StringBuilder(ldapServer);
			hostSt.append(IConstants.CARACTER_DOS_PUNTOS);
			hostSt.append(ldapPort);
			this.host = hostSt.toString();
			this.mgrDN = ldapUser;
			this.mgrPW = ldapCred;
			this.sec_aut = sec_aut;
			this.searchBase = searchBase.replace(BUSQUEDA_REPLACE_COMERCIO, comercio);
			this.searchBaseComercio = searchBaseComercio;

		} catch (Throwable t) {
			log.error(t.getMessage(), t);
		}
	}

	/**
	 * Inicializa las variables necesarias para realizar la conexi�n con el
	 * servidor LDAP
	 * 
	 * @param searchBase
	 *            Nodo ra�z desde donde se har�n las busquedas
	 * @param mgrPW
	 *            Password de usuario administrador
	 * @param mgrDN
	 *            DN de usuario administrador
	 * @param host
	 *            Nombre o direcci�n IP del servidor LDAP
	 * @param initCtx
	 *            Contexto inicial
	 */
	public LDAPAccess(String host, String mgrDN, String mgrPW, String sec_aut,
			String searchBase, String searchBaseComercio,
			String searchBaseGroups) {
		this.initCtx = INITIAL_CONTEXT;
		this.host = host;
		this.mgrDN = mgrDN;
		this.mgrPW = mgrPW;
		this.sec_aut = sec_aut;
		this.searchBase = searchBase;
		this.searchBaseComercio = searchBaseComercio;
		this.searchBaseGroups = searchBaseGroups;
	}

	/**
	 * Establece conexi�n con el servidor LDAP
	 * 
	 * @throws javax.naming.NamingException
	 * @return Una nueva instancia de la clase DirContext
	 */
	private DirContext getInitialDirContext() throws NamingException {
		Hashtable<String, String> env = new Hashtable<String, String>();

		// Se especifica la clase a usar para nuestro JNDI provider
		env.put(Context.INITIAL_CONTEXT_FACTORY, initCtx);
		env.put(Context.PROVIDER_URL, host);
		env.put(Context.SECURITY_AUTHENTICATION, sec_aut);
		env.put(Context.SECURITY_PRINCIPAL, mgrDN);
		env.put(Context.SECURITY_CREDENTIALS, mgrPW);
		// Trae una referencia a un directory context
		DirContext ctx = new InitialDirContext(env);
		return ctx;
	}


	/**
	 * Verifica que un usuario se encuentre creado.
	 * 
	 * @throws javax.naming.NamingException
	 * @return
	 * @param userVO
	 * @param ctx
	 */
	public boolean existsUser(UserVO userVO) {
		StringBuilder messageError = new StringBuilder("::: ERROR CONSULTANDO EL USUARIO ::: ");
		StringBuilder lookupText = new StringBuilder(LDAP_CADENA_CN);
		lookupText.append(userVO.getCn());
		lookupText.append(CARACTER_COMMA);
		lookupText.append(searchBase);
		try {
			DirContext ctx = getInitialDirContext();
			return ctx.lookup(lookupText.toString()) != null;
		} catch (Exception e) {
			messageError.append(e.getMessage());
			log.error(messageError,e);
		}
		return false;
	}

	/**
	 * Permite cambiar el password del usuario
	 * 
	 * @throws javax.naming.NamingException
	 * @return
	 * @param newPass
	 * @param userID
	 * @param ctx
	 */
	public boolean changePass(String userID, String currentPass, String newPass) throws NamingException
	{
		try {
			ctx = getInitialDirContext();
			ModificationItem[] mods = new ModificationItem[4];
		     String oldQuotedPassword =  currentPass ;
		     String newQuotedPassword =  newPass ;

		     mods[0] = new ModificationItem(DirContext.REMOVE_ATTRIBUTE,
		                   new BasicAttribute(ATTRIB_PSWD, oldQuotedPassword));
		     mods[1] = new ModificationItem(DirContext.ADD_ATTRIBUTE,
		                   new BasicAttribute(ATTRIB_PSWD, newQuotedPassword));
		     mods[2] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
	                   new BasicAttribute(ATTRIB_CLAVE_TEMPORAL, UsuarioDTO.CLAVE_TEMPORAL_FALSE));
		     mods[3] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
	                   new BasicAttribute(ATTRIB_FECHA_PWD_TMP, null));

		     // Perform the update
		     ctx.modifyAttributes(LDAP_CADENA_CN + userID + CARACTER_COMMA + searchBase, mods);
		     log.info("Changed Password for successfully");
		     ctx.close();
						
		} catch (NamingException e) {
			log.error("::: NO FUE POSIBLE ACTUALIZAR LA CONTRASE�A: " + e.getMessage() + " :::", e);
			StringBuilder message = new StringBuilder(managePasswordException(userID, e));
			if (message.length() == 0){
				message.append(MessageFormatter.format(IMessageException.ErrorChangingPass	+ IMessageException.ConsultSystemAdministrator, new Object[] { userID }));
			}
			throw new NamingException(message.toString());
		} finally {
			if (null != ctx) {
				ctx.close();
				ctx = null;
			}
		}
		return true;
	}
	
	/**
	 * Permite cambiar el password del usuario
	 * 
	 * @throws javax.naming.NamingException
	 * @return
	 * @param newPass
	 * @param userID
	 * @param ctx
	 */
	public boolean changePassRoot(String userID, String newPass, String fechaPasswordTemp) throws NamingException
	{
		try {
			ctx = getInitialDirContext();	
			ModificationItem[] mods = new ModificationItem[3];
		     mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
		                   new BasicAttribute(ATTRIB_PSWD, newPass));
		     mods[1] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
	                   new BasicAttribute(ATTRIB_FECHA_PWD_TMP, fechaPasswordTemp));
		     mods[2] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
	                   new BasicAttribute(ATTRIB_CLAVE_TEMPORAL, UsuarioDTO.CLAVE_TEMPORAL_TRUE));

		     // Perform the update
		     ctx.modifyAttributes(LDAP_CADENA_CN + userID + CARACTER_COMMA + searchBase, mods);
		     log.info("Changed Password for successfully");
		     ctx.close();
		} catch (NamingException e) {
			log.error("::: NO FUE POSIBLE CAMBIAR LA CONTRASE�A: " + e.getMessage() + " :::", e);
			StringBuilder message = new StringBuilder(managePasswordException(userID, e));
			if (message.length() == 0){
				message.append(MessageFormatter.format(e.getMessage() + e.getCause(), new Object[] { userID }));
				//MessageFormatter.format(IMessageException.ErrorChangingPass	+ IMessageException.ConsultSystemAdministrator,new Object[] { userID });
			}
			throw new NamingException(message.toString());
		} finally {
			if (null != ctx) {
				ctx.close();
				ctx = null;
			}
		}
		return true;
	}

	/**
	 * Maneja las excepciones causadas por errores en asignaci�n de claves.
	 * 
	 * @throws LDAPException
	 * @return
	 * @param userName
	 * @param errorMessage
	 * @param e
	 */
	public String managePasswordException(String userName, Exception e) {
		String error = e.getMessage();
		String message = STRING_VACIO;

		try {
			if (error.startsWith(ILDAPErrors.NumericCharacter) || error.startsWith(ILDAPErrors.NumericCharacterSet)) {
				String numero = properties.getProperty(IConstants.MIN_NUMERIC_CHARACTERS);
				message = MessageFormatter.format(
						IMessageException.LeastOneNumericCharacter,new Object[] { numero });
			}
			else if (error.startsWith(ILDAPErrors.UserExists)) {
				message = MessageFormatter.format(IMessageException.UserExistent,new Object[] { userName });
			}
			else if (error.startsWith(ILDAPErrors.LessCharacters) || error.startsWith(ILDAPErrors.LessCharactersSet)) {
				String numero = properties.getProperty(IConstants.MIN_LENGTH_PSWD);
				message = MessageFormatter.format(IMessageException.LessCharacters,new Object[] {numero});
			}
			else if (error.startsWith(ILDAPErrors.UserExistsInGroup)) {
				message = MessageFormatter.format(IMessageException.UserExistent,	new Object[] {userName});
			}
			else if (error.startsWith(ILDAPErrors.OldPswd)) {
				message = IMessageException.CannotAssignOldPswd;
			}
			else if (error.startsWith(ILDAPErrors.PswdMinDiffChars)) {
				message = IMessageException.PswdMinDiffChars;
			}
			else if(error.startsWith(ILDAPErrors.NoSuchAttribute)){
				message = IMessageException.NoSuchAttributePass;
			}
		} catch (Exception ex) {
			log.error(ex.getMessage(), e);
		}
		return message;
	}
	
	/**
	 * Maneja las excepciones causadas por errores en autenticacion de usuarios
	 * 
	 * @throws LDAPException
	 * @return
	 * @param userName
	 * @param errorMessage
	 * @param e
	 */
	public String manageLoginException(String userName, Exception e) {
		String error = e.getMessage();
		String message = STRING_VACIO;
		
		try {
			if (error.startsWith(ILDAPErrors.LockedAccount)) {
				message = MessageFormatter.format(IMessageException.LockedAccount,new Object[] { userName });
			}
			else if (error.startsWith(ILDAPErrors.PswdExpired)) {
				message = MessageFormatter.format(IMessageException.PswdExpired,new Object[] { userName });
			}
			else if (error.startsWith(ILDAPErrors.InvalidCredentials)) {
				message = MessageFormatter.format(IMessageException.InvalidCredentials,new Object[] {userName});
			}else{
				message =e.getMessage();
			}
		} catch (Exception ex) {
			log.error(ex.getMessage(), e);
		}
		return message;
	}
	/**
	 * Maneja las excepciones causadas por errores en autenticacion de usuarios
	 * 
	 * @throws LDAPException
	 * @return
	 * @param userName
	 * @param errorMessage
	 * @param e
	 */
	public String manageLoginException(String userName, Throwable e) {
		String error = e.getMessage();
		String message = STRING_VACIO;
		
		try {
			if (error.startsWith(ILDAPErrors.LockedAccount)) {
				message = IMessageException.LockedAccount;
			}
			else if (error.startsWith(ILDAPErrors.PswdExpired)) {
				message = IMessageException.PswdExpired;
			}
			else if (error.startsWith(ILDAPErrors.InvalidCredentials)) {
				message = IMessageException.InvalidCredentials;
			}else{
				message =e.getMessage();
			}
		} catch (Exception ex) {
			log.error(ex.getMessage(), e);
		}
		return message;
	}
	/**
	 * Crear objeto Usuario a partir de los datos almacenados en el directorio
	 * @param user
	 * @return objeto Usuario con los datos almacenados en el directorio
	 * @throws LDAPException 
	 */
	public UsuarioDTO searchUserVoByUsername(String user) throws LDAPException{
		
		UsuarioDTO result = null;
		StringBuilder mensajeError = new StringBuilder("::: ERROR EN EL METODO searchUserVoByUsername(String user), user = ");
		StringBuilder message = new StringBuilder(STRING_VACIO);
		mensajeError.append(user);
		try {
			//Obtener los atributos del usuario
			Attributes attrs = getInitialDirContext().getAttributes(LDAP_CADENA_CN + user + CARACTER_COMMA + this.searchBase);
			
			if (attrs != null) {
				//Construir el objeto usuario
				result = new UsuarioDTO(); 								
				result.setUsuario(user);	
				
				//usuario
				result.setUsuario(user);

				if(attrs.get(ATTRIB_PSWD) != null && attrs.get(ATTRIB_PSWD).get() != null){
					result.setClave(attrs.get(ATTRIB_PSWD).get().toString());
				}
				//Nombre1
				if (attrs.get(ATTRIB_NOMBRE1) != null && attrs.get(ATTRIB_NOMBRE1).get() != null) {
					result.setPrimerNombre(attrs.get(ATTRIB_NOMBRE1).get().toString());
				}
				//Nombre2
				if (attrs.get(ATTRIB_NOMBRE2) != null && attrs.get(ATTRIB_NOMBRE2).get() != null) {
					result.setSegundoNombre(attrs.get(ATTRIB_NOMBRE2).get().toString());
				}
				//Apellido 1
				if (attrs.get(ATTRIB_APELLIDO1) != null && attrs.get(ATTRIB_APELLIDO1).get() != null) {
					result.setPrimerApellido(attrs.get(ATTRIB_APELLIDO1).get().toString());
				}
				//Apellido 2
				if (attrs.get(ATTRIB_APELLIDO2) != null && attrs.get(ATTRIB_APELLIDO2).get() != null) {
					result.setSegundoApellido(attrs.get(ATTRIB_APELLIDO2).get().toString());
				}
				//Direccion
				if (attrs.get(ATTRIB_DIRECCION) != null && attrs.get(ATTRIB_DIRECCION).get() != null) {
					result.setDireccion(attrs.get(ATTRIB_DIRECCION).get().toString());
				}
				//CorreoElectronico
				if (attrs.get(ATTRIB_EMAIL) != null && attrs.get(ATTRIB_EMAIL).get() != null) {
					result.setCorreoElectronico(attrs.get(ATTRIB_EMAIL).get().toString());
				}
				//Estado
				if (attrs.get(ATTRIB_ESTADO) != null && attrs.get(ATTRIB_ESTADO).get() != null) {
					result.setEstado(attrs.get(ATTRIB_ESTADO).get().toString());
				}
				//Clave Temporal
				if (attrs.get(ATTRIB_CLAVE_TEMPORAL) != null && attrs.get(ATTRIB_CLAVE_TEMPORAL).get() != null) {
					result.setClaveTemporal(UsuarioDTO.CLAVE_TEMPORAL_TRUE.equals(attrs.get(ATTRIB_CLAVE_TEMPORAL).get().toString()));
				}
				//FechaUltimoLogin
				if (attrs.get(ATTRIB_ULT_LOGIN) != null && attrs.get(ATTRIB_ULT_LOGIN).get() != null) {
					String ultimoLogin= attrs.get(ATTRIB_ULT_LOGIN).get().toString();
					try{
						int a�o = Integer.valueOf(ultimoLogin.substring(0,4));
						int mes = Integer.valueOf(ultimoLogin.substring(4,6))-1;
						int dia = Integer.valueOf(ultimoLogin.substring(6,8));
						int hora = Integer.valueOf(ultimoLogin.substring(8,10));
						int min = Integer.valueOf(ultimoLogin.substring(10,12));
						int seg = Integer.valueOf(ultimoLogin.substring(12,14));
						Calendar fechaUltLog = Calendar.getInstance();
						fechaUltLog.set(a�o,mes,dia,hora,min,seg);
						result.setFechaUltimoLogin(fechaUltLog.getTime());
					}catch(Exception e){
						log.warn("No se pudo convertir la fecha de ultimo login usuario: "+ user +" fecha:"+ultimoLogin);
						result.setFechaUltimoLogin(new Date());
					}
				}
				//Telefono
				if (attrs.get(ATTRIB_TELEFONO) != null && attrs.get(ATTRIB_TELEFONO).get() != null) {
					result.setTelefono(attrs.get(ATTRIB_TELEFONO).get().toString());
				}
				
				//FechaClaveTemporal
				if (attrs.get(ATTRIB_FECHA_PWD_TMP) != null && attrs.get(ATTRIB_FECHA_PWD_TMP).get() != null) {
					String claveTemporal= attrs.get(ATTRIB_FECHA_PWD_TMP).get().toString();
					try{
						int a�o = Integer.valueOf(claveTemporal.substring(0,4));
						int mes = Integer.valueOf(claveTemporal.substring(4,6))-1;
						int dia = Integer.valueOf(claveTemporal.substring(6,8));
						int hora = Integer.valueOf(claveTemporal.substring(8,10));
						int min = Integer.valueOf(claveTemporal.substring(10,12));
						int seg = Integer.valueOf(claveTemporal.substring(12,14));
						Calendar fechaClaveTemp = Calendar.getInstance();
						fechaClaveTemp.set(a�o,mes,dia,hora,min,seg);
						result.setFechaClaveTemporal(fechaClaveTemp.getTime());
					}catch(Exception e){
						log.warn("No se pudo convertir la fecha de asignaci�n de clave temporal: "+ user +" fecha:"+claveTemporal);
						result.setFechaUltimoLogin(new Date());
					}
				}
				
				//Numero de intentos
				if (attrs.get(ATTRIB_INTENTOS) != null && attrs.get(ATTRIB_INTENTOS).get() != null) {
					result.setIntentos(attrs.get(ATTRIB_INTENTOS).get().toString());
				}
				else{
					result.setIntentos("0");
				}
				
			} else {
				log.warn("No se recuper� un usuario del LDAP");
			}
		} catch (NameNotFoundException e) {
			//control de error cuando el usuario no existe
			log.error(mensajeError.toString(), e);
			message.append(MessageFormatter.format(IMessageException.UserNotFoundInDB, new Object[] { user }));
			throw new LDAPException(message.toString());
		}catch (CommunicationException e) {
			log.error(mensajeError.toString(), e);
			message.append(MessageFormatter.format(IMessageException.ErrorValidateClientData, new Object[] { }));
			throw new LDAPException(message.toString());
		}catch (NamingException e) {
			log.error(mensajeError.toString(), e);
			message.append(MessageFormatter.format(IMessageException.ErrorQuery, new Object[] { }));
			throw new LDAPException(message.toString());
		}
		
		return result;
	}
	

	
	/**
	 * Crear objeto Comercio a partir de los datos almacenados en el directorio
	 * @param comercio
	 * @return objeto Comercio con los datos almacenados en el directorio
	 * @throws LDAPException 
	 */
	public ComercioDTO searchComercioByName(String comercio) throws LDAPException{
		
		ComercioDTO result = null;
		StringBuilder messageError = new StringBuilder(STRING_VACIO);
		
		try {
			//Obtener los atributos del comercio
			Attributes attrs = getInitialDirContext().getAttributes("dc=" + comercio + CARACTER_COMMA + this.searchBaseComercio);
			
			if (attrs != null) {
				//Construir el objeto usuario
				result = new ComercioDTO(); 	
				result.setNombreEnTDS(comercio);
				//Id
				if (attrs.get(ATTRIB_ID_COMERCIO) != null && attrs.get(ATTRIB_ID_COMERCIO).get() != null) {
					try{
						result.setId(Integer.valueOf(attrs.get(ATTRIB_ID_COMERCIO).get().toString()));
					}catch(Exception e){
						result.setId(0);
					}
				}
				if (attrs.get(ATTRIB_DESCRIPCION) != null && attrs.get(ATTRIB_DESCRIPCION).get() != null) {
					try{
						result.setDescripcion(attrs.get(ATTRIB_DESCRIPCION).get().toString());
					}catch(Exception e){
						result.setId(0);
					}
				}
								
			} else {
				log.warn("No se recuper� un comercio del LDAP");
			}
		} catch (NameNotFoundException e) {
			//control de error cuando el comercio no existe
			messageError.append(MessageFormatter.format(IMessageException.UserNotFoundInDB, new Object[] { comercio }));
			log.error(e.getMessage(), e);
			throw new LDAPException(messageError.toString());
		} catch (NamingException e) {
			messageError.append(MessageFormatter.format(IMessageException.ErrorQuery, new Object[] { }));
			log.error(e.getMessage(), e);
			throw new LDAPException(messageError.toString());
		}
		
		return result;
	}
	
	/**
	 * Actualiza la fecha de login del usuario
	 * @param fechaLogin en formato yyyyMMddhhmmss.000000
	 * @param login del usuario
	 * @throws NamingException
	 */
	public void modifyLoginUserName(String fechaLogin, String loginUsuario) throws NamingException {
		
		if (loginUsuario == null || loginUsuario.length()==0 || fechaLogin == null || fechaLogin.length()==0) {
			throw new NamingException(MessageFormatter.format(
					IMessageException.ErrorActualizarValor, new Object[] { }));
		}
			
		List<ModificationItem> mods = new ArrayList<ModificationItem>();

		mods.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE, 
				new BasicAttribute(ATTRIB_ULT_LOGIN, fechaLogin)));

		//Actualizacion de datos en TDS		
		modifyUserAttribute(loginUsuario, mods.toArray(new ModificationItem[mods.size()]));

	}
	
	public void modifyAttemptsUser(String intento, String usuario) throws NamingException {
		
		if (usuario == null || usuario.length() == 0 || intento == null || intento.length() == 0) {
			throw new NamingException(MessageFormatter.format(IMessageException.ErrorActualizarValor, new Object[] { }));
		}
			
		List<ModificationItem> mods = new ArrayList<ModificationItem>();

		mods.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute(ATTRIB_INTENTOS, intento)));

		//Actualizacion de datos en TDS		
		modifyUserAttribute(usuario, mods.toArray(new ModificationItem[mods.size()]));

	}
	
    /**
     * Manejo del mensaje de excepciones
     * @param exception
     * @return
     */
    public String menageMessageException(Exception e){
    	String error = e.getMessage();
		String message = STRING_VACIO;
		
    	if (error.startsWith(ILDAPErrors.NoSuchObject)) {
			message = "Usuario no existe";
    	}
    	
    	return message;
    }
    
    /**
     * Autentica usuario al LDAP
     * @param user
     * @param password
     * @return
     */
    @SuppressWarnings("unused")
	public boolean authenticateUser(String user, char[] password) throws LDAPException{
    	StringBuilder messageError = new StringBuilder(STRING_VACIO);
		try {
			Hashtable<String,String> env = new Hashtable<String,String>();
			// Se especifica la clase a usar para nuestro JNDI provider
			env.put(Context.INITIAL_CONTEXT_FACTORY, initCtx);
			env.put(Context.PROVIDER_URL, host);
			env.put(Context.SECURITY_AUTHENTICATION, sec_aut);
			env.put(Context.SECURITY_PRINCIPAL, LDAP_CADENA_CN + user + CARACTER_COMMA + searchBase);
			env.put(Context.SECURITY_CREDENTIALS, new String(password));
			InitialDirContext a = new InitialDirContext(env); 
			return true; 
		} catch (AuthenticationException ae) {
			log.warn(MENSAJE_ERROR_PROCESO_AUTENTICACION + ae.getMessage());
			messageError.append(MessageFormatter.format(IMessageException.ErrorLoginUser, new Object[] { user }));
			messageError.append(manageLoginException(user, ae));
			throw new LDAPException(messageError.toString());
			
		} catch (Throwable t) {
			log.error(MENSAJE_ERROR_PROCESO_AUTENTICACION, t);
			messageError.append(MessageFormatter.format(IMessageException.ErrorLoginUser, new Object[] { user }));
			messageError.append(manageLoginException(user, t));
			throw new LDAPException(messageError.toString());
		}
	}	
     	
	/**
	 * M�todo que permite consultar los roles.
	 */
	@SuppressWarnings("rawtypes")
	public List<RolesVO> searchGroupsInTds() throws LDAPException {
		log.info("INICIA LA CONSULTA DE ROLES...");
		SearchControls constraints = new SearchControls();
		constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
		List<RolesVO> listaRoles = new ArrayList<RolesVO>();
		int cont = 0;
		try {
			NamingEnumeration results = null;
			results = getInitialDirContext().search(this.searchBaseGroups, "(objectclass=groupOfNames)", constraints);
			while (results.hasMore()) {
				cont++;
				SearchResult si = (SearchResult) results.next();
				Attributes attrs = si.getAttributes();
				if (attrs.get(ATTRIB_CN) != null
						&& attrs.get(ATTRIB_CN).get() != null) {
					RolesVO rol = new RolesVO();
					rol.setId(cont);
					rol.setRol(attrs.get(ATTRIB_CN).get().toString());
					if (attrs.get(ATTRIB_MIEMBROS) != null
							&& attrs.get(ATTRIB_MIEMBROS).size() > 0) {
						List<String> miembros = new ArrayList<String>();
						for (int i = 0; i < attrs.get(ATTRIB_MIEMBROS).size(); i++) {
							String[] miembroCompleto = attrs.get(ATTRIB_MIEMBROS).get(i).toString().split(CARACTER_COMMA);
							String[] miembro = miembroCompleto[0].split("=");
							miembros.add(miembro[1]);
						}
						rol.setMiembros(miembros);
					}
					listaRoles.add(rol);
				}
			}
		} catch (NamingException e1) {
			log.error("NO SE PUDO REALIZAR LA CONSULTA DE ROLES...", e1);
		} finally {
			if (null != ctx) {
				try {
					ctx.close();
				} catch (NamingException e) {
					log.error("ERROR EN EL CIERRE DEL CONTEXTO...", e);
				}
				ctx = null;
			}
		}
		log.info("FINALIZA LA CONSULTA DE ROLES...");
		return listaRoles;
	}

	/**
	 * M�todo que permite consultar los usuarios asociados a un comercio.
	 */
	@SuppressWarnings("rawtypes")
	public List<UsuarioDTO> searchUsersInTds(String comercio,
			List<RolesVO> roles) throws LDAPException {
		log.info("INICIA LA CONSULTA DE USUARIOS ASOCIADOS AL COMERCIO...");
		ComercioDTO comercioUser = new ComercioDTO();
		comercioUser.setDescripcion(comercio);
		SearchControls constraints = new SearchControls();
		constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
		List<UsuarioDTO> listaUsuarios = new ArrayList<UsuarioDTO>();
		try {
			NamingEnumeration results = null;
			results = getInitialDirContext().search(searchBase, "(objectclass=personapasarela)", constraints);
			while (results.hasMore()) {
				SearchResult si = (SearchResult) results.next();
				Attributes attrs = si.getAttributes();
				if (attrs.get(ATTRIB_CN) != null
						&& attrs.get(ATTRIB_CN).get() != null
						&& !(STRING_VACIO.equals(attrs.get(ATTRIB_CN).get()))) {
					UsuarioDTO usuario = new UsuarioDTO();
					// Rol
					for (RolesVO rol : roles) {
						if (rol.getMiembros() != null) {
							for (String user : rol.getMiembros()) {
								if (user.equals(attrs.get(ATTRIB_CN).get().toString())) {
									usuario.setRol(rol.getRol());
									break;
								}
							}

						}
					}

					// Usuario
					String[] usuarioCompleto = attrs.get(ATTRIB_CN).get().toString().split("_");
					String nombreUsuario = usuarioCompleto[0];
					usuario.setUsuario(nombreUsuario);
					
					usuario.setUsuario_mod(nombreUsuario);
					if(nombreUsuario.contains(" ")){
						String nuevoUsuario = nombreUsuario.replace(" ", "_");
						usuario.setUsuario_mod(nuevoUsuario);
					}

					// Clave
					if (attrs.get(ATTRIB_PSWD) != null
							&& attrs.get(ATTRIB_PSWD).get() != null
							&& !(STRING_VACIO.equals(attrs.get(ATTRIB_PSWD).get()))) {
						usuario.setClave(attrs.get(ATTRIB_PSWD).get()
								.toString());
					}

					// Descripcion
					if (attrs.get(ATTRIB_DESCRIPCION) != null
							&& attrs.get(ATTRIB_DESCRIPCION).get() != null
							&& !(STRING_VACIO.equals(attrs.get(ATTRIB_DESCRIPCION).get()))) {
						usuario.setDescripcion(attrs.get(ATTRIB_DESCRIPCION)
								.get().toString());
					}

					// Nombre1
					if (attrs.get(ATTRIB_NOMBRE1) != null
							&& attrs.get(ATTRIB_NOMBRE1).get() != null
							&& !(STRING_VACIO.equals(attrs.get(ATTRIB_NOMBRE1).get()))) {
						String nombre = attrs.get(ATTRIB_NOMBRE1).get()
								.toString();
						String mayuscula = nombre.charAt(0) + STRING_VACIO;
						mayuscula = mayuscula.toUpperCase();
						nombre = nombre.replaceFirst(nombre.charAt(0) + STRING_VACIO,
								mayuscula);
						usuario.setPrimerNombre(nombre);
					}

					// Nombre2
					if (attrs.get(ATTRIB_NOMBRE2) != null
							&& attrs.get(ATTRIB_NOMBRE2).get() != null
							&& !(STRING_VACIO.equals(attrs.get(ATTRIB_NOMBRE2).get()))) {
						String nombre = attrs.get(ATTRIB_NOMBRE2).get()
								.toString();
						String mayuscula = nombre.charAt(0) + STRING_VACIO;
						mayuscula = mayuscula.toUpperCase();
						nombre = nombre.replaceFirst(nombre.charAt(0) + STRING_VACIO,
								mayuscula);
						usuario.setSegundoNombre(nombre);
					}

					// Apellido 1
					if (attrs.get(ATTRIB_APELLIDO1) != null
							&& attrs.get(ATTRIB_APELLIDO1).get() != null
							&& !(STRING_VACIO.equals(attrs.get(ATTRIB_APELLIDO1).get()))) {
						String apellido = attrs.get(ATTRIB_APELLIDO1).get()
								.toString();
						String mayuscula = apellido.charAt(0) + STRING_VACIO;
						mayuscula = mayuscula.toUpperCase();
						apellido = apellido.replaceFirst(apellido.charAt(0) + STRING_VACIO, mayuscula);
						usuario.setPrimerApellido(apellido);
					}

					// Apellido 2
					if (attrs.get(ATTRIB_APELLIDO2) != null
							&& attrs.get(ATTRIB_APELLIDO2).get() != null
							&& !(STRING_VACIO.equals(attrs.get(ATTRIB_APELLIDO2).get()))) {
						String apellido = attrs.get(ATTRIB_APELLIDO2).get()
								.toString();
						String mayuscula = apellido.charAt(0) + STRING_VACIO;
						mayuscula = mayuscula.toUpperCase();
						apellido = apellido.replaceFirst(apellido.charAt(0)
								+ STRING_VACIO, mayuscula);
						usuario.setSegundoApellido(apellido);
					}

					// Direccion
					if (attrs.get(ATTRIB_DIRECCION) != null
							&& attrs.get(ATTRIB_DIRECCION).get() != null
							&& !(STRING_VACIO.equals(attrs.get(ATTRIB_DIRECCION).get()))) {
						usuario.setDireccion(attrs.get(ATTRIB_DIRECCION).get()
								.toString());
					}

					// CorreoElectronico
					if (attrs.get(ATTRIB_EMAIL) != null
							&& attrs.get(ATTRIB_EMAIL).get() != null
							&& !(STRING_VACIO.equals(attrs.get(ATTRIB_EMAIL).get()))) {
						usuario.setCorreoElectronico(attrs.get(ATTRIB_EMAIL)
								.get().toString());
					}

					// Estado
					if (attrs.get(ATTRIB_ESTADO) != null
							&& attrs.get(ATTRIB_ESTADO).get() != null
							&& !(STRING_VACIO.equals(attrs.get(ATTRIB_ESTADO).get()))) {
						String estado = attrs.get(ATTRIB_ESTADO).get()
								.toString();
						if (UsuarioDTO.ESTADO_ACTIVO.equals(estado)) {
							usuario.setEstado("Activo");
						} else {
							usuario.setEstado("Inactivo");
						}
					}

					// Clave Temporal
					if (attrs.get(ATTRIB_CLAVE_TEMPORAL) != null && !(STRING_VACIO.equals(attrs.get(ATTRIB_CLAVE_TEMPORAL).get())) && attrs.get(ATTRIB_CLAVE_TEMPORAL).get() != null) {
						usuario.setClaveTemporal(UsuarioDTO.CLAVE_TEMPORAL_TRUE.equals(attrs.get(ATTRIB_CLAVE_TEMPORAL).get().toString()) ? true : false);
					}

					// FechaUltimoLogin
					if (attrs.get(ATTRIB_ULT_LOGIN) != null
							&& !(STRING_VACIO.equals(attrs.get(ATTRIB_ULT_LOGIN).get()))
							&& attrs.get(ATTRIB_ULT_LOGIN).get() != null) {
						String ultimoLogin = attrs.get(ATTRIB_ULT_LOGIN).get()
								.toString();
						try {
							int a�o = Integer.valueOf(ultimoLogin.substring(0, 4));
							int mes = Integer.valueOf(ultimoLogin.substring(4, 6)) - 1;
							int dia = Integer.valueOf(ultimoLogin.substring(6, 8));
							int hora = Integer.valueOf(ultimoLogin.substring(8, 10));
							int min = Integer.valueOf(ultimoLogin.substring(10, 12));
							int seg = Integer.valueOf(ultimoLogin.substring(12, 14));
							Calendar fechaUltLog = Calendar.getInstance();
							fechaUltLog.set(a�o, mes, dia, hora, min, seg);
							usuario.setFechaUltimoLogin(fechaUltLog.getTime());
						} catch (Exception e) {
							StringBuilder mensaje = new StringBuilder();
							mensaje.append("No se pudo convertir la fecha de ultimo login usuario: ");
							mensaje.append(usuario.getUsuario());
							mensaje.append(" fecha: ");
							mensaje.append(ultimoLogin);
							log.warn(mensaje.toString());
							log.error(e.getMessage(), e);
							usuario.setFechaUltimoLogin(new Date());
						}
					}

					// Telefono
					if (attrs.get(ATTRIB_TELEFONO) != null
							&& !(STRING_VACIO.equals(attrs.get(ATTRIB_TELEFONO).get()))
							&& attrs.get(ATTRIB_TELEFONO).get() != null) {
						usuario.setTelefono(attrs.get(ATTRIB_TELEFONO).get()
								.toString());
					}

					// FechaClaveTemporal
					if (attrs.get(ATTRIB_FECHA_PWD_TMP) != null
							&& !(STRING_VACIO.equals(attrs.get(ATTRIB_FECHA_PWD_TMP).get()))
							&& attrs.get(ATTRIB_FECHA_PWD_TMP).get() != null) {
						String claveTemporal = attrs.get(ATTRIB_FECHA_PWD_TMP)
								.get().toString();
						try {
							int a�o = Integer.valueOf(claveTemporal.substring(0, 4));
							int mes = Integer.valueOf(claveTemporal.substring(4, 6)) - 1;
							int dia = Integer.valueOf(claveTemporal.substring(6, 8));
							int hora = Integer.valueOf(claveTemporal.substring(8, 10));
							int min = Integer.valueOf(claveTemporal.substring(10, 12));
							int seg = Integer.valueOf(claveTemporal.substring(12, 14));
							Calendar fechaClaveTemp = Calendar.getInstance();
							fechaClaveTemp.set(a�o, mes, dia, hora, min, seg);
							usuario.setFechaClaveTemporal(fechaClaveTemp
									.getTime());
						} catch (Exception e) {
							StringBuilder mensaje = new StringBuilder();
							mensaje.append("No se pudo convertir la fecha de asignaci�n de clave temporal: ");
							mensaje.append(usuario.getUsuario());
							mensaje.append(" fecha: ");
							mensaje.append(claveTemporal);
							log.error("NO SE PUDO REALIZAR LA CONSULTA DE USUARIOS ASOCIADOS AL COMERCIO:::: " + mensaje.toString(), e);
							usuario.setFechaUltimoLogin(new Date());
						}
					}
					listaUsuarios.add(usuario);
				}
			}
		} catch (NamingException e1) {
			log.error("NO SE PUDO REALIZAR LA CONSULTA DE USUARIOS ASOCIADOS AL COMERCIO::::", e1);
		} finally {
			if (null != ctx) {
				try {
					ctx.close();
				} catch (NamingException e) {
					log.error(ERROR_CERRANDO_EL_CONTEXTO, e);
				}
				ctx = null;
			}
		}

		log.info("FINALIZA LA CONSULTA DE USUARIOS ASOCIADOS AL COMERCIO::::");
		return listaUsuarios;
	}

	/**
	 * Metodo que permite eliminar un usuario especifico de un grupo
	 */
	public boolean deleteUserFromGroup(String groupName, String userName)
			throws LDAPException {
		log.info("INICIA LA ELIMINACION DEL USUARIO DEL GRUPO ASOCIADO::::");
		boolean resultado;
		String base = searchBase;
		// String baseGroup = properties.getProperty("DN_BASE_GROUPS");
		//String baseGroup = searchBaseGroups;
		StringBuilder userNameCompuest = new StringBuilder(LDAP_CADENA_CN);
		userNameCompuest.append(userName);
		userNameCompuest.append(CARACTER_COMMA);
		userNameCompuest.append(base);
		StringBuilder groupNameCompuest = new StringBuilder(LDAP_CADENA_CN);
		groupNameCompuest.append(groupName);
		groupNameCompuest.append(CARACTER_COMMA);
		groupNameCompuest.append(searchBaseGroups);

		
		try {
			ctx = getInitialDirContext();
			// Create a LDAP remove attribute for the member attribute
			ModificationItem[] mods = new ModificationItem[1];
			mods[0] = new ModificationItem(DirContext.REMOVE_ATTRIBUTE, new BasicAttribute("member", userNameCompuest));
			// update the group
			ctx.modifyAttributes(groupNameCompuest.toString(), mods);
			resultado = true;
		} catch (NamingException e) {
			resultado = false;
			log.error("::: SE PRESENTARON PROBLEMAS AL INTENTAR ELIMINAR EL USUARIO DEL GRUPO ASOCIADO::: " + e.getMessage(), e);
			String error = e.getMessage().substring(0, 20);
			if (error.startsWith(ILDAPErrors.UserExistsInGroup)) {
				error = MessageFormatter.format(IMessageException.UserExistent, new Object[] { userName });
			} else {
				error = MessageFormatter.format(
						IMessageException.NotRemovedUserFromGruop, new Object[] { userName, groupName });
			}
			throw new LDAPException(error);
		} finally {
			if (null != ctx) {
				try {
					ctx.close();
				} catch (NamingException e) {
					log.error(ERROR_CERRANDO_EL_CONTEXTO, e);
				}
				ctx = null;
			}
		}
		log.info(":::FINALIZA LA ELIMINACION DEL USUARIO DEL GRUPO ASOCIADO:::");
		return resultado;
	}

	/**
	 * Metodo que permite eliminar un usuario del LDAP
	 */
	public boolean removeUser(UsuarioDTO usuario) throws LDAPException {
		boolean resultado;
		log.info("::: INICIA LA ELIMINACION DEL LDAP DEL USUARIO SELECCIONADO:::");
		try {
			// Inicio de conexi�n con LDAP
			ctx = getInitialDirContext();
			log.info("Eliminaci�n de UserVO...");
			UserVO userVO = new UserVO(usuario.getUsuario(),
					usuario.getUsuario(), usuario.getClave(), STRING_VACIO, STRING_VACIO, STRING_VACIO,// ou=
					usuario.getCorreoElectronico());
			// Inicio de eliminaci�n de nuevo usuario
			resultado = deleteUser(ctx, userVO);
			resultado = true;
		} catch (NamingException e) {
			resultado = false;
			log.error("::: SE PRESENTARON PROBLEMAS AL INTENTAR ELIMINAR EL USUARIO::: " + e.getMessage(), e);
			StringBuilder message = new StringBuilder(managePasswordException(usuario.getUsuario(), e));
			if (message.length() == 0){
				message.append(MessageFormatter.format(IMessageException.ErrorRemovingUserNow, new Object[] { usuario.getUsuario() }));
				message.append(managePasswordException(usuario.getUsuario(), e));
			}
			throw new LDAPException(message.toString());
		} finally {
			if (null != ctx) {
				try {
					ctx.close();
				} catch (NamingException e) {
					log.error(ERROR_CERRANDO_EL_CONTEXTO, e);
				}
				ctx = null;
			}
		}
		log.info("::: FINALIZA LA ELIMINACION DEL LDAP DEL USUARIO SELECCIONADO:::");
		return resultado;
	}

	/**
	 * M�todo que elimina un objeto del ldap
	 * 
	 * @throws javax.naming.NamingException
	 * @return
	 * @param userVO
	 * @param ctx
	 */
	public boolean deleteUser(DirContext ctx, UserVO userVO) {
		boolean resultado;
		try {
			ctx.unbind(LDAP_CADENA_CN + userVO.getCn() + CARACTER_COMMA + searchBase);
			resultado = true;
		} catch (Exception e) {
			resultado = false;
			log.error("::: ERROR ELIMINANDO EL USUARIO ::: " + e.getMessage(), e);
		}
		return resultado;
	}
	
	/**
	 * Metodo que permite crear un usuario en LDAP
	 * 
	 * @param usuario
	 * @return
	 * @throws LDAPException
	 */
	public boolean createUser(UsuarioDTO usuario) throws LDAPException {
		log.info("::: INICIA LA CREACION DEL USUARIO EN EL LDAP:::");
		boolean resultado;
		String usuarioMensaje = usuario.getUsuario();
		StringBuilder message = new StringBuilder(STRING_VACIO);
		StringBuilder messageError = new StringBuilder("::: SE PRESENTARON PROBLEMAS AL INTENTAR CREAR EL USUARIO::: ");
		try{
			usuarioMensaje = usuarioMensaje.substring(0, usuarioMensaje.indexOf("_"));
		}catch (Exception e) {
		}
		try {
			ctx = getInitialDirContext();

			UserVO userVO = new UserVO(usuario.getUsuario(), // cn
					usuario.getUsuario(), // uid
					usuario.getClave(), // pass
					usuario.getPrimerNombre(), usuario.getUsuario(), // sn
					STRING_VACIO, // ou
					usuario.getCorreoElectronico(), // mail
					usuario.getPrimerNombre() + " " + usuario.getPrimerNombre()
							+ " " + usuario.getPrimerApellido() + " "
							+ usuario.getSegundoApellido(), // name
							usuario.getEstado());
			
			String objectClass = properties.getProperty("OBJECTCLASS");
			String person = properties.getProperty("PERSON");
			String type = properties.getProperty("TYPE");
			AtributosVO attr = new AtributosVO(objectClass, person, type);
		
			// adici�n de nuevo usuario
			try {
				User user = new User(
						usuario.getUsuario(), // cn
						usuario.getUsuario(), // uid
						usuario.getUsuario(), // sn
						usuario.getClave(), // pass
						usuario.getPrimerNombre(),
						usuario.getSegundoNombre(),
						usuario.getPrimerApellido(),
						usuario.getSegundoApellido(), // sn
						usuario.getCorreoElectronico(), // mail
						usuario.getEstado(), usuario.getDireccion(),
						usuario.getTelefono(), attr);
				ctx.bind(LDAP_CADENA_CN + userVO.getCn() + CARACTER_COMMA + searchBase, user);
				resultado = true;
			} catch (Exception e) {
				resultado = false;
				messageError.append(e.getMessage());
				log.error(messageError, e);
				message.append(MessageFormatter.format(IMessageException.ErrorRegisterUserNow, new Object[] { usuarioMensaje }));
				message.append(managePasswordException(usuarioMensaje, e));
				throw new LDAPException(message.toString());
			}
		} catch (NamingException e) {
			resultado = false;
			messageError.append(e.getMessage());
			log.error(messageError, e);
			message.setLength(0);
			message.append(managePasswordException(usuario.getUsuario(), e));
			if (message.length() == 0){
				message.append(MessageFormatter.format(IMessageException.ErrorRegisterUserNow, new Object[] { usuarioMensaje }));
				message.append(managePasswordException(usuarioMensaje, e));
			}
			throw new LDAPException(message.toString());
		} finally {
			if (null != ctx) {
				try {
					ctx.close();
				} catch (NamingException e) {
					log.error(ERROR_CERRANDO_EL_CONTEXTO, e);
				}
				ctx = null;
			}
		}
		log.info("::: FINALIZA LA CREACION DEL USUARIO EN EL LDAP:::");
		return resultado;
	}

	/**
	 * Metodo que permite asociar un usuario a un grupo.
	 */
	public boolean addUsertoGroup(String groupName, String userName)
			throws LDAPException {
		log.info("::: INICIA LA ASIGNACION DEL USUARIO AL GRUPO SELECCIONADO :::");
		boolean resultado;
		String base = searchBase;
		String baseGroup = searchBaseGroups;
		//String baseGroup = "ou=grupos,dc=portalservicio,dc=com,o=pasarelapagos";
		StringBuilder userNameCompuest = new StringBuilder(LDAP_CADENA_CN);
		userNameCompuest.append(userName);
		userNameCompuest.append(CARACTER_COMMA);
		userNameCompuest.append(base);
		StringBuilder groupNameCompuest = new StringBuilder(LDAP_CADENA_CN);
		groupNameCompuest.append(groupName);
		groupNameCompuest.append(CARACTER_COMMA);
		groupNameCompuest.append(baseGroup);
		
		try {
			ctx = getInitialDirContext();
			// Create a LDAP add attribute for the member attribute
			ModificationItem[] mods = new ModificationItem[1];
			mods[0] = new ModificationItem(DirContext.ADD_ATTRIBUTE, new BasicAttribute("member", userNameCompuest));
			// update the group
			ctx.modifyAttributes(groupNameCompuest.toString(), mods);
			resultado = true;
		} catch (NamingException e) {
			resultado = false;
			log.error("::: SE PRESENTARON PROBLEMAS AL INTENTAR CREAR EL USUARIO:::" + e.getMessage(), e);
			String error = STRING_VACIO;
			error = e.getMessage().substring(0, 20);
			if (error.startsWith(ILDAPErrors.UserExistsInGroup)) {
				error = MessageFormatter.format(IMessageException.UserExistent, new Object[] { userName });
			} else {
				error = MessageFormatter.format(
						IMessageException.NotCreatedUserInGruop, new Object[] {userName, groupName });
			}
			throw new LDAPException(error);
		} finally {
			if (null != ctx) {
				try {
					ctx.close();
				} catch (NamingException e) {
					log.error(ERROR_CERRANDO_EL_CONTEXTO, e);
				}
				ctx = null;
			}
		}
		log.info("::: FINALIZA LA ASIGNACION DEL USUARIO AL GRUPO SELECCIONADO:::");
		return resultado;
	}

	/**
	 * Metodo que permite actualizar los datos de un usuario en el LDAP.
	 */
	public boolean modifyUserAttributes(UsuarioDTO usuario)
			throws NamingException {
		log.info("::: INICIA LA MODIFICACION DEL USUARIO SELECCIONADO:::");
		boolean resultado;
		if (usuario == null) {
			throw new NamingException(MessageFormatter.format(
					IMessageException.ErrorActualizarValor, new Object[] {}));
		}

		List<ModificationItem> mods = new ArrayList<ModificationItem>();

		// email
		mods.add(new ModificationItem(
				DirContext.REPLACE_ATTRIBUTE,
				new BasicAttribute(ATTRIB_EMAIL, usuario.getCorreoElectronico())));
		// estado
		mods.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
				new BasicAttribute(ATTRIB_ESTADO, usuario.getEstado())));
		// nombre1
		mods.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
				new BasicAttribute(ATTRIB_NOMBRE1, usuario.getPrimerNombre())));
		// nombre2
		mods.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
				new BasicAttribute(ATTRIB_NOMBRE2, usuario.getSegundoNombre())));
		// apellido1
		mods.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
				new BasicAttribute(ATTRIB_APELLIDO1, usuario
						.getPrimerApellido())));
		// apellido2
		mods.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
				new BasicAttribute(ATTRIB_APELLIDO2, usuario
						.getSegundoApellido())));
		// direccion
		mods.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
				new BasicAttribute(ATTRIB_DIRECCION, usuario.getDireccion())));
		// telefono
		mods.add(new ModificationItem(DirContext.REPLACE_ATTRIBUTE,
				new BasicAttribute(ATTRIB_TELEFONO, usuario.getTelefono())));

		// Actualizacion de datos en TDS
		resultado = modifyUserAttribute(usuario.getUsuario(),
				mods.toArray(new ModificationItem[mods.size()]));
		return resultado;
	}

	/**
	 * Metodo que permite actualizar los datos de un usuario en el LDAP.
	 */
	private boolean modifyUserAttribute(String userID,
			ModificationItem[] modItems) {
		boolean resultado = true;
		try {
			ctx = getInitialDirContext();
			ctx.modifyAttributes(LDAP_CADENA_CN + userID + CARACTER_COMMA + this.searchBase,
					modItems);
			resultado = true;
		} catch (Exception e) {
			resultado = false;
			log.error("::: SE PRESENTARON PROBLEMAS AL INTENTAR MODIFICAR EL USUARIO SELECCIONADO:::", e);
			log.error(e.getMessage());
		} finally {
			if (null != ctx) {
				try {
					ctx.close();
				} catch (NamingException e) {
					log.error(ERROR_CERRANDO_EL_CONTEXTO, e);
				}
				ctx = null;
			}
		}
		log.info("::: FINALIZA LA MODIFICACION DEL USUARIO SELECCIONADO:::");
		return resultado;
	}
	

	// VOID MAIN - EJEMPLO PARA PRUEBAS

	public static void main(String[] args) {
		/*
		 * LDAPAccess lAccess = new LDAPAccess("ldap://10.130.3.40:389",
		 * "cn=root", "tivoli", "simple", "cn=localhost");
		 */

		LDAPAccess lAccess = new LDAPAccess(
				"ldap://10.130.3.44:389",
				"cn=adminpasarela",
				"admin",
				"simple",
				"ou=usuarios,dc=quebuenacompra,dc=portalservicio,dc=com,o=pasarelapagos",
				"dc=portalservicio,dc=com,o=pasarelapagos",
				"ou=grupos,dc=portalservicio,dc=com,o=pasarelapagos");

		/*
		 * Probar la creacion del usuario
		 */
		UsuarioDTO u = new UsuarioDTO();

		u.setUsuario("usuario3");
		u.setClave("clave3");
		u.setPrimerNombre("nombre3");
		u.setPrimerApellido("apellido3");
		u.setCorreoElectronico("correo3@ath.com.co");
		u.setEstado("A");
		u.setTelefono("123456");
		u.setDireccion("casa 12");

		try {
			// lAccess.removeUser(u);
			// lAccess.deleteUserFromGroup("comercial", u.getUsuario());
			// lAccess.createUser(u);
			// lAccess.addUsertoGroup("comercial", "usuario3");
			lAccess.searchGroupsInTds();
			// lAccess.searchUsersInTds();
			// lAccess.modifyUserAttributes(u);
			log.info("Usuario {" + u.getUsuario() + "} modificado.");
		} catch (Exception e) {
			log.error("ERROR EN LA MODIFICACI�N DE USUARIO: ", e);
		}

		/*
		 * u = null; try { u = lAccess.searchUserVoByUsername("occiprueba01"); }
		 * catch (LDAPException e) { e.printStackTrace(); } if (u != null) {
		 * System.out.println("Usuario     >> " + u.getUsuario());
		 * System.out.println("- Nombre    >> " + u.getPrimerNombre());
		 * System.out.println("- Apellido1 >> " + u.getPrimerApellido());
		 * System.out.println("- Apellido2 >> " + u.getSegundoApellido()); }
		 */
		// cn=moni,ou=usuarios,dc=quebuenacompra,dc=portalservicio,dc=com,o=pasarelapagos
		/*
		 * try { lAccess.authenticateUser("moni_quebuenacompra",
		 * "qwer1234".toCharArray()); System.out.println("LOGIN OK");
		 * //lAccess.changePass("moni_quebuenacompra", "asdf1234", "poiu7654");
		 * }catch (LDAPException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */

	}
}