package co.com.portales.common.util;

import java.util.Hashtable;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

import co.com.portales.common.exceptions.ServiceException;
import co.com.portalservicio.interfaces.ListaInterfacesPortalServicio;
import co.com.portalservicio.negocio.ifacade.ActualizaInformacionFacadeRemote;
import co.com.portalservicio.negocio.ifacade.ConciliacionFacadeRemote;
import co.com.portalservicio.negocio.ifacade.ConsultaTransaccionesFacadeRemote;
import co.com.portalservicio.negocio.ifacade.DescargaArchivoFacadeRemote;
import co.com.portalservicio.negocio.ifacade.ReportesEstadisticasFacadeRemote;
import co.com.portalservicio.parametros.ifacade.ConsultaListasFacadeRemote;
import co.com.portalservicio.session.ifacade.SessionFacadeRemote;

/**
 * Locator para acceso a Beans de Negocio
 * @author ATH
 *
 */
public class BeanLocator {

	protected static Logger log = Logger.getLogger(BeanLocator.class);

	/**
	 * Variable de instancia
	 */
	private static BeanLocator instance;
	
	/**
	 * Contexto del contenedor
	 */
	private Context ctx;

	static Properties properties;	
	
	

	static {
		try {
			PropertiesLoader propertiesLoader = PropertiesLoader.getInstance(); 
			properties = propertiesLoader.getProperties("ejb.properties");			
		} catch (Exception e) {
			Logger.getLogger(BeanLocator.class).error(e);
		}
	}

	/**
	 * Construtor de la clase <code>ServiceLocator</code>.
	 * 
	 */
	private BeanLocator() {
		try {
			log.info("Iniciando WebLocator de la aplicaci�n");

			try {
				Hashtable<String, String> env = new Hashtable<String, String>();
				env.put(Context.INITIAL_CONTEXT_FACTORY, "com.ibm.websphere.naming.WsnInitialContextFactory");
				env.put(Context.PROVIDER_URL,
						"corbaloc:iiop:" + properties.getProperty("BOOTSTRAP_HOST") + ":"
								+ properties.getProperty("BOOTSTRAP_PORT") + "");
				ctx = new InitialContext(env);
			} catch (Exception ex) {
				log.warn("Se registro un problema al crear el contexto inicial con propiedades, se procede a crearlo por defecto...");
				try {
					ctx = new InitialContext();
				} catch (NamingException ne) {
					log.info("fall� la inicializaci�n del contexto " + ne.getMessage());
					throw new Exception("Error creando contexto inicial, " + ne.getMessage());
				}
			}

		} catch (Exception e) {
			log.error("fall� la inicializaci�n del contexto " + e.getMessage());
		}
	}

	/**
	 * M�todo que recupera la instancia del <code>ServiceLocator</code>.
	 * 
	 * @return
	 * @throws ServiceException
	 */
	static public BeanLocator getInstance() {
		if (instance == null) {
			instance = new BeanLocator();
		}
		return instance;
	}

	/**
	 * Obtiene EJB desde el contexto de EJB
	 * @param nameJNDI
	 * @return
	 * @throws ServiceException
	 */
	public Object getService(String nameJNDI) throws ServiceException {
		try {
			Object o = (Object) ctx.lookup(nameJNDI);
			return o;
		} catch (NamingException e) {
			log.error("Error recuperando el servicio JNDI" + "[" + nameJNDI + "]" + e.getMessage());
			throw new ServiceException("Error recuperando el servicio JNDI" + "[" + nameJNDI + "]"
					+ e.getMessage()); 
		}
	}

	/**
	 * Retorna interfaz para obtener acceso a metodos de negocio Actualizar Informacion
	 * @return
	 * @throws  
	 * @throws ServiceException
	 */
	public ActualizaInformacionFacadeRemote getActualizaInformacionFacadeRemote() throws ServiceException {
		return (ActualizaInformacionFacadeRemote) javax.rmi.PortableRemoteObject.narrow(getService(ListaInterfacesPortalServicio.ActualizaInformacionFacadeRemote),
				ActualizaInformacionFacadeRemote.class);
	}
	
	/**
	 * Retorna interfaz para obtener acceso a metodos de negocio Conciliacion
	 * @return
	 * @throws ServiceException
	 */
	public ConciliacionFacadeRemote getConciliacionFacadeRemote() throws ServiceException {
		return (ConciliacionFacadeRemote) javax.rmi.PortableRemoteObject.narrow(getService(ListaInterfacesPortalServicio.ConciliacionFacadeRemote),
				ConciliacionFacadeRemote.class);
	}
	/**
	 * Retorna interfaz para obtener acceso a metodos de negocio Consulta transacciones
	 * @return
	 * @throws ServiceException
	 */
	public ConsultaTransaccionesFacadeRemote getConsultaTransaccionesFacadeRemote() throws ServiceException {
		return (ConsultaTransaccionesFacadeRemote) javax.rmi.PortableRemoteObject.narrow(getService(ListaInterfacesPortalServicio.ConsultaTransaccionesFacadeRemote),
				ConsultaTransaccionesFacadeRemote.class);
	}
	/**
	 * Retorna interfaz para obtener acceso a metodos de negocio Reportes Estadisticas
	 * @return
	 * @throws ServiceException
	 */
	public ReportesEstadisticasFacadeRemote getReportesEstadisticasFacadeRemote() throws ServiceException {
		return (ReportesEstadisticasFacadeRemote) javax.rmi.PortableRemoteObject.narrow(getService(ListaInterfacesPortalServicio.ReportesEstadisticasFacadeRemote),
				ReportesEstadisticasFacadeRemote.class);
	}
	
	
	/**
	 * Retorna interfaz para obtener acceso a metodos de negocio Descarga de archivos
	 * @return
	 * @throws ServiceException
	 */
	public DescargaArchivoFacadeRemote getDescargaArchivoFacadeRemote() throws ServiceException {
		return (DescargaArchivoFacadeRemote) javax.rmi.PortableRemoteObject.narrow(getService(ListaInterfacesPortalServicio.DescargaArchivoFacadeRemote),
				DescargaArchivoFacadeRemote.class);
	}
	
	/**
	 * Retorna interfaz para obtener acceso a metodos Consulta listas de presentacion
	 * @return
	 * @throws ServiceException
	 */
	public ConsultaListasFacadeRemote getConsultaListasFacadeRemote() throws ServiceException {
		return (ConsultaListasFacadeRemote) javax.rmi.PortableRemoteObject.narrow(getService(ListaInterfacesPortalServicio.ConsultaListasFacadeRemote),
				ConsultaListasFacadeRemote.class);
	}
	
	/**
	 * Retorna interfaz para obtener acceso a metodos para el manejo de session
	 * @return
	 * @throws ServiceException
	 */
	public SessionFacadeRemote getSessionFacadeRemote() throws ServiceException {
		return (SessionFacadeRemote) javax.rmi.PortableRemoteObject.narrow(getService(ListaInterfacesPortalServicio.SessionFacadeRemote),
				SessionFacadeRemote.class);
	}
	
	
}
