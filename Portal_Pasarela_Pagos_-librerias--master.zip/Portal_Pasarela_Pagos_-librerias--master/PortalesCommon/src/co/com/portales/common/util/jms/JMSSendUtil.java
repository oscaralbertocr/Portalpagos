package co.com.portales.common.util.jms;

import java.util.Properties;

import javax.jms.DeliveryMode;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

import co.com.pasarelapagos.dto.BaseDTO;
import co.com.portales.common.util.PropertiesLoader;


/**
 * Cliente para mensajeria JMS
 * @author ATH - Andres Cortina (Tecnocom)
 *
 */
public class JMSSendUtil {
	
	 /**
     * Adici�n de variables para el manejo del Log
     */
    private Logger log = Logger.getLogger(JMSSendUtil.class);
    
	/**
     * Fabrica de conexiones JMS
     */
    private String jmsConnectionFactory;
    
    /**
     * Cola JMS
     */
    private String jmsQueueSender;    

    /**
     * Objetos requeridos para la comunicacion con servidor
     */
    private Queue queue = null;  
    private QueueConnection connection = null;
    private QueueSession session = null;
    private QueueSender sender = null;
    private QueueConnectionFactory connectionFactory = null;
    
    static Properties properties;
    
    /**
     * Contexto del contenedor
     */
    private Context ctx;
   
    static {
		try {
			PropertiesLoader propertiesLoader = PropertiesLoader.getInstance(); 
			properties = propertiesLoader.getProperties("jms.properties");			
		} catch (Exception e) {
			Logger.getLogger(JMSSendUtil.class).error(e);
		}
	}
    
    /**
     * Obtiene los nombres de la fabrica y cola indicados
     * Ejecuta metodo para abrir conexion con el servidor (cola)
     * @param jmsConnectionFactoryName
     * @param jmsQueueSenderName
     */
    public JMSSendUtil(String jmsConnectionFactoryName, String jmsQueueSenderName){
    	try {
			ctx = new InitialContext();
		} catch (NamingException e1) {
			log.error(e1);
		}
    	try {
        	jmsConnectionFactory = properties.getProperty(jmsConnectionFactoryName);
        	jmsQueueSender = properties.getProperty(jmsQueueSenderName);
        	open(jmsConnectionFactory, jmsQueueSender);              	
        } catch (Exception e){
        	log.error("JMSSendUtil: Error en la apertura de conexion con la cola - " + e.getMessage());
        }
    }
    
    /**
     * Obtiene los nombres de la fabrica y cola indicados a partir del archivo que se 
     * Ejecuta metodo para abrir conexion con el servidor (cola)
     * @param jmsConnectionFactoryName
     * @param jmsQueueSenderName
     */
    public JMSSendUtil(String dirProperties, String jmsConnectionFactoryName, String jmsQueueSenderName){
    	
    	try {
			PropertiesLoader propertiesLoader = PropertiesLoader.getInstance(); 
			properties = propertiesLoader.getProperties(dirProperties, "jms.properties");			
		} catch (Exception e) {
			log.error(e);
		}
    	
    	try {
			ctx = new InitialContext();
		} catch (NamingException e1) {
			log.error("ERROR AL INICIALIZAR EL CONTEXTO...", e1);
		}
    	try {
        	jmsConnectionFactory = properties.getProperty(jmsConnectionFactoryName);
        	jmsQueueSender = properties.getProperty(jmsQueueSenderName);
        	open(jmsConnectionFactory, jmsQueueSender);              	
        } catch (Exception e){
        	log.error("JMSSendUtil: Error en la apertura de conexion con la cola - " + e.getMessage());
        }
    }
    
    /**
     * Abre la conexi�n con el servidor para el uso de la cola
     * @param connectionFactoryName
     * @param queueName
     */
    private void open(String connectionFactoryName, String queueName){
        try {
            connectionFactory = getQueueConnectionFactory(connectionFactoryName);
            connection = connectionFactory.createQueueConnection();
            session = connection.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
            queue = (Queue) getQueue(queueName);            
            sender = session.createSender(queue);            
            sender.setDeliveryMode (DeliveryMode.NON_PERSISTENT);
            log.info("[ JMSSendUtil: Inicializacion completa ]");       
        }catch (Exception e){
        	log.error("JMSSendUtil.open: Error al abrir las conexiones - " + e.getMessage());
        }
    }
    
    /**
     * Este m�todo invoca JMSLogger para enviar el mensaje al destino JMS 
     */
    public void sendMessage(Object message){
    	try {
    		BaseDTO logMessage = (BaseDTO)message;
			ObjectMessage objectMessage = session.createObjectMessage(logMessage);
			sender.send(objectMessage);
			log.info("[ JMSSendUtil.sendMessage: Envio de Message OK ]");
    	} catch(Exception ex) {        	  
    		log.error("[ JMSSendUtil.sendMessage: Exception enviando el Message "+ ex+" ]");              
    	} finally {
    		try {
    			sender.close();
    		} catch (Exception e) {
    			log.error("[ JMSSendUtil.sendMessage: Exception enviando Message "+ e+" ]");
    		}
        close();
      }
    }
    
    
    /**
     * Obtiene la fabrica de colas del jms
     * @param nameReference
     * @return
     * @throws CredicentroException
     */
    public QueueConnectionFactory getQueueConnectionFactory(String nameReference) throws Exception
    {
        try {
            return (QueueConnectionFactory) ctx.lookup(nameReference);
        } catch (Exception e) {
        	log.error(e.getMessage());
            throw new Exception("Error recuperando JMS - QueueConnectionFactory", e);
        }
    }
    /**
     * Obtiene la cola para el jms
     * @param nameReference
     * @return
     * @throws CredicentroException
     */
    public Queue getQueue(String nameReference) throws Exception
    {
        try {
            return (Queue) ctx.lookup(nameReference);
        } catch (NamingException e) {
        	log.error(e.getMessage());
            throw new Exception("Error recuperando JMS - Queue", e);
        }
    }
    
    /**
     * Cierra conexiones
     */
    public void close(){
        try {
            if (session != null)
                session.close();
        } catch (Exception e) {
          log.error("JMSSendUtil.close: Error al cerrar las conexiones - " + e.getMessage());
        }
        try {
            if (connection != null)
                connection.close();
        } catch (Exception e) {
            log.error("JMSSendUtil.close: Error al cerrar las conexiones - " + e.getMessage());
        }
    }

}

