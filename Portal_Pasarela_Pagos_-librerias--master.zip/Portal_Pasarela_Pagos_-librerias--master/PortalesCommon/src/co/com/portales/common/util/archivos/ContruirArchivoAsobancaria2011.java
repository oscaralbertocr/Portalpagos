package co.com.portales.common.util.archivos;

/**
 * Implementa logica para contruir archivos 
 * en formato asobancaria 2011
 * @author ATH
 *
 */
public class ContruirArchivoAsobancaria2011 extends ContruirArchivoAsobancaria{

}
