package co.com.portales.common.contants;

/**
 * Listado de los posibles mensajes de excepci�n 
 * @author saruiz
 *
 */
public interface IMessageException {

	/* Mensajes Genericos*/
	String ConsultSystemAdministrator = " Consulte con el administrador del sistema";
	
	/* Mensajes M�dulo Registro */
    String ErrorCorrespondingData = "Inconsistencias de datos, no permitieron la validaci�n, intente nuevamente";
    String ErrorRecivingData = "Hubo problemas al recibir los datos, por favor intente nuevamente";
    String InvalidClientData = "Los datos ingresados no son v�lidos, por favor intente nuevamente";
    String ErrorValidateClientData = "Problemas de comunicaci�n no permitieron hacer la validaci�n de los datos, por favor intente nuevamente.";
    String ErrorValidateTypeClient = "No se logr� hacer la validaci�n del tipo de cliente";
    String ErrorRegisterUserNow = "No se logr� hacer la inscripci�n del usuario {0}, por favor int�ntelo nuevamente.";
    String ErrorRemovingUserNow = "No se logr� hacer la eliminaci�n del usuario {0}, por favor int�ntelo nuevamente.";
    String ErrorRegisterUser = "No se logr� hacer la inscripci�n del usuario {0}, por favor int�ntelo nuevamente, m�s adelante.";
    String ErrorRemovingUser = "No se logr� hacer la eliminaci�n del usuario {0}, por favor int�ntelo nuevamente, m�s adelante.";
    String ErrorSendMail = "No se ha podido enviar el correo electr�nico de confirmaci�n. Consulte con el Administrador del Sistema";
    String LeastOneNumericCharacter = "La clave de acceso necesita al menos <{0}> caracter(es) n�merico(s)";
    String LessCharacters = "La clave de acceso necesita al menos <{0}> caracter(es)";
    String UserExistent = "El nombre de usuario {0} ya existe en el sistema";
    String ConcesionarioExistente = "Un concesionario con el nombre <{0}> ya existe en el sistema";
    String NotCreatedUserInGruop = "No se ha podido agregar el usuario {0} al grupo {1} del LDAP";
    String NotRemovedUserFromGruop = "No se ha podido eliminar el usuario {0} al grupo {1} del LDAP";
    String ErrorChangingPass = "Ocurri� un error al cambiar la clave del usuario.";
    String CannotAssignOldPswd = "La clave de acceso o una similar ya fue asignada con anterioridad, por razones de seguridad es necesario que intente una nueva clave. ";
    String UserNotFoundInDB = "Usuario {0} no existe";
    String ErrorQuery = "Se detectaron problemas al realizar la consulta necesaria";
    String ErrorLoginUser = "No se logr� autenticar el usuario {0}, por favor int�ntelo nuevamente, m�s adelante.";
    
    /* Mensaje de error para los  */
    String ErrorActualizarValor = "Error al actualizar el valor";
    
    /* Mensaje de error para login  */
    String LockedAccount = "La cuenta del usuario se encuentra bloqueada. ";
    String PswdExpired = "El password del usuario expir�.";
    String InvalidCredentials = "La clave digitada para el usuario no es v�lida.";
    String NoSuchAttributePass = "La clave actual no coincide con la clave del usuario";
    String PswdMinDiffChars = "La clave digitada no cumple con las condiciones de seguridad.";
}
