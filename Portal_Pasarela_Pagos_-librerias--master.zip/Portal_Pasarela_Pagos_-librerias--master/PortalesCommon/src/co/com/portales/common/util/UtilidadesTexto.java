package co.com.portales.common.util;

import co.com.portales.common.contants.IConstants;

public class UtilidadesTexto {

	/**
	 * 
	 * @param correo
	 * @return
	 */
	public static String enmascararCorreo(String correo){
		StringBuilder correoEnmascarado = new StringBuilder("");
    	try{
    		correoEnmascarado.append(enmascararDato(correo.substring(0, correo.indexOf(IConstants.CARACTER_ARROBA))));
    		correoEnmascarado.append(IConstants.CARACTER_ARROBA);
    		correoEnmascarado.append(enmascararDato(correo.substring(correo.indexOf(IConstants.CARACTER_ARROBA)+1, correo.lastIndexOf(IConstants.CARACTER_PUNTO))));
    		correoEnmascarado.append(correo.substring(correo.lastIndexOf(IConstants.CARACTER_PUNTO)));
    	}catch (Exception e) {
    		correoEnmascarado.setLength(0);
    		correoEnmascarado.append(IConstants.CORREO_ENMASCARADO_EXCEPTION);
		}
    	return correoEnmascarado.toString();
    }
	
    private static String enmascararDato(String dato){
    	StringBuilder datoEnmascarado = new StringBuilder("");
    	try{
    		datoEnmascarado.append(dato.substring(0,1));
			for(int i = 1 ; i < dato.length() ; i++){
				datoEnmascarado.append(IConstants.ENMASCARAR_UN_ASTERISCO);
			}
			datoEnmascarado.append(dato.substring(dato.length()-1, dato.length()));
    	}catch (Exception e) {
    		datoEnmascarado.setLength(0);
    		datoEnmascarado.append(IConstants.ENMASCARAR_CUATRO_ASTERISCO);
		}
    	return datoEnmascarado.toString();
    }

    public static String enmascararCVC(String cvc){
		StringBuilder cvcEnmascarado = new StringBuilder("");
    	try{
	    	for(int i = 0 ; i < cvc.length() ; i++){
	    		cvcEnmascarado.append(IConstants.ENMASCARAR_UN_ASTERISCO);
			}
    	}catch (Exception e) {
    		cvcEnmascarado.setLength(0);
    		cvcEnmascarado.append(IConstants.ENMASCARAR_TRES_ASTERISCO);
		}
    	return cvcEnmascarado.toString();
    }
    
    public static String enmascararTC(String numeroTarjeta){
    	StringBuilder numeroTarjetaEnmascarada = new StringBuilder("");
    	try{
	    	String ultimosDigitos = numeroTarjeta.substring(numeroTarjeta.length()-4);
	    	for(int i = 0 ; i < numeroTarjeta.length()-4 ; i++){
	    		numeroTarjetaEnmascarada.append(IConstants.ENMASCARAR_UN_ASTERISCO);
			}
	    	numeroTarjetaEnmascarada.append(ultimosDigitos);
    	}catch (Exception e) {
    		numeroTarjetaEnmascarada.setLength(0);
    		numeroTarjetaEnmascarada.append(IConstants.ENMASCARAR_TC_EXCEPTION);
		}
    	return numeroTarjetaEnmascarada.toString();
    }
    
}
