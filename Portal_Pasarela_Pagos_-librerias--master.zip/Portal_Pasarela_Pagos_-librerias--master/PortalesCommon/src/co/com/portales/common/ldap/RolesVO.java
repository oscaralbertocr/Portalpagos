package co.com.portales.common.ldap;

import java.util.List;

/**
 * Clase VO con el ID del usuario, nombre y correo electr�nico
 */
public class RolesVO {
	private int id;
	private String rol;
	private List<String> miembros;

	public RolesVO() {
		
	}

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the rol
	 */
	public String getRol() {
		return rol;
	}

	/**
	 * @param rol the rol to set
	 */
	public void setRol(String rol) {
		this.rol = rol;
	}

	/**
	 * @return the miembros
	 */
	public List<String> getMiembros() {
		return miembros;
	}

	/**
	 * @param miembros the miembros to set
	 */
	public void setMiembros(List<String> miembros) {
		this.miembros = miembros;
	}

	
	
}
