package co.com.portales.common.util;


import java.sql.Time;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * 
 * Clase encargada de manejar operaciones genericas con Fecha, Hora
 * 
 * @author ATH S.A
 * @author avictoria
 * @version 1.0
 * @create 01/08/2011
 */
public class DateTimeUtil {

	/**
	 * Retorna el numero de a�os entre la fecha actual y cualquier fecha
	 * PRECONDICION: fechaActual >= fechaNacimiento
	 * 
	 * @param fechaNacimiento
	 *            fecha de nacimiento
	 * @return int
	 */
	public static int getAge(Timestamp fechaNacimiento) {
		Calendar calFechaNacimiento = Calendar.getInstance();
		calFechaNacimiento.setTime(fechaNacimiento);

		Calendar fechaActual = Calendar.getInstance();

		int edad = fechaActual.get(Calendar.YEAR) - calFechaNacimiento.get(Calendar.YEAR);

		fechaActual.set(Calendar.YEAR, calFechaNacimiento.get(Calendar.YEAR));

		if (fechaActual.getTimeInMillis() < calFechaNacimiento.getTimeInMillis()) {
			edad--;
		}

		return edad;
	}

	/**
	 * Retorna la fecha actual
	 * @return
	 */
	public static Date getCurrentDate() {
		return Calendar.getInstance().getTime();
	}

	
	/**
	 * Retorna la fecha actual en numero de milisegundos
	 * 
	 * @return Un long que representa el numero de milisegundos.
	 */
	public static long getCurrentDateInMillis() {
		return Calendar.getInstance().getTimeInMillis();
	}

	/**
	 * Retorna el a�o actual
	 * 
	 * @return int entero con el a�o actual ej 2008
	 */
	public static int getCurrentYear() {
		return Calendar.getInstance().get(Calendar.YEAR);
	}

	/**
	 * Retorna la fecha actual en forma de Timestamp
	 * 
	 * @return Timestamp con la fecha actual
	 */
	public static Timestamp getCurrentTimeStamp() {
		return new Timestamp(getCurrentDateInMillis());
	}

	/**
	 * Obtiene la hora actual en forma de Time
	 * 
	 * @return
	 */
	public static Time getCurrentTime() {
		return new Time(getCurrentDateInMillis());
	}

	/**
	 * Obtiene la hora a partir de un long.
	 * 
	 * @param hora
	 * @return
	 */
	public static Time getCurrentTime(long hora) {
		return new Time(hora);
	}

	/**
	 * Retorna el numero de dias entre dos fechas. Precondicion fInicio menor
	 * que fFin
	 * 
	 * @param fInicio
	 * @param fFin
	 * @return
	 */
	public static int daysBetweenDates(Timestamp fFin, Timestamp fInicio) {
		Calendar cFin = Calendar.getInstance();
		cFin.setTime(fFin);

		Calendar cInicio = Calendar.getInstance();
		cInicio.setTime(fInicio);

		long diasMillis = cFin.getTimeInMillis() - cInicio.getTimeInMillis();

		int dias = (int) (diasMillis / (1000 * 3600 * 24));

		return dias;
	}
	
	/**
	 * Retorna el n�mero de meses entre dos fechas. Precondicion fInicio menor
	 * que fFin
	 * @param fFin si es null, la fecha de fin sera la del sistema
	 * @param fInicio 
	 * @return
	 */
	public static double monthsBetweenDates(Timestamp fFin,Timestamp fInicio) {
		Calendar cFin = Calendar.getInstance();
		cFin.setTime(fFin != null ? fFin : getCurrentTime());
		
		Calendar cInicio = Calendar.getInstance();
		cInicio.setTime(fInicio);

		// Por precisi�n esta no es la mejor alternativa
		// long diasMillis = cFin.getTimeInMillis() - cInicio.getTimeInMillis();
		// int meses = (int) (diasMillis / ((365.25 * 24 * 3600 * 1000)/12) );
		int anios = ( cFin.get(Calendar.YEAR) - cInicio.get(Calendar.YEAR)) ;
		
		double meses = ( cFin.get(Calendar.MONTH ) - cInicio.get(Calendar.MONTH));
		meses = anios != 0 ? meses + (anios * 12) : meses;
		
		int dias = ( cFin.get(Calendar.DAY_OF_MONTH) - cInicio.get(Calendar.DAY_OF_MONTH));
		double temp = (double)dias/30;
		meses = meses+temp;
		return meses;
	}
	
	
	/**
	 * Retorna una fecha final calculada, a partir de la fecha inicial que entra
	 * como parametro, la cantidad de unidades y la unidad de tiempo
	 * 
	 * @param fInicio
	 *            Date con la fecha desde donde se va a calcular
	 * @param cantidad
	 *            int cantidad de unidades que se va a aumentar la fechaInicio
	 * @param unidad
	 *            int unidad de tiempo que se va a incrementar a la fechaInicio
	 *            ej. Calendar.MONTH, Calendar.YEAR, etc.
	 * @return fechaFin Timestamp, con la fecha calculada
	 */
	public static Date dateFromDate(Date fechaInicio, int unidad, int cantidad) {
		Calendar tempDate = Calendar.getInstance();
		Date tempTimestamp;
		tempDate.setTime(fechaInicio);
		tempDate.add(unidad, cantidad);
		tempTimestamp = new Date(tempDate.getTimeInMillis());

		return tempTimestamp;
	}
	
	
	/**
	 * Obtiene la fecha actual con la hora que se pase por parametro
	 * @param millis
	 * @return
	 */
	public static Date dateFromTime(long millis) {
		Calendar tempDate = Calendar.getInstance();
		tempDate.setTimeInMillis(millis);
		
		Calendar nowDate = Calendar.getInstance();
		nowDate.set(Calendar.HOUR_OF_DAY, tempDate.get(Calendar.HOUR_OF_DAY));
		nowDate.set(Calendar.MINUTE, tempDate.get(Calendar.MINUTE));
		nowDate.set(Calendar.SECOND, tempDate.get(Calendar.SECOND));
		nowDate.set(Calendar.MILLISECOND, tempDate.get(Calendar.MILLISECOND));
		return nowDate.getTime();
	}

	/**
	 * Obtiene una hora final calculada, a partir de la hora inicial que entra
	 * como parametro, la cantidad de unidades y la unidad de tiempo
	 * 
	 * @param horaInicio
	 * @param unidad
	 *            puede ser Calendar.HOUR, Calendar.MINUTE o Calendar.SECOND
	 * @param cantidad
	 *            numero de acuerdo a la unidad seleccionada.
	 * @return
	 */
	public static Time timeFromtime(Time horaInicio, int unidad, int cantidad) {
		Calendar tempCalendar = Calendar.getInstance();
		Time tempTime;
		tempCalendar.setTime(horaInicio);
		tempCalendar.add(unidad, cantidad);
		tempTime = new Time(tempCalendar.getTimeInMillis());

		return tempTime;
	}

	/**
	 * Metodo que determina el intervalo de tiempo a usar entre una hora inicial
	 * y una hora final cada N minutos.
	 * 
	 * @param horaini
	 * @param horafin
	 * @param minutos
	 * @return
	 */
	public static List<Time> getIntervaloTime(Time horaini, Time horafin, int minutos) {
		List<Time> intervaloTime = new ArrayList<Time>();
		for (long i = horaini.getTime(); i <= horafin.getTime();) {
			intervaloTime.add(timeFromtime(getCurrentTime(i), Calendar.MINUTE, minutos));
			i += (1000 * 60 * minutos);
		}
		return intervaloTime;
	}
	
	/**
	 * M�todo para obtener la hora en long de un date
	 * @param date
	 * @return Long, Time
	 * @throws ParseException
	 */
	public static Long getTime(Date date) throws ParseException{
		SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
		String horaInicio = timeFormat.format(date);
		return timeFormat.parse(horaInicio).getTime();
	}
	
	/**
	 * M�todo que retorna la fecha formateada con el formato dd/MM/yyyy
	 * @param pDate
	 * @return
	 */
	public static String getDateFormat(java.util.Date pDate){
		String formatoFecha = "dd/MM/yyyy";
		return getDateFormat(pDate,formatoFecha);
	}
	
	/**
	 * M�todo que retorna un String formateada de acuerdo al formato pasado 
	 * @param pDate Fecha
	 * @param pFormat Tipo de formato
	 * @return
	 */
	public static String getDateFormat(Date pDate, String pFormat){
		Locale bLocale = new Locale("en", "US");
		SimpleDateFormat sd = new SimpleDateFormat(pFormat, bLocale);
		return sd.format(pDate);
	}
	
	/**
	 * 
	 * @param pDate
	 * @return
	 */
	public static String getTimeFormat(java.util.Date pDate){
		String formatoFecha = "h:mm a";
		return getDateFormat(pDate,formatoFecha);
	}
	
	/**
	 * 
	 * @param pDate
	 * @param pFormat
	 * @return
	 */
	public static String getTimeFormat(Date pDate, String pFormat){
		Locale bLocale = new Locale("en", "US");
		SimpleDateFormat sd = new SimpleDateFormat(pFormat, bLocale);
		return sd.format(pDate);
	}
	
	/**
	 * M�todo que retorna un Date parseado con el formato dd/MM/yyyy
	 * @param pString
	 * @return
	 * @throws ParseException
	 */
	public static Date getDateParse(String pString) throws ParseException{
		String formatoFecha = "dd/MM/yyyy";
		return getDateParse(pString,formatoFecha);
	}
	
	/**
	 * M�todo que retorna un Date parseado con un formato especificado
	 * @param pString
	 * @param pFormat
	 * @return
	 * @throws ParseException
	 */
	public static Date getDateParse(String pString, String pFormat) throws ParseException{
		SimpleDateFormat sd = new SimpleDateFormat(pFormat);
		return sd.parse(pString);
	}
	

}
