package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the DESCARGA database table.
 * 
 */
@Entity
@NamedNativeQueries({
	@NamedNativeQuery(name = "Descarga.archivosUsuario",
			query = "SELECT * FROM DESCARGA WHERE IDUSUARIO = ?1 AND FECHAFINAL >= ?2"),
	@NamedNativeQuery(name = "Descarga.descargasFallidas",
			query = "SELECT * FROM DESCARGA WHERE IDESTADO = ?1 AND INTENTOS <= ?2")
})
public class Descarga implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="DESCARGA_ID_GENERATOR", sequenceName="DESCARGA_SEC" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="DESCARGA_ID_GENERATOR")
	private long id;

	private String archivosystema;

	private String archivousuario;

	@Temporal( TemporalType.TIMESTAMP)
	private Date fechafinal;

    @Temporal( TemporalType.TIMESTAMP)
	private Date fechainicial;

	private String filtro;

	private BigDecimal formato;

	private String idusuario;

	private BigDecimal intentos;

	private BigDecimal regeliminado;

	private Timestamp regfechacreacion;

	private Timestamp regfechamodificacion;

	//bi-directional many-to-one association to Estadosdescarga
    @ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDESTADO")
	private Estadosdescarga estadosdescarga;

    public Descarga() {
    }

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getArchivosystema() {
		return this.archivosystema;
	}

	public void setArchivosystema(String archivosystema) {
		this.archivosystema = archivosystema;
	}

	public String getArchivousuario() {
		return this.archivousuario;
	}

	public void setArchivousuario(String archivousuario) {
		this.archivousuario = archivousuario;
	}

	public Date getFechafinal() {
		return this.fechafinal;
	}

	public void setFechafinal(Date fechafinal) {
		this.fechafinal = fechafinal;
	}

	public Date getFechainicial() {
		return this.fechainicial;
	}

	public void setFechainicial(Date fechainicial) {
		this.fechainicial = fechainicial;
	}

	public String getFiltro() {
		return this.filtro;
	}

	public void setFiltro(String filtro) {
		this.filtro = filtro;
	}

	public BigDecimal getFormato() {
		return this.formato;
	}

	public void setFormato(BigDecimal formato) {
		this.formato = formato;
	}

	public String getIdusuario() {
		return this.idusuario;
	}

	public void setIdusuario(String idusuario) {
		this.idusuario = idusuario;
	}

	public BigDecimal getIntentos() {
		return this.intentos;
	}

	public void setIntentos(BigDecimal intentos) {
		this.intentos = intentos;
	}

	public BigDecimal getRegeliminado() {
		return this.regeliminado;
	}

	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	public Timestamp getRegfechacreacion() {
		return this.regfechacreacion;
	}

	public void setRegfechacreacion(Timestamp regfechacreacion) {
		this.regfechacreacion = regfechacreacion;
	}

	public Timestamp getRegfechamodificacion() {
		return this.regfechamodificacion;
	}

	public void setRegfechamodificacion(Timestamp regfechamodificacion) {
		this.regfechamodificacion = regfechamodificacion;
	}

	public Estadosdescarga getEstadosdescarga() {
		return this.estadosdescarga;
	}

	public void setEstadosdescarga(Estadosdescarga estadosdescarga) {
		this.estadosdescarga = estadosdescarga;
	}
	
}