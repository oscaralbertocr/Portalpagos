package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the MEDIOSPAGOXCOMERCIO database table.
 * 
 */
@Embeddable
public class MediospagoxcomercioPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private long idcomercio;

	private long idmediopago;

    public MediospagoxcomercioPK() {
    }
	public long getIdcomercio() {
		return this.idcomercio;
	}
	public void setIdcomercio(long idcomercio) {
		this.idcomercio = idcomercio;
	}
	public long getIdmediopago() {
		return this.idmediopago;
	}
	public void setIdmediopago(long idmediopago) {
		this.idmediopago = idmediopago;
	}

	public boolean equals(Object other) {
		if (this.equals(other)) {
			return true;
		}
		if (!(other instanceof MediospagoxcomercioPK)) {
			return false;
		}
		MediospagoxcomercioPK castOther = (MediospagoxcomercioPK)other;
		return 
			(this.idcomercio == castOther.idcomercio)
			&& (this.idmediopago == castOther.idmediopago);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.idcomercio ^ (this.idcomercio >>> 32)));
		hash = hash * prime + ((int) (this.idmediopago ^ (this.idmediopago >>> 32)));
		
		return hash;
    }
}