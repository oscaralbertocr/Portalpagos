package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the CODIGOSRESPUESTA database table.
 * 
 */
@Entity
@NamedQueries({
	@NamedQuery(name = "Codigosrespuesta.buscarCodigosRespuesta",
			query = "SELECT c FROM Codigosrespuesta c")		
})
@NamedNativeQueries({
	@NamedNativeQuery(name = "Codigosrespuesta.buscarCodigoTransaccion",
			query = "SELECT * FROM CODIGOSRESPUESTA c WHERE TRIM(c.codigorespuesta) = " +
					"(SELECT TRIM(t.codigorespuesta) FROM TRANSACCIONES t WHERE t.id = ?1)"),
	@NamedNativeQuery(name = "Codigosrespuesta.buscarCodigosRespuestaComercio",
			query = "SELECT c.* FROM Codigosrespuesta c WHERE c.codigorespuesta IN " +
					"(SELECT cm.codigorespuesta FROM CODIGOSRESPUESTAXMEDIOPAGO cm WHERE " +
					"cm.idmediopago IN (SELECT m.idmediopago FROM MEDIOSPAGOXCOMERCIO m WHERE m.idcomercio = ?1))")
})
public class Codigosrespuesta implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="CODIGOSRESPUESTA_CODIGORESPUESTA_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="CODIGOSRESPUESTA_CODIGORESPUESTA_GENERATOR")
	private String codigorespuesta;

	private String descripcion;

	private BigDecimal regeliminado;

	private Timestamp regfechacreacion;

	private Timestamp regfechamodificacion;

	//bi-directional many-to-one association to Codigosrespuestaxmediopago
	@OneToMany(mappedBy="codigosrespuesta")
	private List<Codigosrespuestaxmediopago> codigosrespuestaxmediopagos;

	//bi-directional many-to-one association to Transaccione
	@OneToMany(mappedBy="codigosrespuesta")
	private List<Transaccione> transacciones;

    public Codigosrespuesta() {
    }

	public String getCodigorespuesta() {
		return this.codigorespuesta;
	}

	public void setCodigorespuesta(String codigorespuesta) {
		this.codigorespuesta = codigorespuesta;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public BigDecimal getRegeliminado() {
		return this.regeliminado;
	}

	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	public Timestamp getRegfechacreacion() {
		return this.regfechacreacion;
	}

	public void setRegfechacreacion(Timestamp regfechacreacion) {
		this.regfechacreacion = regfechacreacion;
	}

	public Timestamp getRegfechamodificacion() {
		return this.regfechamodificacion;
	}

	public void setRegfechamodificacion(Timestamp regfechamodificacion) {
		this.regfechamodificacion = regfechamodificacion;
	}

	public List<Codigosrespuestaxmediopago> getCodigosrespuestaxmediopagos() {
		return this.codigosrespuestaxmediopagos;
	}

	public void setCodigosrespuestaxmediopagos(List<Codigosrespuestaxmediopago> codigosrespuestaxmediopagos) {
		this.codigosrespuestaxmediopagos = codigosrespuestaxmediopagos;
	}
	
	public List<Transaccione> getTransacciones() {
		return this.transacciones;
	}

	public void setTransacciones(List<Transaccione> transacciones) {
		this.transacciones = transacciones;
	}
	
}