package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the TRANSACCIONESCONCILIADAS database table.
 * 
 */
@Entity
@Table(name="TRANSACCIONESCONCILIADAS")
public class Transaccionesconciliada implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long id;

	private String estado;

	private Timestamp fechaconciliacion;

	private String red;

	private BigDecimal regeliminado;

	private Timestamp regfechacreacion;

	private Timestamp regfechamodificacion;

	//bi-directional many-to-one association to Transaccione
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDTRANSACCION")
	private Transaccione transaccione;

    public Transaccionesconciliada() {
    }

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getEstado() {
		return this.estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Timestamp getFechaconciliacion() {
		return this.fechaconciliacion;
	}

	public void setFechaconciliacion(Timestamp fechaconciliacion) {
		this.fechaconciliacion = fechaconciliacion;
	}

	public String getRed() {
		return this.red;
	}

	public void setRed(String red) {
		this.red = red;
	}

	public BigDecimal getRegeliminado() {
		return this.regeliminado;
	}

	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	public Timestamp getRegfechacreacion() {
		return this.regfechacreacion;
	}

	public void setRegfechacreacion(Timestamp regfechacreacion) {
		this.regfechacreacion = regfechacreacion;
	}

	public Timestamp getRegfechamodificacion() {
		return this.regfechamodificacion;
	}

	public void setRegfechamodificacion(Timestamp regfechamodificacion) {
		this.regfechamodificacion = regfechamodificacion;
	}

	public Transaccione getTransaccione() {
		return this.transaccione;
	}

	public void setTransaccione(Transaccione transaccione) {
		this.transaccione = transaccione;
	}
	
}