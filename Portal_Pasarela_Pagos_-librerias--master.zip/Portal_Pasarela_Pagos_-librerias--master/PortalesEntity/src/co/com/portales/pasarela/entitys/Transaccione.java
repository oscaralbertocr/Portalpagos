package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;

/**
 * The persistent class for the TRANSACCIONES database table.
 * 
 */
@Entity
@Table(name = "TRANSACCIONES")
@NamedNativeQueries({
		@NamedNativeQuery(name = "Transaccione.consultaTrxMediosPago", query = "SELECT COUNT(*), sum(t.valortotal), t.idmediopago, m.mediopago FROM Transacciones t "
				+ "join mediospago m on t.idmediopago = m.id where t.idmediopago not in (0,9) and t.idestado = 6  and t.idcomercio = ? and "
				+ "fechatransaccion > ? AND fechatransaccion <= ? "
				+ "GROUP by t.idmediopago, m.mediopago"),
		@NamedNativeQuery(name = "Transaccione.consultaTrxPorEstadoFiltro", 
							query = "SELECT SUM(num_trans) total_trans, SUM(total) valor, id_estado, estado FROM " +
										"(SELECT COUNT(*) num_trans, SUM(t.valortotal) total, en.id id_estado, en.estado estado " +
											"FROM transacciones t, estadostransaccion e, estadosnegocio en WHERE t.idmediopago not in (0,9) and t.idcomercio = ? " +
											"AND e.idestadonegocio = en.id AND t.fechatransaccion >= ? and t.fechatransaccion <= ? " +
											"AND t.idestado = e.id AND e.id IN (SELECT id FROM ESTADOSTRANSACCION WHERE idestadonegocio = ?) " +
											"GROUP BY t.idestado, en.id, en.estado) " +
									"GROUP BY id_estado, estado"),
		@NamedNativeQuery(name = "Transaccione.consultaTrxPorAnioFiltro", query = "SELECT COUNT(*), sum(t.valortotal), to_char(t.fechatransaccion, 'mm'), t.idmediopago,"
								+ " m.mediopago FROM Transacciones t join mediospago m on t.idmediopago = m.id where t.idestado = 6 and t.idcomercio = ? and t.idmediopago = ? and"
								+ " t.fechatransaccion >= ? AND t.fechatransaccion <= ? GROUP by to_char(t.fechatransaccion, 'mm'), t.idmediopago, m.mediopago") })
				public class Transaccione implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TRANSACCIONES_ID_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TRANSACCIONES_ID_GENERATOR")
	private BigDecimal id;

	private String correocomprador;

	private String descripcion;

	private Timestamp fechacompensacion;

	private Timestamp fechapago;

	private Timestamp fechatransaccion;

	private BigDecimal idtipopersona;

	private String idtransaccionred;

	private String iptransaccion;

	private String moneda;

	private String nombrecomprador;

	private String nrocelularcomprador;

	private String numeroaprobacion;

	private String numerodocumentocomprador;

	private String numeroorden;

	private String referencia1;

	private String referencia2;

	private String referencia3;

	private BigDecimal regeliminado;

	private Timestamp regfechacreacion;

	private Timestamp regfechamodificacion;

	private String tipodocumentocomprador;

	private BigDecimal valorimpuesto;

	private BigDecimal valortotal;

	//bi-directional many-to-one association to Token
	@OneToMany(mappedBy="transaccione")
	private List<Token> tokens;

	//bi-directional many-to-one association to Banco
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDBANCO")
	private Banco banco;

	//bi-directional many-to-one association to Codigosrespuesta
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="CODIGORESPUESTA")
	private Codigosrespuesta codigosrespuesta;

	//bi-directional many-to-one association to Comercio
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDCOMERCIO")
	private Comercio comercio;

	//bi-directional many-to-one association to Estadostransaccion
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDESTADO")
	private Estadostransaccion estadostransaccion;

	//bi-directional many-to-one association to Mediospago
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDMEDIOPAGO")
	private Mediospago mediospago;

	//bi-directional many-to-one association to Origenestransaccion
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDORIGENTRANSACCION")
	private Origenestransaccion origenestransaccion;

	//bi-directional many-to-one association to Tarjetascredito
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDTARJETACREDITO")
	private Tarjetascredito tarjetascredito;

	//bi-directional many-to-one association to Tiposproducto
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDTIPOPRODUCTO")
	private Tiposproducto tiposproducto;

	//bi-directional many-to-one association to Tipostransaccion
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDTIPOTRANSACCION")
	private Tipostransaccion tipostransaccion;

	//bi-directional many-to-one association to Transaccionesconciliada
	@OneToMany(mappedBy="transaccione")
	private List<Transaccionesconciliada> transaccionesconciliadas;

    public Transaccione() {
    }

	public BigDecimal getId() {
		return this.id;
	}

	public void setId(BigDecimal id) {
		this.id = id;
	}

	public String getCorreocomprador() {
		return this.correocomprador;
	}

	public void setCorreocomprador(String correocomprador) {
		this.correocomprador = correocomprador;
	}

	public String getDescripcion() {
		return this.descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Timestamp getFechacompensacion() {
		return this.fechacompensacion;
	}

	public void setFechacompensacion(Timestamp fechacompensacion) {
		this.fechacompensacion = fechacompensacion;
	}

	public Timestamp getFechapago() {
		return this.fechapago;
	}

	public void setFechapago(Timestamp fechapago) {
		this.fechapago = fechapago;
	}

	public Timestamp getFechatransaccion() {
		return this.fechatransaccion;
	}

	public void setFechatransaccion(Timestamp fechatransaccion) {
		this.fechatransaccion = fechatransaccion;
	}

	public BigDecimal getIdtipopersona() {
		return this.idtipopersona;
	}

	public void setIdtipopersona(BigDecimal idtipopersona) {
		this.idtipopersona = idtipopersona;
	}

	public String getIdtransaccionred() {
		return this.idtransaccionred;
	}

	public void setIdtransaccionred(String idtransaccionred) {
		this.idtransaccionred = idtransaccionred;
	}

	public String getIptransaccion() {
		return this.iptransaccion;
	}

	public void setIptransaccion(String iptransaccion) {
		this.iptransaccion = iptransaccion;
	}

	public String getMoneda() {
		return this.moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getNombrecomprador() {
		return this.nombrecomprador;
	}

	public void setNombrecomprador(String nombrecomprador) {
		this.nombrecomprador = nombrecomprador;
	}

	public String getNrocelularcomprador() {
		return this.nrocelularcomprador;
	}

	public void setNrocelularcomprador(String nrocelularcomprador) {
		this.nrocelularcomprador = nrocelularcomprador;
	}

	public String getNumeroaprobacion() {
		return this.numeroaprobacion;
	}

	public void setNumeroaprobacion(String numeroaprobacion) {
		this.numeroaprobacion = numeroaprobacion;
	}

	public String getNumerodocumentocomprador() {
		return this.numerodocumentocomprador;
	}

	public void setNumerodocumentocomprador(String numerodocumentocomprador) {
		this.numerodocumentocomprador = numerodocumentocomprador;
	}

	public String getNumeroorden() {
		return this.numeroorden;
	}

	public void setNumeroorden(String numeroorden) {
		this.numeroorden = numeroorden;
	}

	public String getReferencia1() {
		return this.referencia1;
	}

	public void setReferencia1(String referencia1) {
		this.referencia1 = referencia1;
	}

	public String getReferencia2() {
		return this.referencia2;
	}

	public void setReferencia2(String referencia2) {
		this.referencia2 = referencia2;
	}

	public String getReferencia3() {
		return this.referencia3;
	}

	public void setReferencia3(String referencia3) {
		this.referencia3 = referencia3;
	}

	public BigDecimal getRegeliminado() {
		return this.regeliminado;
	}

	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	public Timestamp getRegfechacreacion() {
		return this.regfechacreacion;
	}

	public void setRegfechacreacion(Timestamp regfechacreacion) {
		this.regfechacreacion = regfechacreacion;
	}

	public Timestamp getRegfechamodificacion() {
		return this.regfechamodificacion;
	}

	public void setRegfechamodificacion(Timestamp regfechamodificacion) {
		this.regfechamodificacion = regfechamodificacion;
	}

	public String getTipodocumentocomprador() {
		return this.tipodocumentocomprador;
	}

	public void setTipodocumentocomprador(String tipodocumentocomprador) {
		this.tipodocumentocomprador = tipodocumentocomprador;
	}

	public BigDecimal getValorimpuesto() {
		return this.valorimpuesto;
	}

	public void setValorimpuesto(BigDecimal valorimpuesto) {
		this.valorimpuesto = valorimpuesto;
	}

	public BigDecimal getValortotal() {
		return this.valortotal;
	}

	public void setValortotal(BigDecimal valortotal) {
		this.valortotal = valortotal;
	}

	public List<Token> getTokens() {
		return this.tokens;
	}

	public void setTokens(List<Token> tokens) {
		this.tokens = tokens;
	}
	
	public Banco getBanco() {
		return this.banco;
	}

	public void setBanco(Banco banco) {
		this.banco = banco;
	}
	
	public Codigosrespuesta getCodigosrespuesta() {
		return this.codigosrespuesta;
	}

	public void setCodigosrespuesta(Codigosrespuesta codigosrespuesta) {
		this.codigosrespuesta = codigosrespuesta;
	}
	
	public Comercio getComercio() {
		return this.comercio;
	}

	public void setComercio(Comercio comercio) {
		this.comercio = comercio;
	}
	
	public Estadostransaccion getEstadostransaccion() {
		return this.estadostransaccion;
	}

	public void setEstadostransaccion(Estadostransaccion estadostransaccion) {
		this.estadostransaccion = estadostransaccion;
	}
	
	public Mediospago getMediospago() {
		return this.mediospago;
	}

	public void setMediospago(Mediospago mediospago) {
		this.mediospago = mediospago;
	}
	
	public Origenestransaccion getOrigenestransaccion() {
		return this.origenestransaccion;
	}

	public void setOrigenestransaccion(Origenestransaccion origenestransaccion) {
		this.origenestransaccion = origenestransaccion;
	}
	
	public Tarjetascredito getTarjetascredito() {
		return this.tarjetascredito;
	}

	public void setTarjetascredito(Tarjetascredito tarjetascredito) {
		this.tarjetascredito = tarjetascredito;
	}
	
	public Tiposproducto getTiposproducto() {
		return this.tiposproducto;
	}

	public void setTiposproducto(Tiposproducto tiposproducto) {
		this.tiposproducto = tiposproducto;
	}
	
	public Tipostransaccion getTipostransaccion() {
		return this.tipostransaccion;
	}

	public void setTipostransaccion(Tipostransaccion tipostransaccion) {
		this.tipostransaccion = tipostransaccion;
	}
	
	public List<Transaccionesconciliada> getTransaccionesconciliadas() {
		return this.transaccionesconciliadas;
	}

	public void setTransaccionesconciliadas(List<Transaccionesconciliada> transaccionesconciliadas) {
		this.transaccionesconciliadas = transaccionesconciliadas;
	}
	
}