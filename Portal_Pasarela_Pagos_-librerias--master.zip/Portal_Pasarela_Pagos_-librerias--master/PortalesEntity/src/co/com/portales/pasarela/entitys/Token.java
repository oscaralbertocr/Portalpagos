package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the TOKEN database table.
 * 
 */
@Entity
public class Token implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TOKEN_ID_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TOKEN_ID_GENERATOR")
	private String id;

	private String estado;

	private Timestamp fechacreacion;

	private Timestamp fechaexpiracion;

	private BigDecimal intento;

	private BigDecimal regeliminado;

	private Timestamp regfechacreacion;

	private Timestamp regfechamodificacion;

	//bi-directional many-to-one association to Transaccione
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDTRANSACCION")
	private Transaccione transaccione;

    public Token() {
    }

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEstado() {
		return this.estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Timestamp getFechacreacion() {
		return this.fechacreacion;
	}

	public void setFechacreacion(Timestamp fechacreacion) {
		this.fechacreacion = fechacreacion;
	}

	public Timestamp getFechaexpiracion() {
		return this.fechaexpiracion;
	}

	public void setFechaexpiracion(Timestamp fechaexpiracion) {
		this.fechaexpiracion = fechaexpiracion;
	}

	public BigDecimal getIntento() {
		return this.intento;
	}

	public void setIntento(BigDecimal intento) {
		this.intento = intento;
	}

	public BigDecimal getRegeliminado() {
		return this.regeliminado;
	}

	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	public Timestamp getRegfechacreacion() {
		return this.regfechacreacion;
	}

	public void setRegfechacreacion(Timestamp regfechacreacion) {
		this.regfechacreacion = regfechacreacion;
	}

	public Timestamp getRegfechamodificacion() {
		return this.regfechamodificacion;
	}

	public void setRegfechamodificacion(Timestamp regfechamodificacion) {
		this.regfechamodificacion = regfechamodificacion;
	}

	public Transaccione getTransaccione() {
		return this.transaccione;
	}

	public void setTransaccione(Transaccione transaccione) {
		this.transaccione = transaccione;
	}
	
}