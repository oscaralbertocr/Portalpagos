package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the CONTACTOSCOMERCIO database table.
 * 
 */
@Embeddable
public class ContactoscomercioPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private long idcomercio;

	private long idrol;

    public ContactoscomercioPK() {
    }
	public long getIdcomercio() {
		return this.idcomercio;
	}
	public void setIdcomercio(long idcomercio) {
		this.idcomercio = idcomercio;
	}
	public long getIdrol() {
		return this.idrol;
	}
	public void setIdrol(long idrol) {
		this.idrol = idrol;
	}

	public boolean equals(Object other) {
		if (this.equals(other)) {
			return true;
		}
		if (!(other instanceof ContactoscomercioPK)) {
			return false;
		}
		ContactoscomercioPK castOther = (ContactoscomercioPK)other;
		return 
			(this.idcomercio == castOther.idcomercio)
			&& (this.idrol == castOther.idrol);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.idcomercio ^ (this.idcomercio >>> 32)));
		hash = hash * prime + ((int) (this.idrol ^ (this.idrol >>> 32)));
		
		return hash;
    }
}