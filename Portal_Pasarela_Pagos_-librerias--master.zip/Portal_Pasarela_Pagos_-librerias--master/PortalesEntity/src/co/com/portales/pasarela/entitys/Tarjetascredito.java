package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the TARJETASCREDITO database table.
 * 
 */
@Entity
public class Tarjetascredito implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TARJETASCREDITO_ID_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TARJETASCREDITO_ID_GENERATOR")
	private long id;

	private BigDecimal codigoseguridad;

	private String fechavencimiento;

	private String numero;

	private BigDecimal regeliminado;

	private Timestamp regfechacreacion;

	private Timestamp regfechamodificacion;

	//bi-directional many-to-one association to Franquicia
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDFRANQUICIA")
	private Franquicia franquicia;

	//bi-directional many-to-one association to Tarjetahabiente
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDTARJETAHABIENTE")
	private Tarjetahabiente tarjetahabiente;

	//bi-directional many-to-one association to Transaccione
	@OneToMany(mappedBy="tarjetascredito")
	private List<Transaccione> transacciones;

    public Tarjetascredito() {
    }

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public BigDecimal getCodigoseguridad() {
		return this.codigoseguridad;
	}

	public void setCodigoseguridad(BigDecimal codigoseguridad) {
		this.codigoseguridad = codigoseguridad;
	}

	public String getFechavencimiento() {
		return this.fechavencimiento;
	}

	public void setFechavencimiento(String fechavencimiento) {
		this.fechavencimiento = fechavencimiento;
	}

	public String getNumero() {
		return this.numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public BigDecimal getRegeliminado() {
		return this.regeliminado;
	}

	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	public Timestamp getRegfechacreacion() {
		return this.regfechacreacion;
	}

	public void setRegfechacreacion(Timestamp regfechacreacion) {
		this.regfechacreacion = regfechacreacion;
	}

	public Timestamp getRegfechamodificacion() {
		return this.regfechamodificacion;
	}

	public void setRegfechamodificacion(Timestamp regfechamodificacion) {
		this.regfechamodificacion = regfechamodificacion;
	}

	public Franquicia getFranquicia() {
		return this.franquicia;
	}

	public void setFranquicia(Franquicia franquicia) {
		this.franquicia = franquicia;
	}
	
	public Tarjetahabiente getTarjetahabiente() {
		return this.tarjetahabiente;
	}

	public void setTarjetahabiente(Tarjetahabiente tarjetahabiente) {
		this.tarjetahabiente = tarjetahabiente;
	}
	
	public List<Transaccione> getTransacciones() {
		return this.transacciones;
	}

	public void setTransacciones(List<Transaccione> transacciones) {
		this.transacciones = transacciones;
	}
	
}