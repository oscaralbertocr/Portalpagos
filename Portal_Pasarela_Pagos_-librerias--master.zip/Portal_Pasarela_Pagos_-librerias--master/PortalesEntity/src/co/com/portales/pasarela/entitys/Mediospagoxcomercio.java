package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the MEDIOSPAGOXCOMERCIO database table.
 * 
 */
@Entity
public class Mediospagoxcomercio implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private MediospagoxcomercioPK id;

	private BigDecimal regeliminado;

	private Timestamp regfechacreacion;

	private Timestamp regfechamodificacion;

	//bi-directional many-to-one association to Comercio
    @ManyToOne
	@JoinColumn(name="IDCOMERCIO")
	private Comercio comercio;

	//bi-directional many-to-one association to Mediospago
    @ManyToOne
	@JoinColumn(name="IDMEDIOPAGO")
	private Mediospago mediospago;

    public Mediospagoxcomercio() {
    }

	public MediospagoxcomercioPK getId() {
		return this.id;
	}

	public void setId(MediospagoxcomercioPK id) {
		this.id = id;
	}
	
	public BigDecimal getRegeliminado() {
		return this.regeliminado;
	}

	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	public Timestamp getRegfechacreacion() {
		return this.regfechacreacion;
	}

	public void setRegfechacreacion(Timestamp regfechacreacion) {
		this.regfechacreacion = regfechacreacion;
	}

	public Timestamp getRegfechamodificacion() {
		return this.regfechamodificacion;
	}

	public void setRegfechamodificacion(Timestamp regfechamodificacion) {
		this.regfechamodificacion = regfechamodificacion;
	}

	public Comercio getComercio() {
		return this.comercio;
	}

	public void setComercio(Comercio comercio) {
		this.comercio = comercio;
	}
	
	public Mediospago getMediospago() {
		return this.mediospago;
	}

	public void setMediospago(Mediospago mediospago) {
		this.mediospago = mediospago;
	}
	
}