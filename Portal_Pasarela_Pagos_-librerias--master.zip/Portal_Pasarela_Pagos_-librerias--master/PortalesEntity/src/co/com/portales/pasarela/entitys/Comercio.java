package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the COMERCIO database table.
 * 
 */
@Entity
@Table(name="COMERCIO")
@NamedQueries({
	@NamedQuery(name = "Comercio.consultaInformacion",
			query = "SELECT c FROM Comercio c WHERE c.id = :idComercio")		
})
public class Comercio implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="COMERCIO_ID_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="COMERCIO_ID_GENERATOR")
	private long id;

	private String codigoach;

	private String codigoean;

	private String codigoincocredito;

	private String codigonura;

	private String estado;

	private BigDecimal nit;

	private BigDecimal regeliminado;

	private Timestamp regfechacreacion;

	private Timestamp regfechamodificacion;

	//bi-directional one-to-one association to Configuracioncomercio
	@OneToOne(mappedBy="comercio", fetch=FetchType.LAZY)
	private Configuracioncomercio configuracioncomercio;

	//bi-directional many-to-one association to Contactoscomercio
	@OneToMany(mappedBy="comercio", cascade = CascadeType.ALL)
	private List<Contactoscomercio> contactoscomercios;

	//bi-directional many-to-one association to Mediospagoxcomercio
	@OneToMany(mappedBy="comercio")
	private List<Mediospagoxcomercio> mediospagoxcomercios;

	//bi-directional one-to-one association to Subscripcion
	@OneToOne(mappedBy="comercio", fetch=FetchType.LAZY)
	private Subscripcion subscripcion;

	//bi-directional many-to-one association to Transaccione
	@OneToMany(mappedBy="comercio")
	private List<Transaccione> transacciones;

    public Comercio() {
    }

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCodigoach() {
		return this.codigoach;
	}

	public void setCodigoach(String codigoach) {
		this.codigoach = codigoach;
	}

	public String getCodigoean() {
		return this.codigoean;
	}

	public void setCodigoean(String codigoean) {
		this.codigoean = codigoean;
	}

	public String getCodigoincocredito() {
		return this.codigoincocredito;
	}

	public void setCodigoincocredito(String codigoincocredito) {
		this.codigoincocredito = codigoincocredito;
	}

	public String getCodigonura() {
		return this.codigonura;
	}

	public void setCodigonura(String codigonura) {
		this.codigonura = codigonura;
	}

	public String getEstado() {
		return this.estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public BigDecimal getNit() {
		return this.nit;
	}

	public void setNit(BigDecimal nit) {
		this.nit = nit;
	}

	public BigDecimal getRegeliminado() {
		return this.regeliminado;
	}

	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	public Timestamp getRegfechacreacion() {
		return this.regfechacreacion;
	}

	public void setRegfechacreacion(Timestamp regfechacreacion) {
		this.regfechacreacion = regfechacreacion;
	}

	public Timestamp getRegfechamodificacion() {
		return this.regfechamodificacion;
	}

	public void setRegfechamodificacion(Timestamp regfechamodificacion) {
		this.regfechamodificacion = regfechamodificacion;
	}

	public Configuracioncomercio getConfiguracioncomercio() {
		return this.configuracioncomercio;
	}

	public void setConfiguracioncomercio(Configuracioncomercio configuracioncomercio) {
		this.configuracioncomercio = configuracioncomercio;
	}
	
	public List<Contactoscomercio> getContactoscomercios() {
		return this.contactoscomercios;
	}

	public void setContactoscomercios(List<Contactoscomercio> contactoscomercios) {
		this.contactoscomercios = contactoscomercios;
	}
	
	public List<Mediospagoxcomercio> getMediospagoxcomercios() {
		return this.mediospagoxcomercios;
	}

	public void setMediospagoxcomercios(List<Mediospagoxcomercio> mediospagoxcomercios) {
		this.mediospagoxcomercios = mediospagoxcomercios;
	}
	
	public Subscripcion getSubscripcion() {
		return this.subscripcion;
	}

	public void setSubscripcion(Subscripcion subscripcion) {
		this.subscripcion = subscripcion;
	}
	
	public List<Transaccione> getTransacciones() {
		return this.transacciones;
	}

	public void setTransacciones(List<Transaccione> transacciones) {
		this.transacciones = transacciones;
	}
	
}