package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the TIPOSPRODUCTO database table.
 * 
 */
@Entity
@NamedQueries({
	@NamedQuery(name = "Tiposproducto.buscarTiposProducto",
			query = "SELECT t FROM Tiposproducto t")		
})
public class Tiposproducto implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TIPOSPRODUCTO_ID_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TIPOSPRODUCTO_ID_GENERATOR")
	private long id;

	private BigDecimal regeliminado;

	private Timestamp regfechacreacion;

	private Timestamp regfechamodificacion;

	private String tipoproducto;

	//bi-directional many-to-one association to Transaccione
	@OneToMany(mappedBy="tiposproducto")
	private List<Transaccione> transacciones;

    public Tiposproducto() {
    }

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public BigDecimal getRegeliminado() {
		return this.regeliminado;
	}

	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	public Timestamp getRegfechacreacion() {
		return this.regfechacreacion;
	}

	public void setRegfechacreacion(Timestamp regfechacreacion) {
		this.regfechacreacion = regfechacreacion;
	}

	public Timestamp getRegfechamodificacion() {
		return this.regfechamodificacion;
	}

	public void setRegfechamodificacion(Timestamp regfechamodificacion) {
		this.regfechamodificacion = regfechamodificacion;
	}

	public String getTipoproducto() {
		return this.tipoproducto;
	}

	public void setTipoproducto(String tipoproducto) {
		this.tipoproducto = tipoproducto;
	}

	public List<Transaccione> getTransacciones() {
		return this.transacciones;
	}

	public void setTransacciones(List<Transaccione> transacciones) {
		this.transacciones = transacciones;
	}
	
}