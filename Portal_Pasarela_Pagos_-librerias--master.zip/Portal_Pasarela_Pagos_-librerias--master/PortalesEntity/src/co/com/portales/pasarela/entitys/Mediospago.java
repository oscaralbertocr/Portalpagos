package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;

import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the MEDIOSPAGO database table.
 * 
 */
@Entity
@NamedQueries({
	@NamedQuery(name = "Mediospago.buscarMediosPago",
			query = "SELECT m FROM Mediospago m")
	})
@NamedNativeQueries({
	@NamedNativeQuery(name = "Mediospago.buscarMediosPagoComercio",
			query = "SELECT m.* FROM Mediospago m join mediospagoxcomercio mc on m.id = mc.idmediopago where mc.idcomercio = ?")
})
public class Mediospago implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="MEDIOSPAGO_ID_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="MEDIOSPAGO_ID_GENERATOR")
	private long id;

	private String mediopago;

	private BigDecimal regeliminado;

	private Timestamp regfechacreacion;

	private Timestamp regfechamodificacion;

	//bi-directional many-to-one association to Codigosrespuestaxmediopago
	@OneToMany(mappedBy="mediospago")
	private List<Codigosrespuestaxmediopago> codigosrespuestaxmediopagos;

	//bi-directional many-to-many association to Comercio
    @ManyToMany
	@JoinTable(
		name="MEDIOSPAGOXCOMERCIO"
		, joinColumns={
			@JoinColumn(name="IDMEDIOPAGO")
			}
		, inverseJoinColumns={
			@JoinColumn(name="IDCOMERCIO")
			}
		)
	private List<Comercio> comercios;

	//bi-directional many-to-one association to Transaccione
	@OneToMany(mappedBy="mediospago")
	private List<Transaccione> transacciones;

    public Mediospago() {
    }

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getMediopago() {
		return this.mediopago;
	}

	public void setMediopago(String mediopago) {
		this.mediopago = mediopago;
	}

	public BigDecimal getRegeliminado() {
		return this.regeliminado;
	}

	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	public Timestamp getRegfechacreacion() {
		return this.regfechacreacion;
	}

	public void setRegfechacreacion(Timestamp regfechacreacion) {
		this.regfechacreacion = regfechacreacion;
	}

	public Timestamp getRegfechamodificacion() {
		return this.regfechamodificacion;
	}

	public void setRegfechamodificacion(Timestamp regfechamodificacion) {
		this.regfechamodificacion = regfechamodificacion;
	}

	public List<Codigosrespuestaxmediopago> getCodigosrespuestaxmediopagos() {
		return this.codigosrespuestaxmediopagos;
	}

	public void setCodigosrespuestaxmediopagos(List<Codigosrespuestaxmediopago> codigosrespuestaxmediopagos) {
		this.codigosrespuestaxmediopagos = codigosrespuestaxmediopagos;
	}
	
	public List<Transaccione> getTransacciones() {
		return this.transacciones;
	}

	public void setTransacciones(List<Transaccione> transacciones) {
		this.transacciones = transacciones;
	}
	
	public List<Comercio> getComercios() {
		return this.comercios;
	}

	public void setComercios(List<Comercio> comercios) {
		this.comercios = comercios;
	}
	
}