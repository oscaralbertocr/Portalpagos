package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;

/**
 * The primary key class for the CODIGOSRESPUESTAXMEDIOPAGO database table.
 * 
 */
@Embeddable
public class CodigosrespuestaxmediopagoPK implements Serializable {
	//default serial version id, required for serializable classes.
	private static final long serialVersionUID = 1L;

	private long idmediopago;

	private String codigorespuesta;

    public CodigosrespuestaxmediopagoPK() {
    }
	public long getIdmediopago() {
		return this.idmediopago;
	}
	public void setIdmediopago(long idmediopago) {
		this.idmediopago = idmediopago;
	}
	public String getCodigorespuesta() {
		return this.codigorespuesta;
	}
	public void setCodigorespuesta(String codigorespuesta) {
		this.codigorespuesta = codigorespuesta;
	}

	public boolean equals(Object other) {
		if (this.equals(other)) {
			return true;
		}
		if (!(other instanceof CodigosrespuestaxmediopagoPK)) {
			return false;
		}
		CodigosrespuestaxmediopagoPK castOther = (CodigosrespuestaxmediopagoPK)other;
		return 
			(this.idmediopago == castOther.idmediopago)
			&& this.codigorespuesta.equals(castOther.codigorespuesta);

    }
    
	public int hashCode() {
		final int prime = 31;
		int hash = 17;
		hash = hash * prime + ((int) (this.idmediopago ^ (this.idmediopago >>> 32)));
		hash = hash * prime + this.codigorespuesta.hashCode();
		
		return hash;
    }
}