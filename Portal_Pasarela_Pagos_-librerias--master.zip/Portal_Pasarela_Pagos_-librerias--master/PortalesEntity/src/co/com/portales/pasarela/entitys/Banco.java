package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the BANCO database table.
 * 
 */
@Entity
@NamedQueries({
	@NamedQuery(name = "Banco.buscarBancos",
			query = "SELECT b FROM Banco b")		
})
public class Banco implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="BANCO_ID_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="BANCO_ID_GENERATOR")
	private long id;

	private String ach;

	private String aval;

	private String banrepublica;

	private String compensacion;

	private BigDecimal esaval;

	private String nombre;

	private BigDecimal regeliminado;

	private Timestamp regfechacreacion;

	private Timestamp regfechamodificacion;

	//bi-directional many-to-one association to Subscripcion
	@OneToMany(mappedBy="banco")
	private List<Subscripcion> subscripcions;

	//bi-directional many-to-one association to Transaccione
	@OneToMany(mappedBy="banco")
	private List<Transaccione> transacciones;

    public Banco() {
    }

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getAch() {
		return this.ach;
	}

	public void setAch(String ach) {
		this.ach = ach;
	}

	public String getAval() {
		return this.aval;
	}

	public void setAval(String aval) {
		this.aval = aval;
	}

	public String getBanrepublica() {
		return this.banrepublica;
	}

	public void setBanrepublica(String banrepublica) {
		this.banrepublica = banrepublica;
	}

	public String getCompensacion() {
		return this.compensacion;
	}

	public void setCompensacion(String compensacion) {
		this.compensacion = compensacion;
	}

	public BigDecimal getEsaval() {
		return this.esaval;
	}

	public void setEsaval(BigDecimal esaval) {
		this.esaval = esaval;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public BigDecimal getRegeliminado() {
		return this.regeliminado;
	}

	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	public Timestamp getRegfechacreacion() {
		return this.regfechacreacion;
	}

	public void setRegfechacreacion(Timestamp regfechacreacion) {
		this.regfechacreacion = regfechacreacion;
	}

	public Timestamp getRegfechamodificacion() {
		return this.regfechamodificacion;
	}

	public void setRegfechamodificacion(Timestamp regfechamodificacion) {
		this.regfechamodificacion = regfechamodificacion;
	}

	public List<Subscripcion> getSubscripcions() {
		return this.subscripcions;
	}

	public void setSubscripcions(List<Subscripcion> subscripcions) {
		this.subscripcions = subscripcions;
	}
	
	public List<Transaccione> getTransacciones() {
		return this.transacciones;
	}

	public void setTransacciones(List<Transaccione> transacciones) {
		this.transacciones = transacciones;
	}
	
}