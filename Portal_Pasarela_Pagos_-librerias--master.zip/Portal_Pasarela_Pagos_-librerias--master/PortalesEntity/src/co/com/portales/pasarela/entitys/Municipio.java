package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the MUNICIPIO database table.
 * 
 */
@Entity
@NamedQueries({
	@NamedQuery(name = "Municipio.buscarMunicipiosPorDepartamento",
			query = "SELECT m FROM Municipio m WHERE m.departamento.id = :idDepartamento ORDER BY m.nombre")		
})
public class Municipio implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="MUNICIPIO_ID_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="MUNICIPIO_ID_GENERATOR")
	private long id;

	private String dane;

	private String nombre;

	private BigDecimal regeliminado;

	private Timestamp regfechacreacion;

	private Timestamp regfechamodificacion;

	//bi-directional many-to-one association to Departamento
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDDEPARTAMENTO")
	private Departamento departamento;

	//bi-directional many-to-one association to Subscripcion
	@OneToMany(mappedBy="municipio")
	private List<Subscripcion> subscripcions;

    public Municipio() {
    }

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getDane() {
		return this.dane;
	}

	public void setDane(String dane) {
		this.dane = dane;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public BigDecimal getRegeliminado() {
		return this.regeliminado;
	}

	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	public Timestamp getRegfechacreacion() {
		return this.regfechacreacion;
	}

	public void setRegfechacreacion(Timestamp regfechacreacion) {
		this.regfechacreacion = regfechacreacion;
	}

	public Timestamp getRegfechamodificacion() {
		return this.regfechamodificacion;
	}

	public void setRegfechamodificacion(Timestamp regfechamodificacion) {
		this.regfechamodificacion = regfechamodificacion;
	}

	public Departamento getDepartamento() {
		return this.departamento;
	}

	public void setDepartamento(Departamento departamento) {
		this.departamento = departamento;
	}
	
	public List<Subscripcion> getSubscripcions() {
		return this.subscripcions;
	}

	public void setSubscripcions(List<Subscripcion> subscripcions) {
		this.subscripcions = subscripcions;
	}
	
}