package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;


/**
 * The persistent class for the CONFIGURACIONCOMERCIO database table.
 * 
 */
@Entity
public class Configuracioncomercio implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long idcomercio;

	private String contrasena;

	private String logo;

	private BigDecimal regeliminado;

	private Timestamp regfechacreacion;

	private Timestamp regfechamodificacion;

	private String rutacertificado;

	private String urlconfirmacion;

	private String urlrespuesta;

	private String usuario;

	//bi-directional one-to-one association to Comercio
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDCOMERCIO")
	private Comercio comercio;

	//bi-directional many-to-one association to Plantilla
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDPLANTILLA")
	private Plantilla plantilla;

	//bi-directional many-to-one association to Tema
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDTEMA")
	private Tema tema;

    public Configuracioncomercio() {
    }

	public long getIdcomercio() {
		return this.idcomercio;
	}

	public void setIdcomercio(long idcomercio) {
		this.idcomercio = idcomercio;
	}

	public String getContrasena() {
		return this.contrasena;
	}

	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}

	public String getLogo() {
		return this.logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public BigDecimal getRegeliminado() {
		return this.regeliminado;
	}

	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	public Timestamp getRegfechacreacion() {
		return this.regfechacreacion;
	}

	public void setRegfechacreacion(Timestamp regfechacreacion) {
		this.regfechacreacion = regfechacreacion;
	}

	public Timestamp getRegfechamodificacion() {
		return this.regfechamodificacion;
	}

	public void setRegfechamodificacion(Timestamp regfechamodificacion) {
		this.regfechamodificacion = regfechamodificacion;
	}

	public String getRutacertificado() {
		return this.rutacertificado;
	}

	public void setRutacertificado(String rutacertificado) {
		this.rutacertificado = rutacertificado;
	}

	public String getUrlconfirmacion() {
		return this.urlconfirmacion;
	}

	public void setUrlconfirmacion(String urlconfirmacion) {
		this.urlconfirmacion = urlconfirmacion;
	}

	public String getUrlrespuesta() {
		return this.urlrespuesta;
	}

	public void setUrlrespuesta(String urlrespuesta) {
		this.urlrespuesta = urlrespuesta;
	}

	public String getUsuario() {
		return this.usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public Comercio getComercio() {
		return this.comercio;
	}

	public void setComercio(Comercio comercio) {
		this.comercio = comercio;
	}
	
	public Plantilla getPlantilla() {
		return this.plantilla;
	}

	public void setPlantilla(Plantilla plantilla) {
		this.plantilla = plantilla;
	}
	
	public Tema getTema() {
		return this.tema;
	}

	public void setTema(Tema tema) {
		this.tema = tema;
	}
	
}