package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.List;


/**
 * The persistent class for the PLANTILLA database table.
 * 
 */
@Entity
public class Plantilla implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private long id;

	private String plantilla;

	private BigDecimal regeliminado;

	private Timestamp regfechacreacion;

	private Timestamp regfechamodificacion;

	//bi-directional many-to-one association to Configuracioncomercio
	@OneToMany(mappedBy="plantilla")
	private List<Configuracioncomercio> configuracioncomercios;

    public Plantilla() {
    }

	public long getId() {
		return this.id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getPlantilla() {
		return this.plantilla;
	}

	public void setPlantilla(String plantilla) {
		this.plantilla = plantilla;
	}

	public BigDecimal getRegeliminado() {
		return this.regeliminado;
	}

	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	public Timestamp getRegfechacreacion() {
		return this.regfechacreacion;
	}

	public void setRegfechacreacion(Timestamp regfechacreacion) {
		this.regfechacreacion = regfechacreacion;
	}

	public Timestamp getRegfechamodificacion() {
		return this.regfechamodificacion;
	}

	public void setRegfechamodificacion(Timestamp regfechamodificacion) {
		this.regfechamodificacion = regfechamodificacion;
	}

	public List<Configuracioncomercio> getConfiguracioncomercios() {
		return this.configuracioncomercios;
	}

	public void setConfiguracioncomercios(List<Configuracioncomercio> configuracioncomercios) {
		this.configuracioncomercios = configuracioncomercios;
	}
	
}