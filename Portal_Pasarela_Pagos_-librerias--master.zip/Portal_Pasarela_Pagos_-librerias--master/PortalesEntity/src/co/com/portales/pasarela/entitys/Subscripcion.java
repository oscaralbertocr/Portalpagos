package co.com.portales.pasarela.entitys;

import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the SUBSCRIPCION database table.
 * 
 */
@Entity
@Table(name="SUBSCRIPCION")
@NamedQueries({
	@NamedQuery(name = "Subscripcion.consultaInformacion",
			query = "SELECT s FROM Subscripcion s WHERE s.idcomercio = :idComercio")		
})
public class Subscripcion implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="SUBSCRIPCION_IDCOMERCIO_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SUBSCRIPCION_IDCOMERCIO_GENERATOR")
	private long idcomercio;

	private String cedularepresentelegal;

	private BigDecimal digitoverificacion;

	private String direccion;

	private String email;

	private String fax;

    @Temporal( TemporalType.DATE)
	private Date fechacreacion;

	private String razonsocial;

	private BigDecimal regeliminado;

	private Timestamp regfechacreacion;

	private Timestamp regfechamodificacion;

	private String representatelegal;

	private String telefono;

	//bi-directional many-to-one association to Banco
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDBANCO")
	private Banco banco;

	//bi-directional one-to-one association to Comercio
	@OneToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDCOMERCIO")
	private Comercio comercio;

	//bi-directional many-to-one association to Municipio
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="IDMUNICIPIO")
	private Municipio municipio;

    public Subscripcion() {
    }

	public long getIdcomercio() {
		return this.idcomercio;
	}

	public void setIdcomercio(long idcomercio) {
		this.idcomercio = idcomercio;
	}

	public String getCedularepresentelegal() {
		return this.cedularepresentelegal;
	}

	public void setCedularepresentelegal(String cedularepresentelegal) {
		this.cedularepresentelegal = cedularepresentelegal;
	}

	public BigDecimal getDigitoverificacion() {
		return this.digitoverificacion;
	}

	public void setDigitoverificacion(BigDecimal digitoverificacion) {
		this.digitoverificacion = digitoverificacion;
	}

	public String getDireccion() {
		return this.direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFax() {
		return this.fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public Date getFechacreacion() {
		return this.fechacreacion;
	}

	public void setFechacreacion(Date fechacreacion) {
		this.fechacreacion = fechacreacion;
	}

	public String getRazonsocial() {
		return this.razonsocial;
	}

	public void setRazonsocial(String razonsocial) {
		this.razonsocial = razonsocial;
	}

	public BigDecimal getRegeliminado() {
		return this.regeliminado;
	}

	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	public Timestamp getRegfechacreacion() {
		return this.regfechacreacion;
	}

	public void setRegfechacreacion(Timestamp regfechacreacion) {
		this.regfechacreacion = regfechacreacion;
	}

	public Timestamp getRegfechamodificacion() {
		return this.regfechamodificacion;
	}

	public void setRegfechamodificacion(Timestamp regfechamodificacion) {
		this.regfechamodificacion = regfechamodificacion;
	}

	public String getRepresentatelegal() {
		return this.representatelegal;
	}

	public void setRepresentatelegal(String representatelegal) {
		this.representatelegal = representatelegal;
	}

	public String getTelefono() {
		return this.telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public Banco getBanco() {
		return this.banco;
	}

	public void setBanco(Banco banco) {
		this.banco = banco;
	}
	
	public Comercio getComercio() {
		return this.comercio;
	}

	public void setComercio(Comercio comercio) {
		this.comercio = comercio;
	}
	
	public Municipio getMunicipio() {
		return this.municipio;
	}

	public void setMunicipio(Municipio municipio) {
		this.municipio = municipio;
	}
	
}