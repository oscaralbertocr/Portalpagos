package co.com.portalservicio.reportes.dto;

import java.math.BigDecimal;

/**
 * Clase que representa el DTO para el reporte de transacciones por medio de pago.
 * 
 * @author A Toda Hora S.A
 * @author Juan Carlos Ramirez Orozco
 * @version 1.0
 * @create 20/06/2014
 */

public class ReporteTransaccionMedioPagoDTO extends ReporteTransaccionBaseDTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor sin parametros.
	 */
	public ReporteTransaccionMedioPagoDTO(){
		super();
	}
	
	/**
	 * Constructor que recibe monto y cantidad de las transacciones.
	 * @param monto long Monto de las transacciones
	 * @param cantidad long Cantidad de transacciones realizadas.
	 */
	public ReporteTransaccionMedioPagoDTO(BigDecimal monto, long cantidad){
		super(monto, cantidad);
	}

}
