package co.com.portalservicio.reportes.dto;

import java.math.BigDecimal;

/**
 * Clase que representa el DTO para el resumen anual del reporte de transacciones.
 * 
 * @author A Toda Hora S.A
 * @author Juan Carlos Ramirez Orozco
 * @version 1.0
 * @create 20/06/2014
 */

public class ReporteTransaccionResumenAnualDTO extends ReporteTransaccionBaseDTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Mes en que se realizaron las transacciones
	 */
	private String mes;
	
	/**
	 * Constructor sin parametros.
	 */
	public ReporteTransaccionResumenAnualDTO(){
		super();
	}
	
	/**
	 * Constructor que recibe monto y cantidad de las transacciones.
	 * @param monto long Monto de las transacciones
	 * @param cantidad long Cantidad de transacciones realizadas.
	 */
	public ReporteTransaccionResumenAnualDTO(BigDecimal monto, long cantidad){
		super(monto, cantidad);
	}

	/**
	 * @return the mes
	 */
	public String getMes() {
		return mes;
	}

	/**
	 * @param mes the mes to set
	 */
	public void setMes(String mes) {
		this.mes = mes;
	}

}
