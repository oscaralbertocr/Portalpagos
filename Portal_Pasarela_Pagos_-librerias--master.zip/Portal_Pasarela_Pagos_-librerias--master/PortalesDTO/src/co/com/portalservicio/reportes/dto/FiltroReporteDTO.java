package co.com.portalservicio.reportes.dto;

import co.com.pasarelapagos.dto.BaseDTO;

/**
 * Objeto de transporte para transporte de los detalles de los filtros 
 * @author ATH
 *
 */
public class FiltroReporteDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Identificador de filtro
	 */
	private Integer codigoFiltro;
	/**
	 * Descripci�n de filtro
	 */
	private Integer descripcionfiltro;
	
	
	public Integer getCodigoFiltro() {
		return codigoFiltro;
	}
	public void setCodigoFiltro(Integer codigoFiltro) {
		this.codigoFiltro = codigoFiltro;
	}
	public Integer getDescripcionfiltro() {
		return descripcionfiltro;
	}
	public void setDescripcionfiltro(Integer descripcionfiltro) {
		this.descripcionfiltro = descripcionfiltro;
	}
	
	
	
}
