package co.com.portalservicio.reportes.dto;

import java.math.BigDecimal;

import co.com.pasarelapagos.dto.BaseDTO;
import co.com.pasarelapagos.dto.MedioPagoDTO;

/**
 * Clase que representa el DTO para un reporte de transacciones.
 * 
 * @author A Toda Hora S.A
 * @author Juan Carlos Ramirez Orozco
 * @version 1.0
 * @create 20/06/2014
 */

public class ReporteTransaccionBaseDTO extends BaseDTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Monto de las transacciones. 
	 */
	private BigDecimal monto;
	
	/**
	 * Cantidad de transacciones realizadas.
	 */
	private long cantidad;
	
	/**
	 * Medio de pago de la transaccion.
	 * Tarjeta de credito, Pay Pal, ...
	 */
	private MedioPagoDTO medioPago;
	
	/**
	 * Constructor sin parametros.
	 */
	public ReporteTransaccionBaseDTO(){
		super();
	}
	
	/**
	 * Constructor que recibe monto y cantidad de las transacciones.
	 * @param monto long Monto de las transacciones
	 * @param cantidad long Cantidad de transacciones realizadas.
	 */
	public ReporteTransaccionBaseDTO (BigDecimal monto, long cantidad){
		this.monto = monto;
		this.cantidad = cantidad;
	}

	public BigDecimal getMonto() {
		return monto;
	}

	public void setMonto(BigDecimal monto) {
		this.monto = monto;
	}

	public long getCantidad() {
		return cantidad;
	}

	public void setCantidad(long cantidad) {
		this.cantidad = cantidad;
	}

	public MedioPagoDTO getMedioPago() {
		return medioPago;
	}

	public void setMedioPago(MedioPagoDTO medioPago) {
		this.medioPago = medioPago;
	}

}
