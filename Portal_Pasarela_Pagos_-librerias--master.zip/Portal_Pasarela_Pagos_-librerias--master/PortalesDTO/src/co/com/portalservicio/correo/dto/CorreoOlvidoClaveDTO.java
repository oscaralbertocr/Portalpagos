package co.com.portalservicio.correo.dto;


public class CorreoOlvidoClaveDTO extends CorreoDTO {
	/**
	 * Atributos particulares para {@link co.com.itac.ath.eoffice.entity.Solicitud}
	 */
	private String nombres;
	private String apellidos;
	private String clave;
	
	public String getNombres() {
		return nombres;
	}
	public void setNombres(String nombres) {
		this.nombres = nombres;
	}	
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getClave() {
		return clave;
	}
	public void setClave(String clave) {
		this.clave = clave;
	}
}
