package co.com.portalservicio.correo.dto;

public class CorreoDescargaArchivoDTO extends CorreoDTO {
	
	private String nombreUsuario;
	
	private String nombreArchivo;
	
	private String fechaSolicitud;
	
	private String firmaCorreo;
	
	private String destinatario;

	/**
	 * @return the nombreUsuario
	 */
	public String getNombreUsuario() {
		return nombreUsuario;
	}

	/**
	 * @param nombreUsuario the nombreUsuario to set
	 */
	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	/**
	 * @return the nombreArchivo
	 */
	public String getNombreArchivo() {
		return nombreArchivo;
	}

	/**
	 * @param nombreArchivo the nombreArchivo to set
	 */
	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}

	/**
	 * @return the fechaSolicitud
	 */
	public String getFechaSolicitud() {
		return fechaSolicitud;
	}

	/**
	 * @param fechaSolicitud the fechaSolicitud to set
	 */
	public void setFechaSolicitud(String fechaSolicitud) {
		this.fechaSolicitud = fechaSolicitud;
	}

	/**
	 * @return the firmaCorreo
	 */
	public String getFirmaCorreo() {
		return firmaCorreo;
	}

	/**
	 * @param firmaCorreo the firmaCorreo to set
	 */
	public void setFirmaCorreo(String firmaCorreo) {
		this.firmaCorreo = firmaCorreo;
	}

	/**
	 * @return the destinatario
	 */
	public String getDestinatario() {
		return destinatario;
	}

	/**
	 * @param destinatario the destinatario to set
	 */
	public void setDestinatario(String destinatario) {
		this.destinatario = destinatario;
	}

}
