package co.com.portalservicio.validaciones.dto;

/**
 * @author mpbasto
 *
 */
public class TipoCaracterDTO {

	
	public static final String TIPO_LETRAS_MINUSCULAS="LETRAS_MINUSCULAS";
	public static final String TIPO_LETRAS_MAYUSCULAS="LETRAS_MAYUSCULAS";
	public static final String TIPO_NUMEROS="NUMEROS";
	public static final String TIPO_ESPACIO="ESPACIO";
	public static final String TIPO_CARACTERES_ESPECIALES="CARACTERES_ESPECIALES";
	
	public String caracteresValidos;
	public String descripcion;
	
	

	public TipoCaracterDTO(String caracteresValidos, String descripcion) {
		super();
		this.caracteresValidos = caracteresValidos;
		this.descripcion = descripcion;
	}
	
	
	/**
	 * @return the caracteresValidos
	 */
	public String getCaracteresValidos() {
		return caracteresValidos;
	}
	/**
	 * @param caracteresValidos the caracteresValidos to set
	 */
	public void setCaracteresValidos(String caracteresValidos) {
		this.caracteresValidos = caracteresValidos;
	}
	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}
	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}


}
