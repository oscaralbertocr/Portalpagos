package co.com.portalservicio.auditoria.dto;

import java.io.Serializable;
import java.util.Date;

import co.com.pasarelapagos.dto.BaseDTO;

/**
 * Objeto comun para auditoria
 * @author ATH
 *
 */
public class AuditoriaPasarelaMessage extends BaseDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -363757430169785044L;
	private String token;
	private String direccionIp;
	private Date fechaRegistro;
	private String accion;
	private String comercio;
	private String pantalla;
	private String resultado;
	private String informacionAdicional;
	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}
	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}
	/**
	 * @return the direccionIp
	 */
	public String getDireccionIp() {
		return direccionIp;
	}
	/**
	 * @param direccionIp the direccionIp to set
	 */
	public void setDireccionIp(String direccionIp) {
		this.direccionIp = direccionIp;
	}
	/**
	 * @return the fechaRegistro
	 */
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	/**
	 * @param fechaRegistro the fechaRegistro to set
	 */
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	/**
	 * @return the accion
	 */
	public String getAccion() {
		return accion;
	}
	/**
	 * @param accion the accion to set
	 */
	public void setAccion(String accion) {
		this.accion = accion;
	}
	/**
	 * @return the comercio
	 */
	public String getComercio() {
		return comercio;
	}
	/**
	 * @param comercio the comercio to set
	 */
	public void setComercio(String comercio) {
		this.comercio = comercio;
	}
	/**
	 * @return the pantalla
	 */
	public String getPantalla() {
		return pantalla;
	}
	/**
	 * @param pantalla the pantalla to set
	 */
	public void setPantalla(String pantalla) {
		this.pantalla = pantalla;
	}
	/**
	 * @return the resultado
	 */
	public String getResultado() {
		return resultado;
	}
	/**
	 * @param resultado the resultado to set
	 */
	public void setResultado(String resultado) {
		this.resultado = resultado;
	}
	/**
	 * @return the informacionAdicional
	 */
	public String getInformacionAdicional() {
		return informacionAdicional;
	}
	/**
	 * @param informacionAdicional the informacionAdicional to set
	 */
	public void setInformacionAdicional(String informacionAdicional) {
		this.informacionAdicional = informacionAdicional;
	}
	
	
	
	
}
