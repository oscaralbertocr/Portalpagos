package co.com.portalservicio.auditoria.dto;

import java.util.Date;

import co.com.pasarelapagos.dto.BaseDTO;

/**
 * Objeto comun para auditoria
 * @author ATH
 *
 */
public class AuditoriaMessage extends BaseDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = -363757430169785044L;
	private Date fechaRegistro;
	private String usuario;
	private String direccionIp;
	private String funcionalidad;
	private String accion;
	private String estado;
	private String descripcion;
	
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getDireccionIp() {
		return direccionIp;
	}
	public void setDireccionIp(String direccionIp) {
		this.direccionIp = direccionIp;
	}
	public String getFuncionalidad() {
		return funcionalidad;
	}
	public void setFuncionalidad(String funcionalidad) {
		this.funcionalidad = funcionalidad;
	}
	public String getAccion() {
		return accion;
	}
	public void setAccion(String accion) {
		this.accion = accion;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getDescripcion() {
		return this.descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
}
