package co.com.pasarelapagos.session.dto;

import java.util.Date;

import co.com.pasarelapagos.dto.UsuarioDTO;

/**
 * Clase que representa el DTO para la session de un usuario en el portal.
 * 
 * @author A Toda Hora S.A
 * @author Juan Carlos Ramirez Orozco
 * @version 1.0
 * @create 09/01/2015
 */
/**
 * @author proveedor_yhernandez
 *
 */
public class PortalSession extends UsuarioDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Atributo para almacenar la fecha en que el usuario del portal realiza el login.
	 */
	private Date fechaLogin;
	
	/**
	 * Atributo para almacenar la ip desde donde el usuario del portal realiza el login.
	 */
	private String ipOrigen;
	
	/**
	 * Atributo que define si el usuario perdio la sesion por inactividad en el portal.
	 */
	private Boolean timeoutSession;
	
	/**
	 * Atributo que define si el usuario perdio la sesion por multiple login.
	 */
	private Boolean multipleSession;
	
	/**
	 * Atributo que define el id de la sesion del usuario
	 */
	private String sessionId;

	/**
	 * @return the fechaLogin
	 */
	public Date getFechaLogin() {
		return fechaLogin;
	}

	/**
	 * @param fechaLogin the fechaLogin to set
	 */
	public void setFechaLogin(Date fechaLogin) {
		this.fechaLogin = fechaLogin;
	}

	/**
	 * @return the ipOrigen
	 */
	public String getIpOrigen() {
		return ipOrigen;
	}

	/**
	 * @param ipOrigen the ipOrigen to set
	 */
	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	/**
	 * @return the timeoutSession
	 */
	public Boolean isTimeoutSession() {
		return timeoutSession;
	}

	/**
	 * @param timeoutSession the timeoutSession to set
	 */
	public void setTimeoutSession(Boolean timeoutSession) {
		this.timeoutSession = timeoutSession;
	}

	/**
	 * @return the multipleSession
	 */
	public Boolean isMultipleSession() {
		return multipleSession;
	}

	/**
	 * @param multipleSession the multipleSession to set
	 */
	public void setMultipleSession(Boolean multipleSession) {
		this.multipleSession = multipleSession;
	}

	/**
	 * @return the sessionId
	 */
	public String getSessionId() {
		return sessionId;
	}

	/**
	 * @param sessionId the sessionId to set
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
}
