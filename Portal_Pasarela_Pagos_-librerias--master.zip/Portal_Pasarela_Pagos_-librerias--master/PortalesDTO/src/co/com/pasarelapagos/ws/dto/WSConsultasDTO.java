package co.com.pasarelapagos.ws.dto;

import java.util.Date;

import co.com.pasarelapagos.dto.BaseDTO;
import co.com.pasarelapagos.dto.TransaccionesDTO;

/**
 * DTO para transportar informaci�n que se necesita para el consumo del servicio web se consultas.
 * @author ATH
 * @author proveedor_jcramirez
 * @create 21/08/2014
 * @version 1.0
 */
public class WSConsultasDTO extends BaseDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Direcci�n IP desde donde se hace la petici�n.
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private String ipOrigen;
	
	/**
	 * Identificador �nico del mensaje.
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private long rqUID;
	
	/**
	 * 1 - Pasarela
	 * 2 - Call Center
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private String channel;
	
	/**
	 * Fecha y hora de solicitud.
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private Date fechaSolicitud;
	
	/**
	 * Se almacena la informacion de la transaccion para consulta de transacciones
	 */
	private TransaccionesDTO transaccion;
	
	private String tipo;

	/**
	 * @return the ipOrigen
	 */
	public String getIpOrigen() {
		return ipOrigen;
	}

	/**
	 * @param ipOrigen the ipOrigen to set
	 */
	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	/**
	 * @return the rqUID
	 */
	public long getRqUID() {
		return rqUID;
	}

	/**
	 * @param rqUID the rqUID to set
	 */
	public void setRqUID(long rqUID) {
		this.rqUID = rqUID;
	}

	/**
	 * @return the fechaSolicitud
	 */
	public Date getFechaSolicitud() {
		return fechaSolicitud;
	}

	/**
	 * @param fechaSolicitud the fechaSolicitud to set
	 */
	public void setFechaSolicitud(Date fechaSolicitud) {
		this.fechaSolicitud = fechaSolicitud;
	}

	/**
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}

	/**
	 * @return the transaccion
	 */
	public TransaccionesDTO getTransaccion() {
		return transaccion;
	}

	/**
	 * @param transaccion the transaccion to set
	 */
	public void setTransaccion(TransaccionesDTO transaccion) {
		this.transaccion = transaccion;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

}
