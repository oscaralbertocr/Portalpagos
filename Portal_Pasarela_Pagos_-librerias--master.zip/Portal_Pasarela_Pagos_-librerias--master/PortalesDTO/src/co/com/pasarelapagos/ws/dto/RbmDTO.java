package co.com.pasarelapagos.ws.dto;

import co.com.pasarelapagos.dto.BaseDTO;
import co.com.pasarelapagos.dto.TarjetaCreditoDTO;

public class RbmDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer numCuotas;
	
	private TarjetaCreditoDTO tarjetaCredito;

	/**
	 * @return the numCuotas
	 */
	public Integer getNumCuotas() {
		return numCuotas;
	}

	/**
	 * @param numCuotas the numCuotas to set
	 */
	public void setNumCuotas(Integer numCuotas) {
		this.numCuotas = numCuotas;
	}

	/**
	 * @return the tarjetaCredito
	 */
	public TarjetaCreditoDTO getTarjetaCredito() {
		return tarjetaCredito;
	}

	/**
	 * @param tarjetaCredito the tarjetaCredito to set
	 */
	public void setTarjetaCredito(TarjetaCreditoDTO tarjetaCredito) {
		this.tarjetaCredito = tarjetaCredito;
	}

}
