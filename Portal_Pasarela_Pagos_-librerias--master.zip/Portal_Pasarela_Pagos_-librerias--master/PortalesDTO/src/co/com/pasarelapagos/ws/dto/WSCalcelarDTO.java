package co.com.pasarelapagos.ws.dto;

import java.util.Date;

import co.com.pasarelapagos.dto.BaseDTO;
import co.com.pasarelapagos.dto.TransaccionesDTO;

public class WSCalcelarDTO extends BaseDTO{ /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Identificador �nico del mensaje.
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private long rqUID;
	
	/**
	 * 1 - Pasarela
	 * 2 - Call Center
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private String channel;
	
	/**
	 * Fecha y hora de solicitud.
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private Date fechaSolicitud;
	
	/**
	 * Direcci�n IP desde donde se hace la petici�n.
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private String ipOrigen;
	
	/**
	 * Se almacena la informacion de la transaccion para consulta de transacciones
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private TransaccionesDTO transaccion;
	
	/**
	 * C�digo de respuesta
	 */
	private long statusCode;
	
	/**
	 * Mensaje descriptivo
	 */
	private String statusDesc;
	
	/**
	 * C�digo de estado generado por el servidor
	 */
	private String serverStatusCode;
	
	/**
	 * Mensaje descriptivo generado por el servidor
	 */
	private String serverStatusDesc;
	

	public long getRqUID() {
		return rqUID;
	}

	public void setRqUID(long rqUID) {
		this.rqUID = rqUID;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public Date getFechaSolicitud() {
		return fechaSolicitud;
	}

	public void setFechaSolicitud(Date fechaSolicitud) {
		this.fechaSolicitud = fechaSolicitud;
	}

	public TransaccionesDTO getTransaccion() {
		return transaccion;
	}

	public void setTransaccion(TransaccionesDTO transaccion) {
		this.transaccion = transaccion;
	}

	public String getIpOrigen() {
		return ipOrigen;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	public long getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(long statusCode) {
		this.statusCode = statusCode;
	}

	public String getServerStatusCode() {
		return serverStatusCode;
	}

	public void setServerStatusCode(String serverStatusCode) {
		this.serverStatusCode = serverStatusCode;
	}

	public String getStatusDesc() {
		return statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getServerStatusDesc() {
		return serverStatusDesc;
	}

	public void setServerStatusDesc(String serverStatusDesc) {
		this.serverStatusDesc = serverStatusDesc;
	}
}
