package co.com.pasarelapagos.ws.dto;

import java.util.List;

import co.com.pasarelapagos.dto.BaseDTO;
import co.com.pasarelapagos.dto.TransaccionesDTO;

public class WSRegistroTransacionesResponseDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8883931007848914613L;
	
	/**
	 * C�digo de respuesta
	 */
	private long statusCode;
	
	/**
	 * Mensaje descriptivo
	 */
	private String statusDesc;
	
	/**
	 * C�digo de estado generado por el servidor
	 */
	private String serverStatusCode;
	
	/**
	 * Mensaje descriptivo generado por el servidor
	 */
	private String serverStatusDesc;
	
	/**
	 * Identificador �nico del mensaje transaccional
	 */
	private long rqUID;
	
	/**
	 * Identificador �nico del mensaje transaccional
	 */
	private String Severity;
	
	/**
	 * Informacion de la transaccion
	 */
	private List<TransaccionesDTO> transacciones;

	public long getStatusCode() {
		return this.statusCode;
	}

	public void setStatusCode(long statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDesc() {
		return this.statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public String getServerStatusCode() {
		return this.serverStatusCode;
	}

	public void setServerStatusCode(String serverStatusCode) {
		this.serverStatusCode = serverStatusCode;
	}

	public String getServerStatusDesc() {
		return this.serverStatusDesc;
	}

	public void setServerStatusDesc(String serverStatusDesc) {
		this.serverStatusDesc = serverStatusDesc;
	}

	public long getRqUID() {
		return this.rqUID;
	}

	public void setRqUID(long rqUID) {
		this.rqUID = rqUID;
	}

	public String getSeverity() {
		return this.Severity;
	}

	public void setSeverity(String severity) {
		this.Severity = severity;
	}

	public List<TransaccionesDTO> getTransacciones() {
		return this.transacciones;
	}

	public void setTransacciones(List<TransaccionesDTO> transacciones) {
		this.transacciones = transacciones;
	}
	
}
