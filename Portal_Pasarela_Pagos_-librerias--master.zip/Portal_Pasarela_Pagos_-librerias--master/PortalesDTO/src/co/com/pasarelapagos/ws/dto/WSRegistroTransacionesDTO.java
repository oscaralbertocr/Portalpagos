package co.com.pasarelapagos.ws.dto;

import java.util.Date;

import co.com.pasarelapagos.dto.BaseDTO;
import co.com.pasarelapagos.dto.UsuarioDTO;

public class WSRegistroTransacionesDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4789209836370453362L;
	
	/**
	 * Identificador �nico del mensaje.
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private long rqUID;
	
	/**
	 * 1 - Pasarela
	 * 2 - Call Center
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private String channel;
	
	/**
	 * Direcci�n IP desde donde se hace la petici�n.
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private String ipOrigen;
	
	/**
	 * Fecha y hora de solicitud.
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private Date fechaSolicitud;
	
	private UsuarioDTO usuario;
	
	/**
	 * Fecha y hora inicial.
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private Date fechaInicial;
	
	/**
	 * Fecha y hora Final.
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private Date fechaFinal;
	
	/**
	 * C�digo de respuesta
	 */
	private String state;

	/**
	 * C�digo de respuesta
	 */
	private String pmtWayId;

	public long getRqUID() {
		return this.rqUID;
	}

	public void setRqUID(long rqUID) {
		this.rqUID = rqUID;
	}

	public String getChannel() {
		return this.channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getIpOrigen() {
		return this.ipOrigen;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	public Date getFechaSolicitud() {
		return this.fechaSolicitud;
	}

	public void setFechaSolicitud(Date fechaSolicitud) {
		this.fechaSolicitud = fechaSolicitud;
	}

	public UsuarioDTO getUsuario() {
		return this.usuario;
	}

	public void setUsuario(UsuarioDTO usuario) {
		this.usuario = usuario;
	}

	public Date getFechaInicial() {
		return this.fechaInicial;
	}

	public void setFechaInicial(Date fechaInicial) {
		this.fechaInicial = fechaInicial;
	}

	public Date getFechaFinal() {
		return this.fechaFinal;
	}

	public void setFechaFinal(Date fechaFinal) {
		this.fechaFinal = fechaFinal;
	}

	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPmtWayId() {
		return this.pmtWayId;
	}

	public void setPmtWayId(String pmtWayId) {
		this.pmtWayId = pmtWayId;
	}
}
