package co.com.pasarelapagos.ws.dto;

import java.util.List;

import co.com.pasarelapagos.dto.BancoDTO;
import co.com.pasarelapagos.dto.BaseDTO;
import co.com.pasarelapagos.dto.TransaccionesDTO;
import co.com.pasarelapagos.dto.DatosPlantillaDTO;
/**
 * DTO para transportar informaci�n de respuesta del servicio web se consultas.
 * @author ATH
 * @author proveedor_jcramirez
 * @create 21/08/2014
 * @version 1.0
 */
public class WSConsultasResponseDTO extends BaseDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * C�digo de respuesta
	 */
	private long statusCode;
	
	/**
	 * Mensaje descriptivo
	 */
	private String statusDesc;
	
	/**
	 * C�digo de estado generado por el servidor
	 */
	private String serverStatusCode;
	
	/**
	 * Mensaje descriptivo generado por el servidor
	 */
	private String serverStatusDesc;
	
	/**
	 * Identificador �nico del mensaje transaccional
	 */
	private long rqUID;
	
	/**
	 * Se almacena la informacion de la transaccion para consulta de transacciones
	 */
	private TransaccionesDTO transaccion;
	
	/**
	 * Se almacena la informaci�n de los bancos asociados a un comercio para pagos PSE
	 */
	private List<BancoDTO> bancos;
	
	
	
	/**
	 * URL de retorno al comercio
	 */
	
	private String portalURL;

	/**
	 * @return the transaccion
	 */
	public TransaccionesDTO getTransaccion() {
		return transaccion;
	}

	/**
	 * @param transaccion the transaccion to set
	 */
	public void setTransaccion(TransaccionesDTO transaccion) {
		this.transaccion = transaccion;
	}

	/**
	 * @return the bancos
	 */
	public List<BancoDTO> getBancos() {
		return bancos;
	}

	/**
	 * @param bancos the bancos to set
	 */
	public void setBancos(List<BancoDTO> bancos) {
		this.bancos = bancos;
	}

	/**
	 * @return the statusCode
	 */
	public long getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(long statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * @return the statusDesc
	 */
	public String getStatusDesc() {
		return statusDesc;
	}

	/**
	 * @param statusDesc the statusDesc to set
	 */
	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	/**
	 * @return the serverStatusCode
	 */
	public String getServerStatusCode() {
		return serverStatusCode;
	}

	/**
	 * @param serverStatusCode the serverStatusCode to set
	 */
	public void setServerStatusCode(String serverStatusCode) {
		this.serverStatusCode = serverStatusCode;
	}

	/**
	 * @return the serverStatusDesc
	 */
	public String getServerStatusDesc() {
		return serverStatusDesc;
	}

	/**
	 * @param serverStatusDesc the serverStatusDesc to set
	 */
	public void setServerStatusDesc(String serverStatusDesc) {
		this.serverStatusDesc = serverStatusDesc;
	}

	/**
	 * @return the rqUID
	 */
	public long getRqUID() {
		return rqUID;
	}

	/**
	 * @param rqUID the rqUID to set
	 */
	public void setRqUID(long rqUID) {
		this.rqUID = rqUID;
	}

	/**
	 * @return the portalURL
	 */
	public String getPortalURL() {
		return portalURL;
	}

	/**
	 * @param portalURL the portalURL to set
	 */
	public void setPortalURL(String portalURL) {
		this.portalURL = portalURL;
	}

}
