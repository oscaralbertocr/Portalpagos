package co.com.pasarelapagos.ws.dto;

import co.com.pasarelapagos.dto.TransaccionesDTO;

public class WSCancelarResponseDTO {

	/**
	 * C�digo de respuesta
	 */
	private long statusCode;
	
	/**
	 * Mensaje descriptivo
	 */
	private String statusDesc;
	
	/**
	 * Identificador �nico del mensaje.
	 */
	private long rqUID;
	
	/**
	 * C�digo de estado generado por el servidor
	 */
	private String serverStatusCode;
	
	/**
	 * Mensaje descriptivo generado por el servidor
	 */
	private String serverStatusDesc;
	
	/**
	 * Se almacena la informacion de la transaccion para consulta de transacciones
	 */
	private TransaccionesDTO transaccion;

	public long getStatusCode() {
		return this.statusCode;
	}

	public void setStatusCode(long statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusDesc() {
		return this.statusDesc;
	}

	public void setStatusDesc(String statusDesc) {
		this.statusDesc = statusDesc;
	}

	public long getRqUID() {
		return this.rqUID;
	}

	public void setRqUID(long rqUID) {
		this.rqUID = rqUID;
	}

	public String getServerStatusCode() {
		return this.serverStatusCode;
	}

	public void setServerStatusCode(String serverStatusCode) {
		this.serverStatusCode = serverStatusCode;
	}

	public String getServerStatusDesc() {
		return this.serverStatusDesc;
	}

	public void setServerStatusDesc(String serverStatusDesc) {
		this.serverStatusDesc = serverStatusDesc;
	}

	public TransaccionesDTO getTransaccion() {
		return this.transaccion;
	}

	public void setTransaccion(TransaccionesDTO transaccion) {
		this.transaccion = transaccion;
	}
}
