package co.com.pasarelapagos.ws.dto;

import java.util.Date;

import co.com.pasarelapagos.dto.BaseDTO;
import co.com.pasarelapagos.dto.ComercioDTO;
import co.com.pasarelapagos.dto.CuentaDTO;
import co.com.pasarelapagos.dto.TransaccionesDTO;

/**
 * DTO para transportar informaci�n que se necesita para el consumo del servicio web de pagos.
 * @author ATH
 * @author proveedor_jcramirez
 * @create 21/08/2014
 * @version 1.0
 */
public class WSPagosDTO extends BaseDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Direcci�n IP desde donde se hace la petici�n.
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private String ipOrigen;
	
	/**
	 * Identificador �nico del mensaje.
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private long rqUID;
	
	/**
	 * 1 - Pasarela
	 * 2 - Call Center
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private String channel;
	
	/**
	 * Fecha y hora de solicitud.
	 * CAMPO OBLIGATORIO PARA EL SERVICIO.
	 */
	private Date fechaSolicitud;
	
	/**
	 * Se almacena la informacion de la transaccion para consulta de transacciones
	 */
	private TransaccionesDTO transaccion;
	
	/**
	 * Se almacena la informacion del comercio para la consulta de los bancos
	 */
	private ComercioDTO comercio;
	
	/**
	 * Se almacena la informaci�n de la cuenta asociada al pago
	 */
	private CuentaDTO cuenta;
	
	/**
	 * URL para el direccionamiento desde PSE
	 */
	private String urlPSE;
	
	/**
	 * Informacion del pago RBM
	 */
	private RbmDTO rbm;
	
	//RQ25542 MotorDeRiesgosPortal
	/**
	 * RSA, Valor del Device Print
	 */
	private String devicePrint;

	//RQ25542 MotorDeRiesgosPortal
	/**
	 * RSA, Valor del Device Token Cookie
	 */
	private String deviceToken;
	
	/**
	 * Cabeceras HTTP Request para motor de riesgo
	 */
	private String httpAccept;
	private String httpAcceptLanguage;
	private String httpReferrer;
	private String userAgent;
	
	
	
	
	public String getDevicePrint() {
		return this.devicePrint;
	}

	public void setDevicePrint(String devicePrint) {
		this.devicePrint = devicePrint;
	}

	public String getDeviceToken() {
		return this.deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}
	
	/**
	 * @return the ipOrigen
	 */
	public String getIpOrigen() {
		return ipOrigen;
	}

	/**
	 * @param ipOrigen the ipOrigen to set
	 */
	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	/**
	 * @return the rqUID
	 */
	public long getRqUID() {
		return rqUID;
	}

	/**
	 * @param rqUID the rqUID to set
	 */
	public void setRqUID(long rqUID) {
		this.rqUID = rqUID;
	}

	/**
	 * @return the fechaSolicitud
	 */
	public Date getFechaSolicitud() {
		return fechaSolicitud;
	}

	/**
	 * @param fechaSolicitud the fechaSolicitud to set
	 */
	public void setFechaSolicitud(Date fechaSolicitud) {
		this.fechaSolicitud = fechaSolicitud;
	}

	/**
	 * @return the channel
	 */
	public String getChannel() {
		return channel;
	}

	/**
	 * @param channel the channel to set
	 */
	public void setChannel(String channel) {
		this.channel = channel;
	}

	/**
	 * @return the transaccion
	 */
	public TransaccionesDTO getTransaccion() {
		return transaccion;
	}

	/**
	 * @param transaccion the transaccion to set
	 */
	public void setTransaccion(TransaccionesDTO transaccion) {
		this.transaccion = transaccion;
	}

	/**
	 * @return the comercio
	 */
	public ComercioDTO getComercio() {
		return comercio;
	}

	/**
	 * @param comercio the comercio to set
	 */
	public void setComercio(ComercioDTO comercio) {
		this.comercio = comercio;
	}

	/**
	 * @return the cuenta
	 */
	public CuentaDTO getCuenta() {
		return cuenta;
	}

	/**
	 * @param cuenta the cuenta to set
	 */
	public void setCuenta(CuentaDTO cuenta) {
		this.cuenta = cuenta;
	}

	/**
	 * @return the urlPSE
	 */
	public String getUrlPSE() {
		return urlPSE;
	}

	/**
	 * @param urlPSE the urlPSE to set
	 */
	public void setUrlPSE(String urlPSE) {
		this.urlPSE = urlPSE;
	}

	/**
	 * @return the rbm
	 */
	public RbmDTO getRbm() {
		return rbm;
	}

	/**
	 * @param rbm the rbm to set
	 */
	public void setRbm(RbmDTO rbm) {
		this.rbm = rbm;
	}
	
	public String getHttpAccept() {
		return this.httpAccept;
	}

	public void setHttpAccept(String httpAccept) {
		this.httpAccept = httpAccept;
	}

	public String getHttpAcceptLanguage() {
		return this.httpAcceptLanguage;
	}

	public void setHttpAcceptLanguage(String httpAcceptLanguage) {
		this.httpAcceptLanguage = httpAcceptLanguage;
	}

	public String getHttpReferrer() {
		return this.httpReferrer;
	}

	public void setHttpReferrer(String httpReferrer) {
		this.httpReferrer = httpReferrer;
	}

	public String getUserAgent() {
		return this.userAgent;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

}
