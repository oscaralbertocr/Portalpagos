package co.com.pasarelapagos.dto;

/**
 * Representacion de objeto para los tipos de cuenta
 * que manejan las transacciones realizadas en la pasarela 
 * @author saruiz
 *
 */
public class ProductoDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String producto;

	public String getProducto() {
		return producto;
	}
	public void setProducto(String producto) {
		this.producto = producto;
	}
	
	

}
