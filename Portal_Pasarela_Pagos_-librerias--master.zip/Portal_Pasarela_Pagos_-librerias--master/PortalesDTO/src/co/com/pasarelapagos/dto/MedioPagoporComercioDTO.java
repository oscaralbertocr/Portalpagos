package co.com.pasarelapagos.dto;

public class MedioPagoporComercioDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ComercioDTO comercio;
	private MedioPagoDTO medioPagoDTO;
	
	
	public ComercioDTO getComercio() {
		return comercio;
	}
	public void setComercio(ComercioDTO comercio) {
		this.comercio = comercio;
	}
	public MedioPagoDTO getMedioPagoDTO() {
		return medioPagoDTO;
	}
	public void setMedioPagoDTO(MedioPagoDTO medioPagoDTO) {
		this.medioPagoDTO = medioPagoDTO;
	}
	
	
}
