package co.com.pasarelapagos.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.security.Timestamp;
import java.util.Date;
import java.util.List;

/**
 * 
 * Representacion de objeto para las transacciones realizadas en la pasarela 
 * @author ATH
 * @modified Sergio Ruiz
 *
 */
public class TransaccionesDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	
	
	private BigDecimal id;
	private ComercioDTO comercio;
	private EstadoPagoDTO estadoPago;
	private MedioPagoDTO medioPago;
	private ProductoDTO productoDTO;
	private String urlComercio;
	private String ipComprador;
	private String numeroOrden;
	private BigDecimal valorTotal;
	private String moneda;
	private String descripcion;
	
	/**
	 * Fecha equivalente a la fecha inicial del pago.
	 */
	private Date fechaTransaccion;
	private Timestamp horaCompra;
	private String numeroAprobacion;
	/**
	 * Fecha equivalente a la fecha final del pago.
	 */
	private Date fechaPago;
	private Date fechaCompensacion;
	private Date ultimaModificacion;
	private CodigoRespuestaDTO codigoRespuesta;
	private TipoTransaccionDTO tipoTransaccion;
	
	private String tipoConsulta;
	
	private OrigenTransaccionDTO origenTransaccion;
	
	private String token;
	
	/**
	 * Atributos que retorna el servicio de consultas
	 */
	private Date fechaVencimiento;
	private Date fechaLimitePago;
	private BigDecimal taza;
	private String referencia1;
	private String referencia2;
	private String referencia3;
	private String referencia4;
	private String approvalId;
	private String trazabilityCode;
	
	private String deviceToken; //RQ25542 MotorDeRiesgosPortal
	private String multiplesrefe; //RQ27225 MultiplesReferencias 
	/**
	 * Corresponde al DeviceTokenCookie de RSA
	 */

	private DatosPlantillaDTO datosPlantillaDTO; //RQ 26210 Taquillas

	private String pmtId;
	private String tipoPmt;
	
	private ImpuestoDTO impuesto;
	
	private UsuarioDTO usuario;
	
	private BancoDTO banco;
	
	private TarjetaCreditoDTO tarjetaCredito;

	public ComercioDTO getComercio() {
		return comercio;
	}
	public void setComercio(ComercioDTO comercio) {
		this.comercio = comercio;
	}
	public EstadoPagoDTO getEstadoPago() {
		return estadoPago;
	}
	public void setEstadoPago(EstadoPagoDTO estadoPago) {
		this.estadoPago = estadoPago;
	}
	public MedioPagoDTO getMedioPago() {
		return medioPago;
	}
	public void setMedioPago(MedioPagoDTO medioPago) {
		this.medioPago = medioPago;
	}
	public ProductoDTO getProductoDTO() {
		return productoDTO;
	}
	public void setProductoDTO(ProductoDTO productoDTO) {
		this.productoDTO = productoDTO;
	}
	public String getUrlComercio() {
		return urlComercio;
	}
	public void setUrlComercio(String urlComercio) {
		this.urlComercio = urlComercio;
	}
	public String getIpComprador() {
		return ipComprador;
	}
	public void setIpComprador(String ipComprador) {
		this.ipComprador = ipComprador;
	}
	public String getNumeroOrden() {
		return numeroOrden;
	}
	public void setNumeroOrden(String numeroOrden) {
		this.numeroOrden = numeroOrden;
	}
	public BigDecimal getValorTotal() {
		return valorTotal;
	}
	public void setValorTotal(BigDecimal valorTotal) {
		this.valorTotal = valorTotal;
	}
	public Timestamp getHoraCompra() {
		return horaCompra;
	}
	public void setHoraCompra(Timestamp horaCompra) {
		this.horaCompra = horaCompra;
	}
	public String getNumeroAprobacion() {
		return numeroAprobacion;
	}
	public void setNumeroAprobacion(String numeroAprobacion) {
		this.numeroAprobacion = numeroAprobacion;
	}
	public Date getFechaPago() {
		return fechaPago;
	}
	public void setFechaPago(Date fechaPago) {
		this.fechaPago = fechaPago;
	}
	public Date getFechaCompensacion() {
		return fechaCompensacion;
	}
	public void setFechaCompensacion(Date fechaCompensacion) {
		this.fechaCompensacion = fechaCompensacion;
	}
	public Date getUltimaModificacion() {
		return ultimaModificacion;
	}
	public void setUltimaModificacion(Date ultimaModificacion) {
		this.ultimaModificacion = ultimaModificacion;
	}
	/**
	 * @return the codigoRespuesta
	 */
	public CodigoRespuestaDTO getCodigoRespuesta() {
		return codigoRespuesta;
	}
	/**
	 * @param codigoRespuesta the codigoRespuesta to set
	 */
	public void setCodigoRespuesta(CodigoRespuestaDTO codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}
	/**
	 * @return the tipoTransaccion
	 */
	public TipoTransaccionDTO getTipoTransaccion() {
		return tipoTransaccion;
	}
	/**
	 * @param tipoTransaccion the tipoTransaccion to set
	 */
	public void setTipoTransaccion(TipoTransaccionDTO tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}
	/**
	 * @return the fechaTransaccion
	 */
	public Date getFechaTransaccion() {
		return fechaTransaccion;
	}
	/**
	 * @param fechaTransaccion the fechaTransaccion to set
	 */
	public void setFechaTransaccion(Date fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}
	/**
	 * @return the tipoConsulta
	 */
	public String getTipoConsulta() {
		return tipoConsulta;
	}
	/**
	 * @param tipoConsulta the tipoConsulta to set
	 */
	public void setTipoConsulta(String tipoConsulta) {
		this.tipoConsulta = tipoConsulta;
	}
	/**
	 * @return the origenTransaccion
	 */
	public OrigenTransaccionDTO getOrigenTransaccion() {
		return origenTransaccion;
	}
	/**
	 * @param origenTransaccion the origenTransaccion to set
	 */
	public void setOrigenTransaccion(OrigenTransaccionDTO origenTransaccion) {
		this.origenTransaccion = origenTransaccion;
	}
	/**
	 * @return the token
	 */
	public String getToken() {
		return token;
	}
	/**
	 * @param token the token to set
	 */
	public void setToken(String token) {
		this.token = token;
	}
	/**
	 * @return the fechaVencimiento
	 */
	public Date getFechaVencimiento() {
		return fechaVencimiento;
	}
	/**
	 * @param fechaVencimiento the fechaVencimiento to set
	 */
	public void setFechaVencimiento(Date fechaVencimiento) {
		this.fechaVencimiento = fechaVencimiento;
	}
	/**
	 * @return the fechaLimitePago
	 */
	public Date getFechaLimitePago() {
		return fechaLimitePago;
	}
	/**
	 * @param fechaLimitePago the fechaLimitePago to set
	 */
	public void setFechaLimitePago(Date fechaLimitePago) {
		this.fechaLimitePago = fechaLimitePago;
	}
	/**
	 * @return the taza
	 */
	public BigDecimal getTaza() {
		return taza;
	}
	/**
	 * @param taza the taza to set
	 */
	public void setTaza(BigDecimal taza) {
		this.taza = taza;
	}
	/**
	 * @return the moneda
	 */
	public String getMoneda() {
		return moneda;
	}
	/**
	 * @param moneda the moneda to set
	 */
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}
	/**
	 * @return the referencia1
	 */
	public String getReferencia1() {
		return referencia1;
	}
	/**
	 * @param referencia1 the referencia1 to set
	 */
	public void setReferencia1(String referencia1) {
		this.referencia1 = referencia1;
	}
	/**
	 * @return the referencia2
	 */
	public String getReferencia2() {
		return referencia2;
	}
	/**
	 * @param referencia2 the referencia2 to set
	 */
	public void setReferencia2(String referencia2) {
		this.referencia2 = referencia2;
	}
	/**
	 * @return the referencia3
	 */
	public String getReferencia3() {
		return referencia3;
	}
	/**
	 * @param referencia3 the referencia3 to set
	 */
	public void setReferencia3(String referencia3) {
		this.referencia3 = referencia3;
	}
	/**
	 * @return the approvalId
	 */
	public String getApprovalId() {
		return approvalId;
	}
	/**
	 * @param approvalId the approvalId to set
	 */
	public void setApprovalId(String approvalId) {
		this.approvalId = approvalId;
	}
	/**
	 * @return the impuesto
	 */
	public ImpuestoDTO getImpuesto() {
		return impuesto;
	}
	/**
	 * @param impuesto the impuesto to set
	 */
	public void setImpuesto(ImpuestoDTO impuesto) {
		this.impuesto = impuesto;
	}
	/**
	 * @return the trazabilityCode
	 */
	public String getTrazabilityCode() {
		return trazabilityCode;
	}
	/**
	 * @param trazabilityCode the trazabilityCode to set
	 */
	public void setTrazabilityCode(String trazabilityCode) {
		this.trazabilityCode = trazabilityCode;
	}
	/**
	 * @return the usuario
	 */
	public UsuarioDTO getUsuario() {
		return usuario;
	}
	/**
	 * @param usuario the usuario to set
	 */
	public void setUsuario(UsuarioDTO usuario) {
		this.usuario = usuario;
	}
	/**
	 * @return the pmtId
	 */
	public String getPmtId() {
		return pmtId;
	}
	/**
	 * @param pmtId the pmtId to set
	 */
	public void setPmtId(String pmtId) {
		this.pmtId = pmtId;
	}
	/**
	 * @return the banco
	 */
	public BancoDTO getBanco() {
		return banco;
	}
	/**
	 * @param banco the banco to set
	 */
	public void setBanco(BancoDTO banco) {
		this.banco = banco;
	}
	/**
	 * @return the tarjetaCredito
	 */
	public TarjetaCreditoDTO getTarjetaCredito() {
		return tarjetaCredito;
	}
	/**
	 * @param tarjetaCredito the tarjetaCredito to set
	 */
	public void setTarjetaCredito(TarjetaCreditoDTO tarjetaCredito) {
		this.tarjetaCredito = tarjetaCredito;
	}
	public BigDecimal getId() {
		return id;
	}
	public void setId(BigDecimal id) {
		this.id = id;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getReferencia4() {
		return referencia4;
	}
	public void setReferencia4(String referencia4) {
		this.referencia4 = referencia4;
	}
	public String getTipoPmt() {
		return tipoPmt;
	}
	public void setTipoPmt(String tipoPmt) {
		this.tipoPmt = tipoPmt;
	}
	
	//RQ25542 MotorDeRiesgosPortal
	public String getDeviceToken() {
		return this.deviceToken;
	}
	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}
	public DatosPlantillaDTO getDatosPlantillaDTO() {
		return this.datosPlantillaDTO;
	}
	public void setDatosPlantillaDTO(DatosPlantillaDTO datosPlantillaDTO) {
		this.datosPlantillaDTO = datosPlantillaDTO;
	}
	//RQ27225 Multiples Referencias 
	public String getMultiplesrefe() {
		return this.multiplesrefe;
	}
	public void setMultiplesrefe(String multiplesrefe) {
		this.multiplesrefe = multiplesrefe;
	}
	
}
