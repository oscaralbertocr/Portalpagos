package co.com.pasarelapagos.dto;

public class OrigenTransaccionDTO extends BaseDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String origentransaccion;

	/**
	 * @return the origentransaccion
	 */
	public String getOrigentransaccion() {
		return origentransaccion;
	}

	/**
	 * @param origentransaccion the origentransaccion to set
	 */
	public void setOrigentransaccion(String origentransaccion) {
		this.origentransaccion = origentransaccion;
	}

}
