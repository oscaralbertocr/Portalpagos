package co.com.pasarelapagos.dto;

import java.math.BigDecimal;

public class ImpuestoDTO extends BaseDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private BigDecimal valorImpuesto;
	
	private BigDecimal taza;
	
	private String moneda;

	/**
	 * @return the valorImpuesto
	 */
	public BigDecimal getValorImpuesto() {
		return valorImpuesto;
	}

	/**
	 * @param valorImpuesto the valorImpuesto to set
	 */
	public void setValorImpuesto(BigDecimal valorImpuesto) {
		this.valorImpuesto = valorImpuesto;
	}

	/**
	 * @return the taza
	 */
	public BigDecimal getTaza() {
		return taza;
	}

	/**
	 * @param taza the taza to set
	 */
	public void setTaza(BigDecimal taza) {
		this.taza = taza;
	}

	/**
	 * @return the moneda
	 */
	public String getMoneda() {
		return moneda;
	}

	/**
	 * @param moneda the moneda to set
	 */
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

}
