package co.com.pasarelapagos.dto;

import java.math.BigDecimal;

public class ConfiguracionDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String contrasena;

	private String logo;

	private BigDecimal regeliminado;

	private String rutacertificado;

	private String urlconfirmacion;

	private String urlrespuesta;

	private String usuario;
	
	private String tema;
	
	private PlantillaDTO plantilla;

	/**
	 * @return the contrasena
	 */
	public String getContrasena() {
		return contrasena;
	}

	/**
	 * @param contrasena the contrasena to set
	 */
	public void setContrasena(String contrasena) {
		this.contrasena = contrasena;
	}

	/**
	 * @return the logo
	 */
	public String getLogo() {
		return logo;
	}

	/**
	 * @param logo the logo to set
	 */
	public void setLogo(String logo) {
		this.logo = logo;
	}

	/**
	 * @return the regeliminado
	 */
	public BigDecimal getRegeliminado() {
		return regeliminado;
	}

	/**
	 * @param regeliminado the regeliminado to set
	 */
	public void setRegeliminado(BigDecimal regeliminado) {
		this.regeliminado = regeliminado;
	}

	/**
	 * @return the rutacertificado
	 */
	public String getRutacertificado() {
		return rutacertificado;
	}

	/**
	 * @param rutacertificado the rutacertificado to set
	 */
	public void setRutacertificado(String rutacertificado) {
		this.rutacertificado = rutacertificado;
	}

	/**
	 * @return the urlconfirmacion
	 */
	public String getUrlconfirmacion() {
		return urlconfirmacion;
	}

	/**
	 * @param urlconfirmacion the urlconfirmacion to set
	 */
	public void setUrlconfirmacion(String urlconfirmacion) {
		this.urlconfirmacion = urlconfirmacion;
	}

	/**
	 * @return the urlrespuesta
	 */
	public String getUrlrespuesta() {
		return urlrespuesta;
	}

	/**
	 * @param urlrespuesta the urlrespuesta to set
	 */
	public void setUrlrespuesta(String urlrespuesta) {
		this.urlrespuesta = urlrespuesta;
	}

	/**
	 * @return the usuario
	 */
	public String getUsuario() {
		return usuario;
	}

	/**
	 * @param usuario the usuario to set
	 */
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	/**
	 * @return the plantilla
	 */
	public PlantillaDTO getPlantilla() {
		return plantilla;
	}

	/**
	 * @param plantilla the plantilla to set
	 */
	public void setPlantilla(PlantillaDTO plantilla) {
		this.plantilla = plantilla;
	}

	/**
	 * @return the tema
	 */
	public String getTema() {
		return tema;
	}

	/**
	 * @param tema the tema to set
	 */
	public void setTema(String tema) {
		this.tema = tema;
	}

}
