package co.com.pasarelapagos.dto;

/**
 * Clase que representa el DTO de un medio de pago.
 * Paghos Aval, TC ...
 * 
 * @author A Toda Hora S.A
 * @author Juan Carlos Ramirez Orozco
 * @version 1.0
 * @create 20/06/2014
 */

public class MedioPagoDTO extends BaseDTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Constructor sin parametros.
	 */
	public MedioPagoDTO(){
		super();
	}
	
	/**
	 * Constructor que recibe la descripcion
	 * @param descripcion String Tarjeta de credito, Pay Pal, ...
	 */
	public MedioPagoDTO(String descripcion){
		this.descripcion = descripcion;
	}
	
	/**
	 * Constructor que recibe el codigo y la descripcion
	 * @param id int Identificador unico del medio de pago
	 * @param descripcion String Tarjeta de credito, Pay Pal, ...
	 */
	public MedioPagoDTO(Integer id, String descripcion){
		this.id = id;
		this.descripcion = descripcion;
	}

}
