package co.com.pasarelapagos.dto;

/**
 * Clase que representa el DTO de un codigo de respuesta.
 * Transaccion no permitida, Tarjeta caducada ...
 * 
 * @author A Toda Hora S.A
 * @author Juan Carlos Ramirez Orozco
 * @version 1.0
 * @create 02/07/2014
 */
public class CodigoRespuestaDTO extends BaseDTO {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String codigoRespuesta;
	
	private String codigoRespuestaHost;

	/**
	 * @return the codigoRespuesta
	 */
	public String getCodigoRespuesta() {
		return codigoRespuesta;
	}

	/**
	 * @param codigoRespuesta the codigoRespuesta to set
	 */
	public void setCodigoRespuesta(String codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}

	/**
	 * @return the codigoRespuestaHost
	 */
	public String getCodigoRespuestaHost() {
		return codigoRespuestaHost;
	}

	/**
	 * @param codigoRespuestaHost the codigoRespuestaHost to set
	 */
	public void setCodigoRespuestaHost(String codigoRespuestaHost) {
		this.codigoRespuestaHost = codigoRespuestaHost;
	}

}
