package co.com.pasarelapagos.dto;

import java.io.Serializable;

public class MensajeJMSDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -759522541276430559L;
	
	

}
