package co.com.pasarelapagos.dto;

/**
 * Representacion de objeto para los estados de los pagos (transacciones)
 * realizadas por la pasarela 
 * @author ATH
 *
 */
public class EstadoPagoDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String estado;
	
	private EstadoTransaccionNegocioDTO estadoNegocio;
	
	/**
	 * @return the estado
	 */
	public String getEstado() {
		return estado;
	}
	/**
	 * @param estado the estado to set
	 */
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	/**
	 * @return the estadoNegocio
	 */
	public EstadoTransaccionNegocioDTO getEstadoNegocio() {
		return estadoNegocio;
	}
	/**
	 * @param estadoNegocio the estadoNegocio to set
	 */
	public void setEstadoNegocio(EstadoTransaccionNegocioDTO estadoNegocio) {
		this.estadoNegocio = estadoNegocio;
	}

}
