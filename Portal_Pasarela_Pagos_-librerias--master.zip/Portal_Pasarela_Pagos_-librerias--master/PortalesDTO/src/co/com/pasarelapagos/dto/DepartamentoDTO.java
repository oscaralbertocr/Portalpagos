package co.com.pasarelapagos.dto;

/**
 * Representacion de objeto para los departamentos
 * @author ATH
 *
 */
public class DepartamentoDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String dane;
	private String nombre;

	public String getDane() {
		return dane;
	}
	public void setDane(String dane) {
		this.dane = dane;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	
}
