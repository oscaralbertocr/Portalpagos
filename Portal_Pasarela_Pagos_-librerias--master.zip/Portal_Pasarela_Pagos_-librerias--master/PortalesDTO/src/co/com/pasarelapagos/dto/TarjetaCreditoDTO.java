package co.com.pasarelapagos.dto;

import java.util.Date;

public class TarjetaCreditoDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Franquicia.
	 * 1 � Visa.
	 * 2 � Mastercard.
	 * 3 � American Express.
	 * 4 � Diners Club.
	 */
	private String franquicia;
	
	/**
	 * N�mero de la tarjeta de cr�dito.
	 */
	private String numeroTarjeta;
	
	/**
	 * Ultimos 4 digitos de la tarjeta de cr�dito.
	 */
	private String cardEmbossNum;
	
	/**
	 * Fecha de vencimiento.
	 */
	private Date fechaVencimiento;
	
	/**
	 * C�digo de verificaci�n.
	 */
	private String codigoVerificacion;
	
	/**
	 * Nombre del titular como aparece en la tarjeta de credito
	 */
	private String nombreTitular;

	/**
	 * @return the franquicia
	 */
	public String getFranquicia() {
		return franquicia;
	}

	/**
	 * @param franquicia the franquicia to set
	 */
	public void setFranquicia(String franquicia) {
		this.franquicia = franquicia;
	}

	/**
	 * @return the numeroTarjeta
	 */
	public String getNumeroTarjeta() {
		return numeroTarjeta;
	}

	/**
	 * @param numeroTarjeta the numeroTarjeta to set
	 */
	public void setNumeroTarjeta(String numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	/**
	 * @return the fechaVencimiento
	 */
	public Date getFechaVencimiento() {
		return fechaVencimiento;
	}

	/**
	 * @param fechaVencimiento the fechaVencimiento to set
	 */
	public void setFechaVencimiento(Date fechaVencimiento) {
		this.fechaVencimiento = fechaVencimiento;
	}

	/**
	 * @return the codigoVerificacion
	 */
	public String getCodigoVerificacion() {
		return codigoVerificacion;
	}

	/**
	 * @param codigoVerificacion the codigoVerificacion to set
	 */
	public void setCodigoVerificacion(String codigoVerificacion) {
		this.codigoVerificacion = codigoVerificacion;
	}

	/**
	 * @return the nombreTitular
	 */
	public String getNombreTitular() {
		return nombreTitular;
	}

	/**
	 * @param nombreTitular the nombreTitular to set
	 */
	public void setNombreTitular(String nombreTitular) {
		this.nombreTitular = nombreTitular;
	}

	/**
	 * @return the cardEmbossNum
	 */
	public String getCardEmbossNum() {
		return cardEmbossNum;
	}

	/**
	 * @param cardEmbossNum the cardEmbossNum to set
	 */
	public void setCardEmbossNum(String cardEmbossNum) {
		this.cardEmbossNum = cardEmbossNum;
	}

}
