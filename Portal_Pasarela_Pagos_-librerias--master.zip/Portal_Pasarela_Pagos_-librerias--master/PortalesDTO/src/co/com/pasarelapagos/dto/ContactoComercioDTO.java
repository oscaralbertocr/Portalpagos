package co.com.pasarelapagos.dto;

/**
 * Representacion de objeto para las contactos por comercio
 * @author ATH
 *
 */
public class ContactoComercioDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ComercioDTO comercio;
	private String nombre;
	private String email;
	private String celular;
	private RolesContactosComercioDTO rol;
	
	public ComercioDTO getComercio() {
		return comercio;
	}
	public void setComercio(ComercioDTO comercio) {
		this.comercio = comercio;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCelular() {
		return celular;
	}
	public void setCelular(String celular) {
		this.celular = celular;
	}
	
	public RolesContactosComercioDTO getRol() {
		return rol;
	}
	public void setRol(RolesContactosComercioDTO rol) {
		this.rol = rol;
	}
	
	
}
