package co.com.pasarelapagos.dto;

import java.io.Serializable;

/**
 * Representacion de objeto base para los DTO's de la aplicaci�n
 * de pasarela.
 * @author ATH
 *
 */
public class BaseDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Identificador del DTO
	 */
	protected Integer id;
	
	/**
	 * Descripcion del DTO
	 */
	protected String descripcion;

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

}
