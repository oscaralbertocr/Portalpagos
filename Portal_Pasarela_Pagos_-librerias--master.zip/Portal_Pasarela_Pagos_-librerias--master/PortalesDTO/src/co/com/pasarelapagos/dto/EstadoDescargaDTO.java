package co.com.pasarelapagos.dto;

/**
 * Representacion de objeto para los estados de las 
 * descarga realizadas por la pasarela de pagos
 * @author ATH
 *
 */
public class EstadoDescargaDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String estado;

	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	
}
