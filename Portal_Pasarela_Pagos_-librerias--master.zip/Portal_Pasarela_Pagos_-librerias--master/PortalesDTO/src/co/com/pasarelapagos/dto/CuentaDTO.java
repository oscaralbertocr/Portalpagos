package co.com.pasarelapagos.dto;

public class CuentaDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Tipo de la cuenta
	 * S � Ahorros.
	 * C � Corriente.
	 */
	private String tipo;
	
	/**
	 * COP � Pesos Colombianos.
	 */
	private String moneda;
	
	/**
	 * 1 � Banco AVVillas.
	 * 2 � Banco de Bogota.
	 * 3 � Banco de Occidente.
	 * 4 � Banco Popular.
	 */
	private BancoDTO banco;
	
	/**
	 * odigo de la oficina de la cuenta.
	 */
	private String codOficina;

	/**
	 * @return the tipo
	 */
	public String getTipo() {
		return tipo;
	}

	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	/**
	 * @return the moneda
	 */
	public String getMoneda() {
		return moneda;
	}

	/**
	 * @param moneda the moneda to set
	 */
	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	/**
	 * @return the banco
	 */
	public BancoDTO getBanco() {
		return banco;
	}

	/**
	 * @param banco the banco to set
	 */
	public void setBanco(BancoDTO banco) {
		this.banco = banco;
	}

	/**
	 * @return the codOficina
	 */
	public String getCodOficina() {
		return codOficina;
	}

	/**
	 * @param codOficina the codOficina to set
	 */
	public void setCodOficina(String codOficina) {
		this.codOficina = codOficina;
	}

}
