package co.com.pasarelapagos.dto;

public class RolesContactosComercioDTO extends BaseDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private ContactoComercioDTO contactoComercioDTO;
	private String rol;
	
	public ContactoComercioDTO getContactoComercioDTO() {
		return contactoComercioDTO;
	}
	public void setContactoComercioDTO(ContactoComercioDTO contactoComercioDTO) {
		this.contactoComercioDTO = contactoComercioDTO;
	}
	public String getRol() {
		return rol;
	}
	public void setRol(String rol) {
		this.rol = rol;
	}

	

}
