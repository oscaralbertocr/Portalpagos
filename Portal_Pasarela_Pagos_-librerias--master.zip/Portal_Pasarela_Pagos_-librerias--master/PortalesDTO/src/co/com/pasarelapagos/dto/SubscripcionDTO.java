package co.com.pasarelapagos.dto;

import java.util.Date;



public class SubscripcionDTO extends BaseDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private ComercioDTO comercio;
	private BancoDTO banco;
	private CiudadDTO ciudad;
	private String razonSocial;
	private String digitoVerificacion;
	private String direccion;
	private String telefono;
	private String email;
	private String fax;
	private String representanteLegal;
	private String cedulaRepresentanteLegal;
	
	public ComercioDTO getComercio() {
		return comercio;
	}
	public void setComercio(ComercioDTO comercio) {
		this.comercio = comercio;
	}
	public BancoDTO getBanco() {
		return banco;
	}
	public void setBanco(BancoDTO banco) {
		this.banco = banco;
	}
	public CiudadDTO getCiudad() {
		return ciudad;
	}
	public void setCiudad(CiudadDTO ciudad) {
		this.ciudad = ciudad;
	}
	public String getRazonSocial() {
		return razonSocial;
	}
	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}
	public String getDigitoVerificacion() {
		return digitoVerificacion;
	}
	public void setDigitoVerificacion(String digitoVerificacion) {
		this.digitoVerificacion = digitoVerificacion;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getRepresentanteLegal() {
		return representanteLegal;
	}
	public void setRepresentanteLegal(String representanteLegal) {
		this.representanteLegal = representanteLegal;
	}
	public String getCedulaRepresentanteLegal() {
		return cedulaRepresentanteLegal;
	}
	public void setCedulaRepresentanteLegal(String cedulaRepresentanteLegal) {
		this.cedulaRepresentanteLegal = cedulaRepresentanteLegal;
	}
	public Date getFechaCreacion() {
		return fechaCreacion;
	}
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}
	private Date fechaCreacion;

}
