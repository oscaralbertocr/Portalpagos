package co.com.pasarelapagos.dto;

import java.util.Date;

/**
 * 
 * @author saruiz
 *
 */
public class ConciliacionDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Date fechaInicio;
	private Date fechaFin;
	private ComercioDTO comercio;
	private MedioPagoDTO medioPagoDTO;
	
	
	public Date getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public Date getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}
	public ComercioDTO getComercio() {
		return comercio;
	}
	public void setComercio(ComercioDTO comercio) {
		this.comercio = comercio;
	}
	public MedioPagoDTO getMedioPagoDTO() {
		return medioPagoDTO;
	}
	public void setMedioPagoDTO(MedioPagoDTO medioPagoDTO) {
		this.medioPagoDTO = medioPagoDTO;
	}
	
	

}
