package co.com.pasarelapagos.dto;

import java.io.Serializable;
import java.util.List;

/**
 * Representacion de objeto para los comercios de la pasarela
 * @author ATH
 *
 */
public class ComercioDTO extends BaseDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long nit;
	private char estado;
	private String codigoEan;
	private String codigoNura;
	private String codigoIncocredito;
	private String codigoAch;
	private String nombreEnTDS;
	private SubscripcionDTO subscripcionDTO;
	private List<ContactoComercioDTO> contactoComercioDTO;
	private List<MedioPagoDTO> mediosPagoDTO;
	private String telefono;
	private ConfiguracionDTO configuracion;

	public long getNit() {
		return nit;
	}
	/**
	 * @param nit the nit to set
	 */
	public void setNit(long nit) {
		this.nit = nit;
	}
	public char getEstado() {
		return estado;
	}
	public void setEstado(char estado) {
		this.estado = estado;
	}
	public String getCodigoEan() {
		return codigoEan;
	}
	public void setCodigoEan(String codigoEan) {
		this.codigoEan = codigoEan;
	}
	public String getCodigoNura() {
		return codigoNura;
	}
	public void setCodigoNura(String codigoNura) {
		this.codigoNura = codigoNura;
	}
	public String getCodigoIncocredito() {
		return codigoIncocredito;
	}
	public void setCodigoIncocredito(String codigoIncocredito) {
		this.codigoIncocredito = codigoIncocredito;
	}
	public String getCodigoAch() {
		return codigoAch;
	}
	public void setCodigoAch(String codigoAch) {
		this.codigoAch = codigoAch;
	}
	public String getNombreEnTDS() {
		return nombreEnTDS;
	}
	public void setNombreEnTDS(String nombreEnTDS) {
		this.nombreEnTDS = nombreEnTDS;
	}
	
	public SubscripcionDTO getSubscripcionDTO() {
		return subscripcionDTO;
	}
	public void setSubscripcionDTO(SubscripcionDTO subscripcionDTO) {
		this.subscripcionDTO = subscripcionDTO;
	}
	
	public List<ContactoComercioDTO> getContactoComercioDTO(){
		return this.contactoComercioDTO;
	}
	
	public void setContactoComercioDTO(List<ContactoComercioDTO> contactoComercioDTO){
		this.contactoComercioDTO = contactoComercioDTO;
	}
	
	/**
	 * @return the telefono
	 */
	public String getTelefono() {
		return telefono;
	}
	/**
	 * @param telefono the telefono to set
	 */
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	/**
	 * @return the mediosPagoDTO
	 */
	public List<MedioPagoDTO> getMediosPagoDTO() {
		return mediosPagoDTO;
	}
	/**
	 * @param mediosPagoDTO the mediosPagoDTO to set
	 */
	public void setMediosPagoDTO(List<MedioPagoDTO> mediosPagoDTO) {
		this.mediosPagoDTO = mediosPagoDTO;
	}
	/**
	 * @return the configuracion
	 */
	public ConfiguracionDTO getConfiguracion() {
		return configuracion;
	}
	/**
	 * @param configuracion the configuracion to set
	 */
	public void setConfiguracion(ConfiguracionDTO configuracion) {
		this.configuracion = configuracion;
	}
	

}
