package co.com.pasarelapagos.dto;

import java.util.Date;

/**
 * Representacion de objeto para las descargas a realizar 
 * en el portal de servicio
 * @author ATH
 *
 */
public class DescargaDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private EstadoDescargaDTO estadoDescarga;
	private int formato;
	private String archivoUsuario;
	private String archivoSistema;
	private Date fechaInicial;
	private Date fechaFinal;
	private TransaccionesDTO filtroTransaccion;
	private UsuarioDTO usuarioDescarga;
	private boolean generado;
	private int intentos;
	private int maxIntentos;
	private String filtro;

	public EstadoDescargaDTO getEstadoDescarga() {
		return estadoDescarga;
	}
	public void setEstadoDescarga(EstadoDescargaDTO estadoDescarga) {
		this.estadoDescarga = estadoDescarga;
	}
	public int getFormato() {
		return formato;
	}
	public void setFormato(int formato) {
		this.formato = formato;
	}
	public String getArchivoUsuario() {
		return archivoUsuario;
	}
	public void setArchivoUsuario(String archivoUsuario) {
		this.archivoUsuario = archivoUsuario;
	}
	public String getArchivoSistema() {
		return archivoSistema;
	}
	public void setArchivoSistema(String archivoSistema) {
		this.archivoSistema = archivoSistema;
	}
	public Date getFechaInicial() {
		return fechaInicial;
	}
	public void setFechaInicial(Date fechaInicial) {
		this.fechaInicial = fechaInicial;
	}
	public Date getFechaFinal() {
		return fechaFinal;
	}
	public void setFechaFinal(Date fechaFinal) {
		this.fechaFinal = fechaFinal;
	}
	/**
	 * @return the filtroTransaccion
	 */
	public TransaccionesDTO getFiltroTransaccion() {
		return filtroTransaccion;
	}
	/**
	 * @param filtroTransaccion the filtroTransaccion to set
	 */
	public void setFiltroTransaccion(TransaccionesDTO filtroTransaccion) {
		this.filtroTransaccion = filtroTransaccion;
	}
	/**
	 * @return the usuarioDescarga
	 */
	public UsuarioDTO getUsuarioDescarga() {
		return usuarioDescarga;
	}
	/**
	 * @param usuarioDescarga the usuarioDescarga to set
	 */
	public void setUsuarioDescarga(UsuarioDTO usuarioDescarga) {
		this.usuarioDescarga = usuarioDescarga;
	}
	/**
	 * @return the generado
	 */
	public boolean isGenerado() {
		return generado;
	}
	/**
	 * @param generado the generado to set
	 */
	public void setGenerado(boolean generado) {
		this.generado = generado;
	}
	/**
	 * @return the intentos
	 */
	public int getIntentos() {
		return intentos;
	}
	/**
	 * @param intentos the intentos to set
	 */
	public void setIntentos(int intentos) {
		this.intentos = intentos;
	}
	/**
	 * @return the filtro
	 */
	public String getFiltro() {
		return filtro;
	}
	/**
	 * @param filtro the filtro to set
	 */
	public void setFiltro(String filtro) {
		this.filtro = filtro;
	}
	/**
	 * @return the maxIntentos
	 */
	public int getMaxIntentos() {
		return maxIntentos;
	}
	/**
	 * @param maxIntentos the maxIntentos to set
	 */
	public void setMaxIntentos(int maxIntentos) {
		this.maxIntentos = maxIntentos;
	}	
	
}
