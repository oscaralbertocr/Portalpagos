package co.com.pasarelapagos.dto;

import java.util.Date;

/**
 * Representacion de objeto para los usuarios registrados
 * en la pasarela
 * @author ATH
 *
 */
public class UsuarioDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String ESTADO_ACTIVO = "A";
	public static final String ESTADO_INACTIVO = "I";
	public static final String CLAVE_TEMPORAL_TRUE = "T";
	public static final String CLAVE_TEMPORAL_FALSE = "F";
	
	// Datos basicos beneficiario
	private String legalName;
	private String primerNombre;
	private String segundoNombre;
	private String primerApellido;
	private String segundoApellido;
	private String direccion;
	private String telefono;
	private String genero;	
	private Date   fechaNacimiento;	
	private String nombreCiudad;	
	private String nombreDepartamento;	
	private String pais;	
	private String correoElectronico;
	private String tipoDocumento;
	private String noDocumento;
	private boolean claveTemporal;
	private boolean claveExpirada;
	private String rol;
	
	// Datos basicos pagador
	private String legalNamePago;
	private String primerNombrePago;
	private String segundoNombrePago;
	private String primerApellidoPago;
	private String segundoApellidoPago;
	private String generoPago;
	private Date   fechaNacimientoPago;	
	private String nombreCiudadPago;	
	private String nombreDepartamentoPago;	
	private String paisPago;
	private String direccionPago;
	private String correoElectronicoPago;
	private String telefonoPago;
	private String tipoDocumentoPago;
	private String noDocumentoPago;
	
	// Datos autenticacion
	private String usuario_mod;
	private String usuario;
	private String clave;
	private String estado;
	private Date fechaUltimoLogin;
	private Date fechaClaveTemporal;
	private ComercioDTO comercio;
	private String intentos;
	
	/**
	 * 0 � Personal Natural.
	 * 1 � Persona Jur�dica.
	 */
	private String tipoUsuario;
	
	private String nickName;	
	
	public String getPrimerNombre() {
		return primerNombre==null?"":primerNombre;
	}
	public void setPrimerNombre(String primerNombre) {
		this.primerNombre = primerNombre;
	}
	public String getSegundoNombre() {
		return segundoNombre==null?"":segundoNombre;
	}
	public void setSegundoNombre(String segundoNombre) {
		this.segundoNombre = segundoNombre;
	}
	public String getPrimerApellido() {
		return primerApellido==null?"":primerApellido;
	}
	public void setPrimerApellido(String primerApellido) {
		this.primerApellido = primerApellido;
	}
	public String getSegundoApellido() {
		return segundoApellido==null?"":segundoApellido;
	}
	public void setSegundoApellido(String segundoApellido) {
		this.segundoApellido = segundoApellido;
	}
	public String getCorreoElectronico() {
		return correoElectronico==null?"":correoElectronico;
	}
	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}
	public String getUsuario() {
		return usuario==null?"":usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	public String getClave() {
		return clave==null?"":clave;
	}
	public void setClave(String clave) {
		this.clave = clave;
	}
	public String getDireccion() {
		return direccion==null?"":direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getTelefono() {
		return telefono==null?"":telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public String getNoDocumento() {
		return noDocumento;
	}
	public void setNoDocumento(String noDocumento) {
		this.noDocumento = noDocumento;
	}
	public String getTipoDocumento() {
		return tipoDocumento==null?"":tipoDocumento;
	}
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	public String getEstado() {
		return estado==null?"":estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public Date getFechaUltimoLogin() {
		return fechaUltimoLogin;
	}
	public void setFechaUltimoLogin(Date fechaUltimoLogin) {
		this.fechaUltimoLogin = fechaUltimoLogin;
	}
	public ComercioDTO getComercio() {
		return comercio;
	}
	public void setComercio(ComercioDTO comercio) {
		this.comercio = comercio;
	}
	public boolean isClaveTemporal() {
		return claveTemporal;
	}
	public void setClaveTemporal(boolean claveTemporal) {
		this.claveTemporal = claveTemporal;
	}
	/**
	 * @return the fechaClaveTemporal
	 */
	public Date getFechaClaveTemporal() {
		return fechaClaveTemporal;
	}
	/**
	 * @param fechaClaveTemporal the fechaClaveTemporal to set
	 */
	public void setFechaClaveTemporal(Date fechaClaveTemporal) {
		this.fechaClaveTemporal = fechaClaveTemporal;
	}
	/**
	 * @return the tipoUsuario
	 */
	public String getTipoUsuario() {
		return tipoUsuario;
	}
	/**
	 * @param tipoUsuario the tipoUsuario to set
	 */
	public void setTipoUsuario(String tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}
	
	/**
	 * @return the rol
	 */
	public String getRol() {
		return rol;
	}
	/**
	 * @param rol the rol to set
	 */
	public void setRol(String rol) {
		this.rol = rol;
	}
	/**
	 * @return the genero
	 */
	public String getGenero() {
		return genero;
	}
	/**
	 * @param genero the genero to set
	 */
	public void setGenero(String genero) {
		this.genero = genero;
	}
	/**
	 * @return the fechaNacimiento
	 */
	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}
	/**
	 * @param fechaNacimiento the fechaNacimiento to set
	 */
	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	/**
	 * @return the nombreCiudad
	 */
	public String getNombreCiudad() {
		return nombreCiudad;
	}
	/**
	 * @param nombreCiudad the nombreCiudad to set
	 */
	public void setNombreCiudad(String nombreCiudad) {
		this.nombreCiudad = nombreCiudad;
	}
	/**
	 * @return the nombreDepartamento
	 */
	public String getNombreDepartamento() {
		return nombreDepartamento;
	}
	/**
	 * @param nombreDepartamento the nombreDepartamento to set
	 */
	public void setNombreDepartamento(String nombreDepartamento) {
		this.nombreDepartamento = nombreDepartamento;
	}
	/**
	 * @return the pais
	 */
	public String getPais() {
		return pais;
	}
	/**
	 * @param pais the pais to set
	 */
	public void setPais(String pais) {
		this.pais = pais;
	}
	/**
	 * @return the nickName
	 */
	public String getNickName() {
		return nickName;
	}
	/**
	 * @param nickName the nickName to set
	 */
	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	/**
	 * @return the legalName
	 */
	public String getLegalName() {
		return legalName;
	}
	/**
	 * @param legalName the legalName to set
	 */
	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}
	
	public boolean isClaveExpirada() {
		return claveExpirada;
	}
	public void setClaveExpirada(boolean claveExpirada) {
		this.claveExpirada = claveExpirada;
	}
	public String getPrimerNombrePago() {
		return this.primerNombrePago;
	}
	public void setPrimerNombrePago(String primerNombrePago) {
		this.primerNombrePago = primerNombrePago;
	}
	public String getSegundoNombrePago() {
		return this.segundoNombrePago;
	}
	public void setSegundoNombrePago(String segundoNombrePago) {
		this.segundoNombrePago = segundoNombrePago;
	}
	public String getPrimerApellidoPago() {
		return this.primerApellidoPago;
	}
	public void setPrimerApellidoPago(String primerApellidoPago) {
		this.primerApellidoPago = primerApellidoPago;
	}
	public String getSegundoApellidoPago() {
		return this.segundoApellidoPago;
	}
	public void setSegundoApellidoPago(String segundoApellidoPago) {
		this.segundoApellidoPago = segundoApellidoPago;
	}
	public String getCorreoElectronicoPago() {
		return this.correoElectronicoPago;
	}
	public void setCorreoElectronicoPago(String correoElectronicoPago) {
		this.correoElectronicoPago = correoElectronicoPago;
	}
	public String getTipoDocumentoPago() {
		return this.tipoDocumentoPago;
	}
	public void setTipoDocumentoPago(String tipoDocumentoPago) {
		this.tipoDocumentoPago = tipoDocumentoPago;
	}
	public String getNoDocumentoPago() {
		return this.noDocumentoPago;
	}
	public void setNoDocumentoPago(String noDocumentoPago) {
		this.noDocumentoPago = noDocumentoPago;
	}
	public String getTelefonoPago() {
		return this.telefonoPago;
	}
	public void setTelefonoPago(String telefonoPago) {
		this.telefonoPago = telefonoPago;
	}
	public String getUsuario_mod() {
		return usuario_mod;
	}
	public void setUsuario_mod(String usuario_mod) {
		this.usuario_mod = usuario_mod;
	}
	public String getIntentos() {
		return intentos;
	}
	public void setIntentos(String intentos) {
		this.intentos = intentos;
	}
	public String getLegalNamePago() {
		return legalNamePago;
	}
	public void setLegalNamePago(String legalNamePago) {
		this.legalNamePago = legalNamePago;
	}
	public String getGeneroPago() {
		return generoPago;
	}
	public void setGeneroPago(String generoPago) {
		this.generoPago = generoPago;
	}
	public Date getFechaNacimientoPago() {
		return fechaNacimientoPago;
	}
	public void setFechaNacimientoPago(Date fechaNacimientoPago) {
		this.fechaNacimientoPago = fechaNacimientoPago;
	}
	public String getNombreCiudadPago() {
		return nombreCiudadPago;
	}
	public void setNombreCiudadPago(String nombreCiudadPago) {
		this.nombreCiudadPago = nombreCiudadPago;
	}
	public String getNombreDepartamentoPago() {
		return nombreDepartamentoPago;
	}
	public void setNombreDepartamentoPago(String nombreDepartamentoPago) {
		this.nombreDepartamentoPago = nombreDepartamentoPago;
	}
	public String getPaisPago() {
		return paisPago;
	}
	public void setPaisPago(String paisPago) {
		this.paisPago = paisPago;
	}
	public String getDireccionPago() {
		return direccionPago;
	}
	public void setDireccionPago(String direccionPago) {
		this.direccionPago = direccionPago;
	}
}
