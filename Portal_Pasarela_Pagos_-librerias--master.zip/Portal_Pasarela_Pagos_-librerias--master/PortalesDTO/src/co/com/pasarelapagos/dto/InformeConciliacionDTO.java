package co.com.pasarelapagos.dto;

public class InformeConciliacionDTO extends BaseDTO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String fecha;
	private String cantidadConciliadas;
	private String cantidadNoConciliadas;
	
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public String getCantidadConciliadas() {
		return cantidadConciliadas;
	}
	public void setCantidadConciliadas(String cantidadConciliadas) {
		this.cantidadConciliadas = cantidadConciliadas;
	}
	public String getCantidadNoConciliadas() {
		return cantidadNoConciliadas;
	}
	public void setCantidadNoConciliadas(String cantidadNoConciliadas) {
		this.cantidadNoConciliadas = cantidadNoConciliadas;
	}
	
	

}
