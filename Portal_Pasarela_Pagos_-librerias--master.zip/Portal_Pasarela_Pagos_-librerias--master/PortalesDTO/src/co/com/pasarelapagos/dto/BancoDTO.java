package co.com.pasarelapagos.dto;

/**
 * 
 * Representacion de objeto para los bancos utilizados por la pasarela
 * @author ATH
 *
 */
public class BancoDTO extends BaseDTO {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nombre;
	private String bancRepublica;
	private String ach;
	private String rbm;
	private String approvalId;
	private String bankId;

	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getBancRepublica() {
		return bancRepublica;
	}
	public void setBancRepublica(String bancRepublica) {
		this.bancRepublica = bancRepublica;
	}
	public String getAch() {
		return ach;
	}
	public void setAch(String ach) {
		this.ach = ach;
	}
	public String getRbm() {
		return rbm;
	}
	public void setRbm(String rbm) {
		this.rbm = rbm;
	}
	
	/**
	 * @return the approvalId
	 */
	public String getApprovalId() {
		return approvalId;
	}
	/**
	 * @param approvalId the approvalId to set
	 */
	public void setApprovalId(String approvalId) {
		this.approvalId = approvalId;
	}
	/**
	 * @return the bankId
	 */
	public String getBankId() {
		return bankId;
	}
	/**
	 * @param bankId the bankId to set
	 */
	public void setBankId(String bankId) {
		this.bankId = bankId;
	}
	
}
