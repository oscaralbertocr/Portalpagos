package co.com.pasarelapagos.dto;

import java.io.Serializable;

public class DatosPlantillaDTO implements Serializable {
	
	//RQ26210 Ventanillas de Pago LGNC - Inicio
	
	private static final long serialVersionUID = 1L;
	private String URLTaquilla;
	private String Taquilla;
	private String Tema;

	public String getURLTaquilla() {
		return this.URLTaquilla;
	}

	public void setURLTaquilla(String uRLTaquilla) {
		this.URLTaquilla = uRLTaquilla;
	}

	public String getTaquilla() {
		return this.Taquilla;
	}

	public void setTaquilla(String taquilla) {
		this.Taquilla = taquilla;
	}

	public String getTema() {
		return this.Tema;
	}

	public void setTema(String tema) {
		this.Tema = tema;
	}
	
	//RQ26210 Ventanillas de Pago LGNC - Fin

}
