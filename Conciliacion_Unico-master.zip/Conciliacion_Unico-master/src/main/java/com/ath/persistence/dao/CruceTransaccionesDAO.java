/*
 * TransactionDAO
 *  
 * GSI - Integración
 * Creado el: 29/08/2014
 *
 * Copyright (c) A Toda Hora S.A. Todos los derechos reservados
 * 
 * Este software es confidencial y es propietario de ATH, queda prohibido
 * su uso, reproducción y copia de manera parcial o permanente salvo autorización
 * expresa de A Toda Hora S.A o de quién represente sus derechos.
 */
package com.ath.persistence.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ath.dto.ResponseDTO;
import com.ath.persistence.model.CruceTransacciones;



public interface CruceTransaccionesDAO extends JpaRepository<CruceTransacciones, Long> {

	@Query("SELECT c FROM CruceTransacciones c WHERE (c.nuraApc = :nura OR c.nuraUnico = :nura) AND (c.fechaApc = :fecha OR c.fechaUnico = :fecha)") 
	CruceTransacciones findCruceTransaccionesByNuraFecha(@Param("nura") String nura, @Param("fecha") String fecha);	
	
	
	//@Query("SELECT NEW com.ath.dto.ResponseDTO(a.idCruce,a.nuraApc,NVL(a.cantidadApc,0),NVL(a.valorApc,0),a.fechaApc,a.nuraUnico,NVL(a.cantidadUnico,0),NVL(a.valorUnico,0),a.fechaUnico,a.observaciones) FROM CruceTransacciones a "
	@Query("SELECT NEW com.ath.dto.ResponseDTO(a.idCruce,a.nuraApc, NVL(a.cantidadApc,0),NVL(a.valorApc,0),a.fechaApc,a.nuraUnico,NVL(a.cantidadUnico,0),NVL(a.valorUnico,0),a.fechaUnico,a.observaciones,ABS(NVL(a.cantidadApc,0) - NVL(a.cantidadUnico,0)),ABS(NVL(a.valorApc,0) - NVL(a.valorUnico,0))) FROM CruceTransacciones a "
			+ "WHERE (a.fechaApc = :fecha OR a.fechaUnico = :fecha) ORDER BY a.nuraApc,a.nuraUnico ASC") 
	List<ResponseDTO> findCruceTransaccionesByFecha(@Param("fecha") String fecha);	
	
	@Query("SELECT COUNT(*) FROM CruceTransacciones a "
			+ "WHERE (a.fechaApc = :fecha OR a.fechaUnico = :fecha) AND (NVL(a.cantidadApc,0) <> NVL(a.cantidadUnico,0) OR NVL(a.valorApc,0) <> NVL(a.valorUnico,0))") 
	int cantidadesDiferentes (@Param("fecha") String fecha);
	
	@Query("SELECT COUNT(*) FROM CruceTransacciones a "
			+ "WHERE (a.fechaApc = :fecha OR a.fechaUnico = :fecha) AND (NVL(a.cantidadApc,0) = NVL(a.cantidadUnico,0) AND NVL(a.valorApc,0) = NVL(a.valorUnico,0))") 
	int cantidadesIguales (@Param("fecha") String fecha);

}
