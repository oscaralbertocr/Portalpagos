/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ath.persistence.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author JhonPerez
 */
@Entity
@Table(name = "CRUCE_TRANSACCIONES")
@XmlRootElement
public class CruceTransacciones implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @SequenceGenerator(name="cruce_transacciones", sequenceName="SEQ_CRUCE_TRANSACCIONES", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE ,generator="cruce_transacciones")
    @Basic(optional = false)
    @Column(name = "ID_CRUCE")
    private Long idCruce;
    @Column(name = "NURA_APC")
    private String nuraApc;
    @Column(name = "CANTIDAD_APC")
    private Integer cantidadApc;
    @Column(name = "VALOR_APC")
    private Double valorApc;
    @Column(name = "FECHA_APC")
    private String fechaApc;
    @Column(name = "NURA_UNICO")
    private String nuraUnico;
    @Column(name = "CANTIDAD_UNICO")
    private Integer cantidadUnico;
    @Column(name = "VALOR_UNICO")
    private Double valorUnico;
    @Column(name = "FECHA_UNICO")
    private String fechaUnico;
    @Column(name = "FECHA")
    private String fecha;
    @Column(name = "OBSERVACIONES")
    private String observaciones;

    public CruceTransacciones() {
    }

    public CruceTransacciones(Long idCruce) {
        this.idCruce = idCruce;
    }

    public Long getIdCruce() {
        return idCruce;
    }

    public void setIdCruce(Long idCruce) {
        this.idCruce = idCruce;
    }

    public String getNuraApc() {
        return nuraApc;
    }

    public void setNuraApc(String nuraApc) {
        this.nuraApc = nuraApc;
    }

    public Integer getCantidadApc() {
        return cantidadApc;
    }

    public void setCantidadApc(Integer cantidadApc) {
        this.cantidadApc = cantidadApc;
    }

    public Double getValorApc() {
        return valorApc;
    }

    public void setValorApc(Double valorApc) {
        this.valorApc = valorApc;
    }

    public String getFechaApc() {
        return fechaApc;
    }

    public void setFechaApc(String fechaApc) {
        this.fechaApc = fechaApc;
    }

    public String getNuraUnico() {
        return nuraUnico;
    }

    public void setNuraUnico(String nuraUnico) {
        this.nuraUnico = nuraUnico;
    }

    public Integer getCantidadUnico() {
        return cantidadUnico;
    }

    public void setCantidadUnico(Integer cantidadUnico) {
        this.cantidadUnico = cantidadUnico;
    }

    public Double getValorUnico() {
        return valorUnico;
    }

    public void setValorUnico(Double valorUnico) {
        this.valorUnico = valorUnico;
    }

    public String getFechaUnico() {
        return fechaUnico;
    }

    public void setFechaUnico(String fechaUnico) {
        this.fechaUnico = fechaUnico;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getObservaciones() {
        return observaciones;
    }

    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idCruce != null ? idCruce.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CruceTransacciones)) {
            return false;
        }
        CruceTransacciones other = (CruceTransacciones) object;
        if ((this.idCruce == null && other.idCruce != null) || (this.idCruce != null && !this.idCruce.equals(other.idCruce))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "unicoconciliacion.CruceTransacciones[ idCruce=" + idCruce + " ]";
    }
    
}
