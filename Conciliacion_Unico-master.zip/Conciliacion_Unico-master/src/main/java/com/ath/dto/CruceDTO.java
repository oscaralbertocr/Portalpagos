package com.ath.dto;

public class CruceDTO {
	
	private String nuraApc;
	private String fechaApc;
	private Integer cantidadApc = 0;
	private Double valorApc = (double) 0;
	private String nuraUnico;
	private String fechaUnico;
	private Integer cantidadUnico = 0;
	private Double valorUnico = (double) 0;
	private String nura;
	
	
	public CruceDTO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public CruceDTO(String nuraApc, String fechaApc, Integer cantidadApc, Double valorApc, String nuraUnico,
			String fechaUnico, Integer cantidadUnico, Double valorUnico, String nura) {
		super();
		this.nuraApc = nuraApc;
		this.fechaApc = fechaApc;
		this.cantidadApc = cantidadApc;
		this.valorApc = valorApc;
		this.nuraUnico = nuraUnico;
		this.fechaUnico = fechaUnico;
		this.cantidadUnico = cantidadUnico;
		this.valorUnico = valorUnico;
		this.nura = nura;
	}


	public String getNuraApc() {
		return nuraApc;
	}


	public void setNuraApc(String nuraApc) {
		this.nuraApc = nuraApc;
	}


	public String getFechaApc() {
		return fechaApc;
	}


	public void setFechaApc(String fechaApc) {
		this.fechaApc = fechaApc;
	}


	public Integer getCantidadApc() {
		return cantidadApc;
	}


	public void setCantidadApc(Integer cantidadApc) {
		this.cantidadApc = cantidadApc;
	}


	public Double getValorApc() {
		return valorApc;
	}


	public void setValorApc(Double valorApc) {
		this.valorApc = valorApc;
	}


	public String getNuraUnico() {
		return nuraUnico;
	}


	public void setNuraUnico(String nuraUnico) {
		this.nuraUnico = nuraUnico;
	}


	public String getFechaUnico() {
		return fechaUnico;
	}


	public void setFechaUnico(String fechaUnico) {
		this.fechaUnico = fechaUnico;
	}


	public Integer getCantidadUnico() {
		return cantidadUnico;
	}


	public void setCantidadUnico(Integer cantidadUnico) {
		this.cantidadUnico = cantidadUnico;
	}


	public Double getValorUnico() {
		return valorUnico;
	}


	public void setValorUnico(Double valorUnico) {
		this.valorUnico = valorUnico;
	}


	public String getNura() {
		return nura;
	}


	public void setNura(String nura) {
		this.nura = nura;
	}
}
