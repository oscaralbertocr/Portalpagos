package com.ath.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ResponseLoginDTO {
	
	@JsonProperty("listaUsuario")
	private List<String> listaUsuario;
	@JsonProperty("token")
	private String token;
	
	
	public List<String> getListaUsuario() {
		
		if(listaUsuario == null) {
			listaUsuario = new ArrayList<String>();			
		}
		return listaUsuario;
	}
	public void setListaUsuario(List<String> listaUsuario) {
		this.listaUsuario = listaUsuario;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	
}
