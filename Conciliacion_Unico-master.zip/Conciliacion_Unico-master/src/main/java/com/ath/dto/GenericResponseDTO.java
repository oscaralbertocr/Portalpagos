package com.ath.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GenericResponseDTO {
	
	@JsonProperty("lista")
	private List<ResponseDTO> lista;
	@JsonProperty("cantidadIguales")
	private int cantidadIguales = 0;
	@JsonProperty("cantidadDiferentes")
	private int cantidadDiferentes = 0;
	


	public List<ResponseDTO> getLista() {
		if(lista == null) {
			lista = new ArrayList<ResponseDTO>();			
		}
		return lista;
	}


	public void setLista(List<ResponseDTO> lista) {
		this.lista = lista;
	}


	public int getCantidadIguales() {
		return cantidadIguales;
	}


	public void setCantidadIguales(int cantidadIguales) {
		this.cantidadIguales = cantidadIguales;
	}


	public int getCantidadDiferentes() {
		return cantidadDiferentes;
	}


	public void setCantidadDiferentes(int cantidadDiferentes) {
		this.cantidadDiferentes = cantidadDiferentes;
	}
	
	
}
