package com.ath.dto;

import org.apache.commons.lang3.StringUtils;

import com.ath.util.CheckUtil;

public class ResponseDTO {
	
	private Long idCruce;
	private String nuraApc;
	private String fechaApc;
	private String cantidadApc;
	private String valorApc ;
	private String nuraUnico;
	private String fechaUnico;
	private String cantidadUnico;
	private String valorUnico ;
	private String observaciones;	
	private String cantidad;
	private String valor;
	
	
	public ResponseDTO() {
		super();
		// TODO Auto-generated constructor stub
	}


	
	
	public ResponseDTO(Long idCruce, String nuraApc, String fechaApc, String cantidadApc, String valorApc,
			String nuraUnico, String fechaUnico, String cantidadUnico, String valorUnico, String observaciones,
			String cantidad, String valor) {
		super();
		this.idCruce = idCruce;
		this.nuraApc = nuraApc;
		this.fechaApc = fechaApc;
		this.cantidadApc = cantidadApc;
		this.valorApc = valorApc;
		this.nuraUnico = nuraUnico;
		this.fechaUnico = fechaUnico;
		this.cantidadUnico = cantidadUnico;
		this.valorUnico = valorUnico;
		this.observaciones = observaciones;
		this.cantidad = cantidad;
		this.valor = valor;
	}


    

	public ResponseDTO(long idCruce, String nuraApc, int cantidadApc,double valorApc, String fechaApc,
			String nuraUnico,int cantidadUnico, double valorUnico, String fechaUnico, String observaciones,
			int cantidad,double valor) {
		super();
		this.idCruce = idCruce;
		this.nuraApc = !StringUtils.isBlank(nuraApc) ? nuraApc : "";;
		this.cantidadApc = cantidadApc == 0 ? "0" : String.valueOf(cantidadApc) ;
		this.valorApc = valorApc != 0 ? CheckUtil.valorCompletoString(valorApc) :  "0";
		this.fechaApc = !StringUtils.isBlank(fechaApc) ? fechaApc : "";
		this.nuraUnico = !StringUtils.isBlank(nuraUnico) ? nuraUnico : "";
		this.cantidadUnico = cantidadUnico == 0 ? "0" :String.valueOf(cantidadUnico);
		this.valorUnico = valorUnico != 0 ?  CheckUtil.valorCompletoString(valorUnico) :  "0";
		this.fechaUnico = !StringUtils.isBlank(fechaUnico) ? fechaUnico : "";
		this.observaciones = !StringUtils.isBlank(observaciones) ? observaciones : "";
		this.cantidad = cantidad == 0 ? "0" : String.valueOf(cantidad);
		this.valor = valor == 0 ? "0" :  CheckUtil.valorCompletoString(valor);
		
	}



	public Long getIdCruce() {
		return idCruce;
	}


	public void setIdCruce(Long idCruce) {
		this.idCruce = idCruce;
	}


	public String getNuraApc() {
		return nuraApc;
	}


	public void setNuraApc(String nuraApc) {
		this.nuraApc = nuraApc;
	}


	public String getFechaApc() {
		return fechaApc;
	}


	public void setFechaApc(String fechaApc) {
		this.fechaApc = fechaApc;
	}


	public String getCantidadApc() {
		return cantidadApc;
	}


	public void setCantidadApc(String cantidadApc) {
		this.cantidadApc = cantidadApc;
	}


	public String getValorApc() {
		return valorApc;
	}


	public void setValorApc(String valorApc) {
		this.valorApc = valorApc;
	}


	public String getNuraUnico() {
		return nuraUnico;
	}


	public void setNuraUnico(String nuraUnico) {
		this.nuraUnico = nuraUnico;
	}


	public String getFechaUnico() {
		return fechaUnico;
	}


	public void setFechaUnico(String fechaUnico) {
		this.fechaUnico = fechaUnico;
	}


	public String getCantidadUnico() {
		return cantidadUnico;
	}


	public void setCantidadUnico(String cantidadUnico) {
		this.cantidadUnico = cantidadUnico;
	}


	public String getValorUnico() {
		return valorUnico;
	}


	public void setValorUnico(String valorUnico) {
		this.valorUnico = valorUnico;
	}


	public String getObservaciones() {
		return observaciones;
	}


	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}


	public String getCantidad() {
		return cantidad;
	}


	public void setCantidad(String cantidad) {
		this.cantidad = cantidad;
	}


	public String getValor() {
		return valor;
	}


	public void setValor(String valor) {
		this.valor = valor;
	}

	
	
}
