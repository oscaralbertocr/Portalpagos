package com.ath.dto;

public class UserDTO {
	
	private String username;
	private String userPass;
	
		
	
	public UserDTO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public UserDTO(String username, String userPass) {
		super();
		this.username = username;
		this.userPass = userPass;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getUserPass() {
		return userPass;
	}


	public void setUserPass(String userPass) {
		this.userPass = userPass;
	}

}
