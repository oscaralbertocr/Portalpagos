package com.ath.batch.tlf;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ath.dto.CruceDTO;
import com.ath.persistence.dao.CruceTransaccionesDAO;
import com.ath.persistence.model.CruceTransacciones;
import com.ath.util.CheckUtil;
import com.ath.util.DateUtil;
import com.ath.util.JSONUtil;

@Service
@StepScope
public class TlfTasklet implements Tasklet{
	static Logger logger = LoggerFactory.getLogger(TlfTasklet.class);
	
	private static Locale locale = new Locale("en","US");

	@Value(value = "${conciliator.unico.batch.tlf4.path}")
	private String filePath;
	@Value(value = "${conciliator.batch.tlf.file.inicio}")
	private String fileNameInicio;
	@Value(value = "${conciliator.batch.tlf4.file.fin}")
	private String fileNameFin;
	@Resource
	private CruceTransaccionesDAO cruceDAO;
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		FileReader fr = null;
		File fileTlf = null;
		BufferedReader br = null;
		String linea = "", nura = "", valor = "", fechaTlf= "";		
		try {			
			
			//Obreniendo fecha del dia anterior para leer el archivo tlf
			Calendar c = Calendar.getInstance();
			c.add(Calendar.DATE, -1);
			Date date = c.getTime();			
			String fechaArchivo = DateUtil.parseDate(date, "yyyyMMdd");					
			String finalNamefile = filePath + "/"+ fileNameInicio + fechaArchivo +  fileNameFin;
			logger.info("Ruta y archivo TLF a leer : " + finalNamefile);
			try{
				fileTlf = new File (finalNamefile);
				if(!fileTlf.exists()) {
					logger.info("No se encontro el archivo tlf4: " + finalNamefile);
				}
			}catch (Exception e) {
				logger.info("No se encontro el archivo tlf4: " + finalNamefile);
			}			
			
			//fr = new FileReader(filePath + "/"+ finalNamefile);
			fr = new FileReader(finalNamefile);
			br = new BufferedReader(fr);
			HashMap<String, CruceDTO> tlf = new HashMap<String,CruceDTO>();
			

			/*String ruta = filePath + "/"+"filename.txt";
            File file = new File(ruta);
            if (!file.exists()) {
                file.createNewFile();
            }            
            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);*/
			
			
			while ((linea = br.readLine()) != null) {
				if(linea.length() > 10) {
				//System.out.println(linea);
				valor = linea.substring(80, 93);
				nura = linea.substring(153, 161);
				fechaTlf = linea.substring(121,129);			
				
				
	            // Si el archivo no existe es creado           
	            //bw.write("123450429"+fechaTlf+""+nura+"000000000012345678"+linea.substring(80, 93)+"00"+fechaTlf);
	            //bw.newLine();
	            			
				//logger.info("nura: "+nura+"; valor: "+valor+"; fecha: "+fechaTlf);
				if(tlf.containsKey(nura)) {
					CruceDTO cruceAnterior = tlf.get(nura);
					Double valorNuevo = CheckUtil.convertirADoble(valor);
					cruceAnterior.setValorApc((double) Math.round((cruceAnterior.getValorApc() + valorNuevo) * 100)/100);
					cruceAnterior.setCantidadApc(cruceAnterior.getCantidadApc()+1);
					tlf.put(nura, cruceAnterior);
					
				}
				else {
					CruceDTO cruce = new CruceDTO();
					cruce.setFechaApc(fechaTlf);
					cruce.setNura(nura);
					cruce.setNuraApc(nura);
					cruce.setCantidadApc(cruce.getCantidadApc()+1);
					cruce.setValorApc((double) Math.round((CheckUtil.convertirADoble(valor)) * 100)/100);
					tlf.put(nura, cruce);
					
				}
				
				
				} else {
					logger.info("Encabezado");
					
				}
			}
			//bw.close();
			logger.info("Imprimiendo el mapa Tlf4: {} "+JSONUtil.marshal(tlf));
			
			
			for(CruceDTO cruze : tlf.values()) {				
				
				 CruceTransacciones cruceTranasaccion = null;	
				 boolean existeCruce = false;
				 cruceTranasaccion = cruceDAO.findCruceTransaccionesByNuraFecha(cruze.getNuraApc(), cruze.getFechaApc());
				 if(cruceTranasaccion != null) {					 
					 existeCruce = true;					 
				 } else {					 
					 cruceTranasaccion =  new CruceTransacciones();						 
				 }				 
				 cruceTranasaccion.setNuraApc(cruze.getNuraApc());
				 cruceTranasaccion.setFechaApc(cruze.getFechaApc());
				 cruceTranasaccion.setCantidadApc(cruceTranasaccion.getCantidadApc() != null ?  cruceTranasaccion.getCantidadApc()+ cruze.getCantidadApc() : cruze.getCantidadApc());
				 cruceTranasaccion.setValorApc(cruceTranasaccion.getValorApc() !=null ? cruceTranasaccion.getValorApc() + cruze.getValorApc() : cruze.getValorApc());
				 cruceTranasaccion.setFecha(cruze.getFechaApc());
				 if(cruceTranasaccion.getCantidadUnico() == null) {
					 cruceTranasaccion.setCantidadUnico(cruze.getCantidadUnico());
				 }					 
				 if(cruceTranasaccion.getValorUnico() == null) {
					 cruceTranasaccion.setValorUnico(cruze.getValorUnico());
				 }
				 
				 if(!existeCruce) {
					 cruceDAO.save(cruceTranasaccion);
					 logger.info("Creando cruce Tlf: {} "+JSONUtil.marshal(cruceTranasaccion));
				 } else {
					 cruceDAO.save(cruceTranasaccion);
					 logger.info("Actualizando cruce Tlf: {} "+JSONUtil.marshal(cruceTranasaccion));
				 }
				  
				  
				
			}
			
			
		}catch (Exception e) {
			 logger.error("Exception TlfTasklet:  "+e);
		}
		
		
		
		
		
		logger.info("TLF_Tasklet Fin");
		return RepeatStatus.FINISHED;
		
	}

}
