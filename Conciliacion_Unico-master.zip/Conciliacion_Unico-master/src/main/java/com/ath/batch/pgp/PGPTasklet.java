package com.ath.batch.pgp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ath.dto.CruceDTO;
import com.ath.persistence.dao.CruceTransaccionesDAO;
import com.ath.persistence.model.CruceTransacciones;
import com.ath.util.CheckUtil;
import com.ath.util.DateUtil;
import com.ath.util.JSONUtil;
import com.ath.util.PGPFileProcessor;

@Service
@StepScope
public class PGPTasklet implements Tasklet{
	static Logger logger = LoggerFactory.getLogger(PGPTasklet.class);
	
	private static Locale locale = new Locale("en","US");
	
	
	
	@Value(value = "${conciliator.unico.llave.unico.path}")
	private String privKeyUnico;	
	@Value(value = "${conciliator.unico.batch.unico.path}")
	private String filePathUnico;
	@Value(value = "${conciliator.batch.unico.file}")
	private String fileNameUnico;
	@Value(value = "${conciliator.unico.llave.unico.pass}")
	private String keyPass;
	@Value(value = "${conciliator.unico.llave.unico.extension}")
	private String extension;
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
			
		try {		
			
			
			//Obreniendo fecha del dia anterior para leer el archivo unico
			Calendar c = Calendar.getInstance();
			c.add(Calendar.DATE, -1);
			Date date = c.getTime();			
			String fechaArchivo = DateUtil.parseDate(date, "yyyyMMdd");	
			
			
		
			
			
	

			
	        //Desencriptar archivo unico
		    PGPFileProcessor pUnico = new PGPFileProcessor();
		    try {
		    	pUnico.setKeyFile(privKeyUnico);
		    	pUnico.setPassphrase(keyPass);
		    	String inputNamefileUnico = filePathUnico + "/"+ fileNameUnico +fechaArchivo +".txt"+extension;
		    	logger.info("Archivo a desencriptar Unico-->" + inputNamefileUnico);
		    	pUnico.setInputFile(inputNamefileUnico);
		    	String outputNamefileUnico = filePathUnico + "/"+ fileNameUnico +fechaArchivo +".txt";
		    	pUnico.setOutputFile(outputNamefileUnico);
		    	pUnico.decrypt();
                logger.info("El archivo unico se desencripto-->"
                    + outputNamefileUnico);
            
		    }catch (Exception e) {
				 logger.error("Exception decrypt Unico:  "+e);
				 
			} 
			
		    

			
			
			
		}catch (Exception e) {
			 logger.error("Exception PgpTasklet:  "+e);
		}
		
		
		
		
		
		logger.info("PGP_Tasklet Fin");
		return RepeatStatus.FINISHED;
		
	}

}
