package com.ath.batch.unico;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;

import javax.annotation.Resource;

import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ath.dto.CruceDTO;
import com.ath.persistence.dao.CruceTransaccionesDAO;
import com.ath.persistence.model.CruceTransacciones;
import com.ath.util.CheckUtil;
import com.ath.util.DateUtil;
import com.ath.util.JSONUtil;

@Service
@StepScope
public class UnicoTasklet implements Tasklet{
	static Logger logger = LoggerFactory.getLogger(UnicoTasklet.class);
	
	public static final String SEPARADOR = ";";
	
	private static Locale locale = new Locale("en","US");

	@Value(value = "${conciliator.unico.batch.unico.path}")
	private String filePath;
	@Value(value = "${conciliator.batch.unico.file}")
	private String fileName;
	@Resource
	private CruceTransaccionesDAO cruceDAO;
	@Override
	public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
		
		FileReader fr = null;
		File fileUnico = null;
		BufferedReader br = null;
		String linea = "", nura = "", valor = "", fechaUnico= "";		
		try {			
			
			//Obreniendo fecha del dia anterior para leer el archivo unico
			Calendar c = Calendar.getInstance();
			c.add(Calendar.DATE, -1);
			Date date = c.getTime();			
			String fechaArchivo = DateUtil.parseDate(date, "yyyyMMdd");	
			String finalNamefile = filePath + "/"+ fileName +fechaArchivo +".txt";
			logger.info("Ruta y archivo Unico a leer: " + finalNamefile);		
			try{
				fileUnico = new File (finalNamefile);
				if(!fileUnico.exists()) {
					logger.info("No se encontro el archivo unico: " + finalNamefile);
				}
			}catch (Exception e) {
				logger.info("No se encontro el archivo unico: " + finalNamefile);
			}		
			
			fr = new FileReader(finalNamefile);
			br = new BufferedReader(fr);
			HashMap<String, CruceDTO> unico = new HashMap<String,CruceDTO>();
			while ((linea = br.readLine()) != null) {
				
				//Para archivo separado por punto y coma
				/*String[] campos = linea.split(SEPARADOR); 
				
				logger.info("nura: " + campos[3] + "; fecha: "+campos[2]+ "; valor: "+campos[5]);
				
				
				valor = campos[5].substring(0, 12) + "." + campos[5].substring(12, 14);
				nura = campos[3];
				fechaUnico = campos[2];*/
				
				//Para archivo plano 
				valor = linea.substring(43, 56) + "." + linea.substring(56, 58);
				nura = linea.substring(17, 25);
				fechaUnico = linea.substring(58,66);
				
				//logger.info("nura: "+nura+"; valor: "+valor+"; fecha: "+fechaUnico);
				if(unico.containsKey(nura)) {
					CruceDTO cruceAnterior = unico.get(nura);
					Double valorNuevo = CheckUtil.convertirADoble(valor);
					cruceAnterior.setValorUnico((double) Math.round((cruceAnterior.getValorUnico() + valorNuevo) * 100)/100);
					cruceAnterior.setCantidadUnico(cruceAnterior.getCantidadUnico()+1);
					unico.put(nura, cruceAnterior);
					
				}
				else {
					CruceDTO cruce = new CruceDTO();
					cruce.setFechaUnico(fechaUnico);
					cruce.setNura(nura);
					cruce.setNuraUnico(nura);
					cruce.setCantidadUnico(cruce.getCantidadUnico()+1);
					cruce.setValorUnico((double) Math.round((CheckUtil.convertirADoble(valor)) * 100)/100);
					unico.put(nura, cruce);
					
				}
				
				
				
			}
			
			logger.info("Imprimiendo el mapa unico: {} "+JSONUtil.marshal(unico));
			
			
			for(CruceDTO cruze : unico.values()) {				
				
				 CruceTransacciones cruceTranasaccion = null;	
				 boolean existeCruce = false;
				 cruceTranasaccion = cruceDAO.findCruceTransaccionesByNuraFecha(cruze.getNuraUnico(), cruze.getFechaUnico());
				 if(cruceTranasaccion != null) {					 
					 existeCruce = true;					 
				 } else {					 
					 cruceTranasaccion =  new CruceTransacciones();						 
				 }				 
				 cruceTranasaccion.setNuraUnico(cruze.getNuraUnico());
				 cruceTranasaccion.setFechaUnico(cruze.getFechaUnico());
				 cruceTranasaccion.setCantidadUnico(cruze.getCantidadUnico());
				 cruceTranasaccion.setValorUnico(cruze.getValorUnico());
				 cruceTranasaccion.setFecha(cruze.getFechaUnico());
				 if(cruceTranasaccion.getCantidadApc() == null) {
					 cruceTranasaccion.setCantidadApc(cruze.getCantidadApc());
				 }					 
				 if(cruceTranasaccion.getValorApc() == null) {
					 cruceTranasaccion.setValorApc(cruze.getValorApc());
				 }
				 
				 
				 if(!existeCruce) {
					 cruceDAO.save(cruceTranasaccion);
					 logger.info("Creando unico: {} "+JSONUtil.marshal(cruceTranasaccion));
				 } else {
					 cruceDAO.save(cruceTranasaccion);
					 logger.info("Actualizando unico: {} "+JSONUtil.marshal(cruceTranasaccion));
				 }
				  
				  
				
			}
			
			
		}catch (Exception e) {
			logger.error("Exception UnicoTasklet:  "+e);			
		}
		
		logger.info("Unico_Tasklet Fin");
		return RepeatStatus.FINISHED;
		
	}

}
