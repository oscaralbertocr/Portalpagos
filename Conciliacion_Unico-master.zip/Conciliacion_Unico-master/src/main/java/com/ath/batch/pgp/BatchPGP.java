package com.ath.batch.pgp;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;



@Service
public class BatchPGP {
	static Logger logger = LoggerFactory.getLogger(BatchPGP.class);
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;
	
	@Autowired
	private JobLauncher jobLauncher;
	
	@Resource
	private PGPTasklet pgpTasklet;
	
	private Job jobInstance;
	
	private static final String JOB_NAME  = "JOB_PGP_C3";
	private static final String STEP_NAME = "STEP_PGP_C3";
	private final String TASKLET_PGP = "TASKLET_PGP";
	
	@PostConstruct
	public void init() {
		// Se crea la instancia del job al cargar el contexto
		jobInstance = createJob();
	}

	@Scheduled(cron="${conciliator.conciliacion.unico.batch.pgp.cron}")	
	public void run() {
		
		logger.info("*** Inicia ejecucion del job: {}" , JOB_NAME);
		
		JobParametersBuilder jobParams = new JobParametersBuilder();
		jobParams.addLong("time", System.currentTimeMillis());
		
		JobExecution jobExecution = null;
		try {
			jobExecution = jobLauncher.run(jobInstance, jobParams.toJobParameters());
		} catch (JobExecutionAlreadyRunningException |JobRestartException | JobInstanceAlreadyCompleteException |JobParametersInvalidException e) {
			logger.error(" Error en el Job {}. {}", JOB_NAME, e);
		}  catch (Exception e) {
			logger.error(" Error iniciando  batch pgp. {}", e);
		}		
		
	}
	
	@Bean
	public Job createJob() {
		return jobBuilderFactory.get(JOB_NAME)
				.flow(decryptFilePgp())
				.end()
				.build();
	}
	
	@Bean
	public Step decryptFilePgp() {
		return this.stepBuilderFactory.get(this.TASKLET_PGP)
				.tasklet(this.pgpTasklet)
				.build();
	}
	
	
}