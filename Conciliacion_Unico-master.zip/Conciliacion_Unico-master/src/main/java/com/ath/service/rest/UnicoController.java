package com.ath.service.rest;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.util.StringUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ath.dto.GenericResponseDTO;
import com.ath.dto.ResponseDTO;
import com.ath.dto.ResponseLoginDTO;
import com.ath.dto.UserDTO;
import com.ath.persistence.dao.CruceTransaccionesDAO;
import com.ath.persistence.model.CruceTransacciones;
import com.ath.service.impl.UnicoImplement;
import com.ath.util.JSONUtil;
import com.ath.util.ResponseBuilder;




@RestController
@RequestMapping(value ="/tlf-c3" , produces = MediaType.APPLICATION_JSON_VALUE)
@CrossOrigin(origins = "*", methods = {RequestMethod.DELETE, RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT})
public class UnicoController {
	static Logger logger = LoggerFactory.getLogger(UnicoController.class);

	@Autowired
	CruceTransaccionesDAO cruceDao;
	
	@Autowired
	UnicoImplement unicoImp;
	
	
	@PostMapping("/search/date")
	public ResponseEntity searchDate(@RequestBody String fecha) {
		//logger.info("Entrando al servicio de login conciliacion");
		ResponseBuilder response = ResponseBuilder.newBuilder();
		GenericResponseDTO genericResponse =  new GenericResponseDTO();
		try {			
			
			List<ResponseDTO> cruces = cruceDao.findCruceTransaccionesByFecha(fecha);
			genericResponse.setCantidadDiferentes(cruceDao.cantidadesDiferentes(fecha));
			genericResponse.setCantidadIguales(cruceDao.cantidadesIguales(fecha));
			genericResponse.setLista(cruces);
			logger.info("UnicoController respuesta: {} "+ JSONUtil.marshal(cruces));
			if(cruces.size() >= 0) {
				response.withStatus(HttpStatus.OK)
				.withBusinessStatus(String.valueOf(HttpStatus.OK.value()))
				.withResponse(genericResponse);
				//logger.info("Se encontro al usuario");
				
			}	else {
				response.withStatus(HttpStatus.BAD_REQUEST)
				.withBusinessStatus(String.valueOf(HttpStatus.BAD_REQUEST.value()))
				.withResponse(genericResponse);		
				//logger.info("Usuario no existee");
				
			}
			
			
			
		} catch (Exception e) {
			logger.error("UnicoController Exception: {} "+ e);
			response.withStatus(HttpStatus.BAD_REQUEST)
			.withBusinessStatus("1000")
			.withResponse(e.getMessage());	
		}
		
		finally {
			return response.withPath("")
					.buildResponse();
		}
	}
	
	
	@PostMapping("/update/record")
	public ResponseEntity updateRecord(@RequestBody ResponseDTO data) {
		//logger.info("Entrando al servicio de login conciliacion");
		ResponseBuilder response = ResponseBuilder.newBuilder();
		List<ResponseDTO> cruces = new ArrayList<>();
		GenericResponseDTO genericResponde = new GenericResponseDTO();
		try {			
			
			CruceTransacciones curuce =  cruceDao.findOne(data.getIdCruce());			
			if(curuce != null) {
				logger.info("Se encuentra registro cruce por id: "+ data.getIdCruce());
				curuce.setObservaciones(data.getObservaciones());
				cruceDao.save(curuce);
				logger.info("Se actualiza registro con observacion: "+ JSONUtil.marshal(curuce));
			} else {
				logger.info("No se  actualizo registro con id: "+ data.getIdCruce());
			}
			
			cruces = cruceDao.findCruceTransaccionesByFecha(!StringUtils.isBlank(data.getFechaApc()) ? data.getFechaApc() : data.getFechaUnico());
			if(curuce != null) {
				response.withStatus(HttpStatus.OK)
				.withBusinessStatus(String.valueOf(HttpStatus.OK.value()))
				.withResponse(cruces);
				//logger.info("Se encontro al usuario");
				
			}	else {
				response.withStatus(HttpStatus.BAD_REQUEST)
				.withBusinessStatus(String.valueOf(HttpStatus.BAD_REQUEST.value()))
				.withResponse(cruces);		
				//logger.info("Usuario no existee");
				
			}
			
			
			
		} catch (Exception e) {
			logger.error("UnicoController Exception: {} "+ e);
			response.withStatus(HttpStatus.INTERNAL_SERVER_ERROR)
			.withBusinessStatus(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()))
			.withResponse(cruces);	
		}
		
		finally {
			return response.withPath("")
					.buildResponse();
		}
	}
	
	@PostMapping("/unico/login")
	public ResponseEntity login(@RequestBody UserDTO data) {		
		logger.info("Entrando al servicio de login conciliacion unico");
		ResponseBuilder response = ResponseBuilder.newBuilder();
		List<String> lista = new LinkedList<String>();
		ResponseLoginDTO responseLogin = new ResponseLoginDTO();
		String token = null;
		String token2 = null;
		
		try {	
			
			
			 lista = unicoImp.loginUser(data.getUsername(), data.getUserPass());
			 logger.info("Imprimiendo lista de sesion ldap: "+ JSONUtil.marshal(lista));			
			
			if(lista != null && lista.size()>0) {
				token = unicoImp.GenerateToken(data.getUsername(), data.getUserPass());
				responseLogin.setToken(token);
				responseLogin.setListaUsuario(lista);
				response.withStatus(HttpStatus.OK)
				.withBusinessStatus(String.valueOf(HttpStatus.OK.value()))
				.withResponse(responseLogin);
				//logger.info("Se encontro al usuario");
				
			}	else {
				response.withStatus(HttpStatus.BAD_REQUEST)
				.withBusinessStatus(String.valueOf(HttpStatus.BAD_REQUEST.value()))
				.withResponse(responseLogin);		
				//logger.info("Usuario no existee");
				
			}			
			
		} catch (Exception e) {
			logger.error("UnicoController Exception: {} "+ e);
			response.withStatus(HttpStatus.INTERNAL_SERVER_ERROR)
			.withBusinessStatus(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()))
			.withResponse(responseLogin);	
		}
		
		finally {
			return response.withPath("")
					.buildResponse();
		}
	}
}
