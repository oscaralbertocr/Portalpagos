package com.ath.service.impl;


import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;

import javax.crypto.SecretKey;
import javax.naming.Context;
import javax.naming.NameNotFoundException;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.JwtBuilder;	
import io.jsonwebtoken.Jwts;	
import io.jsonwebtoken.SignatureAlgorithm;	
import io.jsonwebtoken.security.Keys;

import com.ath.util.JSONUtil;
@Service
public class UnicoImplement {

	static Logger logger = LoggerFactory.getLogger(UnicoImplement.class);
	
	@Autowired
	private Environment environm;

	
	
	public List<String> loginUser(final String username,final String usernamePass){
		
		logger.info("Entrando inplement login ");
		List<String> lista = new LinkedList<String>();
		LdapContext ctx = null;
	     Hashtable<String, String> env = new Hashtable<String, String>();	     
	        
	     
	        env.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.ldap.LdapCtxFactory");
	        env.put(Context.SECURITY_AUTHENTICATION, "simple");
	        env.put(Context.SECURITY_PRINCIPAL, "ATH\\"+username);//esto te lo dice el administrados de LDAP
	        env.put(Context.SECURITY_CREDENTIALS, usernamePass);
	        env.put(Context.PROVIDER_URL, environm.getProperty("ldap.url"));//esto tambien te lo da el administrados del LDAP
	       
	       
	      
	        
	        
	        try {
	           //logger.info("env:  "+JSONUtil.marshal(env));
	           logger.info("try");
	     	   ctx = new InitialLdapContext(env, null);	    
	     	   logger.info("----- 1 -------- ");
	     	   SearchControls searchControls = new SearchControls();
	     	   searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
	     	   logger.info("Entrando inplement login");
	     	   //String searchFilter =  "(&(objectClass=user)(sAMAccountName=mmacias))"; 
	     	   String searchFilter =  "(&(objectClass=user)(sAMAccountName="+username+"))"; 
	     	   //logger.info("searchFilter : "+searchFilter);
	     	   String ldapSearchBase = environm.getProperty("ldap.base.dn");
	     	   //logger.info("ldapSearchBase : "+ldapSearchBase);
	     	   NamingEnumeration<SearchResult> results = ctx.search(ldapSearchBase, searchFilter, searchControls);
	     	   
	     	   
	     	    SearchResult searchResult = null;
	     	    while(results.hasMoreElements()) {
	     	    	//logger.info("HEREEEEEEEEEEEEEEEEEEEEEE ");
	     	                searchResult = (SearchResult) results.nextElement();
	     	                NamingEnumeration<String> var = searchResult.getAttributes().getIDs();
	     	                //Mi ajuste
	     	                Attributes attributes = searchResult.getAttributes();
	    	                Attribute attr = attributes.get("cn");
	    	                String cn = attr.get().toString();
	    	                lista.add(cn);
	    	                //Hasta aqui	     	                
	     	                String prop; 
	     	                while(var.hasMoreElements()){
	     	                 prop=var.next();
	     	                //logger.info("VAR: "+prop+" %"+searchResult.getAttributes().get(prop).get());
	     	                  
	     	                 }     	              
	     	    }
	     	    
	     	   logger.info("Salida de los usuarios encontrados:  "+JSONUtil.marshal(lista));
	     	         	   
	     	   
	     	  } catch (NamingException e) {
	     	   // TODO Auto-generated catch block
	     		 logger.error("NamingException : "+e);
	     		 //lista = loginUserOptionA(username, usernamePass);
	     	  }
		
		return lista;
	}
	
	
	public String GenerateToken(final String username, final String userPass) { 	
		try{		
					
			SignatureAlgorithm signatureAlgorithm = SignatureAlgorithm.HS512;			
			String signatureString = signatureAlgorithm.toString();			
						
			HashMap<String, Object> header = new HashMap<String,Object>();			
			header.put("alg", signatureString);			
			header.put("typ","JWT");			
				
			JwtBuilder tokenJWT = Jwts			
			.builder()			
			.setHeader(header)			
			.setId(userPass)			
			.setSubject(username)			
			.claim("name", username)			
			.claim("scope", "athLdap")			
					
			.setIssuedAt(new Date(System.currentTimeMillis()))			
					
			.setExpiration(new Date(System.currentTimeMillis() + 600000));			
					
			String tokenJWTString = tokenJWT.compact();			
			//logger.info(tokenJWTString);						
			//Response to Request from Controller			
			return tokenJWTString;	
			
			}catch (Exception e) { 			
				
				return "Error creating the token JWT";			
			}		
		
	}
	
	
	
	public List<String> getAllPersonNames() {
    	String urlCompleta = "ldap://192.168.14.182:389"+"/"+environm.getProperty("ldap.base.dn");
    	logger.info("getAllPersonNames urlCompleta: {}"+ urlCompleta);
        Hashtable env = new Hashtable();
        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, urlCompleta);
        //env.put(Context.SECURITY_PROTOCOL, "ssl");
        //ultima opcion

        DirContext ctx = null;
        try {
           ctx = new InitialDirContext(env);
        } catch (NamingException e) {
           //throw new RuntimeException(e);
        	logger.info(" NamingException getAllPersonNames: {}"+ e);
        }

        List<String> list = new LinkedList<String>();
        NamingEnumeration results = null;
        try {
           SearchControls controls = new SearchControls();
           controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
           results = ctx.search("", "(objectclass=person)", controls);

           while (results.hasMore()) {
              SearchResult searchResult = (SearchResult) results.next();
              Attributes attributes = searchResult.getAttributes();
              Attribute attr = attributes.get("cn");
              String cn = attr.get().toString();
              list.add(cn);
           }
        } catch (NameNotFoundException e) {
           // The base context was not found.
           // Just clean up and exit.
        	logger.info(" NameNotFoundException getAllPersonNames: {}"+ e);
        } catch (NamingException e) {
           //throw new RuntimeException(e);
        	logger.info(" NamingException V2 getAllPersonNames: {}"+ e);
        } finally {
           if (results != null) {
              try {
                 results.close();
              } catch (Exception e) {
                 // Never mind this.
            	  logger.info(" Exception getAllPersonNames: {}"+ e);
              }
           }
           if (ctx != null) {
              try {
                 ctx.close();
              } catch (Exception e) {
                 // Never mind this.
              }
           }
        }
        return list;
     }	
	
	
}
