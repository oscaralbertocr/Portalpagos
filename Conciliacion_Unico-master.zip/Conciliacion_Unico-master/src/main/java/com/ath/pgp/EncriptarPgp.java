package com.ath.pgp;



import com.ath.util.PGPFileProcessor;


/**
 *
 * @author javier.mantillap
 */
public class EncriptarPgp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        PGPFileProcessor p = new PGPFileProcessor();
        try {
           /* p.setKeyFile("D:\\pgp\\certificado-llave\\CertificadoPublico.asc");
            p.setInputFile("D:\\pgp\\texto-prueba.txt");
            p.setOutputFile("D:\\pgp\\salida\\final.txt.gpg");
            p.encrypt();
            System.out.println("El archivo se encripto-->"
                    + "D:\\pgp\\salida\\final.txt.gpg");*/
        } catch (Exception e) {
        }

    }

}
