package com.ath.pgp;



import com.ath.util.PGPFileProcessor;

/**
 *
 * @author javier.mantillap
 */
public class DesencriptarPgp {

    public static void main(String[] args) {
        try {
            /*PGPFileProcessor p = new PGPFileProcessor();
            p.setKeyFile("D:\\pgp\\llavePrivada.gpg");
            p.setPassphrase("123456");
            p.setInputFile("D:\\pgp\\salida\\final.txt.gpg");
            p.setOutputFile("D:\\pgp\\salida\\salida.txt");
            p.decrypt();
            System.out.println("El archivo se desencripto-->"
                    + "D:\\pgp\\salida\\salida.txt");*/
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
