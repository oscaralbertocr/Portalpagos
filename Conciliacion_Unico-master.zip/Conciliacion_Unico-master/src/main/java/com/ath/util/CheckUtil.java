package com.ath.util;

import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class CheckUtil {
	
	static Logger logger = LoggerFactory.getLogger(CheckUtil.class);
	private static Locale locale = new Locale("en","US");

	public static String checkNullString(final String input) {
		return input == null ? "" : input;
	}

	public static Long checkNullLong(final Object input) {
		return input == null ? 0L : Long.parseLong(input.toString());
	}
	
	public static String checkNullDate(final Date input) {
		return input == null ? "" : DateUtil.getDateToString(input);
	}

	public static  String checkNullLongToString(final Long input){
		return input == null ? "" : Long.toString(input);
		
	}
	
	public static  String checkTransFormUTF8(final String input){
		if(input == null) {
			return "";
		}		
		try {
			byte[] ptext = input.getBytes("ISO-8859-1"); 
			String value = new String(ptext, "UTF-8");
			return value;	
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "";
		} 
			
	}
	
public static String valorCompletoString(final Double valorSolicitud) {
    	
    	String valorString = null;
    	if(valorSolicitud != null && valorSolicitud != 0) {
    	double d = valorSolicitud.doubleValue();
    	
    	//DecimalFormat formato1 = new DecimalFormat("#.00");
    	DecimalFormat formato1 = new DecimalFormat("###,###.##");
		valorString = formato1.format(d);
		if(!valorString.contains(",")) {
			valorString = valorString +",00";
		}
    	} else {
    		valorString = "0";
    	}
		
    	return valorString;
	}


public static Double convertirADoble(final String valor) {
	
	Double valorNuevo = (double) 0;
	try {
		if(!StringUtils.isBlank(valor)) {
			valorNuevo =  new Double(valor);
		} 
		
	} catch (Exception e) {
		logger.error("Error en convertirADoble: " + e);
		valorNuevo = (double) 0;
	}
	
	
	return valorNuevo;
}
	
}
