package com.ath.enums;

public enum TransactionState {
	OK,
	FAIL,

}
