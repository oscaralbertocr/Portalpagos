package com.ath.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * Configuracion persistencia para el api
 * @author SophosSolutions
 * @version 1.0
 */
@Configuration
@ComponentScan(basePackages = {"com.ath.persistence.dao",
		"com.ath.persistence.model"})
public class PersistenceConfig {


}
