package com.ath.config;

import java.util.HashMap;

import javax.naming.NamingException;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.explore.support.JobExplorerFactoryBean;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.batch.support.DatabaseType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jndi.JndiTemplate;
//import org.springframework.ldap.core.LdapTemplate;
//import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.PlatformTransactionManager;



@Configuration
@EnableScheduling
@EnableBatchProcessing
@PropertySource({ "file:D:/pgw-core-config/conciliacion-unico.properties" })
@EnableJpaRepositories(
	basePackages = "com.ath.persistence", 
	entityManagerFactoryRef = "prvEntityManager", 
	transactionManagerRef = "prvTransactionManager")
public class DataSourceConfig  implements BatchConfigurer{
	
	static Logger logger = LoggerFactory.getLogger(DataSourceConfig.class);

	@Autowired
	private Environment env;

	/**
	 * obtencion de entityManager.
	 * @return LocalContainerEntityManagerFactoryBean
	 */	
	@Bean
	public LocalContainerEntityManagerFactoryBean prvEntityManager() {
		LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
		try {
			em.setDataSource(prvDataSource());
		/*} catch (NamingException e) {
			e.printStackTrace();
		}*/
		em.setPackagesToScan(new String[] { "com.ath.persistence.model" });

		HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
		em.setJpaVendorAdapter(vendorAdapter);
		HashMap<String, Object> properties = new HashMap<>();
		logger.info("----------------- auto -----------------------: "+ env.getProperty("spring.jpa.hibernate.ddl-auto"));
		properties.put("hibernate.hbm2ddl.auto", env.getProperty("spring.jpa.hibernate.ddl-auto"));
		logger.info("------------------------ dialect ---------------------------: "+ env.getProperty("spring.jpa.properties.hibernate.dialect"));
		properties.put("hibernate.dialect", env.getProperty("spring.jpa.properties.hibernate.dialect"));
		properties.put("hibernate.connection.release_mode", "after_transaction");
		em.setJpaPropertyMap(properties);
		} catch (NamingException e) {
			e.printStackTrace();
			logger.error("prvEntityManager NamingException "+ e.toString());
		}

		return em;
	}


	/**
	 * obtencion de Datasource.
	 * @return DataSource
	 */	
	@Bean (destroyMethod = "")
	public DataSource prvDataSource() throws NamingException {
		DataSource dataSource = null;
		try{
		logger.info("-------------------- url ---------------------: "+ env.getProperty("jdbc.url"));
		dataSource = (DataSource) new JndiTemplate().lookup(env.getProperty("jdbc.url"));
		logger.info("---------- CONEXION CORRECTA");
		} catch (Exception e) {
		logger.error("------------------- prvDataSource Exception ------------------------"+ e.toString());
		}
		return dataSource;

	}

	
	/**
	 * persistencia del datasource.
	 * @return PlatformTransactionManager
	 */	
	@Bean
	public PlatformTransactionManager prvTransactionManager() {

		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(prvEntityManager().getObject());
		return transactionManager;
	}

	@Override
	public JobExplorer getJobExplorer() throws Exception {
		JobExplorerFactoryBean factory = new JobExplorerFactoryBean();
		factory.setDataSource(prvDataSource());
		factory.afterPropertiesSet();
		return factory.getObject();
	}

	@Override
	public JobLauncher getJobLauncher() throws Exception {
		SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
		jobLauncher.setJobRepository(getJobRepository());
		jobLauncher.setTaskExecutor(new SimpleAsyncTaskExecutor());
		jobLauncher.afterPropertiesSet();
		return jobLauncher;
	}

	@Override
	public JobRepository getJobRepository() throws Exception {
		JobRepositoryFactoryBean factory = new JobRepositoryFactoryBean();
		factory.setDataSource(prvDataSource());
		factory.setIsolationLevelForCreate("ISOLATION_DEFAULT");
		factory.setTransactionManager(getTransactionManager());
		factory.setDatabaseType(DatabaseType.ORACLE.toString());
		factory.setTablePrefix("BATCH_");
		factory.afterPropertiesSet();
		return factory.getObject();
	}

	@Override
	public PlatformTransactionManager getTransactionManager() throws Exception {
		JpaTransactionManager transactionManager = new JpaTransactionManager();
		transactionManager.setEntityManagerFactory(prvEntityManager().getObject());
		return transactionManager;
	}
	
	
}
