package com.portalpagos.comprobantepago.util;

import javax.faces.application.ConfigurableNavigationHandler;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;
import javax.naming.NamingException;
import javax.portlet.PortletRequest;
import javax.portlet.PortletSession;
import javax.servlet.http.HttpServletRequest;

import co.com.ath.logger.CustomLogger;
import com.ibm.faces20.portlet.httpbridge.PortletRequestWrapper;
import com.ibm.portal.portlet.service.PortletServiceUnavailableException;
import com.ibm.portal.um.User;
import com.ibm.portal.um.exceptions.PumaException;

public class ValidateSession implements PhaseListener {

	private static final long serialVersionUID = 1L;

	private static CustomLogger log = new CustomLogger(ValidateSession.class);

	public PhaseId getPhaseId() {
		return PhaseId.APPLY_REQUEST_VALUES;
	}

	/**
	 * HU 53.3.1 Metodo encargado de realizar la validacion de si la sesion es valida.
	 * 
	 * @author melany.rozo
	 * */
	public void beforePhase(PhaseEvent event) {

		FacesContext context = FacesContext.getCurrentInstance();
		ExternalContext ec = context.getExternalContext();

		PortletRequestWrapper requestWrapper = (PortletRequestWrapper) ec.getRequest();
		PortletRequest request = (PortletRequest) requestWrapper.getPortletRequest();
		PortletSession sesion = request.getPortletSession();

		try {
			Puma puma = new Puma();
			User user = puma.getCurrenUser(request);
			if (user != null) {
				String uid = puma.getPropertyFromPuma("uid", request);
				// Se obtiene el id de sesion del usuario actual
				String sessionActual = sesion.getId();
				// Se obtiene el id de la sesion activa, almacenado en el TDS
				String sessionActiva = puma.getSessionIDUsuario(uid, request);
				// Se valida que los dos id sean iguales
				if (null != sessionActual && null != sessionActiva && !sessionActual.equals(sessionActiva)) {
					HttpServletRequest httpRequest = (HttpServletRequest) context.getExternalContext().getRequest();
					String facesRequestHeader = httpRequest.getHeader("Faces-Request");
					boolean isAjaxRequest = facesRequestHeader != null && facesRequestHeader.equals("partial/ajax");
					context.responseComplete();
					// Envia a pagina alterna para cerrar sesion, cuando es peticion ajax
					if (isAjaxRequest) {
						ConfigurableNavigationHandler handler = (ConfigurableNavigationHandler) context.getApplication()
								.getNavigationHandler();
						handler.performNavigation("logout");
					}
				}
			}
		} catch (PortletServiceUnavailableException e1) {
			log.info("Error PortletServiceUnavailableException" + e1.getMessage() + " - " + e1.getCause());
		} catch (NamingException e1) {
			log.info("Error NamingException" + e1.getMessage() + " - " + e1.getCause());
		} catch (PumaException e1) {
			log.info("Error PumaException" + e1.getMessage() + " - " + e1.getCause());
		} catch (Exception e1) {
			log.info("Error Exception" + e1.getMessage() + " - " + e1.getCause());
		}
	}

	public void afterPhase(PhaseEvent event) {

	}

}