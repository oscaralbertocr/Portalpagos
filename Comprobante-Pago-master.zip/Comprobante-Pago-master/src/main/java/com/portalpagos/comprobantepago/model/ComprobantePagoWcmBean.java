package com.portalpagos.comprobantepago.model;

import java.io.Serializable;

public class ComprobantePagoWcmBean implements Serializable {

	private static final long serialVersionUID = 2L;
	private String nombres_Apellidos_Wcm;
	private String nombreConvenio_Wcm;
	private String nit_Wcm;
	private String fechaTransaccion_Wcm;
	private String referenciaPago_Wcm;
	private String estadoTransaccion_Wcm;
	private String medioPago_Wcm;
	private String idTransaccion_Wcm;
	private String valorCompra_Wcm;
	private String numAutorizacion_Wcm;
	private String comentarios_Wcm;
	private String msjContactoEntidad_Wcm;
	private String msjPendientePago_Wcm;
	private String moneda_wcm;
	private String ciudadImpuesto_Wcm;
	private String tipoAporte_Wcm;
	private String referenciaPagoAdicional_Wcm;
	private String nombrePagador_Wcm;
	private String intencionPago_Wcm;
	private String isRedireccion;
	private String urlHome;
	private String tipoMoneda;
	private String enlaceRegistro_Wcm;
	private String txtRegistro_Wcm;
	private String msjInvitacionRegistro_Wcm;
	private String msjRegistroPago_Wcm;
	private String msjTransaccionAprovada;
	private String msjTransaccionRechazada;
	private String msjTransaccionPendiente;
	private String txtInscribierServicio_Wcm;
	private String txtBotonInscribirServicio_Wcm;
	private String lnkBotonInscribirServicio_Wcm;
	private String realizarNuevoPago;
	private String lnkRealizarNuevoPago;
	private String stNombrePasoCompMovil;
	private String stFinalizar;
	//HU 21.5.1 Agregar costo transaccion
	private String lblCostoTransaccion;
	
	//HU 48.1 VG NextDay SP1_2017
	private String lbNextDay;
	private String lbIpOrigen;
	
	// RQ - Confirmar Pago Externo 
	private boolean pagoExterno;

	public String getStNombrePasoCompMovil() {
		return stNombrePasoCompMovil;
	}

	public void setStNombrePasoCompMovil(String stNombrePasoCompMovil) {
		this.stNombrePasoCompMovil = stNombrePasoCompMovil;
	}

	public String getEnlaceRegistro_Wcm() {
		return enlaceRegistro_Wcm;
	}

	public void setEnlaceRegistro_Wcm(String enlaceRegistro_Wcm) {
		this.enlaceRegistro_Wcm = enlaceRegistro_Wcm;
	}

	public String getTxtRegistro_Wcm() {
		return txtRegistro_Wcm;
	}

	public void setTxtRegistro_Wcm(String txtRegistro_Wcm) {
		this.txtRegistro_Wcm = txtRegistro_Wcm;
	}

	public String getMsjInvitacionRegistro_Wcm() {
		return msjInvitacionRegistro_Wcm;
	}

	public void setMsjInvitacionRegistro_Wcm(String msjInvitacionRegistro_Wcm) {
		this.msjInvitacionRegistro_Wcm = msjInvitacionRegistro_Wcm;
	}

	public String getTipoMoneda() {
		return tipoMoneda;
	}

	public void setTipoMoneda(String tipoMoneda) {
		this.tipoMoneda = tipoMoneda;
	}

	public String getUrlHome() {
		return urlHome;
	}

	public void setUrlHome(String urlHome) {
		this.urlHome = urlHome;
	}

	public String getIsRedireccion() {
		return isRedireccion;
	}

	public void setIsRedireccion(String isRedireccion) {
		this.isRedireccion = isRedireccion;
	}

	public String getNombres_Apellidos_Wcm() {
		return nombres_Apellidos_Wcm;
	}

	public void setNombres_Apellidos_Wcm(String nombres_Apellidos_Wcm) {
		this.nombres_Apellidos_Wcm = nombres_Apellidos_Wcm;
	}

	public String getNombreConvenio_Wcm() {
		return nombreConvenio_Wcm;
	}

	public void setNombreConvenio_Wcm(String nombreConvenio_Wcm) {
		this.nombreConvenio_Wcm = nombreConvenio_Wcm;
	}

	public String getNit_Wcm() {
		return nit_Wcm;
	}

	public void setNit_Wcm(String nit_Wcm) {
		this.nit_Wcm = nit_Wcm;
	}

	public String getFechaTransaccion_Wcm() {
		return fechaTransaccion_Wcm;
	}

	public void setFechaTransaccion_Wcm(String fechaTransaccion_Wcm) {
		this.fechaTransaccion_Wcm = fechaTransaccion_Wcm;
	}

	public String getReferenciaPago_Wcm() {
		return referenciaPago_Wcm;
	}

	public void setReferenciaPago_Wcm(String referenciaPago_Wcm) {
		this.referenciaPago_Wcm = referenciaPago_Wcm;
	}

	public String getEstadoTransaccion_Wcm() {
		return estadoTransaccion_Wcm;
	}

	public void setEstadoTransaccion_Wcm(String estadoTransaccion_Wcm) {
		this.estadoTransaccion_Wcm = estadoTransaccion_Wcm;
	}

	public String getMedioPago_Wcm() {
		return medioPago_Wcm;
	}

	public void setMedioPago_Wcm(String medioPago_Wcm) {
		this.medioPago_Wcm = medioPago_Wcm;
	}

	public String getIdTransaccion_Wcm() {
		return idTransaccion_Wcm;
	}

	public void setIdTransaccion_Wcm(String idTransaccion_Wcm) {
		this.idTransaccion_Wcm = idTransaccion_Wcm;
	}

	public String getValorCompra_Wcm() {
		return valorCompra_Wcm;
	}

	public void setValorCompra_Wcm(String valorCompra_Wcm) {
		this.valorCompra_Wcm = valorCompra_Wcm;
	}

	public String getNumAutorizacion_Wcm() {
		return numAutorizacion_Wcm;
	}

	public void setNumAutorizacion_Wcm(String numAutorizacion_Wcm) {
		this.numAutorizacion_Wcm = numAutorizacion_Wcm;
	}

	public String getComentarios_Wcm() {
		return comentarios_Wcm;
	}

	public void setComentarios_Wcm(String comentarios_Wcm) {
		this.comentarios_Wcm = comentarios_Wcm;
	}

	public String getMsjContactoEntidad_Wcm() {
		return msjContactoEntidad_Wcm;
	}

	public void setMsjContactoEntidad_Wcm(String msjContactoEntidad_Wcm) {
		this.msjContactoEntidad_Wcm = msjContactoEntidad_Wcm;
	}

	public String getMsjPendientePago_Wcm() {
		return msjPendientePago_Wcm;
	}

	public void setMsjPendientePago_Wcm(String msjPendientePago_Wcm) {
		this.msjPendientePago_Wcm = msjPendientePago_Wcm;
	}

	public String getMoneda_wcm() {
		return moneda_wcm;
	}

	public void setMoneda_wcm(String moneda_wcm) {
		this.moneda_wcm = moneda_wcm;
	}

	public String getTipoAporte_Wcm() {
		return tipoAporte_Wcm;
	}

	public void setTipoAporte_Wcm(String tipoAporte_Wcm) {
		this.tipoAporte_Wcm = tipoAporte_Wcm;
	}

	public String getCiudadImpuesto_Wcm() {
		return ciudadImpuesto_Wcm;
	}

	public void setCiudadImpuesto_Wcm(String ciudadImpuesto_Wcm) {
		this.ciudadImpuesto_Wcm = ciudadImpuesto_Wcm;
	}

	public String getIntencionPago_Wcm() {
		return intencionPago_Wcm;
	}

	public void setIntencionPago_Wcm(String intencionPago_Wcm) {
		this.intencionPago_Wcm = intencionPago_Wcm;
	}

	public String getNombrePagador_Wcm() {
		return nombrePagador_Wcm;
	}

	public void setNombrePagador_Wcm(String nombrePagador_Wcm) {
		this.nombrePagador_Wcm = nombrePagador_Wcm;
	}

	public String getTxtInscribierServicio_Wcm() {
		return txtInscribierServicio_Wcm;
	}

	public void setTxtInscribierServicio_Wcm(String txtInscribierServicio_Wcm) {
		this.txtInscribierServicio_Wcm = txtInscribierServicio_Wcm;
	}

	public String getTxtBotonInscribirServicio_Wcm() {
		return txtBotonInscribirServicio_Wcm;
	}

	public void setTxtBotonInscribirServicio_Wcm(String txtBotonInscribirServicio_Wcm) {
		this.txtBotonInscribirServicio_Wcm = txtBotonInscribirServicio_Wcm;
	}

	public String getLnkBotonInscribirServicio_Wcm() {
		return lnkBotonInscribirServicio_Wcm;
	}

	public void setLnkBotonInscribirServicio_Wcm(String lnkBotonInscribirServicio_Wcm) {
		this.lnkBotonInscribirServicio_Wcm = lnkBotonInscribirServicio_Wcm;
	}

	public String getMsjRegistroPago_Wcm() {
		return msjRegistroPago_Wcm;
	}

	public void setMsjRegistroPago_Wcm(String msjRegistroPago_Wcm) {
		this.msjRegistroPago_Wcm = msjRegistroPago_Wcm;
	}

	public String getRealizarNuevoPago() {
		return realizarNuevoPago;
	}

	public void setRealizarNuevoPago(String realizarNuevoPago) {
		this.realizarNuevoPago = realizarNuevoPago;
	}

	public String getLnkRealizarNuevoPago() {
		return lnkRealizarNuevoPago;
	}

	public void setLnkRealizarNuevoPago(String lnkRealizarNuevoPago) {
		this.lnkRealizarNuevoPago = lnkRealizarNuevoPago;
	}

	public String getStFinalizar() {
		return stFinalizar;
	}

	public void setStFinalizar(String stFinalizar) {
		this.stFinalizar = stFinalizar;
	}

	public String getLblCostoTransaccion() {
		return lblCostoTransaccion;
	}

	public void setLblCostoTransaccion(String lblCostoTransaccion) {
		this.lblCostoTransaccion = lblCostoTransaccion;
	}
	
	//HU 48.1 VG NextDay SP1_2017
	
	public String getLbNextDay() {
		return lbNextDay;
	}

	public void setLbNextDay(String lbNextDay) {
		this.lbNextDay = lbNextDay;
	}

	public String getReferenciaPagoAdicional_Wcm() {
		return referenciaPagoAdicional_Wcm;
	}

	public void setReferenciaPagoAdicional_Wcm(String referenciaPagoAdicional_Wcm) {
		this.referenciaPagoAdicional_Wcm = referenciaPagoAdicional_Wcm;
	}

	public String getLbIpOrigen() {
		return lbIpOrigen;
	}

	public void setLbIpOrigen(String lbIpOrigen) {
		this.lbIpOrigen = lbIpOrigen;
	}

	public String getMsjTransaccionAprovada() {
		return msjTransaccionAprovada;
	}

	public void setMsjTransaccionAprovada(String msjTransaccionAprovada) {
		this.msjTransaccionAprovada = msjTransaccionAprovada;
	}

	public String getMsjTransaccionRechazada() {
		return msjTransaccionRechazada;
	}

	public void setMsjTransaccionRechazada(String msjTransaccionRechazada) {
		this.msjTransaccionRechazada = msjTransaccionRechazada;
	}

	public String getMsjTransaccionPendiente() {
		return msjTransaccionPendiente;
	}

	public void setMsjTransaccionPendiente(String msjTransaccionPendiente) {
		this.msjTransaccionPendiente = msjTransaccionPendiente;
	}
	
	public boolean isPagoExterno() {
		return pagoExterno;
	}

	public void setPagoExterno(boolean pagoExterno) {
		this.pagoExterno = pagoExterno;
	}
	
}