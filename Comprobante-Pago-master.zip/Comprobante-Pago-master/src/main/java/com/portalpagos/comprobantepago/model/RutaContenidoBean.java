package com.portalpagos.comprobantepago.model;

import java.io.Serializable;

public class RutaContenidoBean implements Serializable {

    private static final long serialVersionUID = 1L;
    private String pathContentComprobantePago;
    private String pathContentContComprobanteMailPagosAval;
    private String urlHome;
    private String portalOrigen;
    private String portletOrigen;
    private String paginaOrigen;
    private String bankId;
    private String userName;
    private String ipAdress;
    private String pathImagenConv;
    private String nombreBaseImgConvenio;
    private String dn;
    private String pathErroresTecnicos;
    private String idTransaccion;
    private String idRequest;

    public String getPathImagenConv() {
        return pathImagenConv;
    }

    public void setPathImagenConv(String pathImagenConv) {
        this.pathImagenConv = pathImagenConv;
    }

    public String getNombreBaseImgConvenio() {
        return nombreBaseImgConvenio;
    }

    public void setNombreBaseImgConvenio(String nombreBaseImgConvenio) {
        this.nombreBaseImgConvenio = nombreBaseImgConvenio;
    }

    public String getIpAdress() {
        return ipAdress;
    }

    public void setIpAdress(String ipAdress) {
        this.ipAdress = ipAdress;
    }

    public String getBankId() {
        return bankId;
    }

    public void setBankId(String bankId) {
        this.bankId = bankId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPortalOrigen() {
        return portalOrigen;
    }

    public void setPortalOrigen(String portalOrigen) {
        this.portalOrigen = portalOrigen;
    }

    public String getPortletOrigen() {
        return portletOrigen;
    }

    public void setPortletOrigen(String portletOrigen) {
        this.portletOrigen = portletOrigen;
    }

    public String getPaginaOrigen() {
        return paginaOrigen;
    }

    public void setPaginaOrigen(String paginaOrigen) {
        this.paginaOrigen = paginaOrigen;
    }

    public String getPathContentComprobantePago() {
        return pathContentComprobantePago;
    }

    public void setPathContentComprobantePago(String pathContentComprobantePago) {
        this.pathContentComprobantePago = pathContentComprobantePago;
    }

    public String getPathContentContComprobanteMailPagosAval() {
        return pathContentContComprobanteMailPagosAval;
    }

    public void setPathContentContComprobanteMailPagosAval(String pathContentContComprobanteMailPagosAval) {
        this.pathContentContComprobanteMailPagosAval = pathContentContComprobanteMailPagosAval;
    }

    public String getUrlHome() {
        return urlHome;
    }

    public void setUrlHome(String urlHome) {
        this.urlHome = urlHome;
    }

    public String getDn() {
        return dn;
    }

    public void setDn(String dn) {
        this.dn = dn;
    }

    public String getPathErroresTecnicos() {
        return pathErroresTecnicos;
    }

    public void setPathErroresTecnicos(String pathErroresTecnicos) {
        this.pathErroresTecnicos = pathErroresTecnicos;
    }

	public String getIdTransaccion()
	{
		return idTransaccion;
	}

	public void setIdTransaccion(String idTransaccion)
	{
		this.idTransaccion = idTransaccion;
	}

	public String getIdRequest()
	{
		return idRequest;
	}

	public void setIdRequest(String idRequest)
	{
		this.idRequest = idRequest;
	}
}