package com.portalpagos.comprobantepago.helper;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.portlet.RenderRequest;

import com.ath.portalpagos.util.ExceptionManager;
import com.ath.portalpagos.util.IpNodoPortal;
import com.ath.portalpagos.util.JSONUtil;
import com.co.pragma.portal.utils.WCMCliente;
import com.google.gson.Gson;
import com.ibm.workplace.wcm.api.ImageComponent;
import com.ibm.workplace.wcm.api.exceptions.WCMException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.KeyLengthException;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.portalpagos.comprobantepago.model.ComprobantePagoBean;
import com.portalpagos.comprobantepago.model.RutaContenidoBean;
import com.portalpagos.comprobantepago.portlet.ComprobantePagoPortlet;
import com.portalpagos.comprobantepago.util.ErrorManager;
import com.portalpagos.comprobantepago.util.Puma;

import co.com.ath.clientes.payments.mc.service.util.ConfigurationService;
import co.com.ath.logger.CustomLogger;
import co.com.ath.mc.utilities.util.CloneUtil;
import co.com.ath.mc.utilities.util.EnmascararUtil;
import co.com.ath.mc.utilities.util.TruncarUtil;
import co.com.ath.payments.mc.auditor.publisher.traza.TrazaPublisher;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.auditor.publisher.util.WebServiceClientHTTPS;
import co.com.ath.payments.mc.cache.manager.CacheManager;
import co.com.ath.payments.mc.service.model.AuditorRq;
import co.com.ath.payments.mc.service.model.ErrorData;
import co.com.ath.payments.mc.service.model.json.BankInfoType;
import co.com.ath.payments.mc.service.model.json.GetConvenioInfoRq;
import co.com.ath.payments.mc.service.model.json.GetConvenioInfoRs;
import co.com.ath.payments.mc.service.model.json.GetInvoicesRq;
import co.com.ath.payments.mc.service.model.json.GetInvoicesRs;
import co.com.ath.payments.mc.service.model.json.GetParametroRs;
import co.com.ath.payments.mc.service.model.json.GetPaymentStatusRq;
import co.com.ath.payments.mc.service.model.json.GetPaymentStatusRs;
import co.com.ath.payments.mc.service.model.json.ReferenceAgreementType;
import co.com.ath.payments.mc.service.model.json.ReferenceType;
import co.com.ath.payments.mc.service.model.json.SearchPaymentHistoryRq;
import co.com.ath.payments.mc.service.model.json.SearchPaymentHistoryRs;
import co.com.ath.payments.mc.service.util.CommonUtils;

/**
 * HU24 Clase que se encarga de receptar los datos del comprobante de pago.
 * 
 * @author: germandiaz
 * @author: carlos.cardona
 */
public class ComprobantePagoController {

    private CustomLogger logger = new CustomLogger(ComprobantePagoPortlet.class);

    private static final String RS = "RS";
    private static final String NODO_INTEGRACION = "Nodo WebLogic";
    private static final String NODO = "Nodo Portal";
    private static final String NODO_WEBLOGIC = "Nodo WebLogic";
    private static final String ESTADO = "Estado tx";
    private static final String DOSPUNTOS = ":";
    private static final String REFERENCIAS_ADICIONALES = "Referencias Adicionales";
    private static final String PM_TRANSACCION_CONVENIO_ID= "{transaccionConvenioId}";
    private static final String PM_TRANSACCION_ID= "{transaccionId}";
    private static final String PM_APROBADO= "{aprobado}";
    private static final String PM_REF_1= "{ref1}";
    private static final String PM_VALOR= "{valor}";
    private static final String PM_UUID= "{uuid}";
    private static final String POS_IDCOMERCIO_EXT = "200"; 
    private static final String TOKEN = "{token}";
    public static final String CONVENIO_ID = "00007461";
    private String user;
    private String rquid;
    private static String operacion = "Comprobante de Pago";
    private String idPago = "";
    // Tokenización 28-07-2017
    // datos para enmascaramiento
    private static int enmascararIzquierda;
    private static int enmascararDerecha;
    private static char enmascararCaracter;
    private static int truncarIzquierda;
    private static int truncarDerecha;
    private static char truncarCaracter;
    private final static String enmascararIzquierdaParametro = "ATH_CANT_INICIAL_MASCARA";
    private final static String enmascararDerechaParametro = "ATH_CANT_FINAL_MASCARA";
    private final static String enmascararCaracterParametro = "ATH_CARACTER_MASCARA";
    private static final int POSICION_REF_TC = 0;
    private final static String truncarIzquierdaParametro = "ATH_CANT_PREVIA_TRUNCADO";
    private final static String truncarDerechaParametro = "ATH_CANT_FINAL_TRUNCADO";
    private final static String truncarCaracterParametro = "ATH_CARACTER_PREVIO_TRUNCADO";

    /**
     * HU24 Inicializa el Gestor de log con los datos enviados desde el Portlet.
     * 
     * @author German Diaaz
     */
    public ComprobantePagoController() {
        super();
    }

    /**
     * HU24 Envia el id de la transaccion al Middleware de comunicaciones, se capturan los recuperan los datos del usuario y se settean a
     * los atributos del bean.
     * 
     * @author German Diaz
     * @since 05/11/2014
     * @param idTransaccion
     * @param request
     * @param idRequest
     * @param isUrl
     * @param usuario
     * @return ComprobantePagoBean bean para manipular en vista.
     * @exception controla
     *                los errores al consultar del middle de comunicaciones
     */
    public ComprobantePagoBean cargarDatos(String idTransaccion, RenderRequest request, String idRequest, Boolean isUrl, String usuario) {
    	
    	logger.info("*******************************************Cargar Datos ************************************************************");
        RutaContenidoBean rContenido = (RutaContenidoBean) request.getAttribute("RutaContenidoBean");
        rContenido.setIdTransaccion(idTransaccion);
        rContenido.setIdRequest(idRequest);
        ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.comprobantepago.portlet.nl.ComprobantePagoPortletResource");
        String accion = rb.getString("auditoria.consultarEstadoPago");
        Date fechaTransaccion, fechaHabil = null;
        double valorRq;
        String nombres = "", nombreConvenio = "", nit = "", fechaFormateada = "", estadoTransaccion = "", Idtransaccion = "",
                valorCompra = "", numAutorizacion = "", comentarios = "", emailCliente = "", formatoMedioPago = "", valorAutorizacion = "",
                conceptoPago = "", urlRetorno = "";
        String moneda = "", idConvenio = "", ciudad = "", tipoAporte = "", tipoConv = "", medioPagors = "", bancoMedioPago = "",
                franquicia = "", numtarjeta = "", nombrePagador = "", intencionPago = "", costoTrans = "", referenciaPago = "";
        Boolean isPermitePagoDolar = false;
        String tipoMoneda = "";
        int totalFacturas = -1;

        // HU 48.1 VG 15/12/2016 NextDay
        Boolean mostrarNextDay = false;
        Boolean trxAprobada = false;
        Boolean trxPendiente = false;
        List<ReferenceType> referenceList = null;

        ComprobantePagoBean conMdw = new ComprobantePagoBean();
        GetPaymentStatusRq rq = null;
        GetPaymentStatusRs rs = null;

        String errorCode = "";
        String descExcepcion = "";

        // Tokenizacion
        GetConvenioInfoRs response = null;
        boolean esTarjetaCredito = false;
        GetPaymentStatusRs responseCloneLog = null;

        try {

            // Tokenizacion cargamos parámetros
            cargarParametrosCache();

            conMdw.setIpAddress(rContenido.getIpAdress());
            user = usuario;
            rquid = idRequest;
            BankInfoType infoBanco = new BankInfoType();
            infoBanco.setBankId(rContenido.getBankId());
            infoBanco.setBankName(rContenido.getPortalOrigen());

            logger.info("Se procede a llenar el request");
            logger.info("idPago:" + rContenido.getIdTransaccion() + ", rquid:" + rContenido.getIdRequest());
            
            rq = new GetPaymentStatusRq();
            rq.setPaymentId(idTransaccion);
            rq.setRequestOriginPortal(rContenido.getPortalOrigen());
            rq.setRequestPage(rContenido.getPaginaOrigen());
            rq.setRequestSender(rContenido.getPortletOrigen());
            rq.setRequestDate(new Date());
            rq.setIpAddress(rContenido.getIpAdress());
            rq.setRequestID(idRequest);
            /* Si no es un pago realizado por ventanilla se setea el usuario */
            if (null == request.getAttribute("pagoDesdeTaquillas")) {
                rq.setRequestUser(rContenido.getUserName());
            }
            rq.setBankInfo(infoBanco);
            rq.setUrl(isUrl);

            String idTypeAttr = "";
            String idNumberAttr = "";
            if (user != null) {
                Puma puma;
                puma = new Puma();
                idTypeAttr = puma.getPropertyFromPuma("ath-tipo-documento", request);
                idNumberAttr = puma.getPropertyFromPuma("ath-numero-documento", request);
            }
            rq.setCustomerId(idNumberAttr);
            rq.setCustomerIdType(idTypeAttr);

            Gson gson = new Gson();
            logger.info("[REQUEST - getTransaction] DATA: " + gson.toJson(rq));
            String endpointGetTransaction = ConfigurationService.getInstance().getEndpointRest();
            rs = (GetPaymentStatusRs) WebServiceClientHTTPS.getInstance(GetPaymentStatusRs.class)
                    .procesarRequest(endpointGetTransaction + "getTransaction", rq);

            
            /* INI Tokenizacion Consume el cache manager para traer la informacion del convenio 28-07-2017 */
            if (null != rs && rs.isValidarBin()) {
                esTarjetaCredito = true;
            }

            if (null != rs.getReferences()) {
            	//Se agrega el label al id comercio para que se muestre en el comprobante
            	referenciaIdComercioCpv(rs.getReferences());
                conMdw.setListaReferenciasCopy(rs.getReferences());
            } else {
                conMdw.setListaReferenciasCopy(new ArrayList<ReferenceType>());
            }
            
            // RQ29184 - Factura personalizada
            if(rs.getCustomInvoice() != null &&!rs.getCustomInvoice().isEmpty()) {
            	conMdw.setFacturaPersonalizada(rs.getCustomInvoice());
            }

            // realizamos el log y modificamos referencias de ser necesario
            responseCloneLog = (GetPaymentStatusRs) CloneUtil.clone(rs);
            if (esTarjetaCredito) {
                List<ReferenceType> referencias = responseCloneLog.getReferences();
                ReferenceType referenciaTc = referencias.get(POSICION_REF_TC);
                String referenciaTcTexto = EnmascararUtil.enmascararTarjetaDeCredito(referenciaTc.getReference(), enmascararCaracter,
                        enmascararIzquierda, enmascararDerecha);
                referenciaTc.setReference(referenciaTcTexto);
                referencias.set(POSICION_REF_TC, referenciaTc);
                responseCloneLog.setReferences(referencias);
                conMdw.setReferenciaEnmascarada(referenciaTcTexto);
            }

            logger.info("[RESPONSE - getTransaction clone] DATA: " + gson.toJson(responseCloneLog));
            // FIN Tokenizacion

            // Alertas INI se debe controlar el null del getTransaction
            if (rs != null) {
                if (!("SUCCESS".equals(rs.getStatus().getStatusCode()))) {
                    if ("DENIED".equals(rs.getStatus().getStatusCode())) {
                        request.setAttribute("isRedirect", "true");
                    } else {
                        if (null != rs.getExcepcion() && null != rs.getExcepcion().getCodigo()) {
                            errorCode = rs.getExcepcion().getCodigo();
                            descExcepcion = rs.getExcepcion().getMensaje();
                        }
                        logger.info(
                                "getPaymentStatus PMTID: " + idTransaccion + ". Response CODE: " + errorCode + ", DESC: " + descExcepcion);
                        String cuerpoLightbox = "";
                        String tituloError = "";
                        if ("ERROR_200".equals(rs.getStatus().getStatusDesc())) {
                            String mensajeGeneral = rb.getString("stMsgErrorConsultaFactura");
                            String serverStatusCode = null != rs.getStatus().getServerStatusCode()
                                    && !rs.getStatus().getServerStatusCode().isEmpty() ? "(" + rs.getStatus().getServerStatusCode() + ")"
                                            : "";
                            cuerpoLightbox = null != rs.getStatus().getServerStatusDescp()
                                    && !rs.getStatus().getServerStatusDescp().isEmpty()
                                            ? rs.getStatus().getServerStatusDescp() + " " + serverStatusCode
                                            : mensajeGeneral + " " + serverStatusCode;
                            tituloError = rb.getString("stTituloMensajeError");
                            conMdw.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                            logger.info("---------------ERROR_200" + cuerpoLightbox + " " + tituloError);
                        } else if ("ERROR_100".equals(rs.getStatus().getStatusDesc())) {
                            String mensajeGeneral = rb.getString("stMensajeError100");
                            String serverStatusCode = null != rs.getStatus().getServerStatusCode()
                                    && !rs.getStatus().getServerStatusCode().isEmpty() ? "(" + rs.getStatus().getServerStatusCode() + ")"
                                            : "";
                            cuerpoLightbox = mensajeGeneral + " " + serverStatusCode;
                            tituloError = rb.getString("stTituloMensajeError");
                            conMdw.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                            logger.info("---------------ERROR_100" + cuerpoLightbox + " " + tituloError);
                        } else if ("ERROR_300".equals(rs.getStatus().getStatusDesc())) {
                            String mensajeGeneral = rb.getString("stMensajeError300");
                            String serverStatusCode = null != rs.getStatus().getServerStatusCode()
                                    && !rs.getStatus().getServerStatusCode().isEmpty() ? "(" + rs.getStatus().getServerStatusCode() + ")"
                                            : "";
                            cuerpoLightbox = mensajeGeneral + " " + serverStatusCode;
                            tituloError = rb.getString("stTituloMensajeError");
                            conMdw.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                            logger.info("---------------ERROR_300" + cuerpoLightbox + " " + tituloError);
                        } else if ("ERROR_600".equals(rs.getStatus().getStatusDesc())) {
                            String mensajeGeneral = rb.getString("stMensajeError600");
                            String serverStatusCode = null != rs.getStatus().getServerStatusCode()
                                    && !rs.getStatus().getServerStatusCode().isEmpty() ? "(" + rs.getStatus().getServerStatusCode() + ")"
                                            : "";
                            cuerpoLightbox = mensajeGeneral + " " + serverStatusCode;
                            tituloError = rb.getString("stTituloMensajeError");
                            conMdw.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                            logger.info("---------------ERROR_600" + cuerpoLightbox + " " + tituloError);
                        } else if ("ERROR_700".equals(rs.getStatus().getStatusDesc())) {
                            String mensajeGeneral = rb.getString("stMensajeError700");
                            String serverStatusCode = null != rs.getStatus().getServerStatusCode()
                                    && !rs.getStatus().getServerStatusCode().isEmpty() ? "(" + rs.getStatus().getServerStatusCode() + ")"
                                            : "";
                            cuerpoLightbox = mensajeGeneral + " " + serverStatusCode;
                            tituloError = rb.getString("stTituloMensajeError");
                            conMdw.mostrarModal(cuerpoLightbox, "icon-error", tituloError);
                            logger.info("---------------ERROR_700" + cuerpoLightbox + " " + tituloError);
                        } else {
                            String error[] = ErrorManager.getInstance(request, rquid, user)
                                    .obtenerErrorWCM(rContenido.getPathErroresTecnicos(), errorCode, request);
                            conMdw.mostrarModal(error[0], "icon-error", error[1]);
                        }
                        urlRetorno = "";
                    }
                } else {
                    if (null != rs.getAgreementName()) {
                        request.setAttribute("isRedirect", "false");
                        if (rs.getModalidadConvenio() != null) {
                            tipoConv = rs.getModalidadConvenio();
                            if (tipoConv.equals("5") || tipoConv.equals("6")) {
                                // Impuestos
                                if (rs.getCiudad() != null) {
                                    ciudad = rs.getCiudad();
                                }
                                if (tipoConv.equals("5")) {
                                    if (rs.getTipoAporte() != null) {
                                        tipoAporte = rs.getTipoAporte();
                                    }
                                }
                            } else if (tipoConv.equals("4") || tipoConv.equals("7")) {
                                // Obligaciones financieras
                                if (rs.getCurCode() != null) {
                                    // campo moneda, obligaciones financieras
                                    moneda = rs.getCurCode();
                                }
                            }
                        }

                        tipoMoneda = rs.getTipoMoneda();
                        if (rs.isPermitePagoDolares()) {
                            isPermitePagoDolar = rs.isPermitePagoDolares();
                        }
                        if (rs.getCustomerName() != null) {
                            nombres = rs.getCustomerName() + " " + rs.getCustomerLastName();
                        }
                        if (rs.getAgreementName() != null) {
                            nombreConvenio = rs.getAgreementName();
                        }
                        if (rs.getCustomerNit() != null) {
                            nit = rs.getCustomerNit();
                        }
                        fechaTransaccion = new Date();
                        if (rs.getDatePaymentInit() != null) {
                            fechaTransaccion = rs.getDatePaymentInit();
                        }
                        // Formateo de la fecha para la estructura que cumpla con la estructura yyyy-MM-dd HH:mm:ss
                        ComprobantePagoLogica com = new ComprobantePagoLogica();
                        fechaFormateada = com.formatearFecha(fechaTransaccion, request, rquid, user);

                        if (rs.getReferences() != null) {
                            // INI Tokenizacion 28-07-2017
                            referenceList = rs.getReferences();
                            if (esTarjetaCredito) {
                                referenciaPago = TruncarUtil.truncarTarjetaDeCredito(referenceList.get(0).getReference(), truncarDerecha,
                                        truncarCaracter, truncarIzquierda);
                                referenceList.get(0).setReference(referenciaPago);
                            }
                            /*
                             * else { if (rs.isEnmascarar()) { referenciaPago =
                             * com.cifrarReferenciaPago(referenceList.get(0).getReference(), rquid, user);
                             * referenceList.get(0).setReference(referenciaPago); } }
                             */
                            // FIN Tokenizacion
                        }
                        if (rs.getNombrePagador() != null) {
                            nombrePagador = rs.getNombrePagador();
                        }
                        if (rs.getIntencionPago() != null) {
                            intencionPago = rs.getIntencionPago();
                        }
                        if (rs.getTransactionStatusRs() != null) {
                            estadoTransaccion = rs.getTransactionStatusRs().getTrnStatusDesc();
                            ResourceBundle rb2 = ResourceBundle.getBundle("com.portalpagos.comprobantepago.properties.ComprobantePago");
                            String aprobada = rb2.getString("transaccion.estadoAceptado");
                            String aprobada2 = rb2.getString("transaccion.estadoAceptado");
                            // Modificaci�n HU Nueva NextDay
                            String estadoPendiente = rb2.getString("transaccion.estadoPendiente");

                            if (estadoTransaccion.equalsIgnoreCase(aprobada2) || estadoTransaccion.equalsIgnoreCase(aprobada)) {
                                // HU 48.1 VG 16/12/2016
                                trxAprobada = true;
                                // Si la transaccion es aprobada logger.info("user: " + user);
                                if (user != null) {
                                    // Si existe usuario autenticado, va a consultar facturas
                                    totalFacturas = this.consultaTotalFacturas(rContenido, rb, idNumberAttr, idTypeAttr);
                                }
                            } else if (estadoTransaccion.equalsIgnoreCase(estadoPendiente)) {
                                trxPendiente = true;
                            }
                        }
                        if (rs.getPaymentMode() != null && rs.getPaymentMode().getPmNombre() != null) {
                            medioPagors = String.valueOf(rs.getPaymentMode().getPmNombre());
                        }
                        Idtransaccion = idTransaccion;
                        valorRq = 0.0;
                        if (rs.getPaymentAmmount() != null) {
                            valorRq = Double.parseDouble((String.valueOf(rs.getPaymentAmmount().getAmmount())));
                        }
                        valorCompra = com.formatearMoneda(valorRq, request, rquid, user);
                        if (rs.getAuthNum() != null) {
                            valorAutorizacion = rs.getAuthNum();
                        }
                        if (rs.getComments() != null) {
                            comentarios = rs.getComments();
                        }
                        if (rs.getPaymentMode() != null && rs.getPaymentMode().getBankInfo() != null
                                && rs.getPaymentMode().getBankInfo().getBankName() != null) {
                            bancoMedioPago = rs.getPaymentMode().getBankInfo().getBankName();
                        }
                        if (rs.getPaymentMode() != null && rs.getPaymentMode().getBankInfo() != null
                                && rs.getPaymentMode().getBankInfo().getFranchise() != null) {
                            franquicia = rs.getPaymentMode().getBankInfo().getFranchise();
                        }
                        if (rs.getPaymentMode() != null && rs.getPaymentMode().getBankInfo() != null
                                && rs.getPaymentMode().getBankInfo().getCardNumber() != null) {
                            numtarjeta = rs.getPaymentMode().getBankInfo().getCardNumber();
                        }
                        if (rs.getAgreementId() != null) {
                            idConvenio = rs.getAgreementId();
                        }
                        formatoMedioPago = com.ocultarTcredito(medioPagors, bancoMedioPago, franquicia, numtarjeta, request, rquid, user);
                        numAutorizacion = com.ocultarNumAutorizacion(valorAutorizacion, request, rquid, user);
                        // HU 21.5.1 Agregar costo transaccion
                        double costoTransacc = rs.getCostoTransaccion();
                        DecimalFormat formato = new DecimalFormat("$ #,###.###", new DecimalFormatSymbols(new Locale("ES")));
                        costoTrans = formato.format(new Double(costoTransacc));

                        // HU 48.1 VG 13/02/2017 SP1_2017 NextDay
                        fechaHabil = new Date();
                        if (rs.getFechaHorarioHabil() != null) {
                            fechaHabil = rs.getFechaHorarioHabil();
                        }
                        String fechaFormateadaHabil = "";
                        fechaFormateadaHabil = com.formatearFecha(fechaHabil, request, rquid, user);

                        SimpleDateFormat formateador = new SimpleDateFormat("yyyy-MM-dd");
                        Date fechaTransaccion1 = formateador.parse(fechaFormateada);
                        Date fechaHabil1 = formateador.parse(fechaFormateadaHabil);
                        // Si la fecha de la transaccion es menor de la la fecha habil y es de obligaciones y es Satisfactoria
                        logger.info("*fechaTransaccion1: *" + fechaTransaccion1 + " fechaHabil1:" + fechaHabil1);
                        // Modificacion || trxPendiente
                        if ((fechaTransaccion1.before(fechaHabil1)) && (tipoConv.equals("4") || tipoConv.equals("7"))
                                && (trxAprobada || trxPendiente)) {
                            mostrarNextDay = true;
                        }
                        // HU FIN 48.1 VG 13/02/2017 SP1_2017 NextDay

                        /* HU 21.6 conceptos de pago */
                        conceptoPago = rs.getConceptoPago();
                        /* Consume el cache manager para traer la información del convenio */
                        GetConvenioInfoRq requestConvenioInfo = new GetConvenioInfoRq();
                        requestConvenioInfo.setAgreementId(rs.getAgreementId());

                        logger.info("[REQUEST - getConvenioInfo] DATA: " + new Gson().toJson(requestConvenioInfo));
                        response = CacheManager.getInstance().getConvenioInfo(requestConvenioInfo);
                        logger.info("[RESPONSE - getConvenioInfo] DATA: " + new Gson().toJson(response));
                        if (null != response && "SUCCESS".equals(response.getStatus().getStatusCode())) {
                            referenceList = mapeoReferenceList(referenceList, response.getReferences());
                        } else {
                            errorCode = ExceptionManager.PP_PORTAL_GENERIC_01;
                            String error[] = ErrorManager.getInstance(request, rquid, user)
                                    .obtenerErrorWCM(rContenido.getPathErroresTecnicos(), ExceptionManager.PP_PORTAL_GENERIC_01, request);
                            conMdw.mostrarModal(error[0], "icon-error", error[1]);
                        }
                        
                        // Metodo para redireccionamiento para url CPV
                        logger.info("---------------Inicializacion para el metodo Url CPV-----------------------");
                        logger.info("AgreementId  ---->>>>>> " +requestConvenioInfo.getAgreementId());
                        logger.info("*******************************************************************");

						if (null == rs.getUrlRespuesta() || rs.getUrlRespuesta().isEmpty()) {
							urlRetorno = "";
						} else {
							if (!requestConvenioInfo.getAgreementId().equalsIgnoreCase(CONVENIO_ID)) {
								urlRetorno = ulrRedirectConvenioCPV(rs, Idtransaccion, estadoTransaccion, valorCompra);
							} else {
								/// Metodo para CCXC Redireccionamiento
								logger.info("-------------Metodo CCXC else -----------------------");
								urlRetorno = urlRedirectConvenioCCXC(rs,rq,
										"com.portalpagos.comprobantepago.properties.ComprobantePago");
							}
						}						

                    } else {
                        request.setAttribute("isRedirect", "true");
                    }
                }
              
            } else {
                errorCode = ExceptionManager.PP_PORTAL_GENERIC_01;
                String error[] = ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                        ExceptionManager.PP_PORTAL_GENERIC_01, request);
                conMdw.mostrarModal(error[0], "icon-error", error[1]);
            }
            // Alertas Fin
        } catch (Exception e) {
            errorCode = ExceptionManager.PP_PORTAL_GENERIC_01;
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: Cargar datos, " + operacion, "cargarDatos",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
            String error[] = ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                    ExceptionManager.PP_PORTAL_GENERIC_01, request);
            conMdw.mostrarModal(error[0], "icon-error", error[1]);
        } finally {
            // Tokenizacion
            auditorRsGetPaymentStatus(responseCloneLog, rq, accion, idRequest, errorCode, estadoTransaccion, rContenido);
        }
        String nombres_Apellidos = !nombres.trim().isEmpty() ? nombres : "";

        conMdw.setNombres_Apellidos(nombres_Apellidos);
        conMdw.setNombreConvenio(nombreConvenio);
        conMdw.setNit(nit);
        conMdw.setFechaTransaccion(rs.getDatePaymentInit());
        conMdw.setFechaformateada(fechaFormateada.toString());
        // Alertas if cuando es null
        String valReference = "";
        if (rs.getReferences() != null && rs.getReferences().size() >= 1) {
            valReference = rs.getReferences().get(0).getReference();
        }
        /// INI Tokenizacion Se ajusta la referencia de pago para guardarlo a nivel de auditoria
        /// solo si es está establecida la mascara
        if (conMdw.getReferenciaEnmascarada() != null) {
            conMdw.setReferenciaPago(conMdw.getReferenciaEnmascarada());
        } else {
            conMdw.setReferenciaPago(valReference);
        }
        conMdw.setValidaBIN(esTarjetaCredito);
        /// FIN
        conMdw.setListaReferencias(referenceList);
        conMdw.setReferenciasSinCifrar(rs.getReferences());
        conMdw.setEstadoTransaccion(estadoTransaccion);
        conMdw.setMedioPago(formatoMedioPago);
        conMdw.setIdTransaccion(Idtransaccion);
        conMdw.setValorCompra(valorCompra);
        conMdw.setNumAutorizacion(numAutorizacion);
        conMdw.setComentarios(comentarios);
        conMdw.setEmail(emailCliente);
        conMdw.setMoneda(moneda);
        conMdw.setTipoConvenio(tipoConv);
        conMdw.setTipoAporte(tipoAporte);
        conMdw.setCiudad(ciudad);
        conMdw.setPortalOrigen(rContenido.getPortalOrigen());
        conMdw.setPortletOrigen(rContenido.getPortletOrigen());
        conMdw.setPaginaOrigen(rContenido.getPaginaOrigen());

        // Se realiza trim para validar que el campo no llegue con espacios
        String nombrePagadorTrim = !nombrePagador.trim().isEmpty() ? nombrePagador : "";
        conMdw.setNombrePagador(nombrePagadorTrim);
        conMdw.setIntencionPago(intencionPago);
        conMdw.setTotalFacturas(totalFacturas);
        conMdw.setImagen(searchConvImage(rContenido, idConvenio));
        conMdw.setImagenTransacionRespuesta(searchTransactionImage(rContenido, estadoTransaccion));
        conMdw.setAgreementId(idConvenio);
        conMdw.setIsPermitePagoDolares(isPermitePagoDolar);
        conMdw.setTipoMoneda(tipoMoneda);
        conMdw.setTaquillas(rs.isTaquilla());
        // HU 21.5.1 Agregar costo transaccion
        conMdw.setCostoTransaccion(costoTrans);
        conMdw.setCostoTransaccionPdf(rs.getCostoTransaccion());

        // HU 48.1 VG 15/12/2016 NextDay
        conMdw.setFechaHabil(fechaHabil);
        conMdw.setMostrarNextDay(mostrarNextDay);
        // HU FIN 48.1
        /* HU 21.6 conceptos de pago */
        conMdw.setConceptoPago(conceptoPago);
        conMdw.setUrlRetornoExterno(urlRetorno);
        conMdw.setPagoExterno((urlRetorno != null && !urlRetorno.isEmpty())?Boolean.TRUE: Boolean.FALSE);
        
		logger.info("setPagoExterno " + conMdw.isPagoExterno());
        
        

        /*
         * HU 136.6: Registro nombre personalizado del servicio para convenios tipo 2 y el atributo PermiteInscripcion retorne en true. en
         * caso de que se retorne el atributo isPorRegistrar en false se valida si no hay usuario en sesion y PermiteInscripcion, de no
         * cumplir las anteriores condiciones no se presenta el boton registrar ni el mensaje de invitacion a registro.
         * 
         * HU 136.7: Inscribir el convenio consultado en el getPaymentStatus.
         * 
         * @autor: carlos.cardona
         * 
         * @autor: germandiaz
         */
        logger.info("::::TipoConvenio: " + tipoConv + " PorRegistrar: " + rs.isPorRegistrar() + " PermiteInscripcion: "
                + rs.isPermiteInscripcion() + " User: " + user);
        conMdw.setFacturador(false);
        conMdw.setNoFacturador(false);
        if ("1".equals(tipoConv) || "2".equals(tipoConv)) {
            if (null != user && !rs.isPorRegistrar()) {
                if ("1".equals(tipoConv) && rs.isPermiteInscripcion()) {
                    conMdw.setFacturador(true);
                } else {
                    conMdw.setNoFacturador(true);
                }
            } else if (null == user) {
                conMdw.setNoFacturador(true);
            }
        }
        return conMdw;
    }

	/*
     * HU 21.7:Metodo que mapea los label de las referencias.
     * 
     * @autor: germandiaz
     * 
     * @since 31/03/2017
     */
	private List<ReferenceType> mapeoReferenceList(List<ReferenceType> referenceList,
			List<ReferenceAgreementType> references) {
		// Recorre la lista de referencias guardada al al realizar el pago y agrega al
		// atributo label el valor correspondiente de BD
		for (ReferenceType reference : referenceList) {
			// Mostrar label Id de transaccion
			// Recorre la lista del getConvenioInfo para saber el valor del label
			for (ReferenceAgreementType referenceAgreementType : references) {
				// Si la posicion del pago es la misma de la consultada en el getConvInfo se
				// adiciona el valor
				if (String.valueOf(reference.getPosition()).equals(referenceAgreementType.getPosicion())) {
					reference.setLabel(referenceAgreementType.getLabel());
					break;
				}
			}

		}
		referenciaIdComercioCpv(referenceList);
		return referenceList;

	}
	
	/**
	 * Asociar el label a la referencia de pago cuando es por integracion Cpv
	 */
	private void referenciaIdComercioCpv(List<ReferenceType> references) {
		ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.comprobantepago.portlet.nl.ComprobantePagoPortletResource");
		if (references != null && !references.isEmpty()) {
			for (ReferenceType referencia : references) {
				if (String.valueOf(referencia.getPosition()).equalsIgnoreCase(POS_IDCOMERCIO_EXT)) {
					referencia.setLabel(rb.getString("stCampoIdComercio"));
					break;
				}
			}
		}
	}

    /**
     * HU 143 Funcion encargada de Trazar del RS de auditorRsGetPaymentStatus.
     * 
     * @param response
     * @param request
     * @param accion
     * @param idRequest
     * @param errorCode
     * @param estadoTransaccion
     * @param referenceList
     * @param rContenido
     */
    private void auditorRsGetPaymentStatus(GetPaymentStatusRs response, GetPaymentStatusRq request, String accion, String idRequest,
            String errorCode, String estadoTransaccion, RutaContenidoBean rContenido) {
        try {
            // Alertas Ini
            String valAccion, valErrorCode, valCodigoServicioInt = "", valIpAddress = "", valOriginPortal = "", valPage = "",
                    valPortlet = "", valRequestId = "", valUser = "", valPaymentId = "";

            valAccion = accion != null ? accion : "";
            valErrorCode = errorCode != null ? errorCode : "";
            valRequestId = idRequest != null ? idRequest : "";
            if (response != null) {
                valCodigoServicioInt = response.getCodigoServicio() != null ? response.getCodigoServicio() : "";
            }
            if (request != null) {
                valIpAddress = request.getIpAddress() != null ? request.getIpAddress() : "";
                valOriginPortal = request.getRequestOriginPortal() != null ? request.getRequestOriginPortal() : "";
                valPage = request.getRequestPage() != null ? request.getRequestPage() : "";
                valPortlet = request.getRequestSender() != null ? request.getRequestSender() : "";
                valUser = request.getRequestUser() != null ? request.getRequestUser() : "";
                valPaymentId = request.getPaymentId() != null ? request.getPaymentId() : "";
            }
            // Alertas Fin
            AuditorRq auditorRq = new AuditorRq();
            auditorRq.setAction(valAccion);
            if ("".equalsIgnoreCase(estadoTransaccion)) {
                estadoTransaccion = null;
            }
            String referenAdi = "";
            if (null != response.getReferences() && !response.getReferences().isEmpty() && response.getReferences().size() > 1) {
                for (int i = 1; i < response.getReferences().size(); i++) {
                    referenAdi += "REF_" + i + ": " + response.getReferences().get(i).getReference();
                }
                auditorRq.setAdditionalInfo(JSONUtil.getJson(ESTADO + DOSPUNTOS + estadoTransaccion,
                        NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(), NODO_INTEGRACION + DOSPUNTOS + response.getIpIntegracion(),
                        REFERENCIAS_ADICIONALES + DOSPUNTOS + referenAdi));
            } else {
                auditorRq.setAdditionalInfo(JSONUtil.getJson(ESTADO + DOSPUNTOS + estadoTransaccion,
                        NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(), NODO_INTEGRACION + DOSPUNTOS + response.getIpIntegracion()));
            }
            auditorRq.setCodigoServicioInt(valCodigoServicioInt);
            auditorRq.setErrorCode(valErrorCode);
            auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
            auditorRq.setIpAddress(valIpAddress);
            auditorRq.setOriginPortal(valOriginPortal);
            auditorRq.setPage(valPage);
            auditorRq.setPortlet(valPortlet);
            auditorRq.setRequestId(valRequestId);
            auditorRq.setTipoServicio(RS);
            auditorRq.setUser(valUser);
            // Alertas condicion si es null
            String refe = "";
            if (response.getReferences() != null && response.getReferences().size() >= 1) {
                refe = response.getReferences().get(0).getReference();
            }
            auditorRq.setReference(refe);
            auditorRq.setPaymentId(valPaymentId);
            TrazaPublisher.getInstance().publish(auditorRq);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: auditorRsGetPaymentStatus, " + operacion,
                    "auditorRsGetPaymentStatus", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    /**
     * HU60.5.2 Consulta del total de facturas pendientes de pago.
     * 
     * @author melany.rozo
     * @since 20/05/2015
     */
    public int consultaTotalFacturas(RutaContenidoBean rContenido, ResourceBundle rb, String idNum, String idType) {
        int totalFacturas = 0;
        String errorCode = "";
        GetInvoicesRq rq = new GetInvoicesRq();
        GetInvoicesRs rs = new GetInvoicesRs();

        String requestId = PublisherUtil.getInstance().generateRequestID();
        try {
            BankInfoType banco = new BankInfoType();
            banco.setBankId(rContenido.getBankId());
            banco.setBankName(rContenido.getPortalOrigen());

            this.trazaGetInvoicesRq(rb, errorCode, rContenido, requestId);
            rq.setRequestOriginPortal(rContenido.getPortalOrigen());
            rq.setRequestSender(rb.getString("auditoria.nombrePortlet"));
            rq.setRequestPage(rContenido.getPaginaOrigen());
            rq.setRequestDate(new Date());
            rq.setRequestID(requestId);
            rq.setIpAddress(rContenido.getIpAdress());
            rq.setCustIdNum(idNum);
            rq.setCustIdType(idType);
            rq.setCustLoginId(rContenido.getUserName());
            rq.setBankInfo(banco);

            logger.info("[REQUEST - getInvoices] DATA: " + new Gson().toJson(rq));

            String EndPointRESTServiceExecutePayment = ConfigurationService.getInstance().getEndpointRest();

            rs = (GetInvoicesRs) WebServiceClientHTTPS.getInstance(GetInvoicesRs.class)
                    .procesarRequest(EndPointRESTServiceExecutePayment + "getInvoices", rq);

            logger.info("[RESPONSE - getInvoices] DATA: " + new Gson().toJson(rs));

            if ("SUCCESS".equals(rs.getStatus().getStatusCode())) {
                totalFacturas = rs.getTotalFacturas();
            } else {
                totalFacturas = -1;
                if (null != rs && null != rs.getExcepcion() && null != rs.getExcepcion().getCodigo()) {
                    errorCode = rs.getExcepcion().getCodigo();
                }
                logger.info("Response getInvoices usuario " + rContenido.getUserName() + " CODE: " + errorCode + ", DESC: "
                        + rs.getExcepcion().getMensaje());
            }
        } catch (Exception e) {
            errorCode = ExceptionManager.PP_PORTAL_GENERIC_01;
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, requestId, ExceptionManager.PP_PORTAL_WCM_01,
                    rContenido.getUserName(),
                    ExceptionManager.MSG_PORTAL_WCM_01 + " - Operacion: Consulta facturas, Consulta servicios inscritos",
                    "consultaTotalFacturas", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        } finally {
            trazaGetInvoicesRs(rq, rs, rb, errorCode, rContenido);
        }
        return totalFacturas;
    }

    /**
     * HU60.5.2 Traza del RQ para consulta de total de facturas.
     * 
     * @author melany.rozo
     */
    public void trazaGetInvoicesRq(ResourceBundle rb, String errorCode, RutaContenidoBean rContenido, String rquid) {
        try {
            AuditorRq auditorRq = new AuditorRq();
            auditorRq.setRequestId(rquid);
            auditorRq.setIpAddress(rContenido.getIpAdress());
            auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
            auditorRq.setAction(rb.getString("auditoria.consultaFacturas"));
            auditorRq.setOriginPortal(rContenido.getPortalOrigen());
            auditorRq.setPage(rContenido.getPaginaOrigen());
            auditorRq.setPortlet(rb.getString("auditoria.nombrePortlet"));
            auditorRq.setUser(rContenido.getUserName());
            auditorRq.setTipoServicio("RQ");
            auditorRq.setAdditionalInfo(JSONUtil.getJson(NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
            TrazaPublisher.getInstance().publish(auditorRq);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01,
                    rContenido.getUserName(),
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: trazaGetInvoicesRq, Consulta servicios inscritos",
                    "trazaGetInvoicesRq", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    /**
     * HU60.5.2 Traza del RS para consulta de total de facturas
     * 
     * @author melany.rozo
     * @since 20/05/2015
     */
    public void trazaGetInvoicesRs(GetInvoicesRq rq, GetInvoicesRs rs, ResourceBundle rb, String errorCode, RutaContenidoBean rContenido) {
        try {
            AuditorRq auditorRq = new AuditorRq();
            auditorRq.setRequestId(rq.getRequestID());
            auditorRq.setIpAddress(rq.getIpAddress());
            auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
            auditorRq.setAction(rb.getString("auditoria.consultaFacturas"));
            auditorRq.setOriginPortal(rq.getRequestOriginPortal());
            auditorRq.setPage(rq.getRequestPage());
            auditorRq.setPortlet(rq.getRequestSender());
            auditorRq.setUser(rq.getCustLoginId());
            auditorRq.setTipoServicio("RS");
            auditorRq.setErrorCode(errorCode);
            auditorRq.setCodigoServicioInt(rs.getCodigoServicio());
            auditorRq.setAdditionalInfo(
                    JSONUtil.getJson(NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(), NODO_WEBLOGIC + DOSPUNTOS + rs.getIpIntegracion()));
            TrazaPublisher.getInstance().publish(auditorRq);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rq.getRequestID(), ExceptionManager.PP_PORTAL_GENERIC_01,
                    rContenido.getUserName(),
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: trazaGetInvoicesRs, Consulta servicios inscritos",
                    "trazaGetInvoicesRs", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    /**
     * HU 21.1.2 Funcion encargada de buscar la imagen del convenio en el WCM.
     * 
     * @author santiago.cuervo
     * @param rContenido
     * @since 20/11/2015
     */
    private String searchConvImage(RutaContenidoBean rContenido, String idConvenio) {
        WCMCliente clienteImage = null;
        String rutaImg = "";
        try {
            String rutaContenido = rContenido.getPathImagenConv();
            String nombreBaseImgConvenio = rContenido.getNombreBaseImgConvenio();
            String nombreContenido = nombreBaseImgConvenio + idConvenio.toUpperCase();
            clienteImage = new WCMCliente(rutaContenido + nombreContenido);
            rutaImg = ((ImageComponent) clienteImage.getComponent("imgImagenConvenio")).getResourceURL();
            if (rutaImg != null) {
                rutaImg = rutaImg.replaceAll("/myconnect/", "/connect/");
            }
        } catch (WCMException e) {
            rutaImg = "";
        } catch (Exception e) {
            rutaImg = "";
        } finally {
            if (clienteImage != null)
                clienteImage.endWorkspace();
        }
        return rutaImg;
    }
    
    /**
     * Tokenizacion Metodo que permite setear los parametros a partir de cache
     * 
     * @return void
     */
    private void cargarParametrosCache() {
        List<GetParametroRs> parametros;
        try {
            parametros = CacheManager.getInstance().obtenerParametros();
            cargarEnmascaradoParametrizado(parametros);
            cargarTruncadoParametrizado(parametros);
        } catch (Exception e) {
            logger.error("ERROR al obtener los parametros de cache", e);
            enmascararIzquierda = 6;
            enmascararDerecha = 4;
            enmascararCaracter = '*';
            truncarIzquierda = 2;
            truncarDerecha = 4;
            truncarCaracter = '*';
        }

    }

    private void cargarEnmascaradoParametrizado(List<GetParametroRs> parametros) {
        try {
            for (GetParametroRs parametro : parametros) {
                if (parametro.getNombre().equals(enmascararIzquierdaParametro)) {
                    enmascararIzquierda = Integer.parseInt(parametro.getValor());
                } else if (parametro.getNombre().equals(enmascararDerechaParametro)) {
                    enmascararDerecha = Integer.parseInt(parametro.getValor());
                } else if (parametro.getNombre().equals(enmascararCaracterParametro)) {
                    enmascararCaracter = parametro.getValor().charAt(0);
                }
            }
        } catch (NumberFormatException e) {
            enmascararIzquierda = 6;
            enmascararDerecha = 4;
        } catch (Exception e) {
            logger.error("ERROR al obtener los parametros de cache", e);
            enmascararIzquierda = 6;
            enmascararDerecha = 4;
            enmascararCaracter = '*';
        }
    }

    private void cargarTruncadoParametrizado(List<GetParametroRs> parametros) {
        try {
            for (GetParametroRs parametro : parametros) {
                if (parametro.getNombre().equals(truncarIzquierdaParametro)) {
                    truncarIzquierda = Integer.parseInt(parametro.getValor());
                } else if (parametro.getNombre().equals(truncarDerechaParametro)) {
                    truncarDerecha = Integer.parseInt(parametro.getValor());
                } else if (parametro.getNombre().equals(truncarCaracterParametro)) {
                    truncarCaracter = parametro.getValor().charAt(0);
                }
            }
        } catch (NumberFormatException e) {
            truncarIzquierda = 2;
            truncarDerecha = 4;
        } catch (Exception e) {
            logger.error("ERROR al obtener los parametros de cache", e);
            truncarIzquierda = 2;
            truncarDerecha = 4;
            truncarCaracter = '*';
        }
    }

	/**
	 * HU 21.1.2 Funcion encargada de buscar la imagen de la respuesta transacción en el WCM.
	 * 
	 * @author johan.castro
	 * @param rContenido
	 * @since 20/06/2019
	 */
	private String searchTransactionImage(RutaContenidoBean rContenido, String rTransaction) {
		WCMCliente clienteImage = null;
		String rutaImg = "";
		try {
			String rutaContenido = rContenido.getPathContentComprobantePago();
			clienteImage = new WCMCliente(rutaContenido);
			if (rTransaction.equals("Aprobada")) {
				rutaImg = ((ImageComponent) clienteImage.getComponent("imgMensajeAprobado")).getResourceURL();
			}else if (rTransaction.equalsIgnoreCase("Pendiente")) {
				rutaImg = ((ImageComponent) clienteImage.getComponent("imgMensajePendiente")).getResourceURL();
			}else if (rTransaction.equalsIgnoreCase("Rechazada")||rTransaction.equalsIgnoreCase("Fallida")) {
				rutaImg = ((ImageComponent) clienteImage.getComponent("imgMensajeRechazo")).getResourceURL();
			} 
				
			if (rutaImg != null) {
                rutaImg = rutaImg.replaceAll("/myconnect/", "/connect/");
            }else {
            	rutaImg = "";
            }
			
		} catch (WCMException e) {
			rutaImg = "";
		} catch (Exception e) {
			rutaImg = "";
		} finally {
			if (clienteImage != null)
				clienteImage.endWorkspace();
		}
		return rutaImg;
	}
	
	

	private String ulrRedirectConvenioCPV(GetPaymentStatusRs rs, String idTransaccion, String estadoTransaccion, String valorCompra) {
		String urlRetorno = "";
		logger.info("---------------------------------------Ingreso a la Url de CPV V1-----------------------------------------------------");
		String idTransaccionConvExt = rs.getIdTransaccionConvExterno() == null ? "" : rs.getIdTransaccionConvExterno();
		String referenciaConvExt = rs.getReferences().get(0) == null ? "" : rs.getReferences().get(0).getReference();
		urlRetorno = rs.getUrlRespuesta().replace(PM_TRANSACCION_ID, idTransaccion)
				.replace(PM_TRANSACCION_CONVENIO_ID, idTransaccionConvExt)
				.replace(PM_APROBADO, estadoTransaccion)
				.replace(PM_REF_1, referenciaConvExt)
				.replace(PM_VALOR, valorCompra)
				.replace(PM_UUID, user);
		logger.info("Url de retorno para CPV :" + urlRetorno);
		return urlRetorno;
	} 
	
	private String urlRedirectConvenioCCXC(GetPaymentStatusRs getPaymentRs,GetPaymentStatusRq getPaymentRq, String bundle) {
		logger.info("Ingresa al metodo urlRedirectConvenioCCXC ");
		String tokenUser = null;
		String urlRetornoConvenio = "";
		tokenUser = setTokenSucces(getPaymentRs, getPaymentRq, bundle);
		urlRetornoConvenio = getPaymentRs.getUrlRespuesta().replace(TOKEN, tokenUser);
		logger.info("urlRetornoConvenio : " + urlRetornoConvenio);		
		return urlRetornoConvenio;
	}
	
	
	 /**
     * Se encriptan los datos de retorno
     * @param comprobanteWcm
     * @param comprobantePagoBean
     * @param bundle del properties
     * @return String url para retornar al convenio 
     */
	public String setTokenSucces(GetPaymentStatusRs getPaymentRs,GetPaymentStatusRq getPaymentRq, String bundle) {
		logger.info("ComprobantePago, inicia setToken");
		SearchPaymentHistoryRs res = null;
		SearchPaymentHistoryRq req = new SearchPaymentHistoryRq();
		ResourceBundle rb = ResourceBundle.getBundle(bundle);
		String secreto = rb.getString("transaccion.secretCnvCcxc");
		String url = "";
		String token = null;
		String tipoDeDocumento = "";
		String numeroDeIdent = "";
		String telefono = "";
		String correoElectronico = "";
		String urlRetornoConve = "";
		String razonSocial = "";
		try {
			for(ReferenceType ref: getPaymentRs.getReferences()) {
				if (ref.getLabel().equals("Tipo de documento")) {
					tipoDeDocumento = ref.getReference();
					}							
				if (ref.getLabel().equals("Número de identificación")) {
				numeroDeIdent = ref.getReference();										
				}
				if (ref.getLabel().equals("Telefono")) {
				telefono = ref.getReference();										
				}
				if (ref.getLabel().equals("Correo electrónico")) {
					correoElectronico = ref.getReference();										
				}
				if (ref.getLabel().equals("Razon social / nombre")) {
					razonSocial = ref.getReference();										
				}
			}
			JWTClaimsSet claims = new JWTClaimsSet.Builder()
					.claim("nit", getPaymentRs.getCustomerNit())
					.claim("razonSocial/Nombre", razonSocial)
					.claim("tipoDeDocumento", tipoDeDocumento)
					.claim("numeroDeIdentificacion", numeroDeIdent)
					.claim("telefono", telefono)
					.claim("correoElectronico", correoElectronico)
					.claim("codigoConceptoPago", getPaymentRs.getConceptoPago())
					.claim("status", getPaymentRs.getStatus().getStatusCode())
					.claim("pmtId", getPaymentRq.getPaymentId())
					.build();
			logger.info("Claims: " + claims.toJSONObject());
			JWSSigner signer = new MACSigner(secreto);
			SignedJWT signedJWT = new SignedJWT(new JWSHeader(JWSAlgorithm.HS256), claims);
			signedJWT.sign(signer);
			token = signedJWT.serialize();
			logger.info("Convenio encriptado Success");
		} catch (KeyLengthException e) {
			ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, "No se pudo generar clave", "",
					"ComprobantePago, setToken", "setToken", "", "", "", "");
			logger.error(errorData, e);
		} catch (Exception e) {
			ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, "Error generico ", "",
					"ComprobantePago, setToken", "setToken", "", "", "", "");
			logger.error(errorData, e);
		}
		urlRetornoConve = "?userdata=" + token;
		return urlRetornoConve;
		}

}