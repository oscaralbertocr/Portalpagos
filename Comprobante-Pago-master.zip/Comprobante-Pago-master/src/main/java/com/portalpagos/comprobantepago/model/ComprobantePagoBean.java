package com.portalpagos.comprobantepago.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import co.com.ath.payments.mc.service.model.json.CustomInvoiceField;
import co.com.ath.payments.mc.service.model.json.ReferenceType;

import com.ath.portalpagos.util.Modal;

public class ComprobantePagoBean implements Serializable {

	private static final long serialVersionUID = 1L;
	private String nombres_Apellidos;
	private String nombreConvenio;
	private String nit;
	private Date fechaTransaccion;
	private String fechaformateada;
	private String referenciaPago;
	private String estadoTransaccion;
	private String medioPago;
	private String idTransaccion;
	private String valorCompra;
	private String numAutorizacion;
	private String comentarios;
	private String email;
	private String agreementId;
	private Boolean isPermitePagoDolares;
	private String tipoMoneda;
	private String moneda;
	private String ciudad;
	private String tipoAporte;
	private String tipoConvenio;
	private String mostrarLighbox;
	private String tituloLighbox;
	private String cuerpoLighbox;
	private String widhtLightbox;
	private String heightLightbox;
	private String tipoModal;
	private String portalOrigen;
	private String portletOrigen;
	private String paginaOrigen;
	private String nombrePagador;
	private String intencionPago;
	private int totalFacturas;
	private String imagen;
	private String from;
	private String asunto;
	private boolean noFacturador;
	private boolean facturador;
	private boolean taquillas;
	private String imagenTransacionRespuesta;
	//HU 21.5.1 Agregar costo transaccion
	private String costoTransaccion;
	private double costoTransaccionPdf;
	//RQ33121 ¿Es convenio externo?
	private boolean isConvenioExterno;
	
	//HU 48.1 15/12/2016 VG SP1_2017
	private Date fechaHabil;
	private Boolean mostrarNextDay;
	
	/*HU 21.6 Conceptos de pago valor a pagar*/
	private String conceptoPago;
	
	/*HU 21.7 Multiples referencias*/
	private List<ReferenceType> listaReferencias;
	private List<ReferenceType> referenciasSinCifrar;

	private String ipAddress;
	
	//Atributo Tokenizacion
	private String referenciaEnmascarada;
	private List<ReferenceType> listaReferenciasCopy;
	private boolean validaBIN;
	
	// RQ29184 - Factura personalizada para facturadores
	private List<CustomInvoiceField> facturaPersonalizada;
	
	// RQ - Confirmar Pago Externo 
	private boolean pagoExterno;
	
	// Cambio Capilalize Av Villas
	private static final String [] AVVILLAS_CAPITALIZE= {"Av Villas", "Avvillas" , "av villas", "avvillas"};
	private static final String AVVILLAS_REPLACE= "AV Villas";
	
	 private String urlRetornoExterno;
	 
	 //RQ33121 - volver a CCXC
	 private String urlRetornoConvenioExterno;
	
	public boolean isValidaBIN() {
		return validaBIN;
	}

	public void setValidaBIN(boolean validaBIN) {
		this.validaBIN = validaBIN;
	}

	public double getCostoTransaccionPdf() {
		return costoTransaccionPdf;
	}

	public void setCostoTransaccionPdf(double costoTransaccionPdf) {
		this.costoTransaccionPdf = costoTransaccionPdf;
	}

	public boolean getTaquillas() {
		return taquillas;
	}

	public void setTaquillas(boolean taquillas) {
		this.taquillas = taquillas;
	}

	// Url de retorno para taquillas
	private String urlRetorno;

	public String getUrlRetorno() {
		return urlRetorno;
	}

	public void setUrlRetorno(String urlRetorno) {
		this.urlRetorno = urlRetorno;
	}

	public String getTipoMoneda() {
		return tipoMoneda;
	}

	public void setTipoMoneda(String tipoMoneda) {
		this.tipoMoneda = tipoMoneda;
	}

	public Boolean getIsPermitePagoDolares() {
		return isPermitePagoDolares;
	}

	public void setIsPermitePagoDolares(Boolean isPermitePagoDolares) {
		this.isPermitePagoDolares = isPermitePagoDolares;
	}

	public String getAgreementId() {
		return agreementId;
	}

	public void setAgreementId(String agreementId) {
		this.agreementId = agreementId;
	}

	public String getPortalOrigen() {
		return portalOrigen;
	}

	public void setPortalOrigen(String portalOrigen) {
		this.portalOrigen = portalOrigen;
	}

	public String getPortletOrigen() {
		return portletOrigen;
	}

	public void setPortletOrigen(String portletOrigen) {
		this.portletOrigen = portletOrigen;
	}

	public String getPaginaOrigen() {
		return paginaOrigen;
	}

	public void setPaginaOrigen(String paginaOrigen) {
		this.paginaOrigen = paginaOrigen;
	}

	public String getMostrarLighbox() {
		return mostrarLighbox;
	}

	public void setMostrarLighbox(String mostrarLighbox) {
		this.mostrarLighbox = mostrarLighbox;
	}

	public String getTituloLighbox() {
		return tituloLighbox;
	}

	public void setTituloLighbox(String tituloLighbox) {
		this.tituloLighbox = tituloLighbox;
	}

	public String getCuerpoLighbox() {
		return cuerpoLighbox;
	}

	public void setCuerpoLighbox(String cuerpoLighbox) {
		this.cuerpoLighbox = cuerpoLighbox;
	}

	public String getWidhtLightbox() {
		return widhtLightbox;
	}

	public void setWidhtLightbox(String widhtLightbox) {
		this.widhtLightbox = widhtLightbox;
	}

	public String getHeightLightbox() {
		return heightLightbox;
	}

	public void setHeightLightbox(String heightLightbox) {
		this.heightLightbox = heightLightbox;
	}

	public String getTipoModal() {
		return tipoModal;
	}

	public void setTipoModal(String tipoModal) {
		this.tipoModal = tipoModal;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getAsunto() {
		return asunto;
	}

	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}

	/**
	 * @return the fechaformateada
	 */
	public String getFechaformateada() {

		return fechaformateada;
	}

	/**
	 * @param fechaformateada
	 *            the fechaformateada to set
	 */
	public void setFechaformateada(String fechaformateada) {
		this.fechaformateada = fechaformateada;
	}

	public String getNombres_Apellidos() {
		return nombres_Apellidos;
	}

	public void setNombres_Apellidos(String nombres_Apellidos) {
		this.nombres_Apellidos = nombres_Apellidos;
	}

	public String getNombreConvenio() {
		return nombreConvenio.replaceAll(AVVILLAS_CAPITALIZE[0], AVVILLAS_REPLACE)
			      .replaceAll(AVVILLAS_CAPITALIZE[1], AVVILLAS_REPLACE)
			      .replaceAll(AVVILLAS_CAPITALIZE[2], AVVILLAS_REPLACE)
			      .replaceAll(AVVILLAS_CAPITALIZE[3], AVVILLAS_REPLACE);
	}

	public void setNombreConvenio(String nombreConvenio) {
		this.nombreConvenio = nombreConvenio;
	}

	public String getNit() {
		return nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public Date getFechaTransaccion() {
		return fechaTransaccion;
	}

	public void setFechaTransaccion(Date date) {
		this.fechaTransaccion = date;
	}

	public String getReferenciaPago() {
		return referenciaPago;
	}

	public void setReferenciaPago(String referenciaPago) {
		this.referenciaPago = referenciaPago;
	}

	public String getEstadoTransaccion() {
		return estadoTransaccion;
	}

	public void setEstadoTransaccion(String estadoTransaccion) {
		this.estadoTransaccion = estadoTransaccion;
	}

	public String getMedioPago() {
		return medioPago;
	}

	public void setMedioPago(String medioPago) {
		this.medioPago = medioPago;
	}

	public String getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(String idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public String getValorCompra() {
		return valorCompra;
	}

	public void setValorCompra(String valorCompra) {
		this.valorCompra = valorCompra;
	}

	public String getNumAutorizacion() {
		return numAutorizacion;
	}

	public void setNumAutorizacion(String numAutorizacion) {
		this.numAutorizacion = numAutorizacion;
	}

	public String getComentarios() {
		return comentarios;
	}

	public void setComentarios(String comentarios) {
		this.comentarios = comentarios;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMoneda() {
		return moneda;
	}

	public void setMoneda(String moneda) {
		this.moneda = moneda;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public String getTipoAporte() {
		return tipoAporte;
	}

	public void setTipoAporte(String tipoAporte) {
		this.tipoAporte = tipoAporte;
	}

	public String getTipoConvenio() {
		return tipoConvenio;
	}

	public void setTipoConvenio(String tipoConvenio) {
		this.tipoConvenio = tipoConvenio;
	}

	/**
	 * HU41 Funcion encargada de setear los valores para mostrar el modal con el mensaje recibido.
	 * 
	 * @author melany.rozo
	 * @since 16/07/2015
	 */
	public void mostrarModal(String mensaje, String tipo, String titulo) {
		this.cuerpoLighbox = mensaje;
		this.tipoModal = tipo;
		this.tituloLighbox = titulo;
		this.mostrarLighbox = "true";
		try {
			String[] categoriaArray = Modal.calcularDimensionModal(mensaje);
			this.widhtLightbox = categoriaArray[0];
			this.heightLightbox = categoriaArray[1];
		} catch (NoClassDefFoundError e) {
			this.widhtLightbox = "375";
			this.heightLightbox = "134";
		}
	}

	public String getIntencionPago() {
		return intencionPago;
	}

	public void setIntencionPago(String intencionPago) {
		this.intencionPago = intencionPago;
	}

	public String getNombrePagador() {
		return nombrePagador;
	}

	public void setNombrePagador(String nombrePagador) {
		this.nombrePagador = nombrePagador;
	}

	public int getTotalFacturas() {
		return totalFacturas;
	}

	public void setTotalFacturas(int totalFacturas) {
		this.totalFacturas = totalFacturas;
	}

	public String getImagen() {
		return imagen;
	}

	public void setImagen(String imagen) {
		this.imagen = imagen;
	}

	public boolean isNoFacturador() {
		return noFacturador;
	}

	public void setNoFacturador(boolean noFacturador) {
		this.noFacturador = noFacturador;
	}

	public boolean isFacturador() {
		return facturador;
	}

	public void setFacturador(boolean facturador) {
		this.facturador = facturador;
	}

	public String getCostoTransaccion() {
		return costoTransaccion;
	}

	public void setCostoTransaccion(String costoTransaccion) {
		this.costoTransaccion = costoTransaccion;
	}
	//HU 48.1 15/12/2016 VG SP1_2017

	public Date getFechaHabil() {
		return fechaHabil;
	}

	public void setFechaHabil(Date fechaHabil) {
		this.fechaHabil = fechaHabil;
	}

	public Boolean getMostrarNextDay() {
		return mostrarNextDay;
	}

	public void setMostrarNextDay(Boolean mostrarNextDay) {
		this.mostrarNextDay = mostrarNextDay;
	}

	public String getConceptoPago() {
		return conceptoPago;
	}

	public void setConceptoPago(String conceptoPago) {
		this.conceptoPago = conceptoPago;
	}

	public List<ReferenceType> getListaReferencias() {
		return listaReferencias;
	}

	public void setListaReferencias(List<ReferenceType> listaReferencias) {
		this.listaReferencias = listaReferencias;
	}

	public List<ReferenceType> getReferenciasSinCifrar() {
		return referenciasSinCifrar;
	}

	public void setReferenciasSinCifrar(List<ReferenceType> referenciasSinCifrar) {
		this.referenciasSinCifrar = referenciasSinCifrar;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getReferenciaEnmascarada() {
		return referenciaEnmascarada;
	}

	public void setReferenciaEnmascarada(String referenciaEnmascarada) {
		this.referenciaEnmascarada = referenciaEnmascarada;
	}

	public List<ReferenceType> getListaReferenciasCopy() {
		return listaReferenciasCopy;
	}

	public void setListaReferenciasCopy(List<ReferenceType> listaReferenciasCopy) {
		this.listaReferenciasCopy = listaReferenciasCopy;
	}
	
	public List<CustomInvoiceField> getFacturaPersonalizada() {
		return facturaPersonalizada;
	}
	
	public void setFacturaPersonalizada(List<CustomInvoiceField> customInvoice) {
		this.facturaPersonalizada = customInvoice;
	}

	public String getImagenTransacionRespuesta() {
		return imagenTransacionRespuesta;
	}

	public void setImagenTransacionRespuesta(String imagenTransacionRespuesta) {
		this.imagenTransacionRespuesta = imagenTransacionRespuesta;
	}
	
	public boolean isPagoExterno() {
		return pagoExterno;
	}

	public void setPagoExterno(boolean pagoExterno) {
		this.pagoExterno = pagoExterno;
	}

	public String getUrlRetornoExterno() {
		return urlRetornoExterno;
	}

	public void setUrlRetornoExterno(String urlRetornoExterno) {
		this.urlRetornoExterno = urlRetornoExterno;
	}

	public String getUrlRetornoConvenioExterno() {
		return urlRetornoConvenioExterno;
	}

	public void setUrlRetornoConvenioExterno(String urlRetornoConvenioExterno) {
		this.urlRetornoConvenioExterno = urlRetornoConvenioExterno;
	}

	public boolean isConvenioExterno() {
		return isConvenioExterno;
	}

	public void setConvenioExterno(boolean isConvenioExterno) {
		this.isConvenioExterno = isConvenioExterno;
	}
	
}