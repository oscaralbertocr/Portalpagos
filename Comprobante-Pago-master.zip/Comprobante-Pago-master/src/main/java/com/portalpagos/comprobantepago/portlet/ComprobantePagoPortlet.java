package com.portalpagos.comprobantepago.portlet;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import javax.naming.NamingException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Event;
import javax.portlet.EventRequest;
import javax.portlet.EventResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.PortletSession;
import javax.portlet.ProcessAction;
import javax.portlet.ProcessEvent;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.exception.ExceptionUtils;

import com.ath.portalpagos.util.ExceptionManager;
import com.ath.portalpagos.util.IpNodoPortal;
import com.ath.portalpagos.util.JSONUtil;
import com.co.pragma.portal.utils.WCMCliente;
import com.google.gson.Gson;
import com.ibm.portal.portlet.service.PortletServiceUnavailableException;
import com.ibm.portal.um.User;
import com.ibm.portal.um.exceptions.PumaException;
import com.ibm.workplace.wcm.api.LinkComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.exceptions.WCMException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.KeyLengthException;
import com.nimbusds.jose.crypto.MACSigner;
import com.nimbusds.jwt.JWTClaimsSet;
import com.nimbusds.jwt.SignedJWT;
import com.portalpagos.comprobantepago.helper.ComprobantePagoController;
import com.portalpagos.comprobantepago.model.ComprobantePagoBean;
import com.portalpagos.comprobantepago.model.ComprobantePagoWcmBean;
import com.portalpagos.comprobantepago.model.RutaContenidoBean;
import com.portalpagos.comprobantepago.util.ErrorManager;
import com.portalpagos.comprobantepago.util.Puma;

import co.com.ath.clientes.payments.mc.service.util.ConfigurationService;
import co.com.ath.logger.CustomLogger;
import co.com.ath.mc.utilities.util.CloneUtil;
import co.com.ath.parameterspage.ParametersPage;
import co.com.ath.payments.mc.auditor.publisher.traza.TrazaPublisher;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.auditor.publisher.util.WebServiceClientHTTPS;
import co.com.ath.payments.mc.cache.manager.CacheManager;
import co.com.ath.payments.mc.service.model.AuditorRq;
import co.com.ath.payments.mc.service.model.ErrorData;
import co.com.ath.payments.mc.service.model.json.BankInfoType;
import co.com.ath.payments.mc.service.model.json.GeneratePdfFileRq;
import co.com.ath.payments.mc.service.model.json.GeneratePdfFileRs;
import co.com.ath.payments.mc.service.model.json.GetConvenioInfoRq;
import co.com.ath.payments.mc.service.model.json.ReferenceType;
import co.com.ath.payments.mc.service.model.json.SearchPaymentHistoryRq;
import co.com.ath.payments.mc.service.model.json.SearchPaymentHistoryRs;
import co.com.ath.payments.mc.service.util.CommonUtils;

/**
 * 
 * Portlet de Comprobante de Pago.
 * 
 * @author carlos.cardona
 * 
 */
public class ComprobantePagoPortlet extends GenericPortlet {

    private CustomLogger logger = new CustomLogger(ComprobantePagoPortlet.class);
    private String user;
    private String ip;
    private String rquid;
    private static String operacion = "Comprobante de Pago";
    private static final String RQ = "RQ";
    private static final String DOSPUNTOS = ":";
    private static final String NODO = "Nodo Portal";
    private static final String USD = "USD";
    private static final String COP = "COP";
    private static final String RS = "RS";
    private static final String NODO_INTEGRACION = "Nodo WebLogic";
    private static final String REFERENCIAS_ADICIONALES = "Referencias Adicionales";
    private static final String VIEW_COMPROBANTE_PAGO = "/jsp/ComprobantePagoView.jsp";
    // Tokenización posicion de referencia Principal TC
    private static final int POSICION_REF_TC = 0;
    private String idPago = "";

    /**
     * HU24
     * 
     * @exception En
     *                el finally Se eliminan los datos en los guardados en Session de los Bean
     */
    @Override
    public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
        RutaContenidoBean rContenido = null;
        try {
            logger.info("::ingreso::");
            String ipaa = InetAddress.getLocalHost().getHostAddress();
            logger.info("::IPAA::" + ipaa);
            ip = this.getIpAddr(com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(request), request);
            logger.info("::1 IP ADRESS::" + ip);

            rquid = PublisherUtil.getInstance().generateRequestID();
            this.consultarUsuario(request, rContenido);
            rContenido = rutaContenido(request, response);
            request.removeAttribute("isRedirect");
            capturarId(request, rContenido);
            obtenerContenidoWCM(request);
            getPortletContext().getRequestDispatcher(VIEW_COMPROBANTE_PAGO).include(request, response);

        } catch (NoClassDefFoundError e) {
            Exception e1 = (Exception) ExceptionUtils.getRootCause(e);
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e1, rquid, ExceptionManager.PP_PORTAL_LIBRERIAS_01, user,
                    ExceptionManager.MSG_PORTAL_LIBRERIAS_01 + " - Operacion: Cargar vista, " + operacion, "doView",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e1);
            String error[] = ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                    ExceptionManager.PP_PORTAL_LIBRERIAS_01, request);
            this.mostrarModalError(request, error);
        } catch (Exception e) {
            try {
                throw ExceptionUtils.getRootCause(e);
            } catch (Exception e1) {
                ErrorData errorData = PublisherUtil.getInstance().getErrorData(e1, rquid, ExceptionManager.PP_PORTAL_FACES_01, user,
                        ExceptionManager.MSG_PORTAL_FACES_01 + " - Operacion: Cargar vista, " + operacion, "doView",
                        rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
                logger.error(errorData, e1);
                String error[] = ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                        ExceptionManager.PP_PORTAL_FACES_01, request);
                this.mostrarModalError(request, error);
            } catch (Throwable e1) {
                ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                        ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: Cargar vista, " + operacion, "doView",
                        rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
                logger.error(errorData, e);
                String error[] = ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                        ExceptionManager.PP_PORTAL_GENERIC_01, request);
                this.mostrarModalError(request, error);
            }
        }
    }

    /**
     * @modified: andres.hernandez - daniel.mejia - john.ramirez - andrea.florez Se creo la variable "varIdPago" para guardar el valor del
     *            processEvent
     */
    @ProcessEvent(name = "responseEventVerComprobante")
    public void processEvent(EventRequest request, EventResponse response) throws PortletException {
        String portlet = "", pagina = "", portal = "";
        try {
            Event event = request.getEvent();
            String responseEventData = event.getValue().toString();
            response.setRenderParameter("idPago", responseEventData);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion:  processEvent, Quo puedo pagar convenios", "processEvent",
                    portlet, pagina, portal);
            logger.error(errorData, e);
        }
    }

    /**
     * Funcion encargada de setear datos al bean para mostrar modal de error.
     * 
     * @author melany.rozo
     */
    private void mostrarModalError(PortletRequest request, String error[]) {
        PortletSession session = request.getPortletSession();
        try {
            ComprobantePagoBean bean = (ComprobantePagoBean) session.getAttribute("comprobantePagoBean", PortletSession.APPLICATION_SCOPE);
            if (null == bean) {
                bean = new ComprobantePagoBean();
            }
            bean.mostrarModal(error[0], "icon-error", error[1]);
            session.setAttribute("comprobantePagoBean", bean, PortletSession.APPLICATION_SCOPE);
        } catch (Exception e) {
            RutaContenidoBean rContenido = (RutaContenidoBean) session.getAttribute("RutaContenidoBean", PortletSession.APPLICATION_SCOPE);
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: Mostrar modal error, " + operacion, "mostrarModalError",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    /**
     * HU24 capturaid. Recupera el id de la transaccion enviado de la pasarela de pagos por method GET
     * 
     * @author Germon Doaz
     * @param request
     * @throws NamingException
     * @exception Controla
     *                los errores ocacionados cuando no se puede capturar el id de la transaccion
     * 
     * @modified: andres.hernandez - daniel.mejia - john.ramirez - andrea.florez Se creo la variable "varIdPago" para guardar el valor del
     *            processEvent
     */
    private void capturarId(RenderRequest request, RutaContenidoBean rContenido) {
    	logger.info("entra a capturar Id");
    	logger.info("idPago Previo a limpieza:" + idPago + ", rquid:" + rquid);
    	String idPago = "";
        PortletSession session = request.getPortletSession();
        request.setAttribute("isRedirect", "false");
        Boolean isUrl = false;
        try {
            idPago = request.getParameter("idPago");
        	logger.info("idPago Posterior a limpieza:" + idPago + ", rquid:" + rquid);
            String pagoTaquillas = (String) request.getAttribute("pagoDesdeTaquillas");
            if ((null == idPago || idPago.equals(""))) {
                // Captura del id de la Transaccion enviada por method GET
                if (null != pagoTaquillas && !"".equals(pagoTaquillas)) {
                    idPago = com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(request).getParameter("?pmtId");
                } else {
                    idPago = com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(request).getParameter("pmtId");
                }
                session.setAttribute("urlComprobantePago",
                        com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(request).getRequestURL(),
                        PortletSession.APPLICATION_SCOPE);

                if (null != idPago && !("").equals(idPago)) {
                    isUrl = true;
                    session.setAttribute("pmtId", idPago, PortletSession.APPLICATION_SCOPE);
                }
            }
            if ((null == idPago || idPago.equals(""))) {
                try {
                    idPago = session.getAttribute("pmtId", PortletSession.APPLICATION_SCOPE).toString();
                } catch (Exception e) {
                    idPago = "";
                    ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                            ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: Capturar PmtId en la Url" + operacion, "capturarId",
                            rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
                    logger.error(errorData, e);
                    String error[] = ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                            ExceptionManager.PP_PORTAL_GENERIC_01, request);
                    this.mostrarModalError(request, error);
                }
            }
            // Alertas logger
            logger.info("idPago:" + idPago + ", rquid:" + rquid);
            ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.comprobantepago.portlet.nl.ComprobantePagoPortletResource");
            String accion = rb.getString("auditoria.consultarEstadoPago");
            auditorGetPaymentStatusRq(rContenido, accion, rquid, idPago);
            ComprobantePagoController comprobante = new ComprobantePagoController();
            ComprobantePagoBean comprobanteBean = null;
            if (idPago != null && !idPago.isEmpty()) {
                comprobanteBean = (ComprobantePagoBean) comprobante.cargarDatos(idPago, request, rquid, isUrl, user);
            } else {
                comprobanteBean = (ComprobantePagoBean) session.getAttribute("comprobantePagoBean", PortletSession.APPLICATION_SCOPE);
                if (null == comprobanteBean) {
                    comprobanteBean = new ComprobantePagoBean();
                }
            }
            // Alertas Fin condicion
            // Envio del Id de la transaccion para extraer la informacion del middleware
            
            session.setAttribute("comprobantePagoBean", comprobanteBean, PortletSession.APPLICATION_SCOPE);
            session.setAttribute("isUrl", isUrl.toString(), PortletSession.APPLICATION_SCOPE);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: Capturar PmtId, " + operacion, "capturarId",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
            String error[] = ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                    ExceptionManager.PP_PORTAL_GENERIC_01, request);
            this.mostrarModalError(request, error);
        }
    }

    /**
     * HU24
     * 
     * @Metodo obtenerContenidoWCM Obtiene la informacion del contenido del WCM para mostrarlos en la vista
     * @author Germon Doaz
     * @since 08/11/2014
     * @param request
     */
    private void obtenerContenidoWCM(RenderRequest request) {
		GetConvenioInfoRq requestConvenioInfo = new GetConvenioInfoRq();
		
        PortletSession session = request.getPortletSession();
        RutaContenidoBean rContenido = (RutaContenidoBean) request.getAttribute("RutaContenidoBean");
        WCMCliente cliente = null;
        Gson gson = new Gson();
        ComprobantePagoController comprobante = new ComprobantePagoController();
        try {
            ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.comprobantepago.portlet.nl.ComprobantePagoPortletResource");
            ComprobantePagoBean comprobanteBean = (ComprobantePagoBean) session.getAttribute("comprobantePagoBean",
                    PortletSession.APPLICATION_SCOPE);
            String tipoConvenio = "";
            if (null != comprobanteBean) {
                tipoConvenio = comprobanteBean.getTipoConvenio();
            }
            String rutaContenido = rContenido.getPathContentComprobantePago();
            cliente = new WCMCliente(rutaContenido);
            String conteNombre = rb.getString("stNombreApellido");
            String conteNombreConvenio = rb.getString("stNombreConvenio");
            String conteFechaTransa = rb.getString("stFechaHoraTransaccion");
            String conteRefPago = rb.getString("stReferenciaPago");
            String conteEstTransac = rb.getString("stEstadoTransaccion");
            String conteMedioPago = rb.getString("stMedioPago");
            String conteIdTransac = rb.getString("stIDTransaccion");
            String conteValorCompra = rb.getString("stValorCompra");
            String conteNoAutoriz = rb.getString("stNoAutorizacion");
            String conteComentarios = rb.getString("stComentarios");
            String conteMsjContacEntidad = rb.getString("txtMensajeContactoEntidad");
            String conteMsjPendPago = rb.getString("txtMensajePendientePago");
            String conteRefPagoAdicional = rb.getString("stReferenciaPagoAdicional");
            String nombrePagador_Wcm = rb.getString("stNombrePagador");
            String intencionPago = rb.getString("stIntencionPago");
            String urlHome = ((ShortTextComponent) cliente.getComponent("stUrlHome")).getText();
            String conteMsjRegistroPago = rb.getString("txtMensajeRegistroPago");
            
            if (null != user) {
                conteMsjRegistroPago = rb.getString("txtMensajeRegistroPago");
            } else {
                conteMsjRegistroPago = rb.getString("txtMensajeRegistroPagoNoSesion");
            }
            requestConvenioInfo.setAgreementId(conteNombreConvenio);
    		requestConvenioInfo.setRequiereActivo(true);
            CacheManager.getInstance().getConvenioInfo(requestConvenioInfo);

            String tipoMoneda = "";
            LinkComponent linkRegistro = (LinkComponent) cliente.getComponent("lnkUrlRegistro");
            String enlaceRegistro_Wcm = linkRegistro.getURL();
            String txtRegistro_Wcm = linkRegistro.getLinkText();
            String conteMsjInvitacionRegistro = rb.getString("txtMensajeInvitacionRegistro");

            LinkComponent linkInscribirServicio = (LinkComponent) cliente.getComponent("lnkInscribirServicio");
            String enlaceBtnInscribirServicio_Wcm = linkInscribirServicio.getURL();
            String txtBtnInscribirServicio_Wcm = linkInscribirServicio.getLinkText();
            String conteMsjInscrivirServicio = rb.getString("txtMensajeInscribirServicios");

            LinkComponent lnkRealizarNuevoPago = (LinkComponent) cliente.getComponent("lnkRealizarNuevoPago");
            String enlaceRealizarNuevoPago = lnkRealizarNuevoPago.getURL();
            String txtRealizarNuevoPago = lnkRealizarNuevoPago.getLinkText();
            String tituloPasoComprMov = rb.getString("stNombrePasoCompMovil");
            ComprobantePagoWcmBean contWcm = new ComprobantePagoWcmBean();
            // De acuerdo al tipo de convenio, cambiar labels
            if ("5".equals(tipoConvenio) || "6".equals(tipoConvenio)) {
                // es impuesto
                conteNombreConvenio = rb.getString("stNombreImpuesto");
                conteRefPago = rb.getString("stReferenciaRecaudo");
                conteValorCompra = rb.getString("stValorPagado");

                String conteCiudad = rb.getString("stCiudadImpuesto");
                String conteAporte = rb.getString("stTipoAporte");
                contWcm.setCiudadImpuesto_Wcm(conteCiudad);
                contWcm.setTipoAporte_Wcm(conteAporte);
            } else if ("4".equals(tipoConvenio) || "7".equals(tipoConvenio)) {
                // es obligacion financiera
                conteNombreConvenio = rb.getString("stNombreObligacion");
                conteRefPago = rb.getString("stNumeroObligacion");
                conteValorCompra = rb.getString("stValorPago");
                if (null != comprobanteBean.getIsPermitePagoDolares() && comprobanteBean.getIsPermitePagoDolares()) {
                    if (null != comprobanteBean.getTipoMoneda() && !"".equals(comprobanteBean.getTipoMoneda())) {
                        if (comprobanteBean.getTipoMoneda().equals(USD)) {
                            tipoMoneda = rb.getString("stLabelDolar");
                        } else if (comprobanteBean.getTipoMoneda().equals(COP)) {
                            tipoMoneda = rb.getString("stLabelPesos");
                        }
                    }
                }
                String conteMoneda = rb.getString("stMoneda");
                contWcm.setMoneda_wcm(conteMoneda);
            }
            String contenidoFinalizar = rb.getString("stFinalizar");
            // HU 21.5.1 Agregar costo transaccion
            String lblCostoTransaccion = rb.getString("lblCostoTrans");
            // HU 48.1 VG 15/12/2016 VG NExtDay
            String lbNextDay = rb.getString("stNextDay");
            String lbIpOrigen = rb.getString("stLabelIpOrigen");

            contWcm.setNombres_Apellidos_Wcm(conteNombre);
            contWcm.setNombreConvenio_Wcm(conteNombreConvenio);
            contWcm.setFechaTransaccion_Wcm(conteFechaTransa);
            contWcm.setReferenciaPago_Wcm(conteRefPago);
            contWcm.setEstadoTransaccion_Wcm(conteEstTransac);
            contWcm.setMedioPago_Wcm(conteMedioPago);
            contWcm.setIdTransaccion_Wcm(conteIdTransac);
            contWcm.setValorCompra_Wcm(conteValorCompra);
            contWcm.setNumAutorizacion_Wcm(conteNoAutoriz);
            contWcm.setComentarios_Wcm(conteComentarios);
            contWcm.setMsjContactoEntidad_Wcm(conteMsjContacEntidad);
            contWcm.setMsjPendientePago_Wcm(conteMsjPendPago);
            contWcm.setRealizarNuevoPago(txtRealizarNuevoPago);
            contWcm.setLnkRealizarNuevoPago(enlaceRealizarNuevoPago);
            contWcm.setReferenciaPagoAdicional_Wcm(conteRefPagoAdicional);
            contWcm.setNombrePagador_Wcm(nombrePagador_Wcm);
            contWcm.setIntencionPago_Wcm(intencionPago);
            contWcm.setIsRedireccion((String) request.getAttribute("isRedirect"));
            request.removeAttribute("isRedirect");
            contWcm.setUrlHome(urlHome);
            contWcm.setTipoMoneda(tipoMoneda);
            contWcm.setEnlaceRegistro_Wcm(enlaceRegistro_Wcm);
            contWcm.setTxtRegistro_Wcm(txtRegistro_Wcm);
            contWcm.setMsjInvitacionRegistro_Wcm(conteMsjInvitacionRegistro);
            contWcm.setMsjRegistroPago_Wcm(conteMsjRegistroPago);
            contWcm.setTxtInscribierServicio_Wcm(conteMsjInscrivirServicio);
            contWcm.setTxtBotonInscribirServicio_Wcm(txtBtnInscribirServicio_Wcm);
            contWcm.setLnkBotonInscribirServicio_Wcm(enlaceBtnInscribirServicio_Wcm);
            contWcm.setStNombrePasoCompMovil(tituloPasoComprMov);
            contWcm.setStFinalizar(contenidoFinalizar);
            contWcm.setLblCostoTransaccion(lblCostoTransaccion);
            // HU 48.1 15/12/2016 VG NextDay
            contWcm.setLbNextDay(lbNextDay);
            contWcm.setLbIpOrigen(lbIpOrigen);
            logger.info("ComprobantePagoWCMBean: " + toString());
            logger.info("Informacion comprobante JSON : "  +gson.toJson(comprobanteBean) );
            logger.info("Nombre comprobante de pago :" +comprobanteBean.getNombreConvenio());
			
//             comprobanteBean.setConvenioExterno((Boolean)session.getAttribute("isConvenioExterno",
//                     PortletSession.APPLICATION_SCOPE));
             session.setAttribute("comprobantePagoBean", comprobanteBean, PortletSession.APPLICATION_SCOPE);
            
            session.setAttribute("comprobantePagoWcmBean", contWcm, PortletSession.APPLICATION_SCOPE);
        } catch (WCMException e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_WCM_01, user,
                    ExceptionManager.MSG_PORTAL_WCM_01 + " - Operacion: cargarDatos Wcm, " + operacion, "obtenerContenidoWCM",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
            String error[] = ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                    ExceptionManager.PP_PORTAL_WCM_01, request);
            this.mostrarModalError(request, error);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " Operacion: cargarDatos Wcm, " + operacion, "obtenerContenidoWCM",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
            String error[] = ErrorManager.getInstance(request, rquid, user).obtenerErrorWCM(rContenido.getPathErroresTecnicos(),
                    ExceptionManager.PP_PORTAL_GENERIC_01, request);
            this.mostrarModalError(request, error);
        } finally {
            if (null != cliente) {
                cliente.endWorkspace();
            }
        }
    }

    /**
     * HU112.1 Metodo para consultar la ruta de contenido del parametro de pagina.
     * 
     * @author santiago.cuervo
     */
    private RutaContenidoBean rutaContenido(RenderRequest request, RenderResponse response) {
        PortletPreferences prefs = request.getPreferences();
        RutaContenidoBean rContenido = null;
        try {
            String pathContentComprobantePago = (String) ParametersPage.getParameterPage(request, response, "pathContent-comprobantePago");
            if (null == pathContentComprobantePago) {
                pathContentComprobantePago = prefs.getValue("pathContent-comprobantePago", "");
            }
            String pathContentContComprobanteMailPagosAval = (String) ParametersPage.getParameterPage(request, response,
                    "pathContent-contComprobanteMailPagosAval");
            if (null == pathContentContComprobanteMailPagosAval) {
                pathContentContComprobanteMailPagosAval = prefs.getValue("pathContent-contComprobanteMailPagosAval", "");
            }
            String urlHome = (String) ParametersPage.getParameterPage(request, response, "urlHome");
            if (null == urlHome) {
                urlHome = prefs.getValue("urlHome", "");
            }
            String portalOrigen = (String) ParametersPage.getParameterPage(request, response, "bankName");
            if (null == portalOrigen) {
                portalOrigen = prefs.getValue("bankName", "");
            }
            String paginaOrigen = (String) ParametersPage.getParameterPage(request, response, "pagina-origen");
            if (null == paginaOrigen) {
                paginaOrigen = prefs.getValue("pagina-origen", "");
            }
            ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.comprobantepago.portlet.nl.ComprobantePagoPortletResource");
            String portletOrigen = rb.getString("auditoria.nombrePortlet");
            String idBanco = (String) ParametersPage.getParameterPage(request, response, "bankId");
            if (null == idBanco) {
                idBanco = prefs.getValue("bankId", "");
            }

            String pagoDesdeTaquillas = (String) ParametersPage.getParameterPage(request, response, "taquillas");
            user = (String) request.getPortletSession().getAttribute("user");
            if (null == user) {
                Puma puma = new Puma();
                User currentUser = puma.getCurrenUser(request);
                if (null != currentUser) {
                    user = puma.getPropertyFromPuma("uid", request);
                    request.getPortletSession().setAttribute("user", user, PortletSession.APPLICATION_SCOPE);
                } else {
                    user = null;
                    request.getPortletSession().removeAttribute("user", PortletSession.APPLICATION_SCOPE);
                }
            }

            String pathImagenConv = (String) ParametersPage.getParameterPage(request, response, "path-imagenConv");
            if (null == pathImagenConv) {
                pathImagenConv = prefs.getValue("path-imagenConv", "");
            }

            String nombreBaseImgConvenio = (String) ParametersPage.getParameterPage(request, response, "nombreBaseImgConvenio");
            if (null == nombreBaseImgConvenio) {
                nombreBaseImgConvenio = prefs.getValue("nombreBaseImgConvenio", "");
            }

            String pathErroresTecnicos = (String) ParametersPage.getParameterPage(request, response, "pathErroresTecnicos");
            if (null == pathErroresTecnicos) {
                pathErroresTecnicos = prefs.getValue("pathErroresTecnicos", "");
            }

            rContenido = new RutaContenidoBean();
            rContenido.setPathContentComprobantePago(pathContentComprobantePago);
            rContenido.setPathContentContComprobanteMailPagosAval(pathContentContComprobanteMailPagosAval);
            rContenido.setUrlHome(urlHome);
            rContenido.setPortalOrigen(portalOrigen);
            rContenido.setPortletOrigen(portletOrigen);
            rContenido.setPaginaOrigen(paginaOrigen);
            rContenido.setBankId(idBanco);
            logger.info("IP variable global: " + ip);
            rContenido.setIpAdress(ip);
            rContenido.setUserName(user);
            rContenido.setPathImagenConv(pathImagenConv);
            rContenido.setNombreBaseImgConvenio(nombreBaseImgConvenio);
            rContenido.setPathErroresTecnicos(pathErroresTecnicos);

            String dn = (String) ParametersPage.getParameterPage(request, response, "dn");
            rContenido.setDn(dn);

            request.setAttribute("RutaContenidoBean", rContenido);
            request.setAttribute("pagoDesdeTaquillas", pagoDesdeTaquillas);
            request.getPortletSession().setAttribute("RutaContenidoBean", rContenido, PortletSession.APPLICATION_SCOPE);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: Obtener rutas contenido, " + operacion, "rutaContenido",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
        return rContenido;
    }

    /***
     * Funcion encargada de consultar el usuario autenticado en el portal.
     * 
     * @author: melany.rozo
     */
    private void consultarUsuario(PortletRequest request, RutaContenidoBean rContenido) {
        try {
            Puma puma = new Puma();
            User currentUser = puma.getCurrenUser(request);
            String nombreUsuario = null;
            if (currentUser != null) {
                nombreUsuario = puma.getPropertyFromPuma("uid", request);
            }
            user = nombreUsuario;
        } catch (PortletServiceUnavailableException e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_PUMA_01, user,
                    ExceptionManager.MSG_PORTAL_PUMA_01 + " - Operacion: Consultar Usuario, " + operacion, "consultarUsuario",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        } catch (NamingException e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_PUMA_01, user,
                    ExceptionManager.MSG_PORTAL_PUMA_01 + " - Operacion: Consultar Usuario, " + operacion, "consultarUsuario",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        } catch (PumaException e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_PUMA_01, user,
                    ExceptionManager.MSG_PORTAL_PUMA_01 + " - Operacion: Consultar Usuario, " + operacion, "consultarUsuario",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion:  Consultar Usuario, " + operacion, "consultarUsuario",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    /**
     * HU 143 Funcion encargada de Trazar la Rq de auditorRqPayCentralBillRq.
     * 
     * @author germandiaz
     * @param idRequest
     */
    private void auditorGetPaymentStatusRq(RutaContenidoBean request, String accion, String idRequest, String pmtId) {
        try {
            AuditorRq auditorRq = new AuditorRq();
            auditorRq.setAction(accion);
            auditorRq.setAdditionalInfo(JSONUtil.getJson(NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
            auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
            auditorRq.setIpAddress(request.getIpAdress());
            auditorRq.setOriginPortal(request.getPortalOrigen());
            auditorRq.setPage(request.getPaginaOrigen());
            auditorRq.setPortlet(request.getPortletOrigen());
            auditorRq.setRequestId(idRequest);
            auditorRq.setTipoServicio(RQ);
            auditorRq.setPaymentId(pmtId);
            auditorRq.setUser(request.getUserName());
            TrazaPublisher.getInstance().publish(auditorRq);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion:  auditorGetPaymentStatusRq, " + operacion,
                    "auditorGetPaymentStatusRq", request.getPortletOrigen(), request.getPaginaOrigen(), request.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    @ProcessAction(name = "registrarPago")
    public void registrarPago(ActionRequest request, ActionResponse response) throws PortletException, IOException {
        PortletSession session = request.getPortletSession();
        String rquid = PublisherUtil.getInstance().generateRequestID();
        RutaContenidoBean rContenido = null;
        ComprobantePagoBean datosBeanComprobante = null;
        Gson gson = new Gson();
        try {
            rContenido = (RutaContenidoBean) session.getAttribute("RutaContenidoBean", PortletSession.APPLICATION_SCOPE);
            datosBeanComprobante = (ComprobantePagoBean) session.getAttribute("comprobantePagoBean", PortletSession.APPLICATION_SCOPE);
            String tipoConvenio = request.getParameter("tipoConvenio");
            consultarUsuario(request, rContenido);

            if ("2".equals(tipoConvenio) || ("1".equals(tipoConvenio) && null == user)) {
                String enventParams = "p=" + datosBeanComprobante.getAgreementId();
                enventParams += "°p=" + gson.toJson(datosBeanComprobante.getReferenciasSinCifrar());
                enventParams += "°p=" + datosBeanComprobante.getIdTransaccion();
                enventParams += "°p=" + tipoConvenio;

                response.setEvent("requestEventRegistrarPago", enventParams);
            } else if ("1".equals(tipoConvenio)) {
                response.setEvent("requestEventInscribirServicio", datosBeanComprobante.getAgreementId() + "/" + "comprobante" + "/" + rquid
                        + "/" + "false" + "/" + datosBeanComprobante.getReferenciasSinCifrar().get(0).getReference());
            }
        } catch (Exception ex) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(ex, rquid, ExceptionManager.PP_PORTAL_GENERIC_01,
                    rContenido.getUserName(), ExceptionManager.MSG_PORTAL_GENERIC_01 + " Operacion: processAction, ResultadoHistoricoPagos",
                    "VerComprobanteListener");
            logger.error(errorData, ex);
        }
    }

    @ProcessAction(name = "generarPDF")
    public void generarPDF(ActionRequest request, ActionResponse response) throws PortletException, IOException {
        PortletSession session = request.getPortletSession();
        RutaContenidoBean rContenido = (RutaContenidoBean) session.getAttribute("RutaContenidoBean", PortletSession.APPLICATION_SCOPE);
        String baseURL = request.getContextPath();
        try {
            rquid = PublisherUtil.getInstance().generateRequestID();
            Boolean isUrl = Boolean.parseBoolean((String) session.getAttribute("isUrl", PortletSession.APPLICATION_SCOPE));
            session.setAttribute("isUrl", isUrl.toString(), PortletSession.APPLICATION_SCOPE);
            ComprobantePagoBean comprobantePagoBean = (ComprobantePagoBean) session.getAttribute("comprobantePagoBean",
                    PortletSession.APPLICATION_SCOPE);
            ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.comprobantepago.portlet.nl.ComprobantePagoPortletResource");
            String accion = rb.getString("auditoria.descargarPdf");
            auditorGeneratePdfRq(rContenido, accion, rquid, comprobantePagoBean);
            session.setAttribute("rquid", rquid, PortletSession.APPLICATION_SCOPE);
            user = rContenido.getUserName();
            String url = baseURL + "/PDFServlet";
            response.sendRedirect(url);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: ProcessAction Descargar PDF, " + operacion, "processAction",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    @Override
    public void serveResource(ResourceRequest request, ResourceResponse response) throws PortletException, IOException {
        PortletSession session = request.getPortletSession();
        RutaContenidoBean rContenido = (RutaContenidoBean) session.getAttribute("RutaContenidoBean", PortletSession.APPLICATION_SCOPE);
        ComprobantePagoBean comprobantePagoBean = (ComprobantePagoBean) session.getAttribute("comprobantePagoBean",
                PortletSession.APPLICATION_SCOPE);
        ComprobantePagoWcmBean comprobantePagoWcmBean = (ComprobantePagoWcmBean) session.getAttribute("comprobantePagoWcmBean",
                PortletSession.APPLICATION_SCOPE);

        String errorCode = "";
        String txtNombrePDF = "";
        GeneratePdfFileRq rq = null;
        GeneratePdfFileRs responsePDF = null;
        // Tokenizacion
        GeneratePdfFileRq rqCloneLog = null;

        ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.comprobantepago.portlet.nl.ComprobantePagoPortletResource");
        String accion = rb.getString("auditoria.descargarPdf");
        try {
            rquid = PublisherUtil.getInstance().generateRequestID();
            Boolean isUrl = Boolean.parseBoolean((String) session.getAttribute("isUrl", PortletSession.APPLICATION_SCOPE));
            session.setAttribute("isUrl", isUrl.toString(), PortletSession.APPLICATION_SCOPE);

            auditorGeneratePdfRq(rContenido, accion, rquid, comprobantePagoBean);
            session.setAttribute("rquid", rquid, PortletSession.APPLICATION_SCOPE);
            user = rContenido.getUserName();
            rq = new GeneratePdfFileRq();
            rq = getpdfRequest(comprobantePagoBean, rquid, rContenido, comprobantePagoWcmBean);

            // Tokenizacion se realiza clone del RQ
            rqCloneLog = (GeneratePdfFileRq) CloneUtil.clone(rq);

            // Alertas condicion null
            if (comprobantePagoBean.getIdTransaccion() != null && comprobantePagoBean.getIdTransaccion() != "") {

                // INI Tokenizacion, se enmascara la referencia

                if (comprobantePagoBean.isValidaBIN()) {
                    // Se realiza copy del log y se inserta
                    List<ReferenceType> referencias = rqCloneLog.getReferences();
                    ReferenceType referenciaTc = referencias.get(POSICION_REF_TC);
                    referenciaTc.setReference(comprobantePagoBean.getReferenciaEnmascarada());
                    referencias.set(POSICION_REF_TC, referenciaTc);
                    rqCloneLog.setReferences(referencias);
                }
                logger.info("[REQUEST - generatePdfFile] DATA: " + new Gson().toJson(rqCloneLog));

                // Fin
                String endPointRESTServiceExecutePayment = ConfigurationService.getInstance().getEndpointRest();

                responsePDF = (GeneratePdfFileRs) WebServiceClientHTTPS.getInstance(GeneratePdfFileRs.class)
                        .procesarRequest(endPointRESTServiceExecutePayment + "generatePdfFile", rq);
                logger.info("[RESPONSE - generatePdfFile] DATA: " + new Gson().toJson(responsePDF));

            } else {
                errorCode = ExceptionManager.PP_PORTAL_GENERIC_01;
                logger.info("generatePdfFile idTransaccion vacio. rquid:" + rquid);
            }

            if (responsePDF != null) {
                if (!("SUCCESS".equals(responsePDF.getStatus().getStatusCode())) || responsePDF.getExcepcion() != null) {
                    if (null != responsePDF.getExcepcion()) {
                        errorCode = responsePDF.getExcepcion().getCodigo();
                    }
                    logger.info("generatePdfFile Response CODE: " + responsePDF.getExcepcion().getCodigo() + ", DESC: "
                            + responsePDF.getExcepcion().getMensaje());
                }
            } else {
                errorCode = ExceptionManager.PP_PORTAL_GENERIC_01;
                logger.info("generatePdfFile null, error al generar PDF. rquid:" + rquid);
            }

            // Fin alertas condicion null
            txtNombrePDF = comprobantePagoBean.getIdTransaccion();
            response.addProperty("Content-disposition", "attachment;filename=" + txtNombrePDF + ".pdf");
            response.setContentType("application/pdf");
            // Alertas condicion por si responde null

            if (responsePDF != null && responsePDF.getData() != null) {
                response.setContentLength(responsePDF.getData().length);
                OutputStream out = response.getPortletOutputStream();
                out.write(responsePDF.getData());
                out.flush();
                out.close();
            }
        } catch (Exception e) {
            errorCode = ExceptionManager.PP_PORTAL_GENERIC_01;
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: ProcessAction Descargar PDF, " + operacion, "processAction",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        } finally {
            // Tokenizacion rqCloneLog
            auditorRsGeneratePdf(responsePDF, rqCloneLog, accion, rquid, errorCode, rContenido);
        }
        super.serveResource(request, response);
    }

    /**
     * HU 143 Funcion encargada de Trazar la Rq de auditorRqPayCentralBillRq
     * 
     * @author germandiaz
     * @param idRequest
     */
    private void auditorGeneratePdfRq(RutaContenidoBean request, String accion, String idRequest, ComprobantePagoBean comprobantePagoBean) {
        try {
            AuditorRq auditorRq = new AuditorRq();
            auditorRq.setAction(accion);
            String referenAdi = "";
            if (null != comprobantePagoBean.getListaReferencias() && !comprobantePagoBean.getListaReferencias().isEmpty()
                    && comprobantePagoBean.getListaReferencias().size() > 0) {
                // Tokenizacion INI se setea para info adicional
                List<ReferenceType> referencias = comprobantePagoBean.getListaReferencias();
                if (comprobantePagoBean.isValidaBIN()) {
                    ReferenceType referenciaTc = referencias.get(POSICION_REF_TC);
                    referenciaTc.setReference(comprobantePagoBean.getReferenciaEnmascarada());
                    referencias.set(POSICION_REF_TC, referenciaTc);
                }
                // Tokenizacion Fin

                int posReference = 1;
                for (ReferenceType referenceType : referencias) {
                    referenAdi += "REF_" + posReference + ": " + referenceType.getReference();
                    posReference++;
                }
            }
            // Alertas Ini
            if (referenAdi != "") {
                auditorRq.setAdditionalInfo(JSONUtil.getJson(NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(), referenAdi));
            } else {
                auditorRq.setAdditionalInfo(JSONUtil.getJson(NODO + DOSPUNTOS + IpNodoPortal.getIpNodo()));
            }
            // Alertas Fin
            auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
            auditorRq.setIpAddress(request.getIpAdress());
            auditorRq.setOriginPortal(request.getPortalOrigen());
            auditorRq.setPage(request.getPaginaOrigen());
            auditorRq.setPortlet(request.getPortletOrigen());
            auditorRq.setRequestId(idRequest);
            auditorRq.setTipoServicio(RQ);
            auditorRq.setUser(request.getUserName());
            auditorRq.setPaymentId(comprobantePagoBean.getIdTransaccion());
            // INI Tokenizacion
            if (comprobantePagoBean.isValidaBIN()) {
                auditorRq.setReference(comprobantePagoBean.getReferenciaEnmascarada());
            } else {
                auditorRq.setReference(comprobantePagoBean.getReferenciaPago());
            }
            // FIN

            TrazaPublisher.getInstance().publish(auditorRq);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: auditorGeneratePdfRq, " + operacion, "auditorGeneratePdfRq",
                    request.getPortletOrigen(), request.getPaginaOrigen(), request.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    /**
     * Generar el objeto Request necesario para enviar al middleware y generar el PDF del comprobante de pago
     * 
     * @param comprobantePagoBean
     * @return
     */
    private GeneratePdfFileRq getpdfRequest(ComprobantePagoBean comprobantePagoBean, String idRequest, RutaContenidoBean rContenido,
            ComprobantePagoWcmBean comprobantePagoWcmBean) {
        try {
            BankInfoType infoBanco = new BankInfoType();
            infoBanco.setBankId(rContenido.getBankId());
            infoBanco.setBankName(rContenido.getPortalOrigen());
            GeneratePdfFileRq rq = new GeneratePdfFileRq();
            rq.setAgreementName(comprobantePagoBean.getNombreConvenio());
            rq.setAmmount(comprobantePagoBean.getValorCompra());
            rq.setAuthorizationNumber(comprobantePagoBean.getNumAutorizacion());
            rq.setComments(comprobantePagoBean.getComentarios());
            rq.setCustName(comprobantePagoBean.getNombres_Apellidos());
            rq.setCurCode("");
            // Tokenización referencia en claro
            // rq.setReferences(comprobantePagoBean.getListaReferencias());
            rq.setReferences(comprobantePagoBean.getListaReferenciasCopy());
            rq.setPaymentWay(comprobantePagoBean.getMedioPago());
            rq.setTransactionDate(comprobantePagoBean.getFechaTransaccion());
            rq.setTransactionId(comprobantePagoBean.getIdTransaccion());
            rq.setTransactionStatus(comprobantePagoBean.getEstadoTransaccion());
            rq.setRequestOriginPortal(comprobantePagoBean.getPortalOrigen());
            rq.setRequestPage(comprobantePagoBean.getPaginaOrigen());
            rq.setRequestSender(comprobantePagoBean.getPortletOrigen());
            rq.setRequestDate(new Date());
            String modalidad = comprobantePagoBean.getTipoConvenio();
            rq.setModalidadConvenio(modalidad);
            rq.setBankInfo(infoBanco);
            rq.setIpAddress(rContenido.getIpAdress());
            rq.setRequestUser(rContenido.getUserName());
            rq.setRequestID(idRequest);
            rq.setNombrePagador(comprobantePagoBean.getNombrePagador());
            rq.setIntencionPago(comprobantePagoBean.getIntencionPago());
            rq.setLogo(comprobantePagoBean.getImagen());
            rq.setAgreementId(comprobantePagoBean.getAgreementId());
            rq.setCamposFacturaPersonalizada(comprobantePagoBean.getFacturaPersonalizada());
            
            // Alertas
            if (comprobantePagoBean.getIsPermitePagoDolares() != null) {
                rq.setPermitePagoDolares(comprobantePagoBean.getIsPermitePagoDolares());
            }
            rq.setTipoMoneda(comprobantePagoBean.getTipoMoneda());
            rq.setTaquilla(comprobantePagoBean.getTaquillas());

            /* HU 21.5 Agregar costo de la transaccion */
            rq.setCostoTransaccion(comprobantePagoBean.getCostoTransaccionPdf());
            /* HU 48.1 NEXT DAY */
            // Alertas null
            if (comprobantePagoBean.getMostrarNextDay() != null && comprobantePagoBean.getMostrarNextDay()) {
                rq.setFechaHorarioHabil(comprobantePagoBean.getFechaHabil());
            }

            /* HU 21.6 Conceptos de pago */
            rq.setConceptoPago(comprobantePagoBean.getConceptoPago());

            // HU136
            if (modalidad != null && ("5".equals(modalidad) || "6".equals(modalidad))) {
                // Si es un impuesto se envia ciudad
                rq.setCiudad(comprobantePagoBean.getCiudad());
                String tipoAporte = comprobantePagoBean.getTipoAporte();
                if (null != tipoAporte && !"".equals(tipoAporte)) {
                    // Si es con aporte se envia tipo de aporte
                    rq.setTipoAporte(tipoAporte);
                }
            }

            // INI Tokenizacion se envia para saber si el comprobante debe truncar la ref Principal
            if (comprobantePagoBean.isValidaBIN()) {
                rq.setTruncarReferencia(true);
            }
            // FIN Tokenizacion
            return rq;
        } catch (Exception ex) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(ex, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: Generar GeneratePdfFileRq, " + operacion, "getpdfRequest",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, ex);
        }
        return null;
    }

    /**
     * HU 143 Funcion encargada de Trazar del RS de auditorRqPayCentralBillRs.
     * 
     * @author germandiaz
     * @param PayCentrallBillResponse
     *            , PayCentralBillRequest, accion, idRequest
     * @since 13/08/2015
     */
    private void auditorRsGeneratePdf(GeneratePdfFileRs response, GeneratePdfFileRq request, String accion, String idRequest,
            String errorCode, RutaContenidoBean rContenido) {
        try {
            // Alertas INI
            String valaccion, validRequest, valerrorCode, valIPAddress = "", valBankName = "", valPage = "", valPortlet = "",
                    valReference = "", valUser = "", valTransactionId = "", valIpIntegracion = "";
            valaccion = accion != null ? accion : "";
            validRequest = idRequest != null ? idRequest : "";
            valerrorCode = errorCode != null ? errorCode : "";

            if (request != null) {
                valIPAddress = request.getIpAddress() != null ? request.getIpAddress() : "";
                valBankName = request.getBankInfo().getBankName() != null ? request.getBankInfo().getBankName() : "";
                valPage = request.getRequestPage() != null ? request.getRequestPage() : "";
                valPortlet = request.getRequestSender() != null ? request.getRequestSender() : "";
                if (request.getReferences() != null && request.getReferences().size() >= 1) {
                    valReference = request.getReferences().get(0).getReference();
                }

                valUser = request.getRequestUser() != null ? request.getRequestUser() : "";
                valTransactionId = request.getTransactionId() != null ? request.getTransactionId() : "";

            }
            if (response != null && response.getIpIntegracion() != null) {
                valIpIntegracion = response.getIpIntegracion();
            }

            // Alertas Fin
            AuditorRq auditorRq = new AuditorRq();
            auditorRq.setAction(valaccion);
            String refenciasAdi = "";
            // Alertas If
            if (request != null && request.getReferences() != null) {
                for (int i = 0; i < request.getReferences().size(); i++) {
                    if (!request.getReferences().get(i).equals("")) {
                        refenciasAdi += "REF_" + i + " " + request.getReferences().get(i) + " - ";
                    }
                }
            }
            // Alertas Fin if
            if (!refenciasAdi.equals("")) {
                refenciasAdi = refenciasAdi.substring(0, refenciasAdi.length() - 3);
            }
            // Aletas Ini
            if (valIpIntegracion == "" && refenciasAdi != "") {
                auditorRq.setAdditionalInfo(
                        JSONUtil.getJson(NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(), REFERENCIAS_ADICIONALES + DOSPUNTOS + refenciasAdi));
            } else if (valIpIntegracion != "" && refenciasAdi == "") {
                auditorRq.setAdditionalInfo(
                        JSONUtil.getJson(NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(), NODO_INTEGRACION + DOSPUNTOS + valIpIntegracion));
            } else if (valIpIntegracion != "" && refenciasAdi != "") {
                auditorRq.setAdditionalInfo(JSONUtil.getJson(NODO + DOSPUNTOS + IpNodoPortal.getIpNodo(),
                        NODO_INTEGRACION + DOSPUNTOS + valIpIntegracion, REFERENCIAS_ADICIONALES + DOSPUNTOS + refenciasAdi));
            }
            // Alertas Fin
            auditorRq.setErrorCode(valerrorCode);
            auditorRq.setExecutionDate(CommonUtils.getInstance().asXMLGregorianCalendar(new Date()));
            auditorRq.setIpAddress(valIPAddress);
            auditorRq.setOriginPortal(valBankName);
            auditorRq.setPage(valPage);
            auditorRq.setPortlet(valPortlet);
            auditorRq.setReference(valReference);
            auditorRq.setRequestId(validRequest);
            auditorRq.setTipoServicio(RS);
            auditorRq.setUser(valUser);
            auditorRq.setPaymentId(valTransactionId);
            TrazaPublisher.getInstance().publish(auditorRq);
        } catch (Exception e) {
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: auditorRsGeneratePdf, " + operacion, "auditorRsGeneratePdf",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
    }

    /**
     * Funcion encargada de obtener la ip del usuario, dado un request
     */
    private String getIpAddr(HttpServletRequest request, PortletRequest portletRequest) {
        String ip = null;
        try {
            final String WL_PROXY_CLIENT_IP = "WL-Proxy-Client-IP";
            final String PROXY_CLIENT_IP = "Proxy-Client-IP";
            final String X_FORWARDER_FOR = "X-Forwarded-For";
            final String HTTP_X_FORWARDED_FOR = "HTTP_X_FORWARDED_FOR";
            final String HTTP_CLIENT_IP = "HTTP_CLIENT_IP";

            ip = request.getHeader(X_FORWARDER_FOR);
            logger.info("IP capturada de X-Forwarded-For: " + ip);

            if (null == ip || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader(WL_PROXY_CLIENT_IP);
                logger.info("IP capturada de WL-Proxy-Client-IP: " + ip);
            }
            if (null == ip || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader(PROXY_CLIENT_IP);
                logger.info("IP capturada de Proxy-Client-IP: " + ip);
            }
            if (null == ip || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader(HTTP_X_FORWARDED_FOR);
                logger.info("IP capturada de HTTP_X_FORWARDED_FOR: " + ip);
            }
            if (null == ip || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader(HTTP_CLIENT_IP);
                logger.info("IP capturada de HTTP_CLIENT_IP: " + ip);
            }
            if (null == ip || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getRemoteAddr();
                logger.info("IP capturada con el método getRemoteAddr: " + ip);
            }
        } catch (Exception e) {
            RutaContenidoBean rContenido = (RutaContenidoBean) portletRequest.getPortletSession().getAttribute("RutaContenidoBean",
                    PortletSession.APPLICATION_SCOPE);
            ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
                    ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operación: getIpAddr, Pago Obligaciones Financieras", "getIpAddr",
                    rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
            logger.error(errorData, e);
        }
        return ip;
    }

}