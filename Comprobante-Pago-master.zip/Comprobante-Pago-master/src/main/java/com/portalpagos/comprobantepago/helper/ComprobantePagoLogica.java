package com.portalpagos.comprobantepago.helper;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.portlet.PortletRequest;
import javax.portlet.RenderRequest;

import co.com.ath.logger.CustomLogger;
import co.com.ath.payments.mc.auditor.publisher.util.PublisherUtil;
import co.com.ath.payments.mc.service.model.ErrorData;

import com.ath.portalpagos.util.ExceptionManager;
import com.portalpagos.comprobantepago.model.RutaContenidoBean;
import com.portalpagos.comprobantepago.portlet.ComprobantePagoPortlet;

public class ComprobantePagoLogica {

	private static CustomLogger logger = new CustomLogger(ComprobantePagoPortlet.class);
	private static String operacion = "Comprobante de Pago";

	/**
	 * HU24 Inicializa el Gestor de log con los datos enviados desde el Portlet
	 * 
	 * @author German Diaz
	 * 
	 */
	public ComprobantePagoLogica() {
		super();
	}

	/**
	 * HU24
	 * 
	 * @Metodo formatearFecha: Realiza la conversian de la fecha al formato yyyy-MM-dd HH:mm:ss
	 * @author German Daaz
	 * @since 07/11/2014
	 * @param fechaorigen
	 * @return fechaForateada
	 * @exception controla
	 *                los errores al formatear la fecha
	 * @limitaciones El tipo de fecha debe ser Date
	 */
	public String formatearFecha(Date fechaorigen, RenderRequest request, String rquid, String user) {
		String fechaFormateada = "";
		try {
			ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.comprobantepago.properties.ComprobantePago");
			String formatFecha = rb.getString("transaccion.formatoFecha");
			SimpleDateFormat fechaformato = new SimpleDateFormat(formatFecha);
			fechaFormateada = fechaformato.format(fechaorigen);
		} catch (Exception e) {
			FacesContext context = FacesContext.getCurrentInstance();
			ExternalContext externalContext = context.getExternalContext();
			PortletRequest requestContenido = (PortletRequest) externalContext.getRequest();
			RutaContenidoBean rContenido = (RutaContenidoBean) requestContenido.getPortletSession().getAttribute("RutaContenidoBean");
			ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
					ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: Formatear fecha, " + operacion, "formatearFecha",
					rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
			logger.error(errorData, e);
		}
		return fechaFormateada;
	}

	/**
	 * HU24
	 * 
	 * @Metodo formatearMoneda: Realiza la conversian del valor al formato del valor #.###.###
	 * @author German Daaz
	 * @since 07/11/2014
	 * @param valor
	 * @return valorFormateado
	 * @exception controla
	 *                los errores al formatear la moneda
	 * @limitaciones El tipo de moneda debe ser double
	 */
	public String formatearMoneda(double valor, RenderRequest request, String rquid, String user) {

		String valorFormateado = "";
		try {
			// Captura los valores almacenados en el properties
			ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.comprobantepago.properties.ComprobantePago");
			String formatValor = rb.getString("transaccion.formatValor");
			String caracterSeparador = rb.getString("transaccion.separadorCaracter");
			String caracterReplace = rb.getString("transaccion.separadorReplace");
			DecimalFormat formatoMoneda = new DecimalFormat(formatValor);
			// Realiza la conversian del valor para que cumpla con el formato #.###.###
			String valorFormato = formatoMoneda.format(valor);
			// cambia los separadores del valor
			valorFormateado = valorFormato.replace(caracterSeparador, caracterReplace);

		} catch (Exception e) {
			FacesContext context = FacesContext.getCurrentInstance();
			ExternalContext externalContext = context.getExternalContext();
			PortletRequest requestContenido = (PortletRequest) externalContext.getRequest();
			RutaContenidoBean rContenido = (RutaContenidoBean) requestContenido.getPortletSession().getAttribute("RutaContenidoBean");
			ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
					ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: Formatear moneda, " + operacion, "formatearMoneda",
					rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
			logger.error(errorData, e);
		}
		return valorFormateado;
	}

	/**
	 * HU24
	 * 
	 * @Metodo ocultarTcredito: Oculta los nameros de la tarjeta de cradito despuas del 4 caracter cuando el pago es realizado por tarjeta
	 *         de cradito. Cuando el medio pago es PSE o Banco Aval concatena al Medio el Banco por el cual se pago
	 * @author German Daaz
	 * @since 07/11/2014
	 * @param medioPago
	 *            , bancoMedioPago, franquicia, numtarjeta, estadoTransaccion
	 * @return medioPagoFormateado: Retorna el namero de tarjeta oculto o el medio de pago y banco concatenados
	 */
	public String ocultarTcredito(String medioPago, String bancoMedioPago, String franquicia, String numtarjeta, RenderRequest request,
			String rquid, String user) {
		String medioPagoFormateado = "";
		String medioPagoFormat = medioPago;
		// Captura los valores almacenados en el properties
		ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.comprobantepago.properties.ComprobantePago");
		String medioPago1 = rb.getString("transaccion.medioPago");
		String medioPago2 = rb.getString("transaccion.medioPago2");
		String medioPago3 = rb.getString("transaccion.medioPago3");
		String medioPago4 = rb.getString("transaccion.medioPago4");
		String cantOcultNum = rb.getString("transaccion.cantidadNumEnmascararTarjeta");
		String caracterOcultaTarjeta = rb.getString("transaccion.caracterOcultaTarjeta");
		try {
			/*
			 * Si el medio de pago es PSE o Banco Aval concatena el Banco en que se realiza el pago
			 */
			if (null != medioPagoFormat && medioPagoFormat.toLowerCase().equalsIgnoreCase(medioPago1)
					|| medioPagoFormat.toLowerCase().equalsIgnoreCase(medioPago2)
					|| medioPagoFormat.toLowerCase().equalsIgnoreCase(medioPago4)) {
				if (!bancoMedioPago.equals("")) {
					medioPagoFormateado = medioPago + " - " + bancoMedioPago;
				} else {
					medioPagoFormateado = medioPago;
				}

				/*
				 * Si el medio de pago es por tarjeta de cradito oculta los caracteres, dejando los altimos 4 nameros visibles
				 */
			} else if (null != medioPagoFormat && medioPagoFormat.toLowerCase().equalsIgnoreCase(medioPago3)) {
				int canNum;
				int finEnmascarado;

				if (numtarjeta != null && !numtarjeta.isEmpty()) {
					canNum = numtarjeta.length();
					finEnmascarado = canNum - Integer.parseInt(cantOcultNum);
				} else {
					canNum = 0;
					finEnmascarado = 0;
				}
				// Calcula la cantidad de nameros que debe ocultar de izquierda a derecha
				// Captura los altimos 4 nameros que deben estar visibles
				Object numMostrar = numtarjeta.substring(finEnmascarado, canNum);
				// Reemplaza los namero por el caracter a ocultar

				medioPagoFormateado = medioPago + " (" + franquicia + " " + caracterOcultaTarjeta + numMostrar.toString() + ")";
			} else if (medioPagoFormat.equals("") && !bancoMedioPago.equals("")) {
				medioPagoFormateado = bancoMedioPago;
			}

		} catch (Exception e) {
			FacesContext context = FacesContext.getCurrentInstance();
			ExternalContext externalContext = context.getExternalContext();
			PortletRequest requestContenido = (PortletRequest) externalContext.getRequest();
			RutaContenidoBean rContenido = (RutaContenidoBean) requestContenido.getPortletSession().getAttribute("RutaContenidoBean");
			ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
					ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: Enmascarar TC, " + operacion, "ocultarTcredito",
					rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
			logger.error(errorData, e);
		}
		return medioPagoFormateado;

	}

	/**
	 * HU24
	 * 
	 * @Metodo ocultarNumAutorizacion: Settea un valor vacao cuando el estado transaccian se encuentra en Pendiente
	 * @author German Daaz
	 * @since 27/11/2014
	 * @param estadoTransaccion
	 * @return numAutorizacion
	 */
	public String ocultarNumAutorizacion(String estadoTransaccion, RenderRequest request, String rquid, String user) {
		String numAutorizacion = null;
		try {
			String estTransac = estadoTransaccion;
			ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.comprobantepago.properties.ComprobantePago");
			String estadoPendiente = rb.getString("transaccion.estadoPendiente");
			// Si estado transaccian es pendiente a numero autorizacian se asigna un valor vacao
			if (estTransac.toLowerCase() == estadoPendiente) {
				numAutorizacion = "";
			} else {
				numAutorizacion = estadoTransaccion;
			}
		} catch (Exception e) {
			FacesContext context = FacesContext.getCurrentInstance();
			ExternalContext externalContext = context.getExternalContext();
			PortletRequest requestContenido = (PortletRequest) externalContext.getRequest();
			RutaContenidoBean rContenido = (RutaContenidoBean) requestContenido.getPortletSession().getAttribute("RutaContenidoBean");
			ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
					ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: Ocultar numAutorizacion, " + operacion,
					"ocultarNumAutorizacion", rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
			logger.error(errorData, e);
		}
		return numAutorizacion;
	}

	/**
	 * HU 149 Funcion encargada de cifrar referencia de pago cuando es tarjeta de crédito
	 * 
	 * @author melany.rozo
	 * @since 13/08/2015
	 * */
	public String cifrarReferenciaPago(String referencia, String rquid, String user) {
		try {
			if (referencia.length() > 4) {
				ResourceBundle rb = ResourceBundle.getBundle("com.portalpagos.comprobantepago.properties.ComprobantePago");
				String caracterOcultaTarjeta = rb.getString("transaccion.caracterOcultaTarjeta");
				int canNum;
				int finEnmascarado;
				if (referencia != null && !referencia.isEmpty()) {
					canNum = referencia.length();
					finEnmascarado = canNum - 4;
				} else {
					canNum = 0;
					finEnmascarado = 0;
				}
				// Calcula la cantidad de numeros que debe ocultar de izquierda a derecha
				// Captura los ultimos 4 numeros que deben estar visibles
				Object numMostrar = referencia.substring(finEnmascarado, canNum);
				referencia = caracterOcultaTarjeta + numMostrar.toString();
			}
		} catch (Exception e) {
			FacesContext context = FacesContext.getCurrentInstance();
			ExternalContext externalContext = context.getExternalContext();
			PortletRequest requestContenido = (PortletRequest) externalContext.getRequest();
			RutaContenidoBean rContenido = (RutaContenidoBean) requestContenido.getPortletSession().getAttribute("RutaContenidoBean");
			ErrorData errorData = PublisherUtil.getInstance().getErrorData(e, rquid, ExceptionManager.PP_PORTAL_GENERIC_01, user,
					ExceptionManager.MSG_PORTAL_GENERIC_01 + " - Operacion: Enmascarar referencia, " + operacion, "cifrarReferenciaPago",
					rContenido.getPortletOrigen(), rContenido.getPaginaOrigen(), rContenido.getPortalOrigen());
			logger.error(errorData, e);
		}
		return referencia;
	}
}